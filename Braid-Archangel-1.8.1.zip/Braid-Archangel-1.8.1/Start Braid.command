#!/bin/sh
# Archangel 1.7.0a6. Retains the validated Mac Launcher Fix 1 discovery logic.
set -eu
HERE=$(CDPATH= cd -P "$(dirname "$0")" && pwd)
cd "$HERE"

# Probe without user-site/PYTHONPATH contamination. Do not install anything,
# change the global Python selection, or create a Braid profile during discovery.
PROBE='import platform, sys, sysconfig
label = "%s %s at %s" % (platform.python_implementation(), platform.python_version(), sys.executable)
if platform.python_implementation() != "CPython" or not (3, 10) <= sys.version_info[:2] < (3, 14):
    print(label + " (requires standard CPython 3.10-3.13)")
    sys.exit(2)
if sysconfig.get_config_var("Py_GIL_DISABLED"):
    print(label + " (free-threaded builds are not supported in a5)")
    sys.exit(2)
try:
    import venv, ensurepip, ssl, sqlite3
except ImportError as exc:
    print(label + " (missing runtime component: " + str(exc) + ")")
    sys.exit(2)
print(label)
'

try_python() {
    candidate=$1
    shift
    [ -f "$candidate" ] && [ -x "$candidate" ] || return 1
    if runtime_info=$("$candidate" -I -c "$PROBE" 2>&1); then
        printf 'Archangel selected %s\n' "$runtime_info"
        if [ "$#" -eq 1 ] && [ "$1" = '--runtime-info' ]; then
            exit 0
        fi
        # Only discovery falls back. An application error must never trigger a
        # second startup under a different interpreter.
        exec "$candidate" "$HERE/start_braid.py" "$@"
    else
        printf 'Skipping %s: %s\n' "$candidate" "$runtime_info" >&2
        return 1
    fi
}

if [ ! -f "$HERE/start_braid.py" ]; then
    printf '%s\n' 'Keep Start Braid.command beside the bundled start_braid.py.' >&2
    exit 1
fi

# An explicit choice fails closed rather than silently choosing another runtime.
if [ -n "${BRAID_PYTHON:-}" ]; then
    explicit=$(command -v "$BRAID_PYTHON" 2>/dev/null || true)
    if [ -z "$explicit" ]; then explicit=$BRAID_PYTHON; fi
    try_python "$explicit" "$@" || {
        printf '%s\n' 'BRAID_PYTHON did not select a supported, complete runtime. No fallback was used.' >&2
        exit 1
    }
fi

# Respect a compatible default/activated environment before looking elsewhere.
for name in python3 python3.13 python3.12 python3.11 python3.10; do
    candidate=$(command -v "$name" 2>/dev/null || true)
    if [ -n "$candidate" ]; then try_python "$candidate" "$@" || :; fi
done

# Finder/Terminal launches can have a limited PATH. Check standard installation
# locations directly. Never crawl Downloads or arbitrary home directories.
for version in 3.13 3.12 3.11 3.10; do
    for directory in \
        /opt/homebrew/bin \
        "/opt/homebrew/opt/python@$version/bin" \
        /usr/local/bin \
        "/usr/local/opt/python@$version/bin" \
        "/Library/Frameworks/Python.framework/Versions/$version/bin" \
        /opt/local/bin \
        "${HOME:-/nonexistent}/.local/bin" \
        "${HOME:-/nonexistent}/.pyenv/shims"; do
        try_python "$directory/python$version" "$@" || :
    done
done

printf '\n%s\n' \
    'No supported Python installation was found.' \
    'Archangel a5 needs standard CPython 3.10-3.13 with venv, ensurepip, ssl and sqlite3.' \
    'Install Python 3.12 or 3.13, or set BRAID_PYTHON to an existing supported interpreter.' \
    'No packages were installed and no Braid profile was opened by this launcher.' >&2
exit 1
