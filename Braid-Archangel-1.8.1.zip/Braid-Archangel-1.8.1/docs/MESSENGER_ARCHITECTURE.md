# Messenger layer: 1.7.0a5 Archangel

## Product shape

The everyday surface has three recognizable parts: a buddy list of owned rigs, an inbox of handoffs, and a reviewed summary composer. It is intentionally a small local client rather than a dashboard of protocol controls. Progress comes from a real receipt, an unread item handled, or additional indexed context—not an invented synchronization percentage.

The default window keeps peer identity, receipt state, and useful text visible. Raw receipts, route files, optical controls, enrollment configuration, and field internals remain available but are not the first screen. The layout has a compact desktop mode and a narrow-screen list/reader mode. It uses system fonts, plain JavaScript, HTML, and CSS with no new third-party UI runtime.

## Composition rather than a replacement protocol

`messenger.py` is a bounded local service for contact approval, pinned-TLS LAN dispatch, durable inbox/drafts, and jobs. `messenger_http.py` is a loopback HTTP facade and static asset handler. The existing `serve_http_app` composes it and leaves the former visual workspace available at `/advanced`.

The existing frame and semantic schemas, receiver-owned acceptance, replay/finality, canonical FP16, reconciliation guard and signed-delta authority boundaries remain enforced. Archangel deliberately changes transport TLS admission and scheduling, private-file handling, and Messenger bookkeeping/lifecycle code. The full CLI remains available. Tests for legacy card authentication and formerly unsupported addresses are updated for the explicit new policy; other retained semantic behavior remains under regression tests.

New LAN setup creates a self-signed public rig card, `intersignal.braid.rig-card.v1`. It is an explicit enrollment convention for this client, not a new network authority and not a public interoperability standard. The receiver approves both a signing key and the included calibrated route. Card self-signatures prove integrity relative to the included key; operators compare fingerprints on the other device before approval.

A new TLS key and certificate are generated locally for the listener, separately from the signing key. The card binds the certificate and endpoint to the signing identity. The sender trusts that approved certificate and requires TLS 1.3; the receiver now admits exact approved client TLS certificates before parsing, then binds the actual Braid signer to that TLS contact and applies its locally approved route. Removing a peer removes future dispatch authorization without deleting historical state.

## Truthful status model

A reachable socket is not transport completion. A completed transport is not Phase B commit. Phase A validation is not acceptance. A commit is not proof that indexing succeeded. Indexed state is not proof that a model read it, agreed with it, or produced a correct answer.

The inbox maps these distinctions to ordinary labels. Explicit contradictory negative fields cannot produce a green acceptance label. Legacy successful receipts are labeled as legacy and do not invent indexing. The sender also checks that the receiver receipt binds the exact sent frame bytes. After uncertain network failure or an interrupted process, no send is automatically replayed.

Inbox read/archive state, one local draft, content-bound per-recipient delivery outcomes, card revision high-water marks and receipt metadata live in SQLite; core receipts, frames, replay controls, and semantic artifacts remain the authority for the protocol workflow. Inputs and message rendering are treated as text, not HTML. The new sender UI does not execute instructions embedded in incoming semantic material.

## Forward-compatible surface, bounded present capability

The UI separates the rig, the envelope/receipt, and its semantic material. Current supported outgoing forms are reviewed summaries, exact context, and exact signed delta material. Versioned card metadata advertises known capabilities; unsupported card formats or payload kinds are refused rather than guessed at.

This leaves a place for future interchange payloads and capability negotiation without making the entire user experience a plain chat transcript. It does not implement native hidden-state transfer, KV-cache interchange, universal latent coordinates, or an arbitrary future payload decoder. Present heterogeneous receivers still use explicit signed semantic material and receiver-local representations. Any future payload requires an actual versioned codec, validation rules, resource limits, migration policy, and physical interoperability tests.

## Security and resource limits

The new management endpoints are loopback-only, validate Host/Origin context, and require a per-session CSRF token for mutations. They do not protect against a malicious process already running as the local user. Legacy advanced endpoints retain their existing a3 security model.

The card workflow accepts explicit numeric private IPv4, CGNAT overlay, direct-link IPv4 and IPv6 ULA/loopback endpoints, not arbitrary remote URLs. Scoped IPv6 link-local, public/wildcard/multicast and known metadata endpoints are refused. Address-only signed revisions preserve identity and cannot roll back the saved high-water mark. Cards are size-bounded, have a validated self-signature, and contain no executable callbacks or model endpoint overrides. Route ZIPs reject traversal, duplicates, symlinks, unreferenced artifacts, hash mismatches, oversized expansions, unsupported NPY types, nonfinite values, and declared array sizes inconsistent with the actual bytes. Validation precedes approval.

Bounds include 16 approved LAN rigs, a 12 MiB card request, 8 MiB expanded route artifacts, two worker threads, four active/queued operations, and a 500-message display window. Large/native-dimension routes that exceed the compact card bounds can still use the retained explicit CLI workflow. Receipt ingestion is live plus a bounded incremental directory cursor (128 entries per reconciliation slice by default), with durable file metadata and periodic complete cycles that also catch in-place updates. TLS admission uses 16 worker slots and a three-second handshake timeout by default; no handshake is performed in the accept loop. Capacity bounds mitigate resource exhaustion but do not guarantee availability under hostile traffic.

Private-file helpers use POSIX modes or a protected Windows account/SYSTEM DACL and fail closed when protection cannot be applied; native Windows execution remains a UAT gate. Files they are not encrypted at rest by this UI. Protect the host account, disk encryption, backups, and signing keys. A signed card can reveal private network addresses and route/model identities, so treat it as public-key enrollment material to share deliberately, not as a secret credential or as anonymous data.

The retained protocol section of `SECURITY.md` remains the semantic-boundary reference; its Archangel preface documents the changed admission and lifecycle surface. This added code has automated tests but has not had independent security review or physical multi-platform certification.
