# Archangel security additions - 1.7.0a5

Direct Messenger ingress requires approved mutual TLS before frame parsing, exact receiver certificate pinning on send, and correspondence between the authenticated TLS contact and actual Braid signer. These are admission controls, not a substitute for receiver-owned route checks, replay policy or Phase B acceptance. Handshakes have finite worker slots/timeouts and shutdown can interrupt sockets; this does not make a reachable listener immune to denial of service.

Delivery idempotency is a sender-local, content-bound durable ledger. Unknown receipts do not auto-retry. An explicit new handoff, duplicated profile or restored backup can create another send; no global exactly-once claim is made.

Rig-card updates are signed, revision-checked and explicit. Public/wildcard/multicast and known metadata addresses are refused in the simplified direct workflow. A private/CGNAT address alone does not establish a trusted network. Scope-qualified IPv6 link-local is not accepted as a portable peer endpoint.

Private-file access uses POSIX modes or a protected Windows account/SYSTEM DACL, not encryption. Native Windows ACL execution remains unverified in this build environment. Backups contain private identities: protect the profile and your external backup media. Never share identity.pem or lan-tls-private.pem as a rig card.

Offline manifests and bundle hashes establish consistency, not independent publisher authenticity. Use trusted Python and package sources. Explicit host-environment reuse is not isolated. The local CSRF and origin boundary does not protect against another malicious process running as the same OS user.

Read AUDIT_RESOLUTION.md and QA.md for tested boundaries and remaining native/physical gates. No new telemetry or remotely controlled updater is added. The historical protocol security guide follows.

---

# Braid Light Client v1.7.0a3 Security Notes

## Receiver sovereignty

Only successful receiver-owned Phase B commit means accepted. Transport arrival, Phase A validation, external validator output, semantic re-embedding, field similarity, delta selection, and language-model output do not possess acceptance authority.

## Semantic Capsule boundary

A Semantic Capsule is signed sender evidence, not truth and not authority. The receiver validates the closed capsule schema, capsule digest, signed wire-payload binding, frozen route/source-model binding, and signed Legend binding when used.

Different native embedding spaces remain non-interchangeable. Heterogeneous semantic ingestion requires explicit signed material. Braid does not infer language from an opaque foreign vector.

## Semantic Field boundary

The Semantic Field is receiver-local derived evidence built only after Phase B commit. Atom vectors, novelty labels, reconciliation clusters, local delta-selection files, and field-query responses do not inherit the sender signature.

Field similarity means relevance, not truth. `possible_update` and `possible_conflict` are heuristic labels. Braid performs no automatic retraction, conflict resolution, or supersession.

Field comparisons fail closed across different `field_space_digest` values. Space identity binds the exact model digest, adapter digest, normalization, target dimension, and a canonical behavior-probe fingerprint. This protects against silently mixing a changed model/backend behavior with an existing field. It is not a cryptographic attestation of the Ollama process or hardware.

## Direct and projected embeddings

Direct 384D output and deterministic native-to-384D projection are separate field spaces. The projection is a model-digest-seeded signed feature hash. It is deterministic and bounded, but it can lose information and can create collisions. It is an experimental retrieval adapter, not a universal learned latent translation.

Native projection is receiver policy and can be disabled. Nonfinite, zero, malformed, oversized, or incorrectly shaped vectors fail closed.

## Field artifact integrity

A local field manifest binds byte size and SHA-256 for `atoms.json`, `atoms.npy`, `novelty.json`, and `delta.json`. Semantic Capsule lineage binds the field-manifest digest, encoder digest, adapter digest, and field-space digest. Normal loads reject partial or mismatched artifacts.

These are receiver-local integrity checks, not protection against an attacker who fully controls the local filesystem and can coherently rewrite all local evidence. Protect the receiver account, storage, and backups accordingly.

## Field construction failure

Field construction is optional post-commit derived work. If the field encoder fails, Braid still atomically persists the authenticated committed Semantic Capsule material and receiver-native vector. The receipt reports degradation and `field-reindex` can retry later. An indexing failure cannot erase or rewrite Phase B finality.

## Legacy reindexing

`field-reindex` requires committed lineage and verifies canonical `material.txt` against the stored semantic-content SHA-256 before indexing. It processes valid objects in commit chronology, never overwrites an existing field marker, and publishes `field.json` last.

A corrupt object fails independently unless `--fail-fast` is chosen. Reindexing does not replay transport, re-sign an object, or create receiver acceptance.

## Semantic delta boundary

`braid.semantic-delta.v1` is part of the signed frame and binds exact ordered atom IDs, source object digest, source field-manifest digest, selection policy, canonical material digest, and `automatic_supersession: false`.

The receiver verifies the signed extension against exact canonical delta material before Phase B. This proves the sender signed that selection. It does not prove the sender's local similarity classification was accurate, that the source field was uncompromised, or that the selected claims are true.

Delta material is explicit text. Braid never reconstructs missing semantics from an opaque delta vector.

## Prompt injection, reconciliation, and model output

Signed semantic text can contain hostile instructions or false claims. Signatures establish integrity and provenance only.

Field-query and whole-capsule query place semantic material beneath a receiver-owned system instruction and label it as context/evidence. This is not a formal security sandbox. Generated output must not directly authorize tools, shell commands, credentials, network access, purchases, or other privileged actions.

v1.7.0a3 treats the completion model's output as a draft. A deterministic receiver-local guard checks a bounded set of reconciliation constraints: presence of every unresolved numeric value, explicit conflict acknowledgment, unsupported unit invention, unsupported supersession, and attempts to designate one unresolved value as current, governing, final, valid, or operative. A failing draft is retained for audit and replaced by a deterministic source-preserving response.

This guard is not a general hallucination detector or truth oracle. It can miss unsupported claims outside its bounded checks, and conservative pattern matching may replace an otherwise acceptable draft. Reconciliation remains heuristic evidence; no automatic conflict resolution occurs.

## Ollama boundary

Built-in Ollama clients accept loopback URLs only and reject redirects away from loopback. Braid rejects model names that explicitly denote cloud execution and rejects Ollama metadata or generation responses carrying non-empty remote-model/remote-host markers.

The receiver independently resolves model digests. A Semantic Capsule or delta cannot supply an inference URL. Local cloud-disable configuration is evidence, not process attestation.

## Resource bounds and denial of service

Field atom count, atom byte size, query size, context size, scanned bundle count, prior atom count, reconciliation size, delta atom count, and delta material size are bounded. Operators should choose lower policy limits on constrained devices.

Embedding and reconciliation remain computationally amplifiable within those bounds. Do not expose field commands or the loopback UI to untrusted remote callers.

## Route-distribution gate boundary

The route PCA/subspace and Mahalanobis measurements are calibrated against a finite conformance corpus. They remain hard receiver gates for opaque/vector-only state, heterogeneous routes, and exact-space paths without receiver-verified capsule/vector coherence.

A same-digest Semantic Capsule may use the documented receiver-owned exact-space verification policy. This is not a sender-controlled bypass. Distribution measurements and override rationale remain receipt evidence and cannot be replaced by field similarity.

## Local UI and network exposure

The existing Field UI remains loopback-only and enforces local Host/Origin constraints. v1.7 field operations are CLI-first in this alpha; do not infer that the historical visualizer exposes or secures every new field operation.

LAN binding requires explicit `--allow-lan`. Public exposure requires explicit public policy and TLS safeguards. Discovery and BLE sensing are untrusted hints.

## Proof-mode boundary

`--semantic-proof` is an operator convenience profile, not a bypass. It requires a route package, enables exact-space receiver re-embedding/coherence verification, and enables post-commit field indexing. Opaque vectors, cross-space vectors, failed coherence checks, malformed capsules, replayed objects, and other gate failures continue to fail closed.

Rich ACK fields expose transport completion, Phase A, Phase B, and field indexing separately. Only `phase_b_committed: true` means accepted. `accepted_and_indexed: true` additionally confirms successful post-commit field publication; it does not grant more authority than Phase B.

## Managed Relay boundary

Jump Kit changes reach, not authority. A TLS connection, relay round trip, or successful sender-side frame creation is not acceptance. Managed Relay success still requires a real receiver ACK with strict `stored`, `validated`, and `accepted` booleans plus an exact matching transport SHA-256.

Enrollment tokens, private keys, and pairing codes remain local. The relay is not granted semantic or Phase B authority.

## Distribution

Source, wheel, sdist, patch, and engineering kit should ship with SHA-256 hashes. Native application claims require native build/verification on that operating system. The v1.6.1 macOS scripts in this alpha source tree are retained historical packaging inputs; they are not evidence of a completed v1.7 signed/notarized application.

## Reporting

Experimental developer software. Inspect, benchmark, and adversarially test before deployment into sensitive or privileged workflows.
