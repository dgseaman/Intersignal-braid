# Offline setup

Python, Ollama and model weights must already exist on the destination. The release
contains the application wheel, not all third-party binaries for every platform.

On a connected machine matching destination OS, architecture and Python minor:

    python3 prepare_offline.py ./offline-pack

Transfer the complete verified pack and this complete release. On the target:

    python3 start_braid.py --offline --wheelhouse ./offline-pack

The target-bound pack is hash-checked and installed without consulting an index.
An advanced operator can deliberately reuse validated host packages with
`--offline --use-existing-env`. This mode is not isolated and remains explicit;
it is never a silent fallback. `--isolated-runtime` restores isolated installation.

No software updates are downloaded from an old release or developer diff.
