#!/usr/bin/env python3
"""Run on a connected equivalent rig, then copy the resulting directory offline."""
from __future__ import annotations
import argparse
import email
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path
from offline_support import target, verify_pack

ROOT=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination',type=Path)
    parser.add_argument('--from-wheelhouse',type=Path,help='Resolve entirely from an existing trusted wheel cache, without an index.')
    args=parser.parse_args()
    import platform,sysconfig
    if not (3,10) <= sys.version_info[:2] < (3,14) or platform.python_implementation() != 'CPython' or sysconfig.get_config_var('Py_GIL_DISABLED'):
        raise ValueError('Build this release pack with standard CPython 3.10 through 3.13.')
    dest=args.destination.expanduser().resolve()
    if dest.exists() and any(dest.iterdir()): raise ValueError('Choose an empty directory; packs are never silently merged.')
    dest.mkdir(parents=True,exist_ok=True)
    extra=['--no-index','--find-links',str(args.from_wheelhouse.resolve())] if args.from_wheelhouse else []
    subprocess.run([sys.executable,'-m','pip','--isolated','--disable-pip-version-check','download','--only-binary=:all:',
                    '--timeout','15','--retries','1','--dest',str(dest),'-r',str(ROOT/'dependencies.txt'),*extra],check=True,timeout=600)
    packages={}
    for wheel in sorted(dest.glob('*.whl')):
        with zipfile.ZipFile(wheel) as archive:
            members=[n for n in archive.namelist() if n.endswith('.dist-info/METADATA')]
            if len(members)!=1: raise ValueError('Invalid wheel metadata')
            metadata=email.message_from_bytes(archive.read(members[0]))
        name=re.sub(r'[-_.]+','-',metadata['Name']).lower()
        version=metadata['Version']
        if not re.fullmatch(r'[a-z0-9-]+',name) or not re.fullmatch(r'[a-zA-Z0-9.+!-]+',version): raise ValueError('Invalid package identity')
        if name in packages: raise ValueError('Duplicate package in offline pack')
        packages[name]=name+'=='+version+' --hash=sha256:'+hashlib.sha256(wheel.read_bytes()).hexdigest()
    (dest/'requirements.lock').write_text('\n'.join(packages[k] for k in sorted(packages))+'\n')
    files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dest.iterdir()) if p.is_file()}
    meta={'schema':'braid.offline-pack.v1','target':target(),'files':files,
          'dependency_spec_sha256':hashlib.sha256((ROOT/'dependencies.txt').read_bytes()).hexdigest()}
    (dest/'wheelhouse-manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
    verify_pack(dest, ROOT/'dependencies.txt')
    print('Verified '+str(len(packages))+' pinned packages for '+str(target()))
    print('Copy this folder and the Archangel bundle; launch with --offline --wheelhouse "'+str(dest)+'"')
    print('Python and local Ollama/model files must be provisioned separately. Hashes are integrity checks, not a publisher signature.')

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print('Offline pack not completed: '+str(exc),file=sys.stderr)
        sys.exit(1)
