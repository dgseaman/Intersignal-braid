# Third-Party Software Notices

The Braid Client source code is released by Intersignal LLC under the MIT License. That license applies to Braid code and does not relicense third-party packages installed alongside it.

## Core dependencies

- **NumPy** — BSD 3-Clause License plus upstream notices.
- **cryptography** — Apache License 2.0 or BSD 3-Clause License.

## Optional camera fallback

- **opencv-python-headless / OpenCV** — Apache License 2.0 plus upstream notices.

## Optional local sensing

- **bleak** — MIT License. Used only for local Bluetooth Low Energy discovery when the `sensing` or `full` extra is installed.

Dependencies are resolved separately by Python packaging tools and are not copied into this source tree. Review the exact license metadata shipped with the versions installed in your environment.

No reference to a third-party project, institution, protocol, or license implies sponsorship, certification, affiliation, or endorsement of Intersignal LLC or Braid.

## Archangel core installation

The core wheel also declares jsonschema; the pinned launcher dependency closure is listed in release/dependencies.txt. Each dependency and transitive dependency retains the license/notices included in its upstream wheel. Third-party dependency wheels are not embedded in the universal release. The optional offline-pack builder preserves downloaded wheel bytes and their included notices; it does not relicense them. Test-only reconstructed local dependency fixtures used for QA are not distributed as upstream packages.
