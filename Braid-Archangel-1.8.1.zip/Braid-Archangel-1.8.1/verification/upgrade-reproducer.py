"""Live predecessor-to-1.8.1 launcher check on a disposable test profile."""
from pathlib import Path
import os,sys,subprocess,tempfile,json,time,urllib.request,hashlib
w=Path('/mnt/data/archangel_181_work');old=w/'baseline/Braid-Archangel-1.8.0';new=w/'Braid-Archangel-1.8.1';out=w/'evidence';checks=[]
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
def check(n,c):
 assert c,n
 checks.append(n);print('PASS',n,flush=True)
def request(url,data=None,csrf=None):
 req=urllib.request.Request(url,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json',**({'X-Braid-CSRF':csrf} if csrf else {})})
 with urllib.request.urlopen(req,timeout=10) as f:return json.load(f)
def start(root,profile,log):
 return subprocess.Popen([sys.executable,str(root/'start_braid.py'),'--profile',str(profile),'--no-browser','--offline','--use-existing-env'],cwd='/tmp',env=env,stdout=log,stderr=subprocess.STDOUT)
def ready(p,profile):
 for _ in range(1200):
  if p.poll() is not None:raise RuntimeError('Early process exit '+str(p.returncode))
  try:
   port=json.loads((profile/'session.json').read_text())['port'];url=f'http://127.0.0.1:{port}'
   return url,request(url+'/api/messenger/state')
  except (OSError,ValueError,KeyError):time.sleep(.1)
 raise TimeoutError('No ready client')
def command(root,profile,*args):
 return subprocess.run([sys.executable,str(root/'start_braid.py'),'--profile',str(profile),*args],cwd='/tmp',env=env,capture_output=True,text=True,timeout=60)
with tempfile.TemporaryDirectory(prefix='braid181-upgrade-') as d:
 profile=Path(d)/'profile'
 with (out/'upgrade-lifecycle.txt').open('w') as log:
  p=start(old,profile,log)
  try:
   url,state=ready(p,profile);check('actual predecessor serves 1.8.0',state['version']=='1.8.0')
   identity=hashlib.sha256((profile/'identity.pem').read_bytes()).hexdigest()
   draft={'handoff_id':'upgrade_test_delta_0123456789','kind':'delta','mode':'review','title':'Saved delta regression','source':'{"atoms":[]}', 'review':'{"atoms":[]}','object_digest':'a'*64,'recipients':[]}
   request(url+'/api/messenger/draft',{'draft':draft},state['csrf'])
   before=json.loads((profile/'session.json').read_text())
   blocked=command(new,profile,'--no-browser','--offline')
   (out/'upgrade-old-running-refusal.txt').write_text(blocked.stdout+blocked.stderr)
   check('new launcher rejects older running version',blocked.returncode!=0 and 'older window was not reopened' in blocked.stderr)
   check('older instance remains running untouched',p.poll() is None and json.loads((profile/'session.json').read_text())==before)
   check('no new runtime created during refusal',not list(profile.glob('runtime-1.8.1*')))
   stopped=command(old,profile,'--stop');check('old client quits cooperatively',stopped.returncode==0 and p.wait(timeout=30)==0)
   p=start(new,profile,log);url,state=ready(p,profile)
   check('complete new release starts 1.8.1',state['version']=='1.8.1')
   check('old identity retained',hashlib.sha256((profile/'identity.pem').read_bytes()).hexdigest()==identity)
   check('saved delta retained for explicit resume',state['draft']==draft)
   check('new release owns distinct runtime',bool(list(profile.glob('runtime-1.8.1*'))))
   check('pre-upgrade desktop snapshot recorded',json.loads((profile/'archangel-upgrade.json').read_text())['version']=='1.8.1')
   with urllib.request.urlopen(url+'/static/messenger.js',timeout=10) as f:js=f.read()
   with urllib.request.urlopen(url+'/',timeout=10) as f:html=f.read().decode()
   check('live new server uses integrated composer bytes',js==(w/'source/braid_client/static/messenger.js').read_bytes())
   check('live visible version is 1.8.1','title="1.8.1 - Archangel">1.8.1</span>' in html)
   stopped=command(new,profile,'--stop');check('new client quits cooperatively',stopped.returncode==0 and p.wait(timeout=30)==0)
  finally:
   if p.poll() is None:
    try:command(new,profile,'--stop');p.wait(timeout=25)
    except Exception:p.kill();p.wait()
(out/'upgrade-check.json').write_text(json.dumps({'passed':True,'checks':checks,'count':len(checks),'method':'Real old/new launchers and installed wheels, disposable Linux profile, explicit host-dependency mode; local HTTP and persistent saved draft/identity. No real model, native Mac/Windows or private user profile.'},indent=2)+'\n')
