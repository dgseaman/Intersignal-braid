#!/bin/sh
set -eu
HERE=$(CDPATH= cd -P "$(dirname "$0")" && pwd)
cd "$HERE"
exec python3 "$HERE/start_braid.py" "$@"
