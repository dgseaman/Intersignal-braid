# Braid v1.6.1rc1 — Summarize and Send Context physical UAT

**Status:** required before final v1.6.1 promotion  
**Topology:** two approved Braid devices on different networks, one pinned Intersignal Managed Relay endpoint

## Objective

Demonstrate that a normal operator can move reviewed situational context from Node A to Node B through the Field UI while Braid preserves the distinction between relay delivery and receiver-owned Phase B finality.

## Freeze before testing

Record:

- source/wheel SHA-256;
- Node A and Node B operating systems;
- Braid and Jump Kit versions;
- source and receiver embedding models plus digests;
- route-package digest/identity;
- relay hostname, SNI/server name, port, CA digest, and certificate SHA-256 pin;
- approved device IDs and human-readable names;
- the exact test text and its UTF-8 byte length.

Do not record enrollment-token contents, private keys, or pairing codes.

## Positive path

1. Confirm Node B's Braid receiver and outbound-only Jump Kit agent are healthy.
2. Confirm Node A and Node B appear as mutually approved peers.
3. On Node A, open the loopback Field UI.
4. Confirm the Managed Relay card shows DigitalOcean / NYC1, TLS 1.3, port 8750, and `READY`.
5. Paste an invented scenario that cannot be supplied by model pretraining and is at most 6,000 UTF-8 bytes.
6. Select **Summarize Context**.
7. Verify the UI states that no network transfer occurred.
8. Review and edit the summary. Record the final reviewed-text SHA-256.
9. Select Node B and choose **Send Context ->**.
10. Require the UI to show transport and receiver fields separately.
11. PASS only if the receipt contains:

```json
{
  "transport": {
    "tls_observed": "TLSv1.3",
    "relay_round_trip_complete": true,
    "delivered_to_receiver": true
  },
  "receiver": {
    "stored": true,
    "validated": true,
    "accepted": true,
    "phase_b_committed": true,
    "finality": "committed"
  },
  "phase_b_committed": true,
  "finality": "committed"
}
```

12. Confirm `receiver.transport_sha256` equals the SHA-256 of the exact Node A private-outbox `.brad` bytes.
13. Confirm Node B persisted `material.txt`, `vector.npy`, and `lineage.json` under the committed object digest.
14. In a fresh receiver-local inference call, ask a paraphrased question whose answer depends on the transferred scenario.
15. Require the retained query artifact to report:

```json
{
  "fresh_context_reconstruction": true,
  "phase_b_committed": true
}
```

## Required negatives

Each negative must fail without a false success banner and without a new receiver-owned Phase B commit:

1. source text of 6,001 ASCII bytes;
2. multibyte UTF-8 input exceeding 6,000 bytes;
3. missing empirical route package;
4. unapproved peer;
5. offline approved peer;
6. wrong enrollment token;
7. wrong relay CA;
8. wrong TLS server name;
9. wrong certificate SHA-256 pin;
10. relay TLS result other than TLS 1.3;
11. local Node B Braid receiver stopped;
12. altered `.brad` bytes in transit or before receiver validation;
13. receiver ACK with string booleans instead of JSON booleans;
14. receiver ACK `transport_sha256` not equal to the sent-frame SHA-256;
15. receiver ACK with any one of `stored`, `validated`, or `accepted` false;
16. operator kill switch `BRAID_MANAGED_RELAY_ENABLED=0`;
17. configured concurrent-send limit reached;
18. tampered committed `material.txt` before a fresh query.

## Presentation checks

- The buttons read **Summarize Context** and **Send Context ->**.
- The summary remains editable before send.
- Source changes invalidate a previous summary.
- The UI never says accepted solely because TLS or relay routing succeeded.
- The only green success state is `Context accepted by <receiver>` after `phase_b_committed: true`.
- The technical receipt exposes digests and status, but no token contents, private keys, or pairing codes.
- A failed send explains that a signed frame remains in the private outbox when applicable.

## Final decision

Promote only when the exact frozen artifacts pass the positive path and every required negative on physical nodes using the exact production relay identity.
