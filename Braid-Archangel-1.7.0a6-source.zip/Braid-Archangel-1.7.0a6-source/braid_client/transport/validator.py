from __future__ import annotations

import shlex
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ValidationResult:
    ran: bool
    accepted: bool
    reason: str
    stdout: str = ""
    stderr: str = ""


def run_validator(command_template: str | None, frame_path: Path, timeout_seconds: float) -> ValidationResult:
    if not command_template:
        return ValidationResult(ran=False, accepted=False, reason="STORED_UNVALIDATED")
    try:
        argv = [part.replace("{file}", str(frame_path)) for part in shlex.split(command_template)]
    except ValueError:
        return ValidationResult(ran=False, accepted=False, reason="ERR_VALIDATOR_PARSE")
    if not argv:
        return ValidationResult(ran=False, accepted=False, reason="ERR_VALIDATOR_EMPTY")
    if not any(str(frame_path) in part for part in argv):
        argv.append(str(frame_path))
    try:
        completed = subprocess.run(
            argv,
            shell=False,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        return ValidationResult(
            ran=True,
            accepted=False,
            reason="ERR_VALIDATOR_TIMEOUT",
            stdout=(exc.stdout or "")[-4000:] if isinstance(exc.stdout, str) else "",
            stderr=(exc.stderr or "")[-4000:] if isinstance(exc.stderr, str) else "",
        )
    except OSError:
        return ValidationResult(ran=False, accepted=False, reason="ERR_VALIDATOR_EXEC")
    return ValidationResult(
        ran=True,
        accepted=completed.returncode == 0,
        reason="VALIDATOR_ACCEPTED" if completed.returncode == 0 else f"ERR_VALIDATOR_REJECTED:{completed.returncode}",
        stdout=completed.stdout[-4000:],
        stderr=completed.stderr[-4000:],
    )
