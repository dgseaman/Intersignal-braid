from __future__ import annotations

import json
import socket
import time
from dataclasses import dataclass
from typing import Iterator

DISCOVERY_MAGIC = "BRAID-LAN-1"
DEFAULT_DISCOVERY_PORT = 8746


@dataclass(frozen=True)
class DiscoveryRecord:
    node_id: str
    host: str
    transport_port: int
    tls: bool
    seen_at_unix: int


def encode_advertisement(node_id: str, transport_port: int, tls: bool) -> bytes:
    if not node_id or len(node_id) > 128:
        raise ValueError("ERR_NODE_ID")
    if not (1 <= transport_port <= 65535):
        raise ValueError("ERR_PORT_RANGE")
    return json.dumps(
        {"magic": DISCOVERY_MAGIC, "node_id": node_id, "port": transport_port, "tls": bool(tls)},
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def decode_advertisement(data: bytes, host: str) -> DiscoveryRecord:
    if len(data) > 2048:
        raise ValueError("ERR_DISCOVERY_SIZE")
    obj = json.loads(data.decode("utf-8"))
    if not isinstance(obj, dict) or set(obj) != {"magic", "node_id", "port", "tls"}:
        raise ValueError("ERR_DISCOVERY_SCHEMA")
    if obj["magic"] != DISCOVERY_MAGIC:
        raise ValueError("ERR_DISCOVERY_MAGIC")
    if not isinstance(obj["node_id"], str) or not obj["node_id"] or len(obj["node_id"]) > 128:
        raise ValueError("ERR_NODE_ID")
    if not isinstance(obj["port"], int) or not (1 <= obj["port"] <= 65535):
        raise ValueError("ERR_PORT_RANGE")
    if not isinstance(obj["tls"], bool):
        raise ValueError("ERR_TLS_FLAG")
    return DiscoveryRecord(obj["node_id"], host, obj["port"], obj["tls"], int(time.time()))


def advertise_once(node_id: str, transport_port: int, *, discovery_port: int = DEFAULT_DISCOVERY_PORT, tls: bool = False, broadcast: str = "255.255.255.255") -> None:
    payload = encode_advertisement(node_id, transport_port, tls)
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.sendto(payload, (broadcast, discovery_port))


def discover(timeout_seconds: float = 2.0, *, discovery_port: int = DEFAULT_DISCOVERY_PORT, bind: str = "0.0.0.0") -> Iterator[DiscoveryRecord]:
    deadline = time.monotonic() + timeout_seconds
    seen: set[tuple[str, str, int]] = set()
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((bind, discovery_port))
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return
            sock.settimeout(remaining)
            try:
                data, address = sock.recvfrom(2048)
            except socket.timeout:
                return
            try:
                record = decode_advertisement(data, address[0])
            except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
                continue
            key = (record.node_id, record.host, record.transport_port)
            if key not in seen:
                seen.add(key)
                yield record
