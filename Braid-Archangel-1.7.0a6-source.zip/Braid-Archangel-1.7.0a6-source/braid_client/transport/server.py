from __future__ import annotations
from ..private_files import secure_fd

import json
import hashlib
import ipaddress
import logging
import os
import socket
import socketserver
import ssl
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from .errors import BraidTransportError, PolicyError
from .policy import BindDecision, enforce_bind_policy
from .protocol import Ack, atomic_write, decode_transfer_from_socket, encode_ack, sanitize_filename
from .validator import run_validator

LOGGER = logging.getLogger("braid_transport")


def _ensure_private_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass


@dataclass(frozen=True)
class ReceiverConfig:
    bind: str = "127.0.0.1"
    port: int = 8745
    output_dir: Path = Path("braid-inbox")
    allow_lan: bool = False
    allow_public: bool = False
    insecure_public: bool = False
    tls_cert: Path | None = None
    tls_key: Path | None = None
    client_ca: Path | None = None
    require_client_cert: bool = False
    max_frame_bytes: int = 2 * 1024 * 1024
    socket_timeout_seconds: float = 10.0
    validator_timeout_seconds: float = 20.0
    validator_command: str | None = None
    retain_rejected: bool = True
    audit_log: Path | None = None
    receiver_callback: Callable[..., dict[str, Any]] | None = None
    # New optional fields follow the legacy positional configuration contract.
    allow_overlay: bool = False
    handshake_timeout_seconds: float = 3.0
    max_connections: int = 16
    tls_peer_authorizer: Callable[[str], bool] | None = None
    bind_tls_identity: bool = False

    @property
    def tls_enabled(self) -> bool:
        return self.tls_cert is not None and self.tls_key is not None


class _ThreadingTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


class _Handler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        server: "_ConfiguredServer" = self.server  # type: ignore[assignment]
        config = server.config
        sock: socket.socket = self.request
        sock.settimeout(config.socket_timeout_seconds)
        digest = ""
        try:
            metadata, payload = decode_transfer_from_socket(sock, config.max_frame_bytes)
            digest = metadata.transport_sha256
            safe_name = sanitize_filename(metadata.filename)
            if config.receiver_callback is not None:
                identity = {}
                if config.bind_tls_identity:
                    identity["tls_peer_cert_sha256"] = hashlib.sha256(sock.getpeercert(binary_form=True) or b"").hexdigest()
                report = config.receiver_callback(
                    payload,
                    source_transport="network",
                    source_name=safe_name,
                    peer=self.client_address[0],
                    **identity,
                )
                reported_accepted = bool(report.get("accepted"))
                stored = bool(report.get("stored"))
                committed = bool(report.get("phase_b_committed"))
                phase_a_value = report.get("phase_a_validated")
                phase_a_validated = (
                    phase_a_value
                    if type(phase_a_value) is bool
                    else committed
                )
                finality = str(report.get("finality") or "")
                invariant_accepted = committed and finality == "committed"
                semantic_transfer = report.get("semantic_transfer")
                semantic_field = (
                    semantic_transfer.get("semantic_field")
                    if isinstance(semantic_transfer, dict)
                    else None
                )
                field_indexed = bool(
                    isinstance(semantic_field, dict)
                    and semantic_field.get("indexed") is True
                )
                accepted_and_indexed = bool(invariant_accepted and field_indexed)
                post_commit_complete = bool(report.get("post_commit_complete"))
                if reported_accepted != invariant_accepted or committed != (finality == "committed"):
                    ack = Ack(
                        stored=stored,
                        validated=phase_a_validated,
                        accepted=False,
                        reason="ERR_FINALITY_INVARIANT",
                        transport_sha256=digest,
                        destination="quarantine",
                        transport_completed=True,
                        phase_a_validated=phase_a_validated,
                        phase_b_committed=False,
                        field_indexed=False,
                        accepted_and_indexed=False,
                        post_commit_complete=False,
                    )
                else:
                    reason = str(report.get("reason") or ("RECEIVER_ACCEPTED" if invariant_accepted else "RECEIVER_REJECTED"))
                    if invariant_accepted:
                        destination = "accepted"
                    elif finality == "quarantined":
                        destination = "quarantine"
                    else:
                        destination = "rejected"
                    ack = Ack(
                        stored=stored,
                        validated=phase_a_validated,
                        accepted=invariant_accepted,
                        reason=reason,
                        transport_sha256=digest,
                        destination=destination,
                        transport_completed=True,
                        phase_a_validated=phase_a_validated,
                        phase_b_committed=committed,
                        field_indexed=field_indexed,
                        accepted_and_indexed=accepted_and_indexed,
                        post_commit_complete=post_commit_complete,
                    )
            else:
                stem = Path(safe_name).stem
                quarantine = config.output_dir / "quarantine" / f"{stem}-{digest[:12]}-{metadata.transfer_id[:8]}.brad"
                _ensure_private_dir(quarantine.parent)
                atomic_write(quarantine, payload)
                validation = run_validator(config.validator_command, quarantine, config.validator_timeout_seconds)
                if validation.ran and validation.accepted:
                    # External validators are non-authoritative prevalidation only.
                    # Without the receiver-owned Phase B transaction, the exact bytes
                    # remain quarantined and MUST NOT produce accepted=True.
                    ack = Ack(
                        True, True, False, "VALIDATED_NOT_COMMITTED", digest, "quarantine",
                        transport_completed=True,
                        phase_a_validated=False,
                        phase_b_committed=False,
                        field_indexed=False,
                        accepted_and_indexed=False,
                        post_commit_complete=False,
                    )
                elif validation.ran:
                    destination = config.output_dir / "rejected" / quarantine.name
                    if config.retain_rejected:
                        _ensure_private_dir(destination.parent)
                        os.replace(quarantine, destination)
                    else:
                        quarantine.unlink(missing_ok=True)
                        destination = None
                    ack = Ack(
                        config.retain_rejected, True, False, validation.reason, digest,
                        "rejected" if destination else None,
                        transport_completed=True,
                        phase_a_validated=False,
                        phase_b_committed=False,
                        field_indexed=False,
                        accepted_and_indexed=False,
                        post_commit_complete=False,
                    )
                else:
                    ack = Ack(
                        True, False, False, validation.reason, digest, "quarantine",
                        transport_completed=True,
                        phase_a_validated=False,
                        phase_b_committed=False,
                        field_indexed=False,
                        accepted_and_indexed=False,
                        post_commit_complete=False,
                    )
            server.audit(
                {
                    "accepted": ack.accepted,
                    "digest": digest,
                    "peer": self.client_address[0],
                    "reason": ack.reason,
                    "stored": ack.stored,
                    "transfer_id": metadata.transfer_id,
                    "validated": ack.validated,
                }
            )
            sock.sendall(encode_ack(ack))
        except (BraidTransportError, OSError, ValueError) as exc:
            reason = str(exc) or exc.__class__.__name__
            server.audit(
                {
                    "accepted": False,
                    "digest": digest,
                    "peer": self.client_address[0] if self.client_address else "unknown",
                    "reason": reason,
                    "stored": False,
                    "validated": False,
                }
            )
            try:
                sock.sendall(encode_ack(Ack(
                    False, False, False, reason, digest,
                    transport_completed=False,
                    phase_a_validated=False,
                    phase_b_committed=False,
                    field_indexed=False,
                    accepted_and_indexed=False,
                    post_commit_complete=False,
                )))
            except OSError:
                pass


class _ConfiguredServer(_ThreadingTCPServer):
    def __init__(self, address: tuple[str, int], config: ReceiverConfig, ssl_context: ssl.SSLContext | None):
        self.config = config
        self.ssl_context = ssl_context
        self._audit_lock = threading.Lock()
        self._active_lock = threading.Lock()
        self._active: set[socket.socket] = set()
        self._slots = threading.BoundedSemaphore(config.max_connections)
        self._stopping = threading.Event()
        try:
            if ipaddress.ip_address(address[0]).version == 6:
                self.address_family = socket.AF_INET6
        except ValueError:
            pass
        super().__init__(address, _Handler)

    def process_request(self, request, client_address):
        # Admission is bounded BEFORE creating a thread or negotiating TLS.
        if self._stopping.is_set() or not self._slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        with self._active_lock:
            self._active.add(request)
        try:
            super().process_request(request, client_address)
        except Exception:
            with self._active_lock:
                self._active.discard(request)
            self._slots.release()
            self.shutdown_request(request)
            raise

    def process_request_thread(self, request, client_address):
        original = request
        try:
            if self._stopping.is_set():
                return
            request.settimeout(self.config.handshake_timeout_seconds)
            context = self.ssl_context
            if context is not None:
                # Never perform a handshake on the accept loop.
                wrapped = context.wrap_socket(request, server_side=True, do_handshake_on_connect=False)
                with self._active_lock:
                    self._active.discard(request)
                    self._active.add(wrapped)
                request = wrapped
                request.do_handshake()
                authorizer = self.config.tls_peer_authorizer
                if authorizer is not None:
                    certificate = request.getpeercert(binary_form=True)
                    if not certificate or not authorizer(hashlib.sha256(certificate).hexdigest()):
                        raise ssl.SSLError('ERR_UNAPPROVED_TLS_IDENTITY')
            if not self._stopping.is_set():
                self.finish_request(request, client_address)
        except (OSError, ValueError):
            # TLS rejection is deliberately pre-parser; no Braid ACK is fabricated.
            pass
        except Exception:
            self.handle_error(request, client_address)
        finally:
            with self._active_lock:
                self._active.discard(original)
                self._active.discard(request)
            self.shutdown_request(request)
            self._slots.release()

    def close_connections(self):
        self._stopping.set()
        with self._active_lock:
            active = list(self._active)
        for sock in active:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            sock.close()

    def audit(self, event: dict[str, Any]) -> None:
        event = {"ts_unix": int(time.time()), **event}
        LOGGER.info("%s", json.dumps(event, sort_keys=True))
        path = self.config.audit_log
        if path is None:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(event, sort_keys=True, separators=(",", ":")) + "\n"
        with self._audit_lock:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
            secure_fd(fd, 0o600)
            with os.fdopen(fd, "a", encoding="utf-8") as handle:
                handle.write(line)
                handle.flush()


@dataclass
class TransportServer:
    config: ReceiverConfig
    decision: BindDecision = field(init=False)
    _server: _ConfiguredServer | None = field(default=None, init=False, repr=False)
    _thread: threading.Thread | None = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        if not (0 <= self.config.port <= 65535):
            raise PolicyError("ERR_PORT_RANGE")
        if self.config.handshake_timeout_seconds <= 0 or self.config.socket_timeout_seconds <= 0 or not 1 <= self.config.max_connections <= 256:
            raise PolicyError("ERR_CONNECTION_BOUNDS")
        if self.config.max_frame_bytes <= 0:
            raise PolicyError("ERR_MAX_FRAME_BYTES")
        if self.config.require_client_cert and not self.config.tls_enabled:
            raise PolicyError("ERR_CLIENT_AUTH_REQUIRES_TLS")
        if self.config.bind_tls_identity and (not self.config.require_client_cert or self.config.tls_peer_authorizer is None):
            raise PolicyError("ERR_IDENTITY_BINDING_REQUIRES_MUTUAL_TLS_POLICY")
        if (self.config.tls_cert is None) != (self.config.tls_key is None):
            raise PolicyError("ERR_TLS_CERT_KEY_PAIR_REQUIRED")
        if self.config.receiver_callback is not None and self.config.validator_command is not None:
            raise PolicyError("ERR_RECEIVER_CALLBACK_VALIDATOR_CONFLICT")
        self.decision = enforce_bind_policy(
            self.config.bind,
            allow_lan=self.config.allow_lan,
            allow_public=self.config.allow_public,
            tls_enabled=self.config.tls_enabled,
            insecure_public=self.config.insecure_public,
            allow_overlay=self.config.allow_overlay,
        )

    def _ssl_context(self) -> ssl.SSLContext | None:
        if not self.config.tls_enabled:
            return None
        assert self.config.tls_cert is not None and self.config.tls_key is not None
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_3
        context.load_cert_chain(str(self.config.tls_cert), str(self.config.tls_key))
        if self.config.client_ca is not None:
            context.load_verify_locations(cafile=str(self.config.client_ca))
        if self.config.require_client_cert:
            if self.config.client_ca is None:
                raise PolicyError("ERR_CLIENT_CA_REQUIRED")
            context.verify_mode = ssl.CERT_REQUIRED
        return context

    @property
    def address(self) -> tuple[str, int]:
        if self._server is None:
            return (self.config.bind, self.config.port)
        host, port = self._server.server_address[:2]
        return str(host), int(port)

    def start(self) -> "TransportServer":
        if self._server is not None:
            return self
        _ensure_private_dir(self.config.output_dir)
        self._server = _ConfiguredServer((self.config.bind, self.config.port), self.config, self._ssl_context())
        self._thread = threading.Thread(target=self._server.serve_forever, name="braid-transport", daemon=True)
        self._thread.start()
        return self

    def serve_forever(self) -> None:
        _ensure_private_dir(self.config.output_dir)
        self._server = _ConfiguredServer((self.config.bind, self.config.port), self.config, self._ssl_context())
        self._server.serve_forever()

    def reload_client_trust(self) -> None:
        if self._server is not None:
            self._server.ssl_context = self._ssl_context()

    def stop(self) -> None:
        if self._server is None:
            return
        self._server.close_connections()
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=5)
        self._server = None
        self._thread = None

    def __enter__(self) -> "TransportServer":
        return self.start()

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.stop()
