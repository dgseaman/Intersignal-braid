from __future__ import annotations

import socket
import hashlib
import ssl
from dataclasses import dataclass
from pathlib import Path

from .errors import PolicyError, ProtocolError
from .policy import BindScope, classify_bind_scope
from .protocol import Ack, decode_ack_from_socket, encode_transfer


@dataclass(frozen=True)
class SendResult:
    host: str
    port: int
    ack: Ack


def _client_ssl_context(ca_file: Path | None, insecure_tls: bool) -> ssl.SSLContext:
    if insecure_tls:
        context = ssl._create_unverified_context()  # noqa: SLF001 - explicit operator override
    else:
        context = ssl.create_default_context(cafile=str(ca_file) if ca_file else None)
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    return context


def _read_bounded_frame(path: Path, max_frame_bytes: int) -> bytes:
    if max_frame_bytes <= 0:
        raise ProtocolError("ERR_MAX_FRAME_BYTES")
    with path.open("rb") as handle:
        data = handle.read(max_frame_bytes + 1)
    if not data:
        raise ProtocolError("ERR_EMPTY_FRAME")
    if len(data) > max_frame_bytes:
        raise ProtocolError("ERR_FRAME_TOO_LARGE")
    return data


def send_frame(
    frame_path: Path,
    host: str,
    port: int,
    *,
    timeout_seconds: float = 15.0,
    max_frame_bytes: int = 2 * 1024 * 1024,
    use_tls: bool = False,
    ca_file: Path | None = None,
    server_name: str | None = None,
    insecure_tls: bool = False,
    allow_plaintext_public: bool = False,
    client_cert: Path | None = None,
    client_key: Path | None = None,
    pinned_cert_sha256: str | None = None,
) -> SendResult:
    if (client_cert is None) != (client_key is None):
        raise PolicyError("ERR_TLS_CLIENT_CERT_KEY_PAIR_REQUIRED")
    if (client_cert or pinned_cert_sha256) and not use_tls:
        raise PolicyError("ERR_TLS_REQUIRED_FOR_IDENTITY")
    if not frame_path.is_file():
        raise FileNotFoundError(frame_path)
    if not (1 <= port <= 65535):
        raise PolicyError("ERR_PORT_RANGE")
    target_scope = classify_bind_scope(host).scope
    if target_scope in {BindScope.PUBLIC, BindScope.WILDCARD} and not use_tls and not allow_plaintext_public:
        raise PolicyError("ERR_PUBLIC_SEND_REQUIRES_TLS_OR_PLAINTEXT_OVERRIDE")
    data = _read_bounded_frame(frame_path, max_frame_bytes)
    packet = encode_transfer(data, frame_path.name, max_frame_bytes=max_frame_bytes)
    with socket.create_connection((host, port), timeout=timeout_seconds) as raw_sock:
        raw_sock.settimeout(timeout_seconds)
        if use_tls:
            context = _client_ssl_context(ca_file, insecure_tls)
            if client_cert is not None:
                context.load_cert_chain(str(client_cert), str(client_key))
            with context.wrap_socket(raw_sock, server_hostname=server_name or host) as sock:
                if pinned_cert_sha256 and hashlib.sha256(sock.getpeercert(binary_form=True)).hexdigest() != pinned_cert_sha256:
                    raise PolicyError("ERR_TLS_CERTIFICATE_PIN")
                sock.sendall(packet)
                ack = decode_ack_from_socket(sock)
        else:
            raw_sock.sendall(packet)
            ack = decode_ack_from_socket(raw_sock)
    return SendResult(host=host, port=port, ack=ack)
