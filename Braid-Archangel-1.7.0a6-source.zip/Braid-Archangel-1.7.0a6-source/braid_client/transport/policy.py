from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass
from enum import Enum

from .errors import PolicyError


class BindScope(str, Enum):
    LOOPBACK = "loopback"
    LAN = "lan"
    PUBLIC = "public"
    WILDCARD = "wildcard"
    OVERLAY = "overlay"


@dataclass(frozen=True)
class BindDecision:
    scope: BindScope
    resolved_addresses: tuple[str, ...]


def _resolve(host: str) -> tuple[str, ...]:
    if host in {"", "0.0.0.0", "::"}:
        return (host or "0.0.0.0",)
    try:
        return (str(ipaddress.ip_address(host)),)
    except ValueError:
        addresses: list[str] = []
        for info in socket.getaddrinfo(host, None, type=socket.SOCK_STREAM):
            address = info[4][0]
            if address not in addresses:
                addresses.append(address)
        if not addresses:
            raise PolicyError("ERR_BIND_RESOLUTION")
        return tuple(addresses)


def classify_bind_scope(host: str) -> BindDecision:
    resolved = _resolve(host)
    scopes: set[BindScope] = set()
    for address in resolved:
        if address in {"", "0.0.0.0", "::"}:
            scopes.add(BindScope.WILDCARD)
            continue
        ip = ipaddress.ip_address(address.split("%", 1)[0])
        if ip.is_loopback:
            scopes.add(BindScope.LOOPBACK)
        elif ip.version == 4 and ip in ipaddress.ip_network("100.64.0.0/10"):
            scopes.add(BindScope.OVERLAY)
        elif ip.is_private or ip.is_link_local:
            scopes.add(BindScope.LAN)
        else:
            scopes.add(BindScope.PUBLIC)
    if BindScope.WILDCARD in scopes:
        scope = BindScope.WILDCARD
    elif BindScope.PUBLIC in scopes:
        scope = BindScope.PUBLIC
    elif BindScope.OVERLAY in scopes:
        scope = BindScope.OVERLAY
    elif BindScope.LAN in scopes:
        scope = BindScope.LAN
    else:
        scope = BindScope.LOOPBACK
    return BindDecision(scope=scope, resolved_addresses=resolved)


def enforce_bind_policy(
    host: str,
    *,
    allow_lan: bool,
    allow_public: bool,
    tls_enabled: bool,
    insecure_public: bool,
    allow_overlay: bool = False,
) -> BindDecision:
    decision = classify_bind_scope(host)
    if decision.scope == BindScope.LOOPBACK:
        return decision
    if decision.scope == BindScope.OVERLAY:
        if not allow_overlay or not tls_enabled:
            raise PolicyError("ERR_OVERLAY_REQUIRES_EXPLICIT_POLICY_AND_TLS")
    if decision.scope == BindScope.LAN and not allow_lan:
        raise PolicyError("ERR_LAN_BIND_REQUIRES_ALLOW_LAN")
    if decision.scope in {BindScope.PUBLIC, BindScope.WILDCARD}:
        if not allow_public:
            raise PolicyError("ERR_PUBLIC_BIND_REQUIRES_ALLOW_PUBLIC")
        if not tls_enabled and not insecure_public:
            raise PolicyError("ERR_PUBLIC_BIND_REQUIRES_TLS_OR_INSECURE_OVERRIDE")
    return decision
