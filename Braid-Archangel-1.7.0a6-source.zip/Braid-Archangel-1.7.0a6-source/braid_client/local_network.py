"""Explicit numeric local/overlay endpoints. No DNS, wildcard or public fallback."""
from __future__ import annotations
import ipaddress
import json
import platform
import re
import shutil
import socket
import subprocess
import time

V4 = tuple(ipaddress.ip_network(x) for x in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16','127.0.0.0/8','100.64.0.0/10','169.254.1.0/24'))
LINK = ipaddress.ip_network('169.254.0.0/16')
DENY = {'169.254.169.254', '169.254.170.2', '169.254.170.23', '100.100.100.200'}


def local_address(value) -> str:
    text = str(value).strip()
    # Interface scope IDs are host-local, not portable in peer-signed cards.
    if '%' in text:
        raise ValueError('Scoped IPv6 link-local addresses are not portable rig endpoints. Use IPv6 ULA, Tailscale IPv4, or IPv4 link-local instead.')
    address = ipaddress.ip_address(text)
    if text in DENY or address.is_multicast or address.is_unspecified:
        raise ValueError('Choose a private LAN or overlay address, not a metadata, multicast or wildcard endpoint.')
    if address.version == 4:
        allowed = any(address in n for n in V4)
        if address in LINK:
            allowed = 1 <= address.packed[2] <= 254 and text not in DENY
    else:
        allowed = address == ipaddress.ip_address('::1') or address in ipaddress.ip_network('fc00::/7')
    if not allowed:
        raise ValueError('Choose a private LAN IPv4, overlay, IPv4 link-local, or IPv6 ULA address. Public Internet connections use Managed Relay.')
    return str(address)


def address_kind(value: str) -> str:
    ip = ipaddress.ip_address(value)
    if ip.is_loopback: return 'this machine only'
    if ip.version == 4 and ip in ipaddress.ip_network('100.64.0.0/10'): return 'overlay / CGNAT (verify your VPN)'
    if ip.is_link_local: return 'direct-link IPv4'
    if ip.version == 6: return 'IPv6 private / ULA'
    return 'private LAN'


def address_available(host: str) -> bool:
    try:
        host = local_address(host)
        with socket.socket(socket.AF_INET6 if ':' in host else socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind((host, 0))
        return True
    except (ValueError, OSError):
        return False

_cache = (0.0, [])
def local_addresses(refresh: bool = False) -> list[str]:
    global _cache
    if not refresh and time.monotonic() - _cache[0] < 15:
        return list(_cache[1])
    values = []
    commands = []
    system = platform.system()
    if system == 'Linux' and shutil.which('ip'):
        commands = [['ip','-j','address','show']]
    elif system == 'Darwin':
        commands = [['/sbin/ifconfig']]
    elif system == 'Windows':
        commands = [['powershell.exe','-NoProfile','-NonInteractive','-Command',
                     'Get-NetIPAddress | Select-Object -ExpandProperty IPAddress | ConvertTo-Json -Compress']]
    for command in commands:
        try:
            output = subprocess.run(command,capture_output=True,text=True,timeout=2,check=True).stdout
            if system == 'Linux':
                values.extend(a.get('local','') for item in json.loads(output) for a in item.get('addr_info',[]))
            elif system == 'Windows':
                data = json.loads(output); values.extend([data] if isinstance(data,str) else data)
            else:
                values.extend(re.findall(r'\binet6?\s+(\S+)',output))
        except (OSError, ValueError, subprocess.SubprocessError):
            pass
    try:
        values.extend(info[4][0] for info in socket.getaddrinfo(socket.gethostname(),None,type=socket.SOCK_STREAM))
    except OSError:
        pass
    from .environment import _private_ipv4_candidates
    values.extend(_private_ipv4_candidates())
    result = []
    for value in values + ['127.0.0.1','::1']:
        try:
            value = local_address(value)
            if value not in result: result.append(value)
        except ValueError:
            pass
    result.sort(key=lambda h: (ipaddress.ip_address(h).is_loopback, ':' in h, h))
    _cache = (time.monotonic(), result)
    return list(result)
