"""Signed channel descriptors and transport-independent note envelopes.

Descriptors identify a topic; they never grant publication, reception, or model
context permission. Those decisions belong to each receiving local profile.
The enclosing Braid frame signature binds this extension to the capsule/vector.
"""
from __future__ import annotations
import hashlib
import json
import re
import uuid
from typing import Any, Mapping
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from .keys import get_raw_public_bytes

CHANNEL_SCHEMA = 'intersignal.braid.channel.v1'
NOTE_SCHEMA = 'intersignal.braid.channel-note.v1'
EXTENSION = 'braid_channel_note'
HEX64 = re.compile(r'^[0-9a-f]{64}$')
HEX32 = re.compile(r'^[0-9a-f]{32}$')


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()


def label(value: Any, maximum: int = 64) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > maximum or any(ord(c) < 32 for c in value):
        raise ValueError('Use a nonempty ordinary text label within its size limit.')
    clean = value.strip().lstrip('#').strip()
    if not clean:
        raise ValueError('A label cannot contain only channel markers or whitespace.')
    return clean


def create_channel_descriptor(key, name: str, description: str = '') -> dict:
    public = get_raw_public_bytes(key.public_key()).hex()
    nonce = uuid.uuid4().hex
    body = dict(schema=CHANNEL_SCHEMA, name=label(name), description=label(description, 500) if description else '',
                creator_key=public, nonce=nonce)
    body['id'] = hashlib.sha256(b'BRAID-CHANNEL-ID-v1\0' + bytes.fromhex(public) + bytes.fromhex(nonce)).hexdigest()
    body['signature'] = key.sign(b'BRAID-CHANNEL-v1\0' + canonical(body)).hex()
    return body


def validate_channel_descriptor(value: Any) -> dict:
    keys = {'schema','name','description','creator_key','nonce','id','signature'}
    if not isinstance(value, Mapping) or set(value) != keys or value.get('schema') != CHANNEL_SCHEMA:
        raise ValueError('ERR_CHANNEL_DESCRIPTOR_SCHEMA')
    d = dict(value)
    if label(d['name']) != d['name'] or (d['description'] and label(d['description'], 500) != d['description']):
        raise ValueError('ERR_CHANNEL_DESCRIPTOR_LABEL')
    if not isinstance(d['description'], str):
        raise ValueError('ERR_CHANNEL_DESCRIPTION')
    if not all(isinstance(d[k], str) and HEX64.fullmatch(d[k]) for k in ('id','creator_key')):
        raise ValueError('ERR_CHANNEL_ID')
    if not isinstance(d['nonce'], str) or not HEX32.fullmatch(d['nonce']):
        raise ValueError('ERR_CHANNEL_NONCE')
    expected = hashlib.sha256(b'BRAID-CHANNEL-ID-v1\0'+bytes.fromhex(d['creator_key'])+bytes.fromhex(d['nonce'])).hexdigest()
    if d['id'] != expected:
        raise ValueError('ERR_CHANNEL_ID_BINDING')
    signature = d.pop('signature')
    try:
        if not isinstance(signature, str) or not re.fullmatch('[0-9a-f]{128}', signature):
            raise ValueError()
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(d['creator_key'])).verify(
            bytes.fromhex(signature), b'BRAID-CHANNEL-v1\0'+canonical(d))
    except Exception as exc:
        raise ValueError('ERR_CHANNEL_DESCRIPTOR_SIGNATURE') from exc
    d['signature'] = signature
    return d


def note_extension(descriptor: dict, note_id: str, text: str, origin: str = 'reviewed_note') -> dict:
    d = dict(schema=NOTE_SCHEMA, channel=validate_channel_descriptor(descriptor), note_id=note_id,
             content_sha256=hashlib.sha256(text.encode('utf-8')).hexdigest(), origin=origin)
    return validate_note_extension(d, text)


def validate_note_extension(value: Any, material: str) -> dict:
    if not isinstance(value, Mapping) or set(value) != {'schema','channel','note_id','content_sha256','origin'} or value.get('schema') != NOTE_SCHEMA:
        raise ValueError('ERR_CHANNEL_NOTE_SCHEMA')
    v = dict(value)
    v['channel'] = validate_channel_descriptor(v['channel'])
    if not isinstance(v['note_id'], str) or not HEX32.fullmatch(v['note_id']):
        raise ValueError('ERR_CHANNEL_NOTE_ID')
    if v['origin'] not in ('reviewed_note','marked_local_note'):
        raise ValueError('ERR_CHANNEL_NOTE_ORIGIN')
    if v['content_sha256'] != hashlib.sha256(material.encode('utf-8')).hexdigest():
        raise ValueError('ERR_CHANNEL_CONTENT_BINDING')
    return v


def extract_channel_note(manifest: Mapping[str, Any], material: str) -> dict | None:
    ext = manifest.get('extensions', {})
    if not isinstance(ext, Mapping):
        raise ValueError('ERR_CHANNEL_EXTENSIONS')
    if EXTENSION not in ext:
        return None
    return validate_note_extension(ext[EXTENSION], material)
