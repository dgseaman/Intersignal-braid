"""
Standards-Compliant ISO/IEC 18004 QR Encoder & Bounded Optical Chunk Stream Collector
--------------------------------------------------------------------------------------
Implements ISO/IEC 18004 Reed-Solomon GF(256) QR Code matrix generation and bounded multi-frame
chunk reassembly for optical Braid state frame streaming.
"""

class QRCapacityError(ValueError):
    """Raised when text or a BRAD1 chunk cannot fit supported QR versions."""
    code = "ERR_QR_CAPACITY"

import base64
import zlib
import hashlib
import math
import time
import numpy as np
from typing import Dict, Any, List, Tuple, Optional

# --- ISO/IEC 18004 Reed-Solomon GF(256) QR Code Encoder ---

GF256_EXP = [0] * 512
GF256_LOG = [0] * 256

def _init_gf256():
    x = 1
    for i in range(255):
        GF256_EXP[i] = x
        GF256_EXP[i + 255] = x
        GF256_LOG[x] = i
        x <<= 1
        if x & 0x100:
            x ^= 0x11d
_init_gf256()

def _gf256_mul(x: int, y: int) -> int:
    if x == 0 or y == 0:
        return 0
    return GF256_EXP[GF256_LOG[x] + GF256_LOG[y]]

def _rs_poly_mul(p1: List[int], p2: List[int]) -> List[int]:
    r = [0] * (len(p1) + len(p2) - 1)
    for j in range(len(p2)):
        for i in range(len(p1)):
            r[i + j] ^= _gf256_mul(p1[i], p2[j])
    return r

def _rs_encode(data: List[int], nsym: int) -> List[int]:
    g = [1]
    for i in range(nsym):
        g = _rs_poly_mul(g, [1, GF256_EXP[i]])
    res = list(data) + [0] * nsym
    for i in range(len(data)):
        coef = res[i]
        if coef != 0:
            for j in range(len(g)):
                res[i + j] ^= _gf256_mul(g[j], coef)
    return res[len(data):]

def _get_format_info(ec_bits: int = 0, mask: int = 0) -> int:
    val = (ec_bits << 3) | mask
    gen = 0x537
    rem = val << 10
    for i in range(14, 9, -1):
        if (rem >> i) & 1:
            rem ^= (gen << (i - 10))
    return ((val << 10) | rem) ^ 0x5412

def _get_version_info(ver: int) -> int:
    if ver < 7:
        return 0
    val = ver
    gen = 0x1F25
    rem = val << 12
    for i in range(17, 11, -1):
        if (rem >> i) & 1:
            rem ^= (gen << (i - 12))
    return (val << 12) | rem

# Reed-Solomon specs for QR Level M (15% EC)
# ver: ([(num_blocks, data_per_block, ec_per_block), ...], align_coords)
RS_SPECS_M = {
    1: ([(1, 16, 10)], []),
    2: ([(1, 28, 16)], [6, 18]),
    3: ([(1, 44, 26)], [6, 22]),
    4: ([(2, 32, 18)], [6, 26]),
    5: ([(2, 43, 24)], [6, 30]),
    6: ([(4, 27, 16)], [6, 34]),
    7: ([(4, 31, 18)], [6, 22, 38]),
    8: ([(2, 38, 22), (2, 39, 22)], [6, 24, 42]),
    9: ([(3, 36, 22), (2, 37, 22)], [6, 26, 46]),
    10: ([(4, 43, 26), (1, 44, 26)], [6, 28, 50]),
    11: ([(1, 50, 30), (4, 51, 30)], [6, 30, 54]),
    12: ([(6, 36, 22), (2, 37, 22)], [6, 32, 58]),
}



def qr_text_capacity_bytes(version: int) -> int:
    """Maximum UTF-8 byte payload for byte mode at Level M for a supported version."""
    if version not in RS_SPECS_M:
        raise QRCapacityError(f"ERR_QR_CAPACITY: Unsupported QR version {version}.")
    blocks_spec, _ = RS_SPECS_M[version]
    total_data_codewords = sum(count * data for count, data, _ in blocks_spec)
    count_bits = 8 if version < 10 else 16
    return max(0, (total_data_codewords * 8 - 4 - count_bits - 4) // 8)


def max_qr_text_capacity_bytes() -> int:
    return max(qr_text_capacity_bytes(v) for v in RS_SPECS_M)


def _select_qr_version(data_len: int) -> int:
    for version in sorted(RS_SPECS_M):
        if data_len <= qr_text_capacity_bytes(version):
            return version
    raise QRCapacityError(
        f"ERR_QR_CAPACITY: {data_len} UTF-8 bytes exceed supported Level-M "
        f"capacity of {max_qr_text_capacity_bytes()} bytes (versions 1-{max(RS_SPECS_M)})."
    )


class StandardQRCodeEncoder:
    """
    ISO/IEC 18004 Standards-Compliant QR Code Matrix Generator.
    Generates 100% decodable 2D QR matrices with Reed-Solomon error correction for optical transport.
    """
    def __init__(self, text: str, ecc_level: str = 'M'):
        self.text = text
        self.text_bytes = text.encode('utf-8')
        self.ecc_level = ecc_level
        self.matrix, self.version, self.size = self._generate_matrix()

    def _generate_matrix(self) -> Tuple[List[List[int]], int, int]:
        data_len = len(self.text_bytes)
        ver = _select_qr_version(data_len)

        blocks_spec, align_pos = RS_SPECS_M[ver]
        tot_data = sum(b_count * b_data for b_count, b_data, _ in blocks_spec)
        size = 17 + ver * 4

        matrix = np.full((size, size), -1, dtype=np.int8)

        # 1. Place Finder Patterns
        def place_finder(r, c):
            for dr in range(-1, 8):
                for dc in range(-1, 8):
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < size and 0 <= nc < size:
                        if 0 <= dr <= 6 and 0 <= dc <= 6:
                            if dr in (0, 6) or dc in (0, 6) or (2 <= dr <= 4 and 2 <= dc <= 4):
                                matrix[nr, nc] = 1
                            else:
                                matrix[nr, nc] = 0
                        else:
                            matrix[nr, nc] = 0

        place_finder(0, 0)
        place_finder(size - 7, 0)
        place_finder(0, size - 7)

        # 2. Timing Patterns
        for i in range(8, size - 8):
            if matrix[6, i] == -1: matrix[6, i] = 1 if i % 2 == 0 else 0
            if matrix[i, 6] == -1: matrix[i, 6] = 1 if i % 2 == 0 else 0

        # 3. Alignment Patterns
        for r in align_pos:
            for c in align_pos:
                if (r == 6 and c == 6) or (r == 6 and c == size - 7) or (r == size - 7 and c == 6):
                    continue
                for dr in range(-2, 3):
                    for dc in range(-2, 3):
                        if matrix[r + dr, c + dc] == -1:
                            val = 1 if abs(dr) == 2 or abs(dc) == 2 or (dr == 0 and dc == 0) else 0
                            matrix[r + dr, c + dc] = val

        # 4. Format & Version Areas Reservation
        matrix[size - 8, 8] = 1  # Dark module
        for i in range(9):
            if matrix[8, i] == -1: matrix[8, i] = 0
            if matrix[i, 8] == -1: matrix[i, 8] = 0
        for i in range(size - 8, size):
            if matrix[8, i] == -1: matrix[8, i] = 0
            if matrix[i, 8] == -1: matrix[i, 8] = 0

        if ver >= 7:
            for r in range(6):
                for c in range(size - 11, size - 8):
                    matrix[r, c] = 0
                    matrix[c, r] = 0

        # 5. Build Bitstream (Byte Mode: 0100)
        bits = [0, 1, 0, 0]
        count_bits = 8 if ver < 10 else 16
        for b in range(count_bits - 1, -1, -1):
            bits.append((data_len >> b) & 1)
        for byte in self.text_bytes:
            for b in range(7, -1, -1):
                bits.append((byte >> b) & 1)

        term_len = min(4, tot_data * 8 - len(bits))
        bits.extend([0] * term_len)
        while len(bits) % 8 != 0:
            bits.append(0)

        pad = [0xEC, 0x11]
        p_idx = 0
        while len(bits) < tot_data * 8:
            pb = pad[p_idx % 2]
            for b in range(7, -1, -1):
                bits.append((pb >> b) & 1)
            p_idx += 1

        code_bytes = []
        for i in range(0, len(bits), 8):
            v = 0
            for b in range(8):
                v = (v << 1) | bits[i + b]
            code_bytes.append(v)

        # 6. Reed-Solomon Blocks & Interleaving
        data_blocks = []
        ec_blocks = []
        curr_idx = 0
        for b_count, b_data, b_ec in blocks_spec:
            for _ in range(b_count):
                sub = code_bytes[curr_idx : curr_idx + b_data]
                curr_idx += b_data
                data_blocks.append(sub)
                ec_blocks.append(_rs_encode(sub, b_ec))

        final_bytes = []
        max_d_len = max(len(b) for b in data_blocks)
        for i in range(max_d_len):
            for bk in range(len(data_blocks)):
                if i < len(data_blocks[bk]):
                    final_bytes.append(data_blocks[bk][i])

        max_e_len = max(len(b) for b in ec_blocks)
        for i in range(max_e_len):
            for bk in range(len(ec_blocks)):
                if i < len(ec_blocks[bk]):
                    final_bytes.append(ec_blocks[bk][i])

        all_bits = []
        for b in final_bytes:
            for bit in range(7, -1, -1):
                all_bits.append((b >> bit) & 1)

        # 7. Interleaved Matrix Placement with Mask 0
        bit_idx = 0
        x = size - 1
        up = True
        while x > 0:
            if x == 6: x -= 1
            y_range = range(size - 1, -1, -1) if up else range(size)
            for y in y_range:
                for col in (x, x - 1):
                    if matrix[y, col] == -1:
                        val = all_bits[bit_idx] if bit_idx < len(all_bits) else 0
                        bit_idx += 1
                        mask = 1 if ((y + col) % 2 == 0) else 0
                        matrix[y, col] = val ^ mask
            up = not up
            x -= 2

        # 8. Format Info
        fmt = _get_format_info(ec_bits=0, mask=0)
        tl = [(8,0), (8,1), (8,2), (8,3), (8,4), (8,5), (8,7), (8,8), (7,8), (5,8), (4,8), (3,8), (2,8), (1,8), (0,8)]
        for i, (r, c) in enumerate(tl):
            matrix[r, c] = (fmt >> (14 - i)) & 1
        for i in range(7):
            matrix[size - 1 - i, 8] = (fmt >> (14 - i)) & 1
        for i in range(8):
            matrix[8, size - 8 + i] = (fmt >> i) & 1

        # 9. Version Info for ver >= 7
        if ver >= 7:
            v_info = _get_version_info(ver)
            for i in range(18):
                bit = (v_info >> i) & 1
                r = size - 11 + (i % 3)
                c = i // 3
                matrix[r, c] = bit
                matrix[c, r] = bit

        return matrix.tolist(), ver, size


# --- Bounded Stateful Optical Chunk Stream Collector ---

class OpticalChunkCollector:
    """
    Bounded stateful collector for reassembling multi-frame optical QR streams.
    Validates frame_id syntax, total chunk counts, CRC32, strict Base64, duplicate
    equality, and expires stale session streams cleanly.
    """
    def __init__(self, max_aggregate_bytes: int = 102400, session_ttl_seconds: int = 300):
        self.sessions: Dict[str, Dict[str, Any]] = {}
        self.max_aggregate_bytes = max_aggregate_bytes
        self.session_ttl_seconds = session_ttl_seconds

    def _cleanup_expired_sessions(self):
        now = time.time()
        expired = [fid for fid, sess in self.sessions.items() if now - sess["last_updated"] > self.session_ttl_seconds]
        for fid in expired:
            del self.sessions[fid]

    def reset_session(self, frame_id: Optional[str] = None):
        if frame_id:
            if frame_id in self.sessions:
                del self.sessions[frame_id]
        else:
            self.sessions.clear()

    def ingest_chunk_string(self, chunk_str: str) -> Dict[str, Any]:
        """
        Parses and ingests an optical chunk formatted as:
        BRAD1:<frame_id>:<total_chunks>:<chunk_idx>:<crc32>:<base64_data>
        """
        self._cleanup_expired_sessions()

        if not isinstance(chunk_str, str):
            return {"status": "error", "error": "ERR_INVALID_CHUNK_TYPE: Chunk string must be str."}

        s = chunk_str.strip()
        parts = s.split(":")
        if len(parts) < 6 or parts[0] != "BRAD1":
            return {"status": "error", "error": "ERR_INVALID_CHUNK_HEADER: Must start with BRAD1:"}

        frame_id = parts[1]
        # Frame ID syntax check: 8-char hex string
        if len(frame_id) != 8 or not all(c in "0123456789abcdefABCDEF" for c in frame_id):
            return {"status": "error", "error": f"ERR_INVALID_FRAME_ID: Frame ID must be 8 hex chars, got '{frame_id}'"}

        try:
            total_chunks = int(parts[2])
            chunk_idx = int(parts[3])
            expected_crc = parts[4].lower()
            base64_data = parts[5]
        except Exception as e:
            return {"status": "error", "error": f"ERR_MALFORMED_CHUNK_FIELDS: {str(e)}"}

        # Validate total count bounds: 1 <= total <= 100
        if total_chunks < 1 or total_chunks > 100:
            return {"status": "error", "error": f"ERR_CHUNK_COUNT_BOUNDS: Total chunks must be 1..100, got {total_chunks}"}

        # Validate index range
        if chunk_idx < 0 or chunk_idx >= total_chunks:
            return {"status": "error", "error": f"ERR_CHUNK_INDEX_OUT_OF_RANGE: Index {chunk_idx} invalid for total {total_chunks}"}

        # CRC32 validation
        actual_crc = f"{zlib.crc32(base64_data.encode('ascii')) & 0xFFFFFFFF:08x}".lower()
        if actual_crc != expected_crc:
            return {
                "status": "error",
                "error": f"ERR_CRC32_MISMATCH: Chunk {chunk_idx} expected {expected_crc}, got {actual_crc}"
            }

        # Strict Base64 decoding check
        try:
            raw_chunk_bytes = base64.b64decode(base64_data, validate=True)
        except Exception as e:
            return {"status": "error", "error": f"ERR_BASE64_DECODE: Strict Base64 validation failed: {str(e)}"}

        # Get or create session entry for frame_id
        if frame_id not in self.sessions:
            self.sessions[frame_id] = {
                "total_chunks": total_chunks,
                "chunks": {},
                "created_at": time.time(),
                "last_updated": time.time()
            }

        session = self.sessions[frame_id]
        if session["total_chunks"] != total_chunks:
            return {"status": "error", "error": f"ERR_TOTAL_CHUNKS_MISMATCH: Session expected {session['total_chunks']}, got {total_chunks}"}

        session["last_updated"] = time.time()

        # Duplicate Chunk Handling
        if chunk_idx in session["chunks"]:
            existing_data = session["chunks"][chunk_idx]
            if existing_data != base64_data:
                return {"status": "error", "error": f"ERR_CONFLICTING_DUPLICATE: Duplicate chunk {chunk_idx} has conflicting payload."}
            # Idempotent skip for identical duplicate
        else:
            session["chunks"][chunk_idx] = base64_data

        received_count = len(session["chunks"])
        is_complete = received_count == total_chunks

        reassembled_bytes = None
        if is_complete:
            full_b64 = "".join([session["chunks"][i] for i in range(total_chunks)])
            reassembled_bytes = base64.b64decode(full_b64)

            # Aggregate size check
            if len(reassembled_bytes) > self.max_aggregate_bytes:
                return {"status": "error", "error": f"ERR_FRAME_SIZE_LIMIT: Reassembled frame size {len(reassembled_bytes)} > limit {self.max_aggregate_bytes}"}

        return {
            "status": "success",
            "frame_id": frame_id,
            "chunk_idx": chunk_idx,
            "total_chunks": total_chunks,
            "received_count": received_count,
            "is_complete": is_complete,
            "reassembled_bytes": reassembled_bytes
        }




def _validate_chunk_size(raw_frame_bytes: bytes, max_chunk_size: int) -> Tuple[str, int]:
    if isinstance(max_chunk_size, bool) or not isinstance(max_chunk_size, int):
        raise ValueError("ERR_CHUNK_SIZE: max_chunk_size must be an integer.")
    if max_chunk_size <= 0:
        raise ValueError("ERR_CHUNK_SIZE: max_chunk_size must be positive.")
    if max_chunk_size % 4 != 0:
        raise ValueError("ERR_CHUNK_SIZE: max_chunk_size must be a multiple of four.")

    b64_str = base64.b64encode(raw_frame_bytes).decode("ascii")
    num_chunks = max(1, math.ceil(len(b64_str) / max_chunk_size))
    if num_chunks > 100:
        raise ValueError(
            f"ERR_CHUNK_COUNT_BOUNDS: Chunk size {max_chunk_size} produces {num_chunks} chunks; maximum is 100."
        )

    frame_id = hashlib.sha256(raw_frame_bytes).hexdigest()[:8]
    max_index = num_chunks - 1
    prefix = f"BRAD1:{frame_id}:{num_chunks}:{max_index}:ffffffff:"
    longest_text_bytes = len(prefix.encode("ascii")) + min(max_chunk_size, len(b64_str))
    capacity = max_qr_text_capacity_bytes()
    if longest_text_bytes > capacity:
        raise QRCapacityError(
            f"ERR_QR_CAPACITY: Formatted BRAD1 chunk requires {longest_text_bytes} bytes, "
            f"but supported QR capacity is {capacity}. Reduce max_chunk_size."
        )
    return b64_str, num_chunks


def chunk_binary_frame(raw_frame_bytes: bytes, max_chunk_size: int = 120) -> List[Dict[str, Any]]:
    """Split raw frame bytes into bounded, QR-capacity-safe BRAD1 strings."""
    if not isinstance(raw_frame_bytes, (bytes, bytearray)):
        raise TypeError("ERR_FRAME_TYPE: raw_frame_bytes must be bytes-like.")
    b64_str, num_chunks = _validate_chunk_size(bytes(raw_frame_bytes), max_chunk_size)
    frame_id = hashlib.sha256(raw_frame_bytes).hexdigest()[:8]

    chunks: List[Dict[str, Any]] = []
    for idx in range(num_chunks):
        start = idx * max_chunk_size
        chunk_data = b64_str[start:start + max_chunk_size]
        crc = f"{zlib.crc32(chunk_data.encode('ascii')) & 0xFFFFFFFF:08x}"
        formatted_str = f"BRAD1:{frame_id}:{num_chunks}:{idx}:{crc}:{chunk_data}"
        StandardQRCodeEncoder(formatted_str)
        chunks.append({
            "frame_id": frame_id,
            "total_chunks": num_chunks,
            "chunk_index": idx,
            "crc32": crc,
            "chunk_str": formatted_str,
            "base64_data": chunk_data,
        })
    return chunks


def rasterize_qr_matrix(
    matrix: List[List[int]], module_scale: int = 8, quiet_zone_modules: int = 4
) -> np.ndarray:
    """Rasterize a QR matrix to uint8 grayscale with an exact quiet zone."""
    if module_scale < 1 or int(module_scale) != module_scale:
        raise ValueError("ERR_QR_SCALE: module_scale must be a positive integer.")
    if quiet_zone_modules < 4 or int(quiet_zone_modules) != quiet_zone_modules:
        raise ValueError("ERR_QR_QUIET_ZONE: quiet zone must be an integer of at least four modules.")
    arr = np.asarray(matrix, dtype=np.uint8)
    if arr.ndim != 2 or arr.shape[0] != arr.shape[1] or not np.isin(arr, [0, 1]).all():
        raise ValueError("ERR_QR_MATRIX: matrix must be square and binary.")
    modules = arr.shape[0] + 2 * quiet_zone_modules
    image = np.full((modules, modules), 255, dtype=np.uint8)
    q = quiet_zone_modules
    image[q:q + arr.shape[0], q:q + arr.shape[1]] = np.where(arr == 1, 0, 255).astype(np.uint8)
    return np.repeat(np.repeat(image, module_scale, axis=0), module_scale, axis=1)


def decode_qr_raster(image: np.ndarray) -> str:
    """Decode a raster through a bounded, independent image channel."""
    try:
        import cv2
    except ImportError as exc:
        raise RuntimeError(
            "ERR_QR_DECODER_UNAVAILABLE: Install braid-client[camera] for OpenCV fallback decoding."
        ) from exc
    try:
        cv2.setNumThreads(1)
        cv2.ocl.setUseOpenCL(False)
    except Exception:
        pass
    arr = np.asarray(image)
    if arr.ndim == 3:
        arr = cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)
    arr = np.ascontiguousarray(arr.astype(np.uint8, copy=False))
    h, w = arr.shape[:2]
    variants = [
        arr,
        cv2.GaussianBlur(arr, (3, 3), 0),
        cv2.erode(arr, np.ones((2, 2), np.uint8), iterations=1),
        cv2.copyMakeBorder(arr, 20, 20, 20, 20, cv2.BORDER_CONSTANT, value=255),
    ]
    for angle in (-3.0, 3.0, -7.0, 7.0):
        rotation = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), angle, 1.0)
        variants.append(cv2.warpAffine(
            arr, rotation, (w, h), flags=cv2.INTER_LINEAR, borderValue=255
        ))
    detector = cv2.QRCodeDetector()
    for candidate in variants:
        text, points, _ = detector.detectAndDecode(candidate)
        if text:
            return text
    try:
        from pyzbar.pyzbar import decode as zbar_decode
        decoded = zbar_decode(arr)
        if decoded:
            return decoded[0].data.decode("utf-8")
    except (ImportError, OSError, UnicodeDecodeError):
        pass
    raise ValueError("ERR_QR_DECODE: No decodable QR symbol found after bounded retries.")
