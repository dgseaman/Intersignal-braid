/* Braid Messenger: a small, dependency-free view over receiver-owned state. */
'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const bytes = value => new TextEncoder().encode(value || '').length;
  const paths = {
    plus:'M12 5v14M5 12h14', close:'m6 6 12 12M18 6 6 18', check:'m5 12 4 4L19 6',
    compose:'M14 4 20 10M4 20l5-1L20 8a2.1 2.1 0 0 0-4-4L5 15l-1 5Z',
    inbox:'M4 4h16l2 12v4H2v-4L4 4ZM2 15h6l2 3h4l2-3h6',
    send:'m3 3 19 9-19 9 4-9-4-9Zm4 9h15',file:'M14 2H5v20h14V7l-5-5Zm0 0v6h5M8 12h8M8 16h6',
    alert:'m12 3 10 18H2L12 3ZM12 9v5M12 17v.1',archive:'M3 3h18v5H3V3Zm2 5v13h14V8M9 12h6',
    refresh:'M20 8a8 8 0 0 0-14-3L3 8m0-5v5h5M4 16a8 8 0 0 0 14 3l3-3m0 5v-5h-5',
    field:'M4 4h6v6H4V4Zm10 0h6v6h-6V4ZM4 14h6v6H4v-6Zm10 0h6v6h-6v-6Z',
    settings:'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8ZM9 3h6l1 3 3 1 2 5-2 5-3 1-1 3H9l-1-3-3-1-2-5 2-5 3-1 1-3Z',
    search:'M10.5 3a7.5 7.5 0 1 0 0 15 7.5 7.5 0 0 0 0-15ZM16 16l5 5',
    lock:'M5 10h14v11H5V10Zm3 0V6a4 4 0 0 1 8 0v4M12 14v3',
    shield:'m12 2 8 3v7c0 5-8 10-8 10S4 17 4 12V5l8-3Zm-4 9 3 3 5-6',
    rig:'M3 3h18v13H3V3Zm5 18h8M12 16v5M7 12h10',
    spark:'m12 3 2.3 6.7L21 12l-6.7 2.3L12 21l-2.3-6.7L3 12l6.7-2.3L12 3Z',
    braid:'M4 3c18 0-2 18 16 18M20 3C2 3 22 21 4 21M5 3v18M19 3v18',
    copy:'M8 8h13v13H8V8ZM16 8V3H3v13h5', back:'m14 6-6 6 6 6M8 12h12',
    clock:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm0 4v5l3 2',dots:'M5 12h.1M12 12h.1M19 12h.1'
  };
  const icon = name => `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name] || paths.file}"/></svg>`;
  document.querySelectorAll('[data-icon]').forEach(e => { e.innerHTML = icon(e.dataset.icon); });
  const labels = {indexed:'Accepted & indexed',accepted:'Accepted · not indexed',accepted_legacy:'Accepted · legacy receipt',rejected:'Not accepted',sending:'Awaiting receipt',queued:'Queued locally',outcome_unknown:'Receipt not confirmed',failed:'Not sent · preparation failed'};
  const attention = m => ['accepted','rejected','outcome_unknown','failed'].includes(m.stage);
  const title = {inbox:'Inbox',sent:'Sent',drafts:'Drafts',attention:'Needs attention',archive:'Archive'};
  let handoffId = '', deliveryCache = {};
  const frozenStages = ['indexed','accepted','accepted_legacy','sending','queued','outcome_unknown'];
  const newHandoffId = () => crypto.randomUUID().replace(/-/g,'');
  let state = null, folder = 'inbox', selected = null, peerFilter = '', renderKey = '', refreshPending = false;
  let csrf = '', composeMode = 'write', payloadKind = 'summary', deltaObject = '', inspection = null, activeTab = 'own';
  let relayPeers = [], working = false, sourceMethod = '', toastTimer;
  const isPreview = !!window.BRAID_PREVIEW;
  async function api(path, data) {
    if (isPreview) return window.BRAID_PREVIEW.request(path, data);
    const response = await fetch('/api/messenger/' + path, {method:data === undefined ? 'GET' : 'POST',
      headers:data === undefined ? {} : {'Content-Type':'application/json','X-Braid-CSRF':csrf},
      body:data === undefined ? undefined : JSON.stringify(data), cache:'no-store'});
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || result.error || 'The local service could not complete this request.');
    return result;
  }
  function toast(text) {
    $('toast').textContent = text; $('toast').hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { $('toast').hidden = true; }, 6500);
  }
  async function safely(fn) { try { return await fn(); } catch (e) { toast(e.message || String(e)); return null; } }
  async function busy(button, label, fn) {
    if (button.disabled) return;
    const original = button.innerHTML, nestedIds = !!button.querySelector('[id]'); button.disabled = true; button.setAttribute('aria-busy','true'); if (!nestedIds) button.textContent = label;
    try { return await fn(); } catch (e) { toast(e.message || String(e)); return null; }
    finally { if (!nestedIds) button.innerHTML = original; button.disabled = false; button.removeAttribute('aria-busy'); updateCompose(); }
  }
  async function job(path, data, progress) {
    const pending = await api(path, data);
    if (!pending.job_id) return pending;
    for (;;) {
      const current = await api('job?id=' + encodeURIComponent(pending.job_id));
      $('activityStatus').textContent = current.kind + (current.status === 'queued' ? ' · queued' : '…');
      if (progress) progress(current);
      if (current.status === 'done') { await refresh(); return current.result; }
      if (current.status === 'error') { await refresh(); throw new Error(current.error || 'Operation failed.'); }
      await new Promise(r => setTimeout(r, 650));
    }
  }
  async function refresh() {
    if (refreshPending) return;
    refreshPending = true;
    try { state = await api('state'); csrf = state.csrf; $('offlineBar').hidden = true;
      for(const d of state.deliveries||[]) if(d.handoff===handoffId) deliveryCache[d.peer]=d.stage;
      render(); if($('composeDialog').open) updateCompose(); }
    catch (e) { $('offlineBar').hidden = false; }
    finally { refreshPending = false; }
  }
  function peerName(id) {
    return state?.peers.find(p => p.id === id)?.name || relayPeers.find(p => p.id === id)?.name || (id && !/^[a-f0-9]{64}$/.test(id) ? id : 'Approved rig');
  }
  function date(value, long = false) {
    const d = new Date(Number(value) * 1000);
    if (!Number.isFinite(d.getTime())) return '';
    return d.toLocaleString(undefined, long ? {month:'short',day:'numeric',hour:'numeric',minute:'2-digit'} :
      (d.toDateString() === new Date().toDateString() ? {hour:'numeric',minute:'2-digit'} : {month:'short',day:'numeric'}));
  }
  function tag(stage) { return `<span class="pill ${stage === 'indexed' ? 'green' : ['accepted','rejected','outcome_unknown','failed'].includes(stage) ? 'amber' : ''}">${esc(labels[stage] || stage)}</span>`; }
  function visibleMessages() {
    const query = $('search').value.trim().toLowerCase();
    return (state?.messages || []).filter(m => {
      const inFolder = folder === 'archive' ? m.archived : !m.archived && (folder === 'inbox' ? m.direction === 'in' : folder === 'sent' ? m.direction === 'out' : folder === 'attention' ? attention(m) : false);
      return inFolder && (!peerFilter || m.peer === peerFilter) && (!query || (m.text + ' ' + m.title + ' ' + peerName(m.peer)).toLowerCase().includes(query));
    });
  }
  function render() {
    if (!state) return;
    $('previewBanner').hidden = !isPreview; $('localName').textContent = state.settings.name;
    $('listenLabel').textContent = state.network?.available===false ? 'Address changed' : state.listener.running ? 'Receiving' : 'Receiving paused';
    $('networkWarning').hidden=!state.network?.warning; $('networkWarning').textContent=state.network?.warning||'';
    $('listenButton').setAttribute('aria-pressed', String(state.listener.running));
    $('localDot').className = 'dot' + (state.listener.running ? ' online' : '');
    $('inboxCount').textContent = state.messages.filter(m => m.direction === 'in' && m.unread && !m.archived).length;
    $('sentCount').textContent = state.messages.filter(m => m.direction === 'out' && !m.archived).length || '';
    $('draftCount').textContent = state.draft ? '1' : '';
    const alerts = state.messages.filter(m => attention(m) && !m.archived).length;
    $('attentionCount').textContent = alerts; $('attentionCount').hidden = !alerts;
    const atoms = state.field.indexed_atom_count || 0, objects = state.field.indexed_object_count || 0;
    $('fieldSummary').textContent = atoms ? `${atoms} items · ${objects} handoffs` : 'No indexed state yet';
    $('rigList').innerHTML = state.peers.length ? state.peers.map(p => {
      const recent = p.presence && Date.now()/1000 - p.presence.checked < 45;
      const present = recent && p.presence.reachable;
      return `<button class="rig ${peerFilter === p.id ? 'active' : ''}" data-peer="${esc(p.id)}" title="${esc(p.receiver_error || (present ? 'Pinned TLS listener reachable; acceptance is checked per transfer.' : recent ? 'Listener not reachable on last check.' : 'Connection not checked recently.'))}"><span class="avatar">${esc(p.name.slice(0,1).toUpperCase())}<span class="dot ${present ? 'online' : ''}"></span></span><span class="rig-info"><strong>${esc(p.name)}</strong><small>${p.receiver_error ? 'Setup needs attention' : present ? 'Reachable · LAN' : recent ? 'Not reachable' : 'Approved · unchecked'}</small></span></button>`;
    }).join('') : '<div class="sidebar-note">Your machines belong here.<br>Add a rig to begin.</div>';
    const running = state.jobs.filter(j => ['running','queued'].includes(j.status));
    $('networkStatus').innerHTML = `<span class="dot ${state.listener.running ? 'online' : ''}"></span>${state.listener.running ? 'TLS 1.3 · receiving' : 'Local workspace · paused'}`;
    $('activityStatus').textContent = running.length ? running.map(j=>j.kind).join(' · ') : state.listener.error || (atoms ? `${atoms} context items indexed. Ready for the next handoff.` : 'Ready when you are.');
    renderList(); renderReader();
    window.dispatchEvent(new CustomEvent('braid:state',{detail:state}));
  }
  function renderList() {
    $('folderTitle').textContent = peerFilter ? peerName(peerFilter) : title[folder];
    document.querySelectorAll('[data-folder]').forEach(e => { e.classList.toggle('active', e.dataset.folder === folder && !peerFilter); e.setAttribute('aria-current', e.classList.contains('active') ? 'page' : 'false'); });
    $('listLabel').textContent = folder === 'attention' ? 'RECEIPTS TO REVIEW' : 'LATEST ACTIVITY';
    $('markAllButton').hidden = !['inbox','attention'].includes(folder);
    if (folder === 'drafts') {
      $('folderMeta').textContent = 'Nothing leaves until you send.';
      $('messageList').innerHTML = state.draft ? `<button class="message-item" data-draft="true"><div class="message-top"><span class="message-sender">Saved on this rig</span><span class="pill">Draft</span></div><div class="message-subject">${esc(state.draft.title || 'Untitled summary')}</div><div class="message-preview">${esc(state.draft.review || state.draft.source || 'Continue your handoff.')}</div></button>` : '<div class="empty-list">No draft waiting.<br>A useful thought is a good place to start.</div>';
      return;
    }
    const messages = visibleMessages();
    $('folderMeta').textContent = `${messages.length} ${messages.length === 1 ? 'handoff' : 'handoffs'}${folder === 'attention' ? ' to review' : ' · state, with receipts'}`;
    $('messageList').innerHTML = messages.length ? messages.map(m => `<button class="message-item ${selected === m.id ? 'selected' : ''}" role="listitem" data-message="${esc(m.id)}" aria-label="${esc(peerName(m.peer) + ': ' + m.title)}" aria-current="${selected === m.id}"><div class="message-top"><span class="message-sender">${m.unread ? '<span class="unread-dot"></span>' : ''}${m.direction === 'out' ? 'To ' : ''}${esc(peerName(m.peer))}</span><span class="message-time">${esc(date(m.created))}</span></div><div class="message-subject">${esc(m.title)}</div><div class="message-preview">${esc(m.text || m.payload?.error || 'Open the receipt for details.')}</div><div class="message-bottom">${tag(m.stage)}${m.payload?.kind === 'delta' ? '<span class="pill">Delta</span>' : ''}</div></button>`).join('') : `<div class="empty-list">${$('search').value ? 'No matching handoffs.' : folder === 'inbox' ? 'A little quieter than your chat apps.<br>When another rig shares state,<br>its receipt will appear here.' : folder === 'attention' ? 'Nothing needs your attention.' : 'No handoffs here yet.'}</div>`;
  }
  function renderReader(force = false) {
    const m = state.messages.find(m => m.id === selected);
    const key = m ? JSON.stringify([m.id,m.stage,m.archived,m.unread,m.payload]) : 'empty:' + folder + ':' + state.peers.length;
    if (!force && key === renderKey) return;
    renderKey = key;
    document.querySelector('.mail-layout').classList.toggle('has-selection', !!m);
    if (!m) {
      $('readingPane').innerHTML = `<div class="welcome empty"><div class="welcome-mark">${icon('braid')}</div><span class="eyebrow">YOUR MACHINES. A SHARED THREAD.</span><h2>Good context<br>should travel.</h2><p>Send the useful part. Keep the receipt.<br>Let your own rigs pick up where you left off.</p><button class="btn primary" data-welcome="${state.peers.length ? 'share' : 'rig'}">${icon(state.peers.length ? 'compose' : 'plus')}${state.peers.length ? 'Share a summary' : 'Add your first rig'}</button><div class="welcome-note">Local models. Explicit trust. Receiver-owned state.</div></div>`;
      return;
    }
    const committed = ['indexed','accepted','accepted_legacy'].includes(m.stage), indexed = m.stage === 'indexed';
    const payload = m.payload || {};
    let note = indexed ? 'The receiver committed this object and indexed its semantic material. It is available for receiver-local retrieval; this is not proof that a model used it in an answer.' : committed ? 'The receiver accepted this object, but this receipt does not confirm field indexing. Retained state can be inspected and reindexed from Shared field.' : m.stage === 'failed' ? 'Local preparation failed before any network send. Correct the reported issue before trying again.' : m.stage === 'outcome_unknown' ? 'No confirmed receipt. The receiver may already have committed this object. Check its inbox before sending again; Braid does not automatically retry.' : m.stage === 'sending' ? 'The transfer is in progress. Acceptance will be shown only when the receiver returns a commit receipt.' : 'The receiver did not confirm acceptance. Open the technical receipt to inspect the reason.';
    const digest = payload.object_digest || payload.object_hash || '';
    $('readingPane').innerHTML = `<div class="reader-head"><div class="reader-kicker"><span>${m.direction === 'in' ? 'RECEIVED STATE' : 'OUTGOING STATE'}${payload.kind === 'delta' ? ' · SIGNED DELTA' : ''}</span><div class="reader-actions"><button class="icon-button" data-read-action="back" aria-label="Back to messages">${icon('back')}</button><button class="icon-button" data-read-action="unread" aria-label="Mark unread">${icon('inbox')}</button><button class="icon-button" data-read-action="${m.archived ? 'restore' : 'archive'}" aria-label="${m.archived ? 'Restore' : 'Archive'}">${icon('archive')}</button></div></div><h2 class="reader-title">${esc(m.title)}</h2><div class="reader-from"><span class="avatar">${esc(peerName(m.peer).slice(0,1).toUpperCase())}</span><span><strong>${m.direction === 'out' ? 'To ' : ''}${esc(peerName(m.peer))}</strong><small>${m.direction === 'in' ? 'Received on ' : 'Shared from '}${esc(state.settings.name)}</small></span><span class="reader-date">${esc(date(m.created, true))}</span></div></div><div class="reader-body"><div class="receipt-track ${attention(m) ? 'attention' : ''}"><span class="track-step">${icon(committed ? 'check' : 'clock')}${m.direction === 'in' ? 'Received' : committed || payload.transport_completed ? 'Sent' : m.stage === 'failed' ? 'Not sent' : 'Attempted'}</span><span class="track-rule"></span><span class="track-step ${committed ? '' : 'pending'}">${icon(committed ? 'check' : 'clock')}${committed ? 'Accepted' : m.stage === 'rejected' ? 'Not accepted' : 'Unconfirmed'}</span><span class="track-rule"></span><span class="track-step ${indexed ? '' : 'pending'}">${icon(indexed ? 'check' : 'clock')}${indexed ? 'Indexed' : 'Not confirmed indexed'}</span></div><div class="message-content">${esc(m.text || 'No readable semantic text accompanies this receipt.')}</div><div class="reader-note"><strong>${esc(labels[m.stage] || m.stage)}.</strong> ${esc(note)}</div></div><div class="reader-footer"><div class="actions"><button class="btn" data-read-action="copy">${icon('copy')}Copy text</button><button class="btn" data-read-action="share">${icon('send')}Share onward</button>${m.direction === 'in' && indexed && digest ? `<button class="btn" data-read-action="delta">${icon('field')}Share delta</button>` : ''}</div><details><summary>Receipt &amp; provenance</summary><pre>${esc(JSON.stringify(payload,null,2))}</pre></details><p class="fine-print">Reading and archiving do not change accepted state. Signatures establish provenance, not truth.</p></div>`;
  }
  async function selectMessage(id) {
    selected = id; const m = state.messages.find(x=>x.id===id);
    renderList(); renderReader(true);
    if (m?.unread) { await api('message',{id,action:'read'}); m.unread=0; render(); }
  }
  function changeFolder(next) { window.dispatchEvent(new Event('braid:mail'));  folder=next; peerFilter=''; selected=null; renderKey=''; render(); }
  document.querySelectorAll('[data-folder]').forEach(b=>b.onclick=()=>changeFolder(b.dataset.folder));
  $('search').oninput=renderList;
  $('messageList').onclick=e=>{ const m=e.target.closest('[data-message]'); if(m) safely(()=>selectMessage(m.dataset.message)); if(e.target.closest('[data-draft]')) openCompose(state.draft); };
  $('rigList').onclick=e=>{ const b=e.target.closest('[data-peer]'); if(b){peerFilter=b.dataset.peer;folder='inbox';selected=null;render();} };
  $('readingPane').onclick=e=>safely(async()=>{
    const welcome=e.target.closest('[data-welcome]'); if(welcome){welcome.dataset.welcome==='rig'?openRig():openCompose();return;}
    const b=e.target.closest('[data-read-action]'); if(!b)return;
    const m=state.messages.find(x=>x.id===selected); if(!m)return;
    const action=b.dataset.readAction;
    if(action==='back'){selected=null;renderKey='';render();return;}
    if(action==='copy'){await navigator.clipboard.writeText(m.text);toast('Copied exact message text.');return;}
    if(action==='share'){openCompose({source:m.text,title:m.title,recipients:[]});return;}
    if(action==='delta'){
      await busy(b,'Preparing delta…',async()=>{
        const digest=m.payload.object_digest || m.payload.object_hash;
        const result=await job('field',{action:'delta',object_digest:digest});
        openCompose({source:result.text,review:result.text,title:'Delta: '+m.title.slice(0,70),mode:'review',kind:'delta',object_digest:digest,method:'Exact signed delta material. Editing requires an ordinary summary instead.'});
      });return;
    }
    await api('message',{id:m.id,action}); if(action==='archive'||action==='restore')selected=null;
    await refresh();
  });
  $('markAllButton').onclick=()=>busy($('markAllButton'),'Marking…',async()=>{for(const m of visibleMessages().filter(x=>x.unread)) await api('message',{id:m.id,action:'read'});await refresh();});
  function dialog(id) { if(!$(id).open) $(id).showModal(); }
  document.querySelectorAll('.close-modal').forEach(b=>b.onclick=()=>b.closest('dialog').close());
  function openCompose(draft) {
    if(!state)return;
    draft=draft || state.draft || {};
    handoffId=draft.handoff_id || newHandoffId(); deliveryCache={};
    for(const d of state.deliveries||[]) if(d.handoff===handoffId) deliveryCache[d.peer]=d.stage;
    composeMode=draft.mode || 'write';payloadKind=draft.kind || 'summary';deltaObject=draft.object_digest || '';sourceMethod=draft.method || 'Ready for your review.';
    $('sourceText').value=draft.source || ''; $('reviewText').value=draft.review || ''; $('composeTitle').value=draft.title || '';
    $('reviewText').readOnly=payloadKind==='delta'; $('composeResult').hidden=true;
    const recipients=[...state.peers,...relayPeers];
    $('recipientList').innerHTML=recipients.length?recipients.map(p=>`<label class="recipient"><input type="checkbox" value="${esc(p.id)}" ${(draft.recipients||[]).includes(p.id)?'checked':''}><span class="dot ${p.presence?.reachable?'online':''}"></span>${esc(p.name)}</label>`).join(''):'<span class="microcopy">No approved rigs yet. Close this draft and choose Add rig.</span>';
    if(recipients.length===1 && !(draft.recipients||[]).length)$('recipientList').querySelector('input').checked=true;
    updateCompose();dialog('composeDialog');
  }
  function selectedRecipients(){return Array.from($('recipientList').querySelectorAll('input:checked')).filter(e=>!frozenStages.includes(deliveryCache[e.value])).map(e=>e.value);}
  function updateCompose(){
    const reviewing=composeMode==='review';
    $('writeSection').hidden=reviewing;$('reviewSection').hidden=!reviewing;$('useExact').hidden=reviewing;$('summarizeButton').hidden=reviewing;$('sendButton').hidden=!reviewing;
    $('stepWrite').classList.toggle('current',!reviewing);$('stepReview').classList.toggle('current',reviewing);
    $('summaryMethod').textContent=sourceMethod;
    const s=bytes($('sourceText').value),r=bytes($('reviewText').value);
    $('sourceCount').textContent=s.toLocaleString()+' / 6,000 bytes';$('reviewCount').textContent=r.toLocaleString()+' / 6,000 bytes';
    $('sourceCount').style.color=s>6000?'var(--amber)':'';$('reviewCount').style.color=r>6000?'var(--amber)':'';
    $('summarizeButton').disabled=working||!s||s>6000;$('useExact').disabled=working||!s||s>6000;
    $('sendButton').disabled=working||!r||r>6000||!selectedRecipients().length;
    $('sendButton').title=selectedRecipients().length?'Send only the reviewed text to the selected rigs.':'Select at least one approved rig.';
    const attempted=Object.keys(deliveryCache).length>0;
    $('newHandoff').hidden=!attempted;$('newHandoff').disabled=working;
    $('backToSource').disabled=working||attempted;$('saveDraft').disabled=working;
    $('sourceText').readOnly=working||attempted;$('reviewText').readOnly=working||attempted||payloadKind==='delta';
    $('composeTitle').disabled=working||attempted;$('recipientList').querySelectorAll('input').forEach(e=>{
      const stage=deliveryCache[e.value], frozen=frozenStages.includes(stage);e.disabled=working||frozen;if(frozen)e.checked=false;
      let note=e.parentElement.querySelector('.delivery-note');if(!note){note=document.createElement('small');note.className='delivery-note';e.parentElement.append(note);}note.textContent=stage?' - '+(labels[stage]||stage):'';
    });
  }
  function draftValue(){return{handoff_id:handoffId,source:$('sourceText').value,review:$('reviewText').value,title:$('composeTitle').value,recipients:selectedRecipients(),mode:composeMode,kind:payloadKind,object_digest:deltaObject,method:sourceMethod};}
  async function saveDraft(){const d=draftValue();await api('draft',{draft:(d.source||d.review)?d:null});await refresh();}
  $('composeButton').onclick=()=>openCompose();
  $('newHandoff').onclick=()=>{
    if(!confirm('Create a separate handoff? This does not resolve uncertain receipts. Check the receiving rig before intentionally sending the same material again.'))return;
    handoffId=newHandoffId();deliveryCache={};updateCompose();safely(saveDraft);
  };
  $('sourceText').oninput=updateCompose;$('reviewText').oninput=updateCompose;$('recipientList').onchange=updateCompose;
  $('useExact').onclick=()=>{payloadKind='context';composeMode='review';$('reviewText').value=$('sourceText').value;sourceMethod='Exact source text. No summarization was applied.';updateCompose();};
  $('backToSource').onclick=()=>{composeMode='write';payloadKind='summary';deltaObject='';$('reviewText').readOnly=false;updateCompose();};
  $('summarizeButton').onclick=()=>busy($('summarizeButton'),'Summarizing locally…',async()=>{
    working=true;updateCompose();
    try{await saveDraft();const result=await job('summary',{text:$('sourceText').value});$('reviewText').value=result.summary;composeMode='review';payloadKind='summary';sourceMethod=result.method==='extractive_fallback'?'Extractive fallback · selected source text, not a model-written summary.':'Summarized by your local model · review before sharing.';if(result.warning)sourceMethod+=' '+result.warning;await saveDraft();}
    finally{working=false;updateCompose();}
  });
  $('saveDraft').onclick=()=>busy($('saveDraft'),'Saving…',async()=>{await saveDraft();$('composeDialog').close();toast('Draft saved on this rig. No additional send was started.');});
  $('composeDialog').addEventListener('close',()=>{if(!working && (state?.draft || $('sourceText').value || $('reviewText').value))safely(saveDraft);});
  $('sendButton').onclick=()=>busy($('sendButton'),'Sharing…',async()=>{
    const outgoing={handoff_id:handoffId,peers:selectedRecipients(),text:$('reviewText').value,title:$('composeTitle').value || 'Shared summary',kind:payloadKind,object_digest:deltaObject};
    working=true;updateCompose();let failed=false;const results=[];
    $('composeResult').hidden=false;$('composeResult').textContent='Preparing the signed handoff. Waiting for receiver receipts…';
    try{
      await saveDraft();
      for(const peer of outgoing.peers){
        try{const result=await job('send',{handoff_id:outgoing.handoff_id,peer,text:outgoing.text,title:outgoing.title,kind:outgoing.kind,object_digest:outgoing.object_digest});deliveryCache[peer]=result.stage;results.push(peerName(peer)+': '+(labels[result.stage] || result.stage)+(result.error?' - '+result.error:''));if(!['indexed','accepted','accepted_legacy'].includes(result.stage))failed=true;}
        catch(e){failed=true;deliveryCache[peer]='outcome_unknown';results.push(peerName(peer)+': '+e.message+' Check Sent and the receiver before retrying.');}
        $('composeResult').textContent=results.join('\n');updateCompose();await saveDraft();
      }
      if(!failed){
        await api('draft',{draft:null});$('sourceText').value='';$('reviewText').value='';await refresh();
        toast(results.join(' · '));$('composeDialog').close();changeFolder('sent');
      }
    }finally{working=false;updateCompose();await refresh();}
  });
  $('importTextButton').onclick=()=>$('textFile').click();
  $('textFile').onchange=()=>safely(async()=>{const f=$('textFile').files[0];if(!f)return;if(f.size>6000)throw new Error('Choose up to 6,000 UTF-8 bytes of source text. Split a longer conversation into focused handoffs.');$('sourceText').value=await f.text();updateCompose();$('textFile').value='';});
  function rigTab(tab){activeTab=tab;['own','other','ready'].forEach(x=>{$('rig'+x[0].toUpperCase()+x.slice(1)).hidden=x!==tab;document.querySelector(`[data-rigtab="${x}"]`).classList.toggle('active',x===tab);});$('rigNext').textContent=tab==='ready'?'Done':'Next →';}
  function openRig(){
    if(!state)return;
    $('rigName').value=state.settings.name;$('rigEmbed').value=state.settings.embed_model;
    const addresses=[...new Set([state.settings.host,...state.addresses,'127.0.0.1'])];
    $('rigAddress').innerHTML=addresses.map(a=>`<option value="${esc(a)}">${esc(a)}${a==='127.0.0.1'?' · this machine only':''}</option>`).join('');
    $('rigAddress').value=state.settings.host;$('ownFingerprint').textContent=state.fingerprint.match(/.{1,4}/g).join(' ');
    $('prepareTitle').textContent=state.route_ready?'Local route is prepared':'Prepare this rig';$('prepareNumber').textContent=state.route_ready?'✓':'1';
    $('exportCard').disabled=!state.route_ready;$('existingRoute').value=state.settings.route_path||'';
    rigTab('own');dialog('rigDialog');
  }
  ['addRigButton','addRigInline'].forEach(id=>$(id).onclick=openRig);
  document.querySelectorAll('[data-rigtab]').forEach(b=>b.onclick=()=>rigTab(b.dataset.rigtab));
  $('rigNext').onclick=()=>activeTab==='ready'?$('rigDialog').close():rigTab(activeTab==='own'?'other':'ready');
  async function saveRigSettings(route){await api('settings',{name:$('rigName').value,host:$('rigAddress').value,embed_model:$('rigEmbed').value,...(route?{route_path:route}:{})});await refresh();}
  $('prepareRig').onclick=()=>busy($('prepareRig'),'Preparing…',async()=>{await saveRigSettings();$('prepareDetail').textContent='Calibrating with your local model. The route is not ready until validation completes.';try{await job('prepare',{});$('prepareTitle').textContent='Local route is prepared';$('prepareNumber').textContent='✓';$('exportCard').disabled=false;$('prepareDetail').textContent='Digest-bound route ready. Save your public rig card next.';}catch(e){$('prepareDetail').textContent='Preparation did not finish. '+e.message;throw e;}});
  $('useExistingRoute').onclick=()=>busy($('useExistingRoute'),'Checking…',async()=>{await saveRigSettings($('existingRoute').value);$('prepareTitle').textContent='Existing route verified';$('exportCard').disabled=false;toast('Existing a3 route verified. No new calibration was run.');});
  $('exportCard').onclick=()=>busy($('exportCard'),'Saving…',async()=>{
    // Persist edited labels/address before export, unless the listener is deliberately running.
    if($('rigName').value!==state.settings.name||$('rigAddress').value!==state.settings.host||$('rigEmbed').value!==state.settings.embed_model)await saveRigSettings();
    const card=await api('card');const blob=new Blob([JSON.stringify(card,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=(state.settings.name.replace(/[^a-z0-9_-]/gi,'-')||'my-rig')+'.braidrig';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Public rig card saved. Compare its fingerprint on the other machine.');
  });
  $('importCardButton').onclick=()=>$('cardFile').click();
  $('cardFile').onchange=()=>safely(async()=>{
    const f=$('cardFile').files[0];if(!f)return;
    try{
      if(f.size>12*1024*1024)throw new Error('Rig card exceeds the 12 MiB limit.');
      const card=JSON.parse(await f.text());$('cardReview').hidden=true;
      await busy($('importCardButton'),'Checking signature and route…',async()=>{
        inspection=await job('inspect-card',{card});$('cardName').textContent=inspection.name;$('cardEndpoint').textContent=inspection.host+':'+inspection.port+' · certificate-pinned TLS';
        $('cardFingerprint').textContent=inspection.id.match(/.{1,4}/g).join(' ');$('cardModel').textContent='Approved route model: '+inspection.source_model+(inspection.update_kind==='address'?'. Verified address-only update; identity, route and history stay intact.':'. New rig.')+' A valid self-signature is not identity proof; compare the fingerprint on the other rig.';
        $('trustCheck').checked=false;$('approveCard').disabled=true;$('cardReview').hidden=false;
      });
    }finally{$('cardFile').value='';}
  });
  $('trustCheck').onchange=()=>{$('approveCard').disabled=!$('trustCheck').checked;};
  $('approveCard').onclick=()=>busy($('approveCard'),'Approving…',async()=>{
    if(!inspection||!$('trustCheck').checked)return;
    await api('approve-card',{inspection_id:inspection.inspection_id,fingerprint:inspection.id,confirmed:true});await refresh();rigTab('ready');toast(inspection.name+' approved. Exchange cards in the other direction too.');inspection=null;
  });
  async function setListening(enabled){await api('listen',{enabled});await refresh();$('connectionResult').textContent=enabled?'This rig is receiving. Start the other rig, then check connections.':'Receiving is paused. Stored state is unchanged.';}
  $('listenButton').onclick=()=>busy($('listenButton'),'Updating…',()=>setListening(!state.listener.running));
  $('startReceiving').onclick=()=>busy($('startReceiving'),'Starting…',()=>setListening(true));
  async function checkPeers(){const result=await job('probe',{});const count=Object.values(result).filter(x=>x.reachable).length;$('connectionResult').textContent=count+' of '+Object.keys(result).length+' approved LAN listeners reachable. Each transfer still needs its own acceptance receipt.';toast(count+' approved rig'+(count===1?'':'s')+' reachable.');}
  $('checkConnections').onclick=()=>busy($('checkConnections'),'Checking…',checkPeers);
  $('refreshPeers').onclick=()=>busy($('refreshPeers'),'…',checkPeers);
  function openSettings(){
    if(!state)return;$('settingsName').value=state.settings.name;$('settingsPort').value=state.settings.port;$('completionModel').value=state.settings.completion_model||'';$('workspacePath').textContent=state.inbox_path;
    $('modelStatus').textContent=state.listener.running?'Pause receiving using the top bar before saving configuration changes.':'Summaries use local Ollama, or a labeled extractive fallback. Channel chat is available from the sidebar. Other chat applications remain separate.';
    $('manageRigs').innerHTML=state.peers.length?state.peers.map(p=>`<div class="setup-row"><span data-icon="rig">${icon('rig')}</span><div><strong>${esc(p.name)}</strong><small>${esc(p.host)}:${p.port} · ${esc(p.id.slice(0,12))}…</small></div><button class="btn" data-remove="${esc(p.id)}">Remove trust</button></div>`).join(''):'<p class="microcopy">No LAN rigs approved yet.</p>';
    $('settingsAddress').value=state.settings.host;
    $('localAddresses').innerHTML=state.addresses.map(a=>`<option value="${esc(a)}"></option>`).join('');
    $('addressStatus').textContent=state.network?.warning||'Changing an address preserves your keys, route and inbox. Share the updated card afterward.';
    dialog('settingsDialog');
  }
  $('settingsButton').onclick=openSettings;
  $('updateAddress').onclick=()=>busy($('updateAddress'),'Updating...',async()=>{const result=await api('address',{host:$('settingsAddress').value});await refresh();$('addressStatus').textContent=result.message;toast('Address updated. Save and share an updated rig card.');});
  $('quitBraid').onclick=()=>busy($('quitBraid'),'Stopping...',async()=>{if(!confirm('Stop receiving and quit Archangel? Unfinished sends will remain unconfirmed.'))return;await api('shutdown',{});toast('Archangel is shutting down. You can close this window.');});
  $('saveSettings').onclick=()=>busy($('saveSettings'),'Saving…',async()=>{await api('settings',{name:$('settingsName').value,port:$('settingsPort').value,completion_model:$('completionModel').value});await refresh();$('settingsDialog').close();toast('Local settings saved.');});
  $('detectModels').onclick=()=>busy($('detectModels'),'Checking local Ollama…',async()=>{
    const result=await job('models',{});const raw=(result.models||[]).filter(x=>typeof x==='string'||x.local_eligible!==false);const names=raw.map(x=>typeof x==='string'?x:x.name||x.model).filter(Boolean);
    for(const id of ['embeddingModels','completionModels'])$(id).innerHTML=names.map(n=>`<option value="${esc(n)}"></option>`).join('');
    $('modelStatus').textContent=names.length?names.length+' installed local models found. Select the appropriate completion model above.':result.error||'No local models found. Start Ollama and install an embedding/completion model first.';
  });
  $('manageRigs').onclick=e=>safely(async()=>{const b=e.target.closest('[data-remove]');if(!b)return;if(!confirm('Remove trust for '+peerName(b.dataset.remove)+'? Future state from this key will not be accepted. Existing inbox and field history stay intact.'))return;await api('remove-peer',{peer:b.dataset.remove});await refresh();openSettings();});
  $('loadRelay').onclick=()=>busy($('loadRelay'),'Checking enrollment…',async()=>{
    const result=await job('relay',{});const raw=result.peers||result.approved_peers||[];
    relayPeers=raw.map(p=>({id:'relay:'+(p.device_id||p.peer_id||p.id||p.peer),name:p.display_name||p.name||p.device_id||p.peer_id||p.id||p.peer})).filter(p=>p.name&&p.id!=='relay:undefined');
    $('relayResult').hidden=false;$('relayResult').textContent=relayPeers.length?'Loaded '+relayPeers.length+' existing approved relay peers. They are now available in the composer.':result.message||'No usable approved relay peers found. Configure enrollment in the retained advanced workflow first.';
  });
  function openAdvanced(){if(isPreview){toast('The advanced a3 workspace is included in the runnable build, not this offline preview.');return;}window.open('/advanced','_blank','noopener');}
  ['advancedLink','openAdvanced'].forEach(id=>$(id).onclick=openAdvanced);
  $('fieldButton').onclick=()=>{
    const f=state.field;$('fieldStats').innerHTML=[['Indexed items',f.indexed_atom_count||0],['Indexed objects',f.indexed_object_count||0],['Dimensions',f.field_dimension||384]].map(([n,v])=>`<div class="stat"><strong>${esc(v)}</strong><span>${esc(n)}</span></div>`).join('');dialog('fieldDialog');
  };
  function fieldPresentation(action, result) {
    if(action==='query') return `<div class="answer">${esc(result.response || 'No response was returned.')}</div>`;
    if(action==='search') {
      const rows=Array.isArray(result.results)?result.results:[];
      return `<p class="microcopy">${rows.length} relevant items selected. Similarity is relevance, not truth.</p>`+rows.slice(0,12).map(r=>`<article class="field-entry"><div class="answer">${esc(r.text)}</div><small>${esc(r.support_count || (r.sources||[]).length)} source occurrence(s)</small></article>`).join('')+(rows.length?'':'<p>No indexed material matched this question in the selected local field space.</p>');
    }
    if(action==='reconcile') {
      const groups=Array.isArray(result.clusters)?result.clusters:[];
      const names={possible_conflict:'Possible conflict',exact_corroboration:'Repeated exact claim',corroborated_variants:'Related claims across objects',related_variants:'Related claims',singleton:'Single claim'};
      return `<p class="microcopy">${esc(result.possible_conflict_count || 0)} possible conflict signal(s). Claims are preserved, not automatically resolved. Showing up to 12 groups.</p>`+groups.slice(0,12).map(g=>`<article class="field-entry ${g.status==='possible_conflict'?'conflict':''}"><span class="pill ${g.status==='possible_conflict'?'amber':'neutral'}">${esc(names[g.status]||g.status)}</span>${(g.members||[]).map(r=>`<blockquote>${esc(r.text)}</blockquote>`).join('')}</article>`).join('')+(groups.length?'':'<p>No claim groups are available in the selected local field space.</p>');
    }
    return `<p>${esc(result.indexed_object_count || 0)} object(s) indexed. ${esc(result.already_indexed_count || 0)} were already indexed. ${esc(result.failed_object_count || 0)} could not be indexed.</p>`+(result.results||[]).filter(r=>r.status==='failed').slice(0,12).map(r=>`<article class="field-entry conflict"><strong>Indexing needs attention</strong><div class="answer">${esc(r.reason)}</div></article>`).join('');
  }
  async function fieldAction(action,button){await busy(button,action==='query'?'Asking locally…':'Working locally…',async()=>{
    $('fieldResult').hidden=false;$('fieldResult').textContent=action==='query'?'Retrieving relevant state and checking the local answer…':'Inspecting receiver-local field evidence…';
    try{
      const result=await job('field',{action,question:$('fieldQuestion').value});
      $('fieldResult').innerHTML=`<h3>${esc(action==='query'?'Guarded answer':action==='reconcile'?'Conflicts & relationships':'Shared field')}</h3>${fieldPresentation(action,result)}<details><summary>Exact result &amp; evidence</summary><pre>${esc(JSON.stringify(result,null,2))}</pre></details>`;
    }catch(e){$('fieldResult').textContent='Not completed. '+e.message;throw e;}
  });}
  $('askField').onclick=()=>fieldAction('query',$('askField'));
  $('searchField').onclick=()=>fieldAction('search',$('searchField'));
  $('reconcileField').onclick=()=>fieldAction('reconcile',$('reconcileField'));
  $('repairField').onclick=()=>fieldAction('reindex',$('repairField'));
  document.addEventListener('keydown',e=>{
    const input=e.target.matches('input,textarea,select,[contenteditable="true"]');
    if(e.key==='Escape'&&!document.querySelector('dialog[open]')&&selected){selected=null;renderKey='';render();}
    if(!input&&!document.querySelector('dialog[open]')){
      if(e.key==='/'){e.preventDefault();$('search').focus();}
      if(e.key==='n'){e.preventDefault();openCompose();}
      if(['ArrowDown','ArrowUp'].includes(e.key)){const list=visibleMessages(),at=list.findIndex(x=>x.id===selected),next=list[Math.max(0,Math.min(list.length-1,at+(e.key==='ArrowDown'?1:-1)))];if(next){e.preventDefault();safely(()=>selectMessage(next.id));}}
    }
    if((e.ctrlKey||e.metaKey)&&e.key==='Enter'&&$('composeDialog').open&&composeMode==='review'&&!$('sendButton').disabled){e.preventDefault();$('sendButton').click();}
  });
  window.BraidDesktop={api,job,refresh,toast,esc,getState:()=>state};
  window.dispatchEvent(new Event('braid:ready'));
  refresh().then(()=>{if(isPreview&&state.messages.length&&window.innerWidth>620)selectMessage(state.messages[0].id);});
  setInterval(()=>{if(!document.hidden)refresh();},4000);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
})();
