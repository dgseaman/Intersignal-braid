/* Archangel channels: explicit local policy, exact evidence, no hidden forwarding. */
'use strict';
(() => {
  const $=id=>document.getElementById(id), D=()=>window.BraidDesktop;
  const E=x=>D().esc(x), uid=()=>crypto.randomUUID().replace(/-/g,''), size=x=>new TextEncoder().encode(x).length;
  let state=null,active='',view=null,thread=null,tab='chat',policyRevision=0,noteId='',sending=false,channelEpoch=0;
  const api=(action,data={})=>D().api('channel',{action,...data});
  const job=(action,data={})=>D().job('channel',{action,...data});
  const chat=(action,data={})=>D().api('chat',{action,...data});
  const notify=msg=>D().toast(msg);
  async function safe(fn){try{return await fn();}catch(e){notify(e.message||String(e));return null;}}
  async function work(button,text,fn){if(button.disabled)return;const old=button.textContent;button.disabled=true;button.textContent=text;button.setAttribute('aria-busy','true');try{return await fn();}catch(e){notify(e.message||String(e));return null;}finally{button.textContent=old;button.disabled=false;button.removeAttribute('aria-busy');}}
  const peer=id=>state?.peers.find(p=>p.id===id)?.name||id.slice(0,12);
  const current=()=>state?.channels?.find(c=>c.id===active)||view?.channel;
  const when=t=>new Date(t*1000).toLocaleString();
  function modal(id){if(!$(id).open)$(id).showModal();}
  function save(name,data,mime='application/json'){const blob=new Blob([data],{type:mime}),u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1500);}
  function sidebar(){
    const channels=state?.channels||[];
    $('channelList').innerHTML=channels.length?channels.map(c=>`<button class="channel-item ${c.id===active&&!$('channelMain').hidden?'active':''}" data-channel="${E(c.id)}" title="#${E(c.descriptor.name)}${c.policy.archived?' (archived)':''}"><span class="hash-sign">#</span><strong>${E(c.descriptor.name)}</strong><small>${c.policy.archived?'archived':c.draft_count?c.draft_count+' draft'+(c.draft_count===1?'':'s'):c.object_count}</small></button>`).join(''):'<span class="sidebar-note">One field. A place for each project.</span>';
    const c=current();if(c&&!$('channelMain').hidden){
      document.querySelectorAll('[data-folder]').forEach(b=>b.classList.remove('active'));
      $('channelTitle').textContent='#'+c.descriptor.name;
      $('channelSubtitle').textContent=c.policy.archived?'Archived locally. History preserved.':c.policy.paused?'Outgoing sharing paused. Received history is retained.':c.descriptor.description||'Your rigs. A focused conversation.';
      $('autoChatLabel').hidden=c.policy.mode!=='automatic_marked';
      if(c.policy.mode!=='automatic_marked')$('autoChat').checked=false;
      $('useShared').disabled=!c.policy.use_in_chat||c.policy.archived;
      $('chatScope').textContent=!c.policy.use_in_chat?'Shared context is off in channel settings. Chat uses no shared notes.':'Local inference. Shared notes are evidence, not verified truth.';
      $('writeChannelNote').disabled=c.policy.archived;
    }
  }
  window.addEventListener('braid:state',e=>{state=e.detail;sidebar();});
  window.addEventListener('braid:mail',()=>{$('channelMain').hidden=true;$('mailMain').hidden=false;sidebar();});
  $('channelList').onclick=e=>{const b=e.target.closest('[data-channel]');if(b)safe(()=>openChannel(b.dataset.channel));};
  document.querySelectorAll('[data-channel-close]').forEach(b=>b.onclick=()=>b.closest('dialog').close());
  async function openChannel(id){
    if(sending&&id!==active){notify('Wait for this conversation response before changing channels.');return;}
    active=id;const epoch=++channelEpoch;thread=null;
    $('autoChat').checked=false;$('suggestNotes').checked=false;$('useShared').checked=true;
    $('channelMain').hidden=false;$('mailMain').hidden=true;
    document.querySelectorAll('[data-folder]').forEach(b=>b.classList.remove('active'));
    $('chatInput').value='';$('chatModel').value=state.settings.completion_model||'';sidebar();
    const result=await api('view',{id});if(epoch!==channelEpoch)return;view=result;
    updateThreads();if(view.threads.length)thread=await chat('view',{thread:view.threads[0].id});
    if(epoch!==channelEpoch)return;setTab('chat');renderChat();renderNotes();
  }
  function updateThreads(){ $('threadSelect').innerHTML='<option value="">New conversation</option>'+view.threads.map(t=>`<option value="${E(t.id)}">${E(t.title)}</option>`).join(''); if(thread)$('threadSelect').value=thread.id; }
  async function reloadView(){if(!active)return;view=await api('view',{id:active});updateThreads();renderNotes();await D().refresh();}
  function setTab(name){tab=name;['chat','notes','conflicts'].forEach(n=>{$('channel'+n[0].toUpperCase()+n.slice(1)).hidden=name!==n;document.querySelector(`[data-channel-tab="${n}"]`).classList.toggle('active',name===n);});}
  document.querySelectorAll('[data-channel-tab]').forEach(b=>b.onclick=()=>safe(async()=>{setTab(b.dataset.channelTab);if(b.dataset.channelTab==='notes')await reloadView();}));
  function evidence(result){
    const notes=result.supplied_notes||[], count=result.shared_note_count||0;
    const rigs=[...new Set(notes.flatMap(n=>(n.sources||[]).map(s=>s.rig)).filter(Boolean))];
    const channels=[...new Set(notes.flatMap(n=>(n.sources||[]).map(s=>s.channel)).filter(Boolean))];
    const conflicts=result.unresolved_conflict_count||0;
    return `<details class="shared-notes"><summary><strong>${count?'Using '+count+' shared note'+(count===1?'':'s'):'No shared notes used'}</strong>${channels.length?'<span>· '+E(channels.map(c=>'#'+c).join(', '))+'</span>':''}${rigs.length?'<span>· '+E(rigs.join(', '))+'</span>':''}${conflicts?'<span class="pill amber">'+conflicts+' unresolved conflict'+(conflicts===1?'':'s')+'</span>':''}</summary><div class="evidence-body"><p>${E(result.count_meaning)}</p>${notes.map((n,i)=>`<article class="evidence-note"><strong>Note ${i+1}${n.reconciliation_supplemental?' · conflict context':''}</strong><blockquote>${E(n.text)}</blockquote>${(n.sources||[]).map(s=>`<div class="evidence-source">${E(s.rig)} · #${E(s.channel)} · ${E(when(s.received_at))}<br>Object <code>${E(s.object_digest)}</code></div>`).join('')}</article>`).join('')}<p class="microcopy">Completion: ${E(result.completion_model)} · ${result.generation_source==='receiver_local_completion_model'?'local model draft passed the bounded guard':'source-preserving guard fallback'}. ${E(result.history_message_count)} prior conversation messages supplied. No measure of internal model attention.</p><details><summary>Exact answer record</summary><pre>${E(JSON.stringify(result,null,2))}</pre></details></div></details>`;
  }
  function renderChat(){
    $('threadSelect').value=thread?.id||'';
    $('chatTurns').innerHTML=thread?.turns.length?thread.turns.map(t=>{
      const r=t.payload?.result,s=t.payload?.suggestion;
      return `<article class="chat-turn"><div class="chat-role">YOU · ${E(when(t.created))}</div><div class="chat-question">${E(t.question)}</div><div class="chat-role">${E(r?.completion_model||t.payload?.model||'LOCAL MODEL')}</div>${r?`<div class="chat-answer">${E(r.response)}</div>${evidence(r)}`:`<p class="chat-notice">${E(t.state==='running'?'Thinking locally…':t.payload?.error||'Interrupted. Nothing is automatically replayed.')}</p>`}${t.payload?.history_reset?'<p class="chat-notice">A new context window was started. Earlier turns remain visible but were not supplied under the changed permissions.</p>':''}${s?`<div class="chat-notice">${s.automatic_attempted?'Marked note: '+E(s.state):'A topic note is ready for your review.'} ${E(s.error||'')} <button class="text-button" data-open-note="${E(s.note_id)}">Inspect note &amp; receipt</button></div>`:''}</article>`;
    }).join(''):'<div class="chat-empty"><span class="eyebrow">CONTEXT WITHOUT THE COPY WORK</span><h2>A familiar conversation.<br>A shared field underneath.</h2><p>Ask your local model a question. Relevant notes from this channel can join the conversation, with their exact sources one click away.</p></div>';
    $('chatTurns').scrollTop=$('chatTurns').scrollHeight;
  }
  $('newThread').onclick=()=>safe(async()=>{if(sending)return;thread=await chat('new',{channel:active});await reloadView();renderChat();$('chatInput').focus();});
  $('threadSelect').onchange=()=>safe(async()=>{if(sending)return;thread=$('threadSelect').value?await chat('view',{thread:$('threadSelect').value}):null;renderChat();});
  $('chatForm').onsubmit=e=>{e.preventDefault();safe(async()=>{
    if(sending)return;
    const question=$('chatInput').value.trim();if(!question)return;
    if(size(question)>6000)throw new Error('Keep this message within 6,000 UTF-8 bytes.');
    const model=$('chatModel').value.trim();if(!model)throw new Error('Choose an installed local completion model above.');
    sending=true;$('sendChat').disabled=true;$('newThread').disabled=true;$('threadSelect').disabled=true;$('sendChat').textContent='Thinking…';
    try{
      if(!thread)thread=await chat('new',{channel:active});
      const request={action:'turn',thread:thread.id,request_id:uid(),question,model,use_shared:!$('useShared').disabled&&$('useShared').checked,allow_suggestions:$('suggestNotes').checked,allow_automatic:$('autoChat').checked};
      $('chatInput').value='';thread.turns.push({id:request.request_id,question,state:'running',created:Date.now()/1000,payload:{model}});renderChat();
      try{await D().job('chat',request);}finally{thread=await chat('view',{thread:thread.id});await reloadView();renderChat();}
    }finally{sending=false;$('sendChat').disabled=false;$('newThread').disabled=false;$('threadSelect').disabled=false;$('sendChat').textContent='Send';$('chatInput').focus();}
  });};
  $('chatInput').onkeydown=e=>{if((e.ctrlKey||e.metaKey)&&e.key==='Enter'){e.preventDefault();$('chatForm').requestSubmit();}};
  $('chatModels').onclick=()=>work($('chatModels'),'Finding…',async()=>{const r=await D().job('models',{});const names=(r.models||[]).filter(m=>typeof m==='string'||m.local_eligible!==false).map(m=>typeof m==='string'?m:m.name||m.model).filter(Boolean);$('completionModels').innerHTML=names.map(n=>`<option value="${E(n)}"></option>`).join('');notify(names.length+' local models found. Choose a generation model, not an embedding model.');});
  ['useShared','suggestNotes','autoChat'].forEach(id=>$(id).onchange=()=>{if(id==='autoChat'&&$(id).checked&&!confirm('Allow this chat to automatically send newly typed /note messages to this channel\'s configured destinations? Ordinary chat, model answers, and received notes will not be sent.'))$(id).checked=false;if(id==='useShared')notify('The next answer will use a fresh context window when permissions differ. Earlier turns remain visible.');});
  function renderNotes(){
    if(!view)return;
    const local=view.notes.map(n=>`<article class="channel-note-card"><span class="channel-note-state">${E(n.state.toUpperCase())} · ${E(when(n.created))}</span><h3>${E(n.title)}</h3><p>${E(n.text)}</p><div class="actions"><button class="btn small" data-open-note="${E(n.id)}">${n.state==='draft'?'Review note':'Inspect outcome'}</button>${!['draft','discarded'].includes(n.state)?`<button class="btn small" data-export-note="${E(n.id)}">Export signed note</button><button class="btn small" data-export-reel="${E(n.id)}">Save QR reel</button>`:''}${n.state==='draft'?`<button class="text-button" data-discard-note="${E(n.id)}">Discard draft</button>`:''}</div></article>`).join('');
    const incoming=view.objects.filter(o=>!o.local).map(o=>`<article class="channel-note-card"><span class="channel-note-state">${o.indexed?'INDEXED':'INDEX NOT CONFIRMED'} · ${E(peer(o.publisher))}</span><p>${E(o.text||o.index_error||'Exact text is available in the original inbox handoff.')}</p><details><summary>Source record</summary><pre>${E(JSON.stringify(o,null,2))}</pre></details></article>`).join('');
    $('channelNotes').innerHTML=`<h3>Your notes &amp; drafts</h3>${local||'<p class="microcopy">No notes written on this rig yet.</p>'}<h3>Received channel notes</h3>${incoming||'<p class="microcopy">No received channel notes yet. Import the same channel card and approve publishers on this rig.</p>'}<h3>Activity</h3>${view.activity.slice(0,30).map(a=>`<details class="channel-activity"><summary>${E(a.kind.replaceAll('_',' '))} · ${E(when(a.created))}</summary><pre>${E(JSON.stringify(a.detail,null,2))}</pre></details>`).join('')}`;
  }
  async function openNote(id=''){
    noteId=id;
    let n=id?view?.notes.find(n=>n.id===id):null;
    if(id&&!n){await reloadView();n=view.notes.find(n=>n.id===id);}
    if(id&&!n)throw new Error('Note not found on this rig.');
    $('noteChannelLabel').textContent='#'+current().descriptor.name+' · WRITE / REVIEW / SHARE';
    const dest=current().policy.send_to.map(peer);
    $('noteDestinations').textContent=dest.length?'Destinations: '+dest.join(', ')+'. Their receipt is separate from local indexing.':'No outgoing destinations selected. This note will be recorded locally only.';
    $('channelNoteTitle').value=n?.title||'Channel note';$('channelNoteText').value=n?.text||'';
    $('channelNoteText').readOnly=!!id;$('channelNoteTitle').readOnly=!!id;
    $('channelNoteResult').hidden=!id;
    if(id)$('channelNoteResult').textContent=JSON.stringify(n.payload,null,2);
    $('channelNoteBytes').textContent=size($('channelNoteText').value)+' / 6,000 bytes';
    $('reviewChannelNote').hidden=!!id;$('saveChannelDraft').hidden=!!id;
    $('publishChannelNote').hidden=!!id&&!['draft','attention'].includes(n.state);
    if(!id)$('publishChannelNote').hidden=true;
    if(n?.state==='attention')$('noteDestinations').textContent='Inspect outcomes below before retrying. Accepted and unconfirmed destinations remain locked; no automatic resend.';
    modal('channelNoteDialog');
  }
  $('writeChannelNote').onclick=()=>safe(()=>openNote());
  $('channelNoteText').oninput=()=>{$('channelNoteBytes').textContent=size($('channelNoteText').value)+' / 6,000 bytes';};
  async function saveNote(){
    const n=await api('note',{channel:active,text:$('channelNoteText').value,title:$('channelNoteTitle').value,note_id:noteId||uid()});noteId=n.id;await reloadView();return n;
  }
  $('saveChannelDraft').onclick=()=>work($('saveChannelDraft'),'Saving…',async()=>{await saveNote();$('channelNoteDialog').close();setTab('notes');notify('Draft saved locally. Nothing was sent.');});
  $('reviewChannelNote').onclick=()=>work($('reviewChannelNote'),'Preparing review…',async()=>{const n=await saveNote();await openNote(n.id);$('channelNoteResult').textContent='Exact text is now fixed for this handoff. Confirm the destinations above, then share.';});
  $('publishChannelNote').onclick=()=>work($('publishChannelNote'),'Sharing…',async()=>{
    try{const result=await job('publish',{note_id:noteId,confirmed:true});$('channelNoteResult').textContent=JSON.stringify(result.payload,null,2);$('channelNoteResult').hidden=false;notify(result.state==='shared'?'Channel handoff completed. Inspect each receipt.':result.state==='local'?'Recorded locally; no remote destinations.':'Some outcomes need inspection. No blind resend.');}
    finally{await reloadView();await openNote(noteId);}
  });
  document.addEventListener('click',e=>safe(async()=>{
    let b=e.target.closest('[data-open-note]');if(b){await reloadView();return openNote(b.dataset.openNote);}
    b=e.target.closest('[data-discard-note]');if(b){await api('discard',{note_id:b.dataset.discardNote});return reloadView();}
    b=e.target.closest('[data-export-reel]');if(b){b.disabled=true;try{const r=await job('export-reel',{note_id:b.dataset.exportReel});save(r.name,r.html,'text/html');notify(r.warning);}finally{b.disabled=false;}return;}
    b=e.target.closest('[data-export-note]');if(b){const r=await api('export-frame',{note_id:b.dataset.exportNote});save(r.name,Uint8Array.from(atob(r.frame_base64),c=>c.charCodeAt(0)),'application/octet-stream');notify(r.warning);}
  }));
  function openCreate(){ $('channelDialogTitle').textContent='Create a channel';$('channelCreate').hidden=false;$('channelPolicy').hidden=true;$('channelName').value='';$('channelDescription').value='';modal('channelDialog'); }
  $('newChannel').onclick=openCreate;
  $('createChannelButton').onclick=()=>work($('createChannelButton'),'Creating…',async()=>{const ch=await api('create',{name:$('channelName').value,description:$('channelDescription').value});await D().refresh();await openChannel(ch.id);openPolicy();notify('Channel created locally. Choose permissions, then save its card for the other rig.');});
  function openPolicy(){
    const c=current();if(!c)return;policyRevision=c.revision;
    $('channelDialogTitle').textContent='#'+c.descriptor.name;$('channelCreate').hidden=true;$('channelPolicy').hidden=false;$('channelId').textContent=c.id;
    $('channelMembers').innerHTML=state.peers.length?state.peers.map(p=>`<div class="channel-member"><span>${E(p.name)}${p.capabilities.includes('channels.v1')?'':' · refresh a6 card'}</span><label><input type="checkbox" data-send-peer="${E(p.id)}" aria-label="Send to ${E(p.name)}" ${c.policy.send_to.includes(p.id)?'checked':''}></label><label><input type="checkbox" data-receive-peer="${E(p.id)}" aria-label="Receive from ${E(p.name)}" ${c.policy.receive_from.includes(p.id)?'checked':''}></label></div>`).join(''):'<p class="microcopy">Add an approved rig first. A local-only channel can still retain your notes.</p>';
    $('channelUse').checked=c.policy.use_in_chat;$('channelMode').value=c.policy.mode;$('channelKeywords').value=c.policy.keywords.join(', ');$('channelRate').value=c.policy.hourly_limit;$('channelPause').checked=c.policy.paused;$('channelArchive').checked=c.policy.archived;$('authorizeAuto').checked=false;modeUI();modal('channelDialog');
  }
  $('channelSettings').onclick=openPolicy;
  function modeUI(){ $('automaticPolicy').hidden=$('channelMode').value!=='automatic_marked'; }
  $('channelMode').onchange=modeUI;
  $('saveChannelPolicy').onclick=()=>work($('saveChannelPolicy'),'Saving…',async()=>{
    const policy={send_to:[...document.querySelectorAll('[data-send-peer]:checked')].map(x=>x.dataset.sendPeer),receive_from:[...document.querySelectorAll('[data-receive-peer]:checked')].map(x=>x.dataset.receivePeer),use_in_chat:$('channelUse').checked,mode:$('channelMode').value,keywords:$('channelKeywords').value.split(',').map(x=>x.trim()).filter(Boolean),hourly_limit:Number($('channelRate').value),paused:$('channelPause').checked,archived:$('channelArchive').checked};
    await api('update',{id:active,revision:policyRevision,policy,authorize_automatic:$('authorizeAuto').checked});await reloadView();$('channelDialog').close();sidebar();notify('Local channel permissions saved. Other rigs keep their own settings.');
  });
  $('exportChannelCard').onclick=()=>work($('exportChannelCard'),'Saving…',async()=>{const d=await api('export',{id:active});save(d.name.replace(/[^a-z0-9_-]/gi,'-')+'.braidchannel',JSON.stringify(d,null,2));notify('Signed channel card saved. Import the same card on the other rig.');});
  $('importChannelButton').onclick=()=>$('channelCardFile').click();
  $('channelCardFile').onchange=()=>safe(async()=>{const f=$('channelCardFile').files[0];try{if(!f)return;if(f.size>10000)throw new Error('Channel card too large.');const d=JSON.parse(await f.text()),r=await api('import',{descriptor:d});if(!confirm('Import #'+r.descriptor.name+'?\n\nChannel ID: '+r.descriptor.id+'\nCreator fingerprint: '+r.creator_fingerprint+'\n\nCompare this identity through a trusted channel. All local permissions start OFF.'))return;const c=await api('import',{descriptor:d,confirmed:true});await D().refresh();await openChannel(c.id);openPolicy();}finally{$('channelCardFile').value='';}});
  $('importSignedNote').onclick=()=>$('channelFrameFile').click();
  $('channelFrameFile').onchange=()=>safe(async()=>{const f=$('channelFrameFile').files[0];try{if(!f)return;if(f.size>130000)throw new Error('Signed note too large.');const raw=new Uint8Array(await f.arrayBuffer());let binary='';raw.forEach(b=>{binary+=String.fromCharCode(b);});const r=await job('import-frame',{frame_base64:btoa(binary)});notify(r.phase_b_committed?'Signed note accepted; inspect its indexing receipt.':'Not accepted: '+(r.reason||r.error||'inspect receipt'));await reloadView();}finally{$('channelFrameFile').value='';}});
  $('refreshChannelConflicts').onclick=()=>work($('refreshChannelConflicts'),'Reconciling…',async()=>{const r=await job('reconcile',{id:active});$('channelConflictResult').innerHTML=`<p class="microcopy">${E(r.possible_conflict_count)} possible conflict signal(s). Nothing is silently resolved or erased.</p>`+(r.clusters||[]).map(c=>`<article class="channel-note-card"><span class="channel-note-state">${E(c.status.replaceAll('_',' '))}</span>${c.members.map(n=>`<blockquote>${E(n.text)}</blockquote>`).join('')}</article>`).join('')+`<details><summary>Exact reconciliation</summary><pre>${E(JSON.stringify(r,null,2))}</pre></details>`;});
  if(D()?.getState()){state=D().getState();sidebar();}
})();
