"""Archangel desktop workflow: retained a3 semantics with hardened transport/lifecycle.

Rig cards are explicit local trust enrollment, not a discovery/authority protocol.
LAN uses TLS 1.3 with the exact certificate supplied in the approved signed card.
No key, received text, model endpoint, or callback is executed from a card.
"""
from __future__ import annotations

import base64
import contextlib
import hashlib
import io
import ipaddress
import json
import os
import re
import math

import numpy as np
import secrets
import shutil
import socket
import sqlite3
import ssl
import tempfile
import threading
import time
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.x509.oid import NameOID

from . import __version__
from .channels import ChannelMixin
from .channel_chat import ChannelChatMixin
from .private_files import atomic_private_write, private_dir, secure_path
from .local_network import local_address, local_addresses, address_available, address_kind
from .context_workflow import summarize_context, validate_context_text, send_context, list_approved_peers
from .environment import default_workspace, _private_ipv4_candidates, _ollama_snapshot
from .keys import get_raw_public_bytes
from .mcp_core.protocol import BraidFrame
from .receiver import AutomatedReceiver, ReceiverAutomationConfig
from .semantic_capsule import SemanticCapsuleHandoffConfig, extract_semantic_capsule
from .semantic_field import (SemanticFieldConfig, inspect_semantic_field, inspect_semantic_field_object,
    query_semantic_field, search_semantic_field, reconcile_semantic_field, reindex_semantic_fields,
    load_semantic_field_bundle, render_semantic_delta_material, build_semantic_delta_extension)
from .semantic_transfer import (build_frame_from_text, calibrate_ollama_route,
    create_validator_from_route_package, load_route_package)
from .transport.client import send_frame
from .transport.server import TransportServer, ReceiverConfig

CARD_SCHEMA = 'intersignal.braid.rig-card.v1'
CAPABILITIES = ['semantic-capsule.v1', 'semantic-field.384.v1', 'signed-delta.v1', 'tls-client.v1', 'durable-handoff.v1', 'channels.v1', 'shared-notes-context.v1']
MAX_CARD_BYTES = 12 * 1024 * 1024
MAX_ROUTE_BYTES = 8 * 1024 * 1024
MAX_PEERS = 16
ARTIFACT_NAME = re.compile(r'^[a-zA-Z0-9_]{1,80}\.npy$')
HEX64 = re.compile(r'^[0-9a-f]{64}$')


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('utf-8')


private_write = atomic_private_write


def certificate_hash(path: Path) -> str:
    cert = x509.load_pem_x509_certificate(path.read_bytes())
    return hashlib.sha256(cert.public_bytes(serialization.Encoding.DER)).hexdigest()


def short_name(value: Any, default: str = '') -> str:
    value = str(value or default).strip()
    if not value or len(value) > 80 or any(ord(c) < 32 for c in value):
        raise ValueError('Use a rig name of 1 to 80 ordinary characters.')
    return value


def route_members(root: Path) -> dict[str, bytes]:
    root = root.resolve()
    report_path = root / 'route.json'
    if report_path.is_symlink() or report_path.stat().st_size > 512 * 1024:
        raise ValueError('Invalid or oversized route.json.')
    raw = report_path.read_bytes()
    report = json.loads(raw)
    artifacts = report.get('artifacts')
    if not isinstance(artifacts, dict) or not 1 <= len(artifacts) <= 20:
        raise ValueError('Invalid route artifact list.')
    files = {'route.json': raw}
    total = len(raw)
    for name, expected in artifacts.items():
        if not ARTIFACT_NAME.fullmatch(name) or not isinstance(expected, str) or not HEX64.fullmatch(expected):
            raise ValueError('Unsafe route artifact name or hash.')
        path = root / name
        if path.is_symlink() or path.resolve().parent != root:
            raise ValueError('Route artifacts cannot be symlinks or leave the route folder.')
        total += path.stat().st_size
        if total > MAX_ROUTE_BYTES:
            raise ValueError('Route package exceeds the card size limit.')
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != expected:
            raise ValueError('Route artifact hash mismatch: ' + name)
        # Inspect the NPY header before numpy can allocate attacker-declared shapes.
        header = io.BytesIO(data)
        version = np.lib.format.read_magic(header)
        if version == (1, 0):
            shape, _, dtype = np.lib.format.read_array_header_1_0(header)
        elif version == (2, 0):
            shape, _, dtype = np.lib.format.read_array_header_2_0(header)
        else:
            raise ValueError('Unsupported route array format.')
        if dtype.kind != 'f' or dtype.itemsize not in (4, 8) or not 1 <= len(shape) <= 2:
            raise ValueError('Route arrays must be bounded real floating-point vectors or matrices.')
        if any(type(d) is not int or d < 1 or d > 8192 for d in shape):
            raise ValueError('Route array shape exceeds the compact-client bounds.')
        expected_size = math.prod(shape) * dtype.itemsize
        if expected_size > MAX_ROUTE_BYTES or len(data) - header.tell() != expected_size:
            raise ValueError('Route array payload does not match its bounded shape.')
        if not np.isfinite(np.frombuffer(data, dtype=dtype, offset=header.tell())).all():
            raise ValueError('Route arrays cannot contain nonfinite values.')
        files[name] = data
    return files


def unpack_route(encoded: str, destination: Path) -> None:
    if not isinstance(encoded, str) or len(encoded) > MAX_CARD_BYTES:
        raise ValueError('Route card is too large.')
    payload = base64.b64decode(encoded, validate=True)
    if len(payload) > MAX_ROUTE_BYTES:
        raise ValueError('Compressed route is too large.')
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        infos = archive.infolist()
        if not 2 <= len(infos) <= 21 or len({i.filename for i in infos}) != len(infos):
            raise ValueError('Invalid route archive members.')
        if sum(i.file_size for i in infos) > MAX_ROUTE_BYTES:
            raise ValueError('Expanded route is too large.')
        for info in infos:
            if info.filename != 'route.json' and not ARTIFACT_NAME.fullmatch(info.filename):
                raise ValueError('Unsafe route archive path.')
            if info.is_dir() or ((info.external_attr >> 16) & 0o170000) == 0o120000:
                raise ValueError('Folders and symlinks are not permitted in a rig card.')
            private_write(destination / info.filename, archive.read(info))
    members = route_members(destination)
    if set(members) != {i.filename for i in infos}:
        raise ValueError('Unreferenced files are not permitted in a route card.')


def receipt_stage(value: dict[str, Any]) -> str:
    """Never infer commitment or indexing from validation or a summary string."""
    if value.get('accepted') is False or value.get('stored') is False:
        return 'rejected'
    if value.get('status') == 'transport_unproven':
        return 'outcome_unknown'
    if value.get('phase_b_committed') is True:
        semantic = value.get('semantic_transfer') or {}
        field = semantic.get('semantic_field') or {}
        if value.get('field_indexed') is True or ('field_indexed' not in value and field.get('indexed') is True):
            return 'indexed'
        return 'accepted'
    if value.get('accepted') is True and value.get('stored') is True and value.get('validated') is True and value.get('phase_b_committed') is None:
        return 'accepted_legacy'
    return 'rejected'


class MessengerService(ChannelMixin, ChannelChatMixin):
    def __init__(self, signing_key: ed25519.Ed25519PrivateKey, inbox: Path, home: Path | None = None):
        self.key = signing_key
        self.public_key = get_raw_public_bytes(signing_key.public_key()).hex()
        self.fingerprint = hashlib.sha256(bytes.fromhex(self.public_key)).hexdigest()
        self.home = Path(home or os.environ.get('BRAID_MESSENGER_HOME') or default_workspace() / 'messenger')
        self.inbox = Path(inbox)
        private_dir(self.home)
        private_dir(self.inbox)
        # Only this profile's ephemeral inspections. Approved trust lives elsewhere.
        shutil.rmtree(self.home / "pending", ignore_errors=True)
        self.lock = threading.RLock()
        self.receive_lock = threading.RLock()
        self.csrf = secrets.token_urlsafe(32)
        self.db_path = self.home / 'messenger.sqlite3'
        self._init_db()
        self._init_channels()
        addresses = local_addresses()
        self.settings = self.get_value('settings') or {
            'name': socket.gethostname().split('.')[0], 'host': addresses[0] if addresses else '127.0.0.1',
            'port': 8746, 'embed_model': 'all-minilm:latest', 'completion_model': '',
            'route_path': '', 'resume_listener': False,
        }
        self.listener: TransportServer | None = None
        self.listener_error: str | None = None
        self.receivers: dict[str, tuple[Any, AutomatedReceiver]] = {}
        self.jobs: dict[str, dict[str, Any]] = {}
        self.pending: dict[str, dict[str, Any]] = {}
        self.pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix='braid-messenger')
        self.probe_cache: dict[str, dict[str, Any]] = {}
        self.model_cache: dict[str, Any] = {}
        self.closed = False
        self.scan_lock = threading.Lock()
        self.scan_iterator = None
        self.scan_due = 0.0
        self._tls_identity()
        self._load_receivers()
        self.scan_receipts()
        if self.settings.get('resume_listener'):
            try:
                self.start_listener()
            except Exception as exc:
                self.listener_error = str(exc)[:300]

    @contextlib.contextmanager
    def _db(self):
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _init_db(self):
        with self._db() as db:
            db.executescript('''
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS messages (id TEXT PRIMARY KEY, direction TEXT NOT NULL,
                    peer TEXT NOT NULL, title TEXT NOT NULL, text TEXT NOT NULL, stage TEXT NOT NULL,
                    created REAL NOT NULL, unread INTEGER NOT NULL DEFAULT 1, archived INTEGER NOT NULL DEFAULT 0,
                    payload TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS contacts (id TEXT PRIMARY KEY, data TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS deliveries (handoff TEXT NOT NULL, peer TEXT NOT NULL,
                    content_hash TEXT NOT NULL, message_id TEXT NOT NULL, stage TEXT NOT NULL,
                    result TEXT NOT NULL, updated REAL NOT NULL, PRIMARY KEY(handoff,peer));
                CREATE TABLE IF NOT EXISTS receipt_files (name TEXT PRIMARY KEY, stamp INTEGER NOT NULL, size INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS trust_highwater (id TEXT PRIMARY KEY, revision INTEGER NOT NULL, card_hash TEXT NOT NULL);
            ''')
            db.execute("UPDATE messages SET stage='outcome_unknown' WHERE stage IN ('sending','queued')")
            db.execute("UPDATE deliveries SET stage='outcome_unknown' WHERE stage IN ('sending','queued')")
        secure_path(self.db_path)

    def get_value(self, key: str):
        with self._db() as db:
            row = db.execute('SELECT value FROM kv WHERE key=?', (key,)).fetchone()
        return json.loads(row[0]) if row else None

    def set_value(self, key: str, value: Any):
        with self._db() as db:
            db.execute('INSERT OR REPLACE INTO kv VALUES (?,?)', (key, canonical(value).decode()))

    def contacts(self) -> list[dict[str, Any]]:
        with self._db() as db:
            return [json.loads(row[0]) for row in db.execute('SELECT data FROM contacts ORDER BY id')]

    def _tls_identity(self):
        self.tls_cert = self.home / 'lan-certificate.pem'
        self.tls_key = self.home / 'lan-tls-private.pem'
        self.server_name = 'braid-' + self.fingerprint[:24] + '.local'
        if self.tls_cert.is_file() != self.tls_key.is_file():
            raise ValueError('Incomplete LAN TLS identity. Restore the matching certificate and key; do not rotate silently.')
        if not self.tls_cert.is_file():
            key = ed25519.Ed25519PrivateKey.generate()
            subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, self.server_name)])
            now = datetime.now(timezone.utc)
            cert = (x509.CertificateBuilder().subject_name(subject).issuer_name(subject)
                .public_key(key.public_key()).serial_number(x509.random_serial_number())
                .not_valid_before(now - timedelta(days=1)).not_valid_after(now + timedelta(days=3650))
                .add_extension(x509.SubjectAlternativeName([x509.DNSName(self.server_name)]), critical=False)
                .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
                .sign(key, algorithm=None))
            private_write(self.tls_key, key.private_bytes(serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
            private_write(self.tls_cert, cert.public_bytes(serialization.Encoding.PEM))
        cert = x509.load_pem_x509_certificate(self.tls_cert.read_bytes())
        if self.server_name not in cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value.get_values_for_type(x509.DNSName):
            raise ValueError('Signing identity changed. Use a separate Messenger profile or restore the original signing key.')

    def submit(self, kind: str, action: Callable[[], Any]) -> dict[str, Any]:
        with self.lock:
            if self.closed or sum(j['status'] in ('queued', 'running') for j in self.jobs.values()) >= 4:
                raise ValueError('There are already several operations in progress. Let one finish before starting another.')
            ident = uuid.uuid4().hex
            self.jobs[ident] = {'id': ident, 'kind': kind, 'status': 'queued', 'created': time.time()}
            done = [k for k,v in self.jobs.items() if v['status'] not in ('queued','running')]
            for key in done[:-20]:
                del self.jobs[key]
        def run():
            with self.lock:
                self.jobs[ident]['status'] = 'running'
            try:
                result = action()
                with self.lock:
                    self.jobs[ident].update(status='done', result=result, finished=time.time())
            except Exception as exc:
                with self.lock:
                    self.jobs[ident].update(status='error', error=str(exc)[:600], finished=time.time())
        self.pool.submit(run)
        return {'job_id': ident}

    def job(self, ident: str) -> dict[str, Any]:
        with self.lock:
            if ident not in self.jobs:
                raise ValueError('Operation not found. Check the inbox before repeating a send.')
            return dict(self.jobs[ident])

    def save_settings(self, data: dict[str, Any]):
        if self.listener is not None:
            raise ValueError('Pause receiving before changing this rig configuration.')
        candidate = dict(self.settings)
        candidate.update(name=short_name(data.get('name'), candidate['name']),
                         host=local_address(data.get('host', candidate['host'])))
        port = data.get('port', candidate['port'])
        if isinstance(port, bool) or not str(port).isdigit() or not 1024 <= int(port) <= 65535:
            raise ValueError('Choose a port from 1024 through 65535.')
        candidate['port'] = int(port)
        for key in ('embed_model', 'completion_model'):
            if key in data:
                value = str(data[key]).strip()
                if len(value) > 200 or any(ord(c) < 32 for c in value):
                    raise ValueError('Invalid model name.')
                candidate[key] = value
        if not candidate['embed_model']:
            raise ValueError('Choose an installed local embedding model.')
        if data.get('route_path'):
            path = Path(str(data['route_path'])).expanduser().resolve()
            route_members(path)
            create_validator_from_route_package(path, self.public_key, self.home / 'route-check.sqlite3')
            candidate['route_path'] = str(path)
        with self.lock:
            self.settings = candidate
            self.set_value('settings', candidate)
            self._load_receivers()
        return {'saved': True}

    def prepare(self) -> dict[str, Any]:
        with self.lock:
            model = self.settings['embed_model']
            if self.listener:
                raise ValueError('Pause receiving before preparing a new route.')
        root = self.home / ('route-' + uuid.uuid4().hex[:12])
        report = calibrate_ollama_route(source_model=model, target_model=model, output_dir=root, count=768)
        create_validator_from_route_package(root, self.public_key, self.home / 'route-check.sqlite3')
        with self.lock:
            self.settings['route_path'] = str(root)
            self.set_value('settings', self.settings)
        return {'prepared': True, 'route_status': report.get('status'), 'route_path': str(root)}

    def export_card(self) -> dict[str, Any]:
        root = Path(self.settings.get('route_path') or self.home / 'missing-route')
        files = route_members(root)
        create_validator_from_route_package(root, self.public_key, self.home / 'route-check.sqlite3')
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
            for name, payload in sorted(files.items()):
                archive.writestr(name, payload)
        with self.lock:
            revision = int(self.get_value('card_revision') or 0) + 1
            self.set_value('card_revision', revision)
        card = {'revision': revision, 'mtls_required': True, 'schema': CARD_SCHEMA, 'name': self.settings['name'], 'public_key': self.public_key,
            'fingerprint': self.fingerprint, 'host': local_address(self.settings['host']), 'port': self.settings['port'],
            'server_name': self.server_name, 'tls_certificate': self.tls_cert.read_text('ascii'),
            'route_sha256': hashlib.sha256(files['route.json']).hexdigest(),
            'route_zip': base64.b64encode(buffer.getvalue()).decode('ascii'),
            'capabilities': CAPABILITIES, 'created': int(time.time())}
        card['signature'] = self.key.sign(b'BRAID-RIG-CARD-v1\0' + canonical(card)).hex()
        return card

    def inspect_card(self, card: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(card, dict) or len(canonical(card)) > MAX_CARD_BYTES:
            raise ValueError('Invalid or oversized rig card.')
        if card.get('schema') != CARD_SCHEMA:
            raise ValueError('This rig-card format is not supported. Nothing was imported.')
        public = card.get('public_key', '')
        if not isinstance(public, str) or not HEX64.fullmatch(public):
            raise ValueError('Invalid rig public key.')
        fingerprint = hashlib.sha256(bytes.fromhex(public)).hexdigest()
        if fingerprint == self.fingerprint:
            raise ValueError('That is this rig\'s card. Import the card from your other machine.')
        if card.get('fingerprint') != fingerprint:
            raise ValueError('Rig fingerprint mismatch.')
        unsigned = dict(card)
        signature = unsigned.pop('signature', '')
        ed25519.Ed25519PublicKey.from_public_bytes(bytes.fromhex(public)).verify(
            bytes.fromhex(signature), b'BRAID-RIG-CARD-v1\0' + canonical(unsigned))
        revision = card.get('revision', 0)
        if type(revision) is not int or not 0 <= revision < 2**63:
            raise ValueError('Invalid card revision.')
        if card.get('mtls_required') is not True or 'tls-client.v1' not in card.get('capabilities', []):
            raise ValueError('Import a refreshed Archangel rig card. Legacy cards do not authorize mutual TLS; no downgrade was applied.')
        card_hash = hashlib.sha256(canonical(card)).hexdigest()
        with self._db() as db:
            watermark = db.execute('SELECT revision,card_hash FROM trust_highwater WHERE id=?',(fingerprint,)).fetchone()
        if watermark and (revision < watermark[0] or (revision == watermark[0] and card_hash != watermark[1])):
            raise ValueError('Stale or conflicting card revision. Export a fresh card on the owning rig.')
        name = short_name(card.get('name'))
        host = local_address(card.get('host'))
        port = card.get('port')
        if type(port) is not int or not 1024 <= port <= 65535:
            raise ValueError('Invalid receiver port.')
        server_name = 'braid-' + fingerprint[:24] + '.local'
        if card.get('server_name') != server_name or len(str(card.get('tls_certificate', ''))) > 16384:
            raise ValueError('Invalid certificate identity.')
        cert = x509.load_pem_x509_certificate(card['tls_certificate'].encode('ascii'))
        if server_name not in cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value.get_values_for_type(x509.DNSName):
            raise ValueError('Certificate does not identify this rig.')
        # A pinned self-signed certificate must prove its own key and be in date.
        cert.public_key().verify(cert.signature, cert.tbs_certificate_bytes)
        now = datetime.now(timezone.utc)
        if cert.issuer != cert.subject or not cert.not_valid_before_utc <= now <= cert.not_valid_after_utc:
            raise ValueError('Rig certificate is expired, not yet valid, or not self-issued.')
        tls_hash = hashlib.sha256(cert.public_bytes(serialization.Encoding.DER)).hexdigest()
        previous = next((c for c in self.contacts() if c['id'] == fingerprint), None)
        update_kind = 'new'
        if previous:
            old_hash = previous.get('tls_sha256') or certificate_hash(Path(previous['route_path'])/'certificate.pem')
            if previous['route_sha256'] != card['route_sha256'] or old_hash != tls_hash:
                raise ValueError('Certificate or route changed. Remove trust explicitly, verify the change on the owning rig, then reapprove. An address update cannot rotate authority.')
            update_kind = 'address'
        with self.lock:
            for ident, entry in list(self.pending.items()):
                if entry['expires'] < time.time():
                    shutil.rmtree(entry['root'], ignore_errors=True)
                    self.pending.pop(ident, None)
            if len(self.pending) >= 4:
                raise ValueError('Finish or cancel the current rig approval first.')
        ident = uuid.uuid4().hex
        root = self.home / 'pending' / ident
        try:
            unpack_route(card.get('route_zip'), root)
            if hashlib.sha256((root / 'route.json').read_bytes()).hexdigest() != card.get('route_sha256'):
                raise ValueError('Route identity mismatch.')
            _, _, _, package = create_validator_from_route_package(root, public, root / 'check.sqlite3')
            private_write(root / 'certificate.pem', card['tls_certificate'].encode('ascii'))
            info = {'revision': revision, 'card_hash': card_hash, 'tls_sha256': tls_hash, 'update_kind': update_kind, 'id': fingerprint, 'name': name, 'host': host, 'port': port, 'public_key': public,
                'server_name': server_name, 'route_sha256': card['route_sha256'],
                'source_model': package['source_model'], 'source_model_digest': package.get('source_model_digest'),
                'capabilities': [str(x)[:80] for x in card.get('capabilities', [])[:16]]}
            with self.lock:
                self.pending[ident] = {'root': root, 'info': info, 'expires': time.time() + 600}
            return {'inspection_id': ident, **info, 'signature_valid': True,
                'approval_note': 'Compare this fingerprint on the other rig. Approval trusts this key AND this route. A self-signature is not identity proof.'}
        except Exception:
            shutil.rmtree(root, ignore_errors=True)
            raise

    def approve_card(self, ident: str, fingerprint: str, confirmed: bool):
        with self.lock:
            pending = self.pending.get(ident)
            if not pending or pending['expires'] < time.time():
                raise ValueError('Rig review expired. Import the card again.')
            info = pending['info']
            if confirmed is not True or fingerprint != info['id']:
                raise ValueError('Compare and confirm the exact fingerprint first.')
            contacts = self.contacts()
            previous = next((c for c in contacts if c['id'] == info['id']), None)
            # Recheck at approval, not only at asynchronous inspection time.
            with self._db() as db:
                watermark = db.execute('SELECT revision,card_hash FROM trust_highwater WHERE id=?',(info['id'],)).fetchone()
            if watermark and (info['revision'] < watermark[0] or (info['revision'] == watermark[0] and info['card_hash'] != watermark[1])):
                raise ValueError('A newer card has already been approved. Import a fresh one.')
            if previous:
                old_hash = previous.get('tls_sha256') or certificate_hash(Path(previous['route_path'])/'certificate.pem')
                if old_hash != info['tls_sha256'] or previous['route_sha256'] != info['route_sha256']:
                    raise ValueError('Trust changed during review. Review and approve again.')
                destination = Path(previous['route_path'])
                shutil.rmtree(pending['root'], ignore_errors=True)
            else:
                if len(contacts) >= MAX_PEERS:
                    raise ValueError('This compact client supports up to 16 approved rigs.')
                destination = self.home / 'peers' / info['id']
                if destination.exists():
                    shutil.rmtree(destination)
                private_dir(destination.parent)
                shutil.move(str(pending['root']), destination)
            info = dict(info, route_path=str(destination), approved_at=time.time())
            with self._db() as db:
                db.execute('INSERT OR REPLACE INTO contacts VALUES (?,?)', (info['id'], canonical(info).decode()))
                db.execute('INSERT OR REPLACE INTO trust_highwater VALUES (?,?,?)', (info['id'], info['revision'], info['card_hash']))
            self.pending.pop(ident)
            self.probe_cache.pop(info['id'], None)
            self._load_receivers()
            self._refresh_client_trust()
        return {'approved': True, 'peer': info['id']}

    def remove_contact(self, ident: str):
        with self.receive_lock, self.lock:
            with self._db() as db:
                db.execute('DELETE FROM contacts WHERE id=?', (ident,))
            self.receivers.pop(ident, None)
            self.probe_cache.pop(ident, None)
            self._refresh_client_trust()
        return {'removed': True, 'history_preserved': True}

    def _receiver_for(self, contact: dict[str, Any]):
        public = ed25519.Ed25519PublicKey.from_public_bytes(bytes.fromhex(contact['public_key']))
        validator, registry, ledger, _ = create_validator_from_route_package(
            Path(contact['route_path']), contact['public_key'], self.inbox / 'replay_ledger.db')
        handoff = SemanticCapsuleHandoffConfig(embedding_model=self.settings['embed_model'],
            verify_exact_space_coherence=True, semantic_field=SemanticFieldConfig(embedding_model=self.settings['embed_model']))
        return public, AutomatedReceiver(validator=validator, registry=registry, ledger=ledger,
            verification_key=public, config=ReceiverAutomationConfig(storage_dir=self.inbox, auto_commit=True,
                semantic_capsule_handoff=handoff))

    def _load_receivers(self):
        receivers, errors = {}, {}
        for contact in self.contacts():
            try:
                receivers[contact['id']] = self._receiver_for(contact)
            except Exception as exc:
                errors[contact['id']] = str(exc)[:300]
        self.receivers, self.receiver_errors = receivers, errors

    def _authorized_tls_peer(self, digest: str) -> bool:
        return any(c.get('tls_sha256') == digest and 'tls-client.v1' in c.get('capabilities', []) for c in self.contacts())

    def _refresh_client_trust(self):
        # Include own certificate as an inert anchor when no peers are approved.
        # Exact-hash authorization still rejects it unless explicitly approved.
        certificates = [self.tls_cert.read_bytes()]
        for contact in self.contacts():
            if 'tls-client.v1' in contact.get('capabilities', []):
                certificates.append((Path(contact['route_path'])/'certificate.pem').read_bytes())
        private_write(self.home/'approved-tls.pem', b'\n'.join(certificates))
        if self.listener:
            self.listener.reload_client_trust()

    def update_address(self, host: str):
        host = local_address(host)
        if not address_available(host):
            raise ValueError('That address is not assigned to this rig. Select a current interface address.')
        was_running = self.listener is not None
        self.stop_listener()
        self.save_settings({'host': host})
        if was_running:
            self.start_listener()
        return {'updated': True, 'identity_preserved': True, 'redistribute_card': True,
                'message': 'Save an updated rig card and approve it on the other rigs. Keys, route and history are unchanged.'}

    def start_listener(self):
        with self.lock:
            if self.listener:
                return {'listening': True}
            if self.closed:
                raise ValueError('Archangel is shutting down.')
            if not address_available(self.settings['host']):
                self.listener_error = 'This rig has changed networks. Use Settings > Update address, then share an updated card.'
                raise ValueError(self.listener_error)
            self._refresh_client_trust()
            config = ReceiverConfig(bind=local_address(self.settings['host']), port=self.settings['port'],
                output_dir=self.inbox, allow_lan=True, tls_cert=self.tls_cert, tls_key=self.tls_key,
                receiver_callback=self.receive, socket_timeout_seconds=60, handshake_timeout_seconds=3,
                allow_overlay=True, require_client_cert=True, client_ca=self.home/'approved-tls.pem',
                tls_peer_authorizer=self._authorized_tls_peer, bind_tls_identity=True)
            listener = TransportServer(config)
            listener.start()
            self.listener = listener
            self.listener_error = None
            self.settings['resume_listener'] = True
            self.set_value('settings', self.settings)
        return {'listening': True, 'tls': 'TLSv1.3', 'bind': config.bind, 'port': self.settings['port']}

    def stop_listener(self):
        with self.lock:
            listener, self.listener = self.listener, None
            self.settings['resume_listener'] = False
            self.set_value('settings', self.settings)
        if listener:
            listener.stop()
        return {'listening': False}

    def receive(self, payload: bytes, **source) -> dict[str, Any]:
        tls_hash = source.pop('tls_peer_cert_sha256', None)
        if self.closed or (source.get('source_transport') == 'network' and not self._authorized_tls_peer(tls_hash or '')):
            return {'accepted': False, 'stored': False, 'phase_b_committed': False,
                    'finality': 'rejected', 'reason': 'ERR_UNAPPROVED_TLS_IDENTITY'}
        try:
            frame = BraidFrame.from_bytes(payload)
        except Exception:
            return {'accepted': False, 'stored': False, 'phase_b_committed': False,
                    'finality': 'rejected', 'reason': 'ERR_MALFORMED_FRAME'}
        with self.receive_lock:
            with self.lock:
                candidates = list(self.receivers.items())
            for peer_id, (public, receiver) in candidates:
                if tls_hash is not None:
                    contact = next((c for c in self.contacts() if c['id'] == peer_id), {})
                    if contact.get('tls_sha256') != tls_hash:
                        continue
                try:
                    public.verify(frame.signature_bytes, frame.signature_preimage)
                except Exception:
                    continue
                try:
                    self._channel_frame_policy(frame, peer_id)
                except ValueError as exc:
                    return {'accepted':False,'stored':False,'phase_b_committed':False,
                            'finality':'rejected','reason':str(exc)[:300]}
                report = receiver.process_bytes(payload, **source)
                self.record_incoming(report, peer_id, frame)
                return report
        return {'accepted': False, 'stored': False, 'phase_b_committed': False,
                'finality': 'rejected', 'reason': 'ERR_UNAPPROVED_RIG'}

    def put_message(self, ident: str, direction: str, peer: str, title: str, text: str,
                    stage: str, payload: Any, *, created: float | None = None, unread: bool = True):
        with self._db() as db:
            db.execute('''INSERT INTO messages(id,direction,peer,title,text,stage,created,unread,payload)
                VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET stage=excluded.stage,payload=excluded.payload''',
                (ident, direction, peer, title[:160], text, stage, created or time.time(), int(unread), canonical(payload).decode()))

    def record_incoming(self, report: dict[str, Any], peer: str = '', frame: BraidFrame | None = None):
        ident = str(report.get('transfer_id') or Path(str(report.get('receipt_path', ''))).stem or uuid.uuid4().hex)
        text = ''
        if frame:
            try:
                capsule, _ = extract_semantic_capsule(frame.manifest)
                text = capsule.get('content', '') if capsule else ''
            except Exception:
                pass
        title = next((s.strip() for s in text.splitlines() if s.strip()), 'Received state')[:120]
        created = report.get('received_at') or report.get('received_at_unix') or report.get('_inbox_received_at') or time.time()
        if not isinstance(created, (int,float)):
            created = time.time()
        if frame:
            self.record_channel_object(report, frame, peer)
        self.put_message('in-' + ident, 'in', peer or str(report.get('source_peer') or 'Imported receipt'), title, text,
                         receipt_stage(report), report, created=created)

    def scan_receipts(self, *, force: bool = False, budget: int = 128):
        """Incremental safety-net reconciliation; live receives ingest immediately.

        Bound metadata work per pass; do not sort or enumerate the entire inbox on
        every UI poll. Revisit all files eventually, even with unchanged dir mtime.
        """
        if not force and time.monotonic() < self.scan_due:
            return
        if not self.scan_lock.acquire(blocking=False):
            return
        try:
            if self.scan_iterator is None:
                try:
                    self.scan_iterator = os.scandir(self.inbox / 'receipts')
                except FileNotFoundError:
                    self.scan_due = time.monotonic() + 10
                    return
            changed = []
            with self._db() as db:
                for _ in range(min(max(budget, 1), 512)):
                    try:
                        entry = next(self.scan_iterator)
                    except StopIteration:
                        self.scan_iterator.close()
                        self.scan_iterator = None
                        break
                    if not entry.name.endswith('.json') or entry.is_symlink():
                        continue
                    try:
                        stat = entry.stat(follow_symlinks=False)
                        if not 0 < stat.st_size <= 512 * 1024:
                            continue
                        previous = db.execute('SELECT stamp,size FROM receipt_files WHERE name=?',(entry.name,)).fetchone()
                        if previous and tuple(previous) == (stat.st_mtime_ns, stat.st_size):
                            continue
                        path = Path(entry.path)
                        report = json.loads(path.read_text('utf-8'))
                        if not isinstance(report,dict) or report.get('schema') != 'braid.receiver.receipt.v1':
                            continue
                        digest = report.get('object_digest', '')
                        frame = None
                        transport_digest = str(report.get('transport_sha256', ''))
                        if HEX64.fullmatch(str(digest)) and HEX64.fullmatch(transport_digest):
                            for candidate in (self.inbox / 'accepted').glob('*' + transport_digest[:12] + '*.brad'):
                                if candidate.is_symlink() or candidate.stat().st_size > 2 * 1024 * 1024:
                                    continue
                                raw = candidate.read_bytes()
                                if hashlib.sha256(raw).hexdigest() == transport_digest:
                                    parsed = BraidFrame.from_bytes(raw)
                                    if parsed.object_digest == digest:
                                        frame = parsed
                                        break
                        report['_inbox_received_at'] = stat.st_mtime
                        changed.append((entry.name, stat.st_mtime_ns, stat.st_size, report, frame))
                    except (OSError, ValueError, TypeError):
                        continue
            # Separate transactions avoid nesting a read snapshot and a writer.
            for name, stamp, size, report, frame in changed:
                self.record_incoming(report, frame=frame)
            if changed:
                with self._db() as db:
                    db.executemany('INSERT OR REPLACE INTO receipt_files VALUES (?,?,?)', [c[:3] for c in changed])
            self.scan_due = time.monotonic() + (1 if self.scan_iterator else 10)
        finally:
            self.scan_lock.release()

    def messages(self):
        with self._db() as db:
            rows = db.execute('SELECT * FROM messages ORDER BY created DESC LIMIT 500').fetchall()
        values = []
        for row in rows:
            item = dict(row)
            item['payload'] = json.loads(item['payload'])
            values.append(item)
        return values

    def message_action(self, ident: str, action: str):
        statement = {'read': 'unread=0', 'unread': 'unread=1', 'archive': 'archived=1', 'restore': 'archived=0'}.get(action)
        if not statement:
            raise ValueError('Unknown inbox action.')
        with self._db() as db:
            db.execute('UPDATE messages SET ' + statement + ' WHERE id=?', (ident,))
        return {'updated': True}

    def delivery_states(self, handoff: str = ''):
        with self._db() as db:
            rows = db.execute('SELECT * FROM deliveries WHERE handoff=? ORDER BY peer', (handoff,)).fetchall() if handoff else []
        return [dict(row, result=json.loads(row['result'])) for row in rows]

    def send(self, peer_id: str, text: str, title: str = '', kind: str = 'summary', object_digest: str = '', handoff_id: str = '', channel_note: dict | None = None):
        explicit = bool(handoff_id)
        handoff_id = handoff_id or uuid.uuid4().hex
        if not re.fullmatch(r'[a-zA-Z0-9_-]{16,80}', handoff_id):
            raise ValueError('Invalid handoff identity.')
        material = validate_context_text(text, field='reviewed summary')
        hash_material = [material,title,kind,object_digest]
        if channel_note is not None:
            from .channel_protocol import validate_note_extension
            channel_note = validate_note_extension(channel_note, material)
            hash_material.append(channel_note)
        content_hash = hashlib.sha256(canonical(hash_material)).hexdigest()
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT * FROM deliveries WHERE handoff=? AND peer=?',(handoff_id,peer_id)).fetchone()
            if row:
                if row['content_hash'] != content_hash:
                    raise ValueError('Reviewed handoff changed. Create a new handoff; previous delivery records are immutable.')
                if row['stage'] not in ('failed','rejected'):
                    result = json.loads(row['result'])
                    return {**result, 'message_id':row['message_id'], 'stage':row['stage'], 'already_recorded':True,
                            'note':'No resend. Inspect Sent and the receiving rig for unconfirmed outcomes.'}
            if self.closed:
                raise ValueError('Archangel is shutting down. No send started.')
            ident = 'out-' + uuid.uuid4().hex
            db.execute('INSERT OR REPLACE INTO deliveries VALUES (?,?,?,?,?,?,?)',
                       (handoff_id,peer_id,content_hash,ident,'sending','{}',time.time()))
        try:
            result = self._send_once(peer_id,material,title,kind,object_digest,ident, **({"channel_note":channel_note} if channel_note is not None else {}))
        except Exception as exc:
            with self._db() as db:
                message = db.execute('SELECT stage,payload FROM messages WHERE id=?',(ident,)).fetchone()
            stage = message['stage'] if message else 'failed'
            result = {'message_id':ident,'stage':stage,'error':str(exc)[:500]}
            with self._db() as db:
                db.execute('UPDATE deliveries SET stage=?,result=?,updated=? WHERE handoff=? AND peer=?',
                           (stage,canonical(result).decode(),time.time(),handoff_id,peer_id))
            if not explicit:
                raise
            return result
        with self._db() as db:
            db.execute('UPDATE deliveries SET stage=?,result=?,updated=? WHERE handoff=? AND peer=?',
                       (result['stage'],canonical(result).decode(),time.time(),handoff_id,peer_id))
        return result

    def _send_once(self, peer_id: str, text: str, title: str, kind: str, object_digest: str, ident: str, channel_note: dict | None = None):
        material = validate_context_text(text, field='reviewed summary')
        contact = next((c for c in self.contacts() if c['id'] == peer_id), None)
        is_relay = peer_id.startswith('relay:')
        if not contact and not is_relay:
            raise ValueError('Choose an approved rig before sending.')
        if kind not in ('summary', 'context', 'delta'):
            raise ValueError('This payload type is not supported. Nothing was sent.')
        if channel_note is not None and (is_relay or 'channels.v1' not in contact.get('capabilities',[])):
            raise ValueError('Channel delivery needs an approved a6 direct peer; no silent legacy/relay downgrade.')
        delta_extension = None
        if kind == 'delta':
            # Rebuild exact signed delta at send time; never sign arbitrary UI-supplied lineage.
            delta_text, delta_extension, delta_evidence = render_semantic_delta_material(storage_dir=self.inbox, object_digest=object_digest)
            if material != delta_text:
                raise ValueError('Signed delta material changed. Export it again, or send the edited text as a normal summary.')
            if is_relay:
                raise ValueError('Use the retained field-delta-frame CLI for a signed delta over Managed Relay.')
        title = short_name(title, 'Shared summary')
        self.put_message(ident, 'out', peer_id, title, material, 'sending', {'kind':kind}, unread=False)
        raw_path = None
        network_started = False
        try:
            if is_relay:
                network_started = True
                result = send_context(material, peer=peer_id[6:], signing_key=self.key)
            else:
                if 'tls-client.v1' not in contact.get('capabilities', []):
                    raise ValueError('Refresh this contact with an Archangel rig card before sending. No TLS downgrade is allowed.')
                root = Path(self.settings.get('route_path') or self.home / 'missing-route')
                frame, raw, _, _ = build_frame_from_text(root, material, self.key, semantic_delta_extension=delta_extension, **({"channel_note_extension":channel_note} if channel_note is not None else {}))
                raw_path = self.home / 'outbox' / (ident + '.brad')
                private_write(raw_path, raw)
                network_started = True
                result = asdict(send_frame(raw_path, contact['host'], contact['port'], timeout_seconds=240,
                    use_tls=True, ca_file=Path(contact['route_path']) / 'certificate.pem', server_name=contact['server_name'],
                    client_cert=self.tls_cert, client_key=self.tls_key, pinned_cert_sha256=contact['tls_sha256']).ack)
                if result.get('transport_sha256') != hashlib.sha256(raw).hexdigest():
                    raise ValueError('Receiver receipt does not bind the exact sent bytes. Acceptance remains unconfirmed.')
                result.update(object_digest=frame.object_digest, tls_peer_verified=True)
            stage = receipt_stage(result)
            self.put_message(ident, 'out', peer_id, title, material, stage, {'kind':kind, **result}, unread=False)
            return {'message_id':ident, 'stage':stage, 'receipt':result}
        except Exception as exc:
            # A timeout may follow a successful commit. Do not quietly retry or invent non-delivery.
            self.put_message(ident, 'out', peer_id, title, material, 'outcome_unknown' if network_started else 'failed',
                {'kind':kind, 'error':str(exc)[:500], 'network_attempted':network_started,
                 'note':'Check the receiver inbox before manually retrying.' if network_started else 'Preparation failed before any network send.'}, unread=False)
            raise

    def probe(self):
        results = {}
        for contact in self.contacts():
            now = time.time()
            try:
                context = ssl.create_default_context(cafile=str(Path(contact['route_path']) / 'certificate.pem'))
                context.minimum_version = ssl.TLSVersion.TLSv1_3
                context.load_cert_chain(str(self.tls_cert), str(self.tls_key))
                with socket.create_connection((contact['host'], contact['port']), timeout=1.2) as raw:
                    with context.wrap_socket(raw, server_hostname=contact['server_name']) as tls:
                        if hashlib.sha256(tls.getpeercert(binary_form=True)).hexdigest() != contact.get('tls_sha256'):
                            raise ValueError('Rig TLS certificate pin changed.')
                results[contact['id']] = {'reachable':True, 'checked':now, 'meaning':'Pinned TLS listener reachable; not proof of receiver acceptance.'}
            except Exception as exc:
                results[contact['id']] = {'reachable':False, 'checked':now, 'error':str(exc)[:180]}
        with self.lock:
            self.probe_cache = results
        return results

    def models(self):
        self.model_cache = _ollama_snapshot()
        return self.model_cache

    def field_action(self, action: str, data: dict[str, Any]):
        common = {'storage_dir':self.inbox, 'embedding_model':self.settings['embed_model']}
        if action == 'status':
            return inspect_semantic_field(storage_dir=self.inbox)
        if action == 'reconcile':
            return reconcile_semantic_field(**common)
        if action == 'search':
            return search_semantic_field(question=str(data.get('question') or ''), **common)
        if action == 'query':
            model = str(data.get('model') or self.settings.get('completion_model') or '')
            if not model:
                raise ValueError('Choose a local completion model in Settings to ask the shared field.')
            return query_semantic_field(question=str(data.get('question') or ''), completion_model=model, **common)
        if action == 'reindex':
            return reindex_semantic_fields(**common)
        if action == 'delta':
            material, extension, evidence = render_semantic_delta_material(storage_dir=self.inbox, object_digest=str(data.get('object_digest') or ''))
            return {'text':material, 'extension':extension, 'evidence':evidence}
        raise ValueError('Unsupported field action.')

    def snapshot(self):
        self.scan_receipts()
        messages = self.messages()
        with self.lock:
            peers = [{**c, 'presence':self.probe_cache.get(c['id']), 'receiver_error':self.receiver_errors.get(c['id'])} for c in self.contacts()]
            jobs = [{k:v for k,v in j.items() if k != 'result'} for j in self.jobs.values()]
            settings = dict(self.settings)
        for peer in peers:
            peer.pop('public_key', None)
            peer.pop('route_path', None)
        try:
            field = inspect_semantic_field(storage_dir=self.inbox)
        except Exception as exc:
            field = {'ready':False, 'error':str(exc)[:200]}
        draft = self.get_value('draft')
        network_ok = address_available(settings['host'])
        return {'version':__version__, 'codename':'Archangel', 'csrf':self.csrf, 'settings':settings,
            'network':{'available':network_ok, 'kind':address_kind(settings['host']),
                       'warning':None if network_ok else 'Address changed. Open Settings > Update address.'},
            'deliveries':self.delivery_states((draft or {}).get('handoff_id','')),
            'fingerprint':self.fingerprint, 'addresses':local_addresses(), 'peers':peers,
            'messages':messages, 'jobs':jobs, 'field':field, 'draft':draft, 'channels':self.channel_list(),
            'listener':{'running':self.listener is not None, 'error':self.listener_error, 'tls':'TLSv1.3 + mutual authentication'},
            'route_ready':bool(settings.get('route_path') and (Path(settings['route_path']) / 'route.json').is_file()),
            'inbox_path':str(self.inbox), 'models':self.model_cache, 'capabilities':CAPABILITIES}

    def close(self):
        # Preserve the explicitly opted-in resume setting; normal exit is not "Pause receiving".
        self.closed = True
        with self.scan_lock:
            if self.scan_iterator is not None:
                self.scan_iterator.close()
                self.scan_iterator = None
        if self.listener:
            self.listener.stop()
            self.listener = None
        self.pool.shutdown(wait=False, cancel_futures=True)
        for entry in self.pending.values():
            shutil.rmtree(entry['root'], ignore_errors=True)
