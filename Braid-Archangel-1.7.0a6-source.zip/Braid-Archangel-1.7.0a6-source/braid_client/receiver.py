"""Unified automated receiver for Braid v1.7.0a3.

All deliberate transport paths terminate here. The receiver owns quarantine,
384D representation checks, receiver-local validation, replay-safe Phase B
commit, evidence emission, and optional local handoff. Transport never grants
authority.

The receipt exposes one deliberately simple invariant:

    accepted == (finality == "committed")

A Phase A pass is evidence, not acceptance. A post-commit artifact or handoff
failure can make delivery degraded, but cannot rewrite an already committed
receiver decision.
"""
from __future__ import annotations
from .private_files import secure_fd

import hashlib
import io
import json
import os
import shlex
import subprocess
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import numpy as np
from cryptography.hazmat.primitives.asymmetric import ed25519

from . import __version__
from .mcp_core.protocol import BraidFrame, ReplayLedger
from .mcp_core.validation import BraidValidator
from .legend import extract_legend_extension
from .ollama_adapter import OllamaHandoffConfig, OllamaReceiverAdapter, validate_ollama_route_binding
from .semantic_capsule import (
    SemanticCapsuleHandoffConfig, SemanticCapsuleReceiverAdapter,
    extract_semantic_capsule, validate_capsule_route_binding,
)


RECEIPT_SCHEMA = "braid.receiver.receipt.v1"
DERIVED_STATE_LINEAGE_SCHEMA = "braid.receiver.derived-state-lineage.v1"


@dataclass(frozen=True)
class ReceiverAutomationConfig:
    storage_dir: Path = Path("braid-inbox")
    max_frame_bytes: int = 2 * 1024 * 1024
    auto_commit: bool = True
    emit_vector_npy: bool = True
    retain_rejected: bool = True
    handoff_command: Optional[str] = None
    handoff_timeout_seconds: float = 20.0
    ollama_handoff: OllamaHandoffConfig | None = None
    semantic_capsule_handoff: SemanticCapsuleHandoffConfig | None = None
    audit_log: Optional[Path] = None


def _ensure_private_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(path, 0o700)
    except OSError:
        # Some platforms have reduced chmod semantics. File modes remain 0600.
        pass


def _atomic_write(path: Path, data: bytes, mode: int = 0o600) -> None:
    _ensure_private_dir(path.parent)
    tmp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
        try:
            os.chmod(path, mode)
        except OSError:
            pass
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass


def _safe_source_name(name: str | None) -> str:
    base = Path(name or "state.brad").name
    stem = Path(base).stem
    clean = "".join(ch for ch in stem if ch.isalnum() or ch in {"-", "_"})[:64]
    return clean or "state"


def _bounded_text(value: object | None, *, fallback: str, max_chars: int) -> str:
    text = str(value if value is not None else fallback).replace("\x00", "")
    text = "".join(ch for ch in text if ch == "\t" or ord(ch) >= 0x20)
    return (text[:max_chars] or fallback)


class AutomatedReceiver:
    """Receiver-owned, transport-agnostic Braid intake pipeline."""

    def __init__(
        self,
        *,
        validator: BraidValidator,
        registry: Any,
        ledger: ReplayLedger,
        verification_key: ed25519.Ed25519PublicKey,
        config: ReceiverAutomationConfig | None = None,
    ) -> None:
        self.validator = validator
        self.registry = registry
        self.ledger = ledger
        self.verification_key = verification_key
        self.config = config or ReceiverAutomationConfig()
        if self.config.max_frame_bytes <= 0:
            raise ValueError("ERR_MAX_FRAME_BYTES")
        if self.config.handoff_timeout_seconds <= 0:
            raise ValueError("ERR_HANDOFF_TIMEOUT_SECONDS")
        built_in_handoffs = int(self.config.ollama_handoff is not None) + int(self.config.semantic_capsule_handoff is not None)
        if (self.config.handoff_command and built_in_handoffs) or built_in_handoffs > 1:
            raise ValueError("ERR_HANDOFF_MODE_CONFLICT")
        self.ollama_adapter = (
            OllamaReceiverAdapter(self.config.ollama_handoff)
            if self.config.ollama_handoff is not None else None
        )
        self.semantic_capsule_adapter = (
            SemanticCapsuleReceiverAdapter(self.config.semantic_capsule_handoff)
            if self.config.semantic_capsule_handoff is not None else None
        )
        _ensure_private_dir(self.config.storage_dir)
        _ensure_private_dir(self.config.storage_dir / "quarantine")
        _ensure_private_dir(self.config.storage_dir / "receipts")

    def _audit(self, event: dict[str, Any]) -> None:
        path = self.config.audit_log
        if path is None:
            return
        _ensure_private_dir(path.parent)
        line = json.dumps({"ts_unix": int(time.time()), **event}, sort_keys=True, separators=(",", ":")) + "\n"
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        secure_fd(fd, 0o600)
        with os.fdopen(fd, "a", encoding="utf-8") as handle:
            handle.write(line)
            handle.flush()
            os.fsync(handle.fileno())

    def _route_file(self, current: Path, bucket: str, name: str) -> Path:
        destination = self.config.storage_dir / bucket / name
        _ensure_private_dir(destination.parent)
        os.replace(current, destination)
        try:
            os.chmod(destination, 0o600)
        except OSError:
            pass
        return destination

    def _receipt_path(self, identity: str, transfer_id: str) -> Path:
        safe_identity = "".join(ch for ch in identity if ch in "0123456789abcdefABCDEF")[:64]
        safe_identity = safe_identity or "unknown"
        return self.config.storage_dir / "receipts" / f"{safe_identity}-{transfer_id[:8]}.json"

    def _write_receipt(self, report: dict[str, Any], receipt_path: Path) -> None:
        report["receipt_path"] = str(receipt_path)
        payload = json.dumps(report, sort_keys=True, indent=2, allow_nan=False).encode("utf-8")
        _atomic_write(receipt_path, payload)

    def _handoff(self, frame_path: Path, vector_path: Path | None, receipt_path: Path) -> dict[str, Any]:
        template = self.config.handoff_command
        if not template:
            return {"configured": False, "ran": False, "accepted": True, "reason": "HANDOFF_NOT_CONFIGURED"}
        replacements = {
            "{frame}": str(frame_path),
            "{vector}": str(vector_path or ""),
            "{receipt}": str(receipt_path),
        }
        try:
            raw_argv = shlex.split(template)
        except ValueError:
            return {"configured": True, "ran": False, "accepted": False, "reason": "ERR_HANDOFF_PARSE"}
        argv: list[str] = []
        for token in raw_argv:
            for key, value in replacements.items():
                token = token.replace(key, value)
            argv.append(token)
        if not argv:
            return {"configured": True, "ran": False, "accepted": False, "reason": "ERR_HANDOFF_EMPTY"}
        try:
            completed = subprocess.run(
                argv,
                shell=False,
                capture_output=True,
                text=True,
                timeout=self.config.handoff_timeout_seconds,
                check=False,
            )
            return {
                "configured": True,
                "ran": True,
                "accepted": completed.returncode == 0,
                "returncode": completed.returncode,
                "reason": "HANDOFF_ACCEPTED" if completed.returncode == 0 else f"ERR_HANDOFF_REJECTED:{completed.returncode}",
                "stdout": completed.stdout[-2000:],
                "stderr": completed.stderr[-2000:],
            }
        except subprocess.TimeoutExpired:
            return {"configured": True, "ran": True, "accepted": False, "reason": "ERR_HANDOFF_TIMEOUT"}
        except OSError:
            return {"configured": True, "ran": False, "accepted": False, "reason": "ERR_HANDOFF_EXEC"}

    def process_bytes(
        self,
        raw_bytes: bytes,
        *,
        source_transport: str,
        source_name: str | None = None,
        peer: str | None = None,
    ) -> dict[str, Any]:
        started = time.perf_counter()
        if not isinstance(raw_bytes, (bytes, bytearray)):
            raise TypeError("ERR_FRAME_BYTES_REQUIRED")
        raw_bytes = bytes(raw_bytes)
        if not raw_bytes:
            raise ValueError("ERR_EMPTY_FRAME")
        if len(raw_bytes) > self.config.max_frame_bytes:
            raise ValueError("ERR_FRAME_TOO_LARGE")

        source_transport = _bounded_text(source_transport, fallback="unknown", max_chars=64)
        peer = _bounded_text(peer, fallback="unknown", max_chars=160) if peer is not None else None
        transport_sha256 = hashlib.sha256(raw_bytes).hexdigest()
        transfer_id = uuid.uuid4().hex
        base = _safe_source_name(source_name)
        quarantine_name = f"{base}-{transport_sha256[:12]}-{transfer_id[:8]}.brad"
        quarantine = self.config.storage_dir / "quarantine" / quarantine_name
        _atomic_write(quarantine, raw_bytes)

        report: dict[str, Any] = {
            "schema": RECEIPT_SCHEMA,
            "version": __version__,
            "transfer_id": transfer_id,
            "accepted": False,
            "finality": "quarantined",
            "post_commit_complete": False,
            "stored": True,
            "source_transport": source_transport,
            "source_peer": peer,
            "transport_sha256": transport_sha256,
            "frame_bytes": len(raw_bytes),
            "pipeline": ["quarantine"],
            "phase_a_validated": False,
            "phase_b_committed": False,
            "transport_completed": True,
            "field_indexed": False,
            "accepted_and_indexed": False,
            "result_summary": "PENDING_RECEIVER_GATES",
            "handoff": {
                "configured": bool(
                    self.config.handoff_command
                    or self.config.ollama_handoff is not None
                    or self.config.semantic_capsule_handoff is not None
                ),
                "ran": False,
            },
        }
        receipt_path = self._receipt_path(transport_sha256, transfer_id)

        try:
            frame = BraidFrame.from_bytes(raw_bytes)
            receipt_path = self._receipt_path(frame.object_digest, transfer_id)
            vector = np.asarray(frame.vector, dtype=np.float32)
            dimension_ok = bool(vector.ndim == 1 and vector.size == 384 and frame.manifest.get("vector_length") == 384)
            finite = bool(np.isfinite(vector).all())
            report.update({
                "object_digest": frame.object_digest,
                "manifest": frame.manifest,
                "receiver_vector": {
                    "dimension": int(vector.size),
                    "expected_dimension": 384,
                    "dimension_ok": dimension_ok,
                    "finite": finite,
                    "l2_norm": float(np.linalg.norm(vector)) if finite else None,
                },
            })
            report["pipeline"].append("parse_384d")
            if not dimension_ok or not finite:
                raise ValueError("ERR_384D_SHAPE_OR_FINITE")

            # Import lazily to avoid a module import cycle with braid_client.server.
            from .server import evaluate_normative_receiver_gates, analyze_vector_stats

            # Strict same-model capsule/vector coherence can establish that the signed
            # 384D state really derives from the explicit signed material. Only that
            # receiver-owned verification may demote a narrow calibration-corpus OOD
            # result from a hard gate to diagnostic evidence. We first run Phase A in
            # diagnostic-candidate mode so signature, route, replay, and artifact
            # bindings are verified before invoking the local embedding model.
            strict_exact_candidate = bool(
                self.semantic_capsule_adapter is not None
                and self.semantic_capsule_adapter.config.verify_exact_space_coherence
            )
            candidate_distribution_mode = (
                "diagnostic" if strict_exact_candidate else "enforce"
            )
            phase_a = self.validator.validate_frame_phase_a(
                raw_bytes,
                distribution_gate_mode=candidate_distribution_mode,
            )
            if not phase_a.is_valid:
                report["reason"] = phase_a.message
                raise RuntimeError("RECEIVER_REJECTED")

            # Semantic Capsules are explicit signed semantic material. Validate the
            # closed schema and route bindings, then perform receiver-local preflight.
            # Exact-space strict verification recomputes the capsule material and
            # compares it to the signed 384D state before any Phase B commit.
            capsule, capsule_evidence = extract_semantic_capsule(
                frame.manifest, required=self.semantic_capsule_adapter is not None
            )
            report["semantic_capsule"] = capsule_evidence
            if capsule is not None:
                capsule_evidence.update(
                    validate_capsule_route_binding(frame.manifest, self.registry, capsule)
                )
                report["pipeline"].append("semantic_capsule_verify")

            semantic_prepared = None
            distribution_gate_mode = "enforce"
            distribution_gate_reason = "route_distribution_enforced"
            if self.semantic_capsule_adapter is not None:
                semantic_prepared = self.semantic_capsule_adapter.prepare(
                    frame=frame, registry=self.registry
                )
                report["semantic_capsule"].update(semantic_prepared.evidence)
                if semantic_prepared.method == "exact_space_fast_path":
                    report["pipeline"].append("semantic_fast_path")
                    if semantic_prepared.evidence.get("exact_space_coherence_verified") is True:
                        distribution_gate_mode = "diagnostic"
                        distribution_gate_reason = (
                            "receiver_verified_exact_space_capsule_vector_coherence"
                        )
                        report["pipeline"].append("distribution_gate_diagnostic_override")
                else:
                    report["pipeline"].append("semantic_reembed_preflight")

            # If strict coherence did not establish the exact-space override, rerun
            # Phase A with the historical hard route-distribution gates.
            if distribution_gate_mode != candidate_distribution_mode:
                phase_a = self.validator.validate_frame_phase_a(
                    raw_bytes,
                    distribution_gate_mode=distribution_gate_mode,
                )
                if not phase_a.is_valid:
                    report["reason"] = phase_a.message
                    raise RuntimeError("RECEIVER_REJECTED")

            if distribution_gate_mode == "diagnostic":
                assert semantic_prepared is not None
                phase_a = self.validator.authorize_distribution_diagnostic(
                    phase_a,
                    transfer_method=semantic_prepared.method,
                    capsule_digest=semantic_prepared.evidence["digest"],
                    exact_space_coherence_verified=bool(
                        semantic_prepared.evidence.get("exact_space_coherence_verified")
                    ),
                    exact_space_coherence_cosine=semantic_prepared.evidence.get(
                        "exact_space_coherence_cosine"
                    ),
                    min_exact_space_cosine=semantic_prepared.evidence.get(
                        "min_exact_space_cosine"
                    ),
                )
                if not phase_a.is_valid:
                    report["reason"] = phase_a.message
                    raise RuntimeError("RECEIVER_REJECTED")

            gates = evaluate_normative_receiver_gates(
                frame,
                self.verification_key,
                self.validator,
                self.registry,
                phase_a_result=phase_a,
                distribution_gate_mode=distribution_gate_mode,
            )
            report["gates"] = gates
            report["distribution_gate_policy"] = {
                "mode": distribution_gate_mode,
                "reason": distribution_gate_reason,
                "receiver_owned": True,
                "semantic_evidence_grants_authority": False,
            }
            report["stats"] = analyze_vector_stats(frame.vector)
            report["effective_authority"] = gates.get("effective_authority", {})
            report["pipeline"].append("phase_a")
            if not phase_a.is_valid or not gates.get("overall_accepted"):
                report["reason"] = gates.get("rejection_reason") or phase_a.message
                raise RuntimeError("RECEIVER_REJECTED")
            report["phase_a_validated"] = True

            # Legend is signed sender context, never authority. If present it must be
            # structurally valid and digest-consistent before Phase B. A configured
            # built-in Ollama handoff requires a Legend.
            legend, legend_evidence = extract_legend_extension(
                frame.manifest, required=self.config.ollama_handoff is not None
            )
            report["legend"] = legend_evidence
            if legend is not None:
                report["pipeline"].append("legend_verify")

            # Recognized Ollama adapter metadata is bound to the receiver-authorized
            # route spaces before Phase B. A configured built-in handoff requires it.
            _, ollama_evidence = validate_ollama_route_binding(
                frame.manifest, self.registry, required=self.config.ollama_handoff is not None
            )
            report["ollama_adapter"] = ollama_evidence
            if ollama_evidence.get("present"):
                report["pipeline"].append("ollama_route_bind")

            # The signed wire vector remains immutable source state. The receiver-local
            # transport map may derive a target-space 384D representation during Phase A.
            # That derived vector is evidence/output only and never inherits the sender
            # signature or authority.
            mapped_vector = np.asarray(
                phase_a.diagnostic_payload.get("mapped_vector", vector), dtype=np.float32
            )
            if mapped_vector.ndim != 1 or mapped_vector.size != 384 or not np.isfinite(mapped_vector).all():
                report["reason"] = "ERR_DERIVED_TARGET_VECTOR"
                raise RuntimeError("RECEIVER_REJECTED")
            report["derived_target_vector"] = {
                "dimension": int(mapped_vector.size),
                "finite": True,
                "l2_norm": float(np.linalg.norm(mapped_vector)),
                "route_id": frame.manifest.get("route_id"),
                "source_space_digest": frame.manifest.get("source_space_digest"),
                "target_space_digest": frame.manifest.get("target_space_digest"),
                "transport_map_digest": frame.manifest.get("transport_map_digest"),
                "legend_digest": report.get("legend", {}).get("digest"),
                "authority": "receiver_local_evidence_only",
            }

            if self.config.auto_commit:
                # Preflight post-commit destinations before the irreversible
                # replay/state transaction is attempted.
                _ensure_private_dir(self.config.storage_dir / "accepted")
                if self.config.emit_vector_npy:
                    _ensure_private_dir(self.config.storage_dir / "state")
                phase_b = self.validator.commit_frame_phase_b(phase_a)
                report["phase_b"] = {
                    "passed": bool(phase_b.is_valid),
                    "gate_name": phase_b.gate_name,
                    "message": phase_b.message,
                }
                report["pipeline"].append("phase_b_commit")
                if not phase_b.is_valid:
                    report["reason"] = phase_b.message
                    raise RuntimeError("RECEIVER_REJECTED")
                report["phase_b_committed"] = True
                report["accepted"] = True
                report["finality"] = "committed"
                report["reason"] = "RECEIVER_COMMITTED"
            else:
                report["phase_b"] = {
                    "passed": False,
                    "gate_name": "PhaseBAtomicCommitGate",
                    "message": "Auto-commit disabled by receiver policy.",
                }
                report["reason"] = "PHASE_A_VALIDATED_NOT_COMMITTED"
                report["result_summary"] = "PHASE_A_VALIDATED_NOT_COMMITTED"
                report["stored_path"] = str(quarantine)
                report["pipeline"].append("quarantine_hold")
                report["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
                self._write_receipt(report, receipt_path)
                self._audit({
                    "accepted": False,
                    "finality": report["finality"],
                    "reason": report["reason"],
                    "object_digest": frame.object_digest,
                    "source_transport": source_transport,
                    "peer": peer,
                    "phase_a_validated": True,
                    "phase_b_committed": False,
                    "transfer_id": transfer_id,
                })
                return report

            # Phase B is authoritative. Everything below is post-commit delivery.
            accepted_path = self._route_file(quarantine, "accepted", quarantine_name)
            report["stored_path"] = str(accepted_path)
            report["pipeline"].append("accepted_store")

            vector_path: Path | None = None
            if self.config.emit_vector_npy:
                vector_path = self.config.storage_dir / "state" / f"{frame.object_digest}.npy"
                buffer = io.BytesIO()
                np.save(buffer, mapped_vector.astype(np.float32), allow_pickle=False)
                vector_bytes = buffer.getvalue()
                _atomic_write(vector_path, vector_bytes, mode=0o600)
                lineage = {
                    "schema": DERIVED_STATE_LINEAGE_SCHEMA,
                    "version": __version__,
                    "source_object_digest": frame.object_digest,
                    "source_transport_sha256": transport_sha256,
                    "derived_artifact_sha256": hashlib.sha256(vector_bytes).hexdigest(),
                    "artifact_kind": "receiver_local_target_space_float32_vector",
                    "route_id": frame.manifest.get("route_id"),
                    "source_space_digest": frame.manifest.get("source_space_digest"),
                    "target_space_digest": frame.manifest.get("target_space_digest"),
                    "transport_map_digest": frame.manifest.get("transport_map_digest"),
                    "legend_digest": report.get("legend", {}).get("digest"),
                    "sender_signature_covers_derived_artifact": False,
                    "authority": "receiver_local_evidence_only",
                    "phase_b_committed": True,
                }
                lineage_path = self.config.storage_dir / "state" / f"{frame.object_digest}.lineage.json"
                _atomic_write(
                    lineage_path,
                    json.dumps(lineage, sort_keys=True, indent=2, allow_nan=False).encode("utf-8"),
                    mode=0o600,
                )
                report["vector_path"] = str(vector_path)
                report["lineage_path"] = str(lineage_path)
                report["derived_state"] = lineage
                report["pipeline"].append("emit_384d")
                report["pipeline"].append("bind_derived_lineage")

            # Write receipt before handoff so any local consumer can verify committed
            # finality. Built-in Ollama consumption is direct Python/loopback API, not
            # a shell command, and is always post-commit.
            report["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
            self._write_receipt(report, receipt_path)
            if self.semantic_capsule_adapter is not None and semantic_prepared is not None:
                try:
                    handoff = self.semantic_capsule_adapter.commit_artifacts(
                        frame=frame, prepared=semantic_prepared, receipt=report,
                        storage_dir=self.config.storage_dir, transport_sha256=transport_sha256,
                    )
                except Exception as handoff_exc:
                    handoff = {
                        "configured": True, "ran": False, "accepted": False,
                        "reason": _bounded_text(handoff_exc, fallback=handoff_exc.__class__.__name__, max_chars=500),
                        "authority": "post_commit_receiver_local_output",
                        "bridge_semantic_invention": False,
                    }
                report["semantic_transfer"] = handoff
                report["pipeline"].append("semantic_transfer")
            elif self.ollama_adapter is not None:
                try:
                    handoff = self.ollama_adapter.consume(
                        frame=frame, mapped_vector=mapped_vector, receipt=report,
                        storage_dir=self.config.storage_dir,
                    )
                except Exception as handoff_exc:
                    handoff = {
                        "configured": True, "ran": False, "accepted": False,
                        "reason": _bounded_text(handoff_exc, fallback=handoff_exc.__class__.__name__, max_chars=500),
                        "authority": "post_commit_local_consumption_only",
                    }
                report["pipeline"].append("ollama_handoff")
            else:
                handoff = self._handoff(accepted_path, vector_path, receipt_path)
                if handoff.get("ran"):
                    report["pipeline"].append("local_handoff")
            report["handoff"] = handoff
            report["post_commit_complete"] = bool(
                handoff.get("accepted", True)
            ) and not bool(handoff.get("degraded", False))
            semantic_field = (
                report.get("semantic_transfer", {}).get("semantic_field")
                if isinstance(report.get("semantic_transfer"), dict)
                else None
            )
            report["field_indexed"] = bool(
                isinstance(semantic_field, dict)
                and semantic_field.get("indexed") is True
            )
            report["accepted_and_indexed"] = bool(
                report.get("phase_b_committed") is True
                and report["field_indexed"]
            )
            report["result_summary"] = (
                "ACCEPTED_AND_INDEXED"
                if report["accepted_and_indexed"]
                else "PHASE_B_COMMITTED_FIELD_NOT_INDEXED"
            )
            report["reason"] = "RECEIVER_ACCEPTED" if report["post_commit_complete"] else "RECEIVER_COMMITTED_HANDOFF_DEGRADED"
            report["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
            self._write_receipt(report, receipt_path)
            self._audit({
                "accepted": True,
                "finality": "committed",
                "object_digest": frame.object_digest,
                "source_transport": source_transport,
                "peer": peer,
                "phase_b_committed": True,
                "post_commit_complete": report["post_commit_complete"],
                "handoff_reason": handoff.get("reason"),
                "transfer_id": transfer_id,
            })
            return report

        except Exception as exc:
            # A commit cannot be rolled back by filesystem/handoff work. Preserve
            # finality if Phase B already succeeded and label any later failure as
            # post-commit degradation rather than a rejection.
            if report.get("phase_b_committed"):
                report["accepted"] = True
                report["finality"] = "committed"
                report["post_commit_complete"] = False
                report["accepted_and_indexed"] = bool(report.get("field_indexed"))
                report["result_summary"] = (
                    "ACCEPTED_AND_INDEXED"
                    if report["accepted_and_indexed"]
                    else "PHASE_B_COMMITTED_FIELD_NOT_INDEXED"
                )
                report["reason"] = f"RECEIVER_COMMITTED_POSTCOMMIT_ERROR:{exc.__class__.__name__}"
            else:
                report["accepted"] = False
                report["finality"] = "rejected"
                report["field_indexed"] = False
                report["accepted_and_indexed"] = False
                report["result_summary"] = "REJECTED_BEFORE_PHASE_B"
                if report.get("reason") is None:
                    report["reason"] = str(exc) or exc.__class__.__name__
                if quarantine.exists():
                    if self.config.retain_rejected:
                        rejected = self._route_file(quarantine, "rejected", quarantine_name)
                        report["stored_path"] = str(rejected)
                        report["pipeline"].append("rejected_store")
                    else:
                        quarantine.unlink(missing_ok=True)
                        report["stored"] = False

            report["latency_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
            try:
                self._write_receipt(report, receipt_path)
            except OSError as receipt_exc:
                report["receipt_error"] = receipt_exc.__class__.__name__
            self._audit({
                "accepted": report["accepted"],
                "finality": report["finality"],
                "reason": report["reason"],
                "source_transport": source_transport,
                "peer": peer,
                "transport_sha256": transport_sha256,
                "phase_b_committed": report.get("phase_b_committed", False),
                "transfer_id": transfer_id,
            })
            return report
