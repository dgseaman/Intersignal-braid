import sys
import json
import os
import jsonschema
from typing import Dict, Any, List

from braid_client.mcp_core.protocol import BraidEnvelope, ReplayLedger
from braid_client.mcp_core.alignment import RepresentationSpace, TransportMap
from braid_client import __version__
from braid_client.mcp_core.validation import BraidValidator, FeatureSpec, ValidationResult
from braid_client.mcp_core.registry import TrustedRegistry, AuthorizedSigner, AuthorizedRoute, compute_space_digest, compute_map_digest
from braid_client.mcp_core.canonical import jcs_loads

# Local ledger relative path inside private directory
REPLAY_LEDGER_DB_PATH = "braid_replay_ledger.db"

# Lazy-loaded replay ledger to prevent database creation prior to configuration validation (P1-11)
REPLAY_LEDGER = None
TRUSTED_REGISTRY = TrustedRegistry()

def print_log(msg: str):
    """Prints debug statements to stderr so they don't corrupt stdout JSON-RPC channel."""
    sys.stderr.write(f"[BRAID-MCP-SERVER] {msg}\n")
    sys.stderr.flush()


def read_bounded_line(stream, max_bytes: int = 10 * 1024 * 1024) -> str:
    """Reads a single line from the stream up to max_bytes. Aborts immediately if exceeded (P1-8)."""
    chunk = stream.readline(max_bytes)
    if len(chunk) >= max_bytes and not chunk.endswith('\n'):
        raise ValueError(f"Forced closed: Received message size exceeds maximum ceiling of {max_bytes} bytes.")
    return chunk


# Strict JSON Schema for receiver_config.json (P1-5)
RECEIVER_CONFIG_SCHEMA = {
    "type": "object",
    "properties": {
        "signers": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "signer_key_id": {"type": "string", "maxLength": 64},
                    "public_key_hex": {"type": "string", "maxLength": 64},
                    "authorized_routes": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "audience": {"type": "string", "maxLength": 64},
                                "source_space_id": {"type": "string", "maxLength": 64},
                                "target_space_id": {"type": "string", "maxLength": 64},
                                "transport_map_id": {"type": "string", "maxLength": 64},
                                "feature_spec_id": {"type": "string", "maxLength": 64}
                            },
                            "required": ["audience", "source_space_id", "target_space_id", "transport_map_id", "feature_spec_id"],
                            "additionalProperties": False
                        }
                    }
                },
                "required": ["signer_key_id", "public_key_hex", "authorized_routes"],
                "additionalProperties": False
            }
        },
        "spaces": {
            "type": "object",
            "additionalProperties": {
                "type": "object",
                "properties": {
                    "model_revision": {"type": "string", "maxLength": 128},
                    "layer": {"type": "string", "maxLength": 128},
                    "pooling": {"type": "string", "maxLength": 32},
                    "dimension": {"type": "integer"},
                    "dtype": {"type": "string", "maxLength": 16},
                    "normalization": {"type": "string", "maxLength": 16},
                    "adapter_id": {"type": "string", "maxLength": 64},
                    "adapter_digest": {"type": "string", "maxLength": 64},
                    "tokenizer_hash": {"type": "string", "maxLength": 64},
                    "semantic_label": {"type": "string", "maxLength": 128},
                    "is_source": {"type": "boolean"}
                },
                "required": ["model_revision", "layer", "pooling", "dimension", "dtype", "normalization", "adapter_id", "adapter_digest", "tokenizer_hash", "semantic_label"],
                "additionalProperties": False
            }
        },
        "maps": {
            "type": "object",
            "additionalProperties": {
                "type": "object",
                "properties": {
                    "algorithm": {"type": "string", "maxLength": 32},
                    "R": {
                        "type": "array",
                        "items": {
                            "type": "array",
                            "items": {"type": "number"}
                        }
                    },
                    "t": {
                        "type": "array",
                        "items": {"type": "number"}
                    },
                    "source_space_digest": {"type": "string", "maxLength": 64},
                    "target_space_digest": {"type": "string", "maxLength": 64},
                    "normalization_policy": {"type": "string", "maxLength": 16},
                    "map_digest": {"type": "string", "maxLength": 64},
                    "elm_W_in": {
                        "type": "array",
                        "items": {
                            "type": "array",
                            "items": {"type": "number"}
                        }
                    },
                    "elm_b_in": {
                        "type": "array",
                        "items": {"type": "number"}
                    }
                },
                "required": ["algorithm", "R", "t", "source_space_digest", "target_space_digest", "normalization_policy"],
                "additionalProperties": False
            }
        },
        "specs": {
            "type": "object",
            "additionalProperties": {
                "type": "object",
                "properties": {
                    "target_space_digest": {"type": "string", "maxLength": 64},
                    "probes": {
                        "type": "object",
                        "additionalProperties": {
                            "type": "array",
                            "items": {"type": "number"},
                            "minItems": 384,
                            "maxItems": 384
                        }
                    },
                    "weights": {
                        "type": "object",
                        "additionalProperties": {"type": "number"}
                    },
                    "aggregate_threshold": {"type": "number"},
                    "per_probe_thresholds": {
                        "type": "object",
                        "additionalProperties": {"type": "number"}
                    },
                    "version": {"type": "string", "maxLength": 16}
                },
                "required": ["target_space_digest", "probes", "weights"],
                "additionalProperties": False
            }
        }
    },
    "required": ["signers", "spaces", "maps", "specs"],
    "additionalProperties": False
}


# Envelope strict JSON schema validator (P1-7 input schema hardening)
ENVELOPE_INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "envelope": {
            "type": "object",
            "properties": {
                "vector": {
                    "type": "array",
                    "items": {"type": "number"},
                    "minItems": 1,
                    "maxItems": 4096 # Supports variable target space dimensions (P1-8)
                },
                "semantic_label": {"type": "string", "maxLength": 128},
                "source_representation": {"type": "object"},
                "target_representation": {"type": "object"},
                "cluster_id": {"type": "integer"},
                "activation_threshold": {"type": "number"},
                "source_space_id": {"type": "string", "maxLength": 64},
                "source_space_digest": {"type": "string", "maxLength": 64},
                "target_space_id": {"type": "string", "maxLength": 64},
                "target_space_digest": {"type": "string", "maxLength": 64},
                "transport_map_id": {"type": "string", "maxLength": 64},
                "transport_map_digest": {"type": "string", "maxLength": 64},
                "feature_spec_id": {"type": "string", "maxLength": 64},
                "feature_spec_digest": {"type": "string", "maxLength": 64},
                "signer_key_id": {"type": "string", "maxLength": 64},
                "algorithm_id": {"type": "string", "maxLength": 32},
                "audience": {"type": "string", "maxLength": 64},
                "schema_version": {"type": "string", "maxLength": 16},
                "object_id": {"type": "string", "maxLength": 64},
                "nonce": {"type": "string", "maxLength": 64},
                "timestamp": {"type": "integer"},
                "expiry": {"type": "integer"},
                "signature": {"type": "string", "maxLength": 128}
            },
            "required": [
                "vector", "semantic_label", "source_representation", "target_representation",
                "source_space_id", "source_space_digest", "target_space_id", "target_space_digest",
                "transport_map_id", "transport_map_digest", "feature_spec_id", "feature_spec_digest",
                "signer_key_id", "algorithm_id", "audience", "schema_version",
                "object_id", "nonce", "timestamp", "expiry", "signature"
            ],
            "additionalProperties": False
        }
    },
    "required": ["envelope"],
    "additionalProperties": False
}


class McpServer:
    """
    Standard-compliant Model Context Protocol stdio server executing JSON-RPC 2.0 handshakes.
    Enforces strict input validation and receiver-side policy execution.
    """
    def __init__(self, registry: TrustedRegistry, ledger: ReplayLedger):
        self.registry = registry
        self.ledger = ledger
        self.initialize_received = False
        self.ready_after_initialized = False

    def handle_message(self, line: str) -> str:
        try:
            # Parse MCP inputs with JCS loads to strictly reject duplicate keys and non-finite numbers (P0-5, P0-7)
            req = jcs_loads(line)
        except Exception:
            return json.dumps({
                "jsonrpc": "2.0",
                "error": {"code": -32700, "message": "Parse error: invalid JSON received or duplicate keys detected."},
                "id": None
            })

        # Validate JSON-RPC 2.0 format
        if not isinstance(req, dict) or req.get("jsonrpc") != "2.0":
            return json.dumps({
                "jsonrpc": "2.0",
                "error": {"code": -32600, "message": "Invalid request: Must be a JSON-RPC 2.0 object."},
                "id": req.get("id") if isinstance(req, dict) else None
            })

        method = req.get("method")
        msg_id = req.get("id")
        params = req.get("params", {})

        is_notification = msg_id is None

        # Standard lifecycle checks (P0-6)
        if method == "initialize":
            if is_notification:
                # Under JSON-RPC, a notification MUST NOT receive a response (P1-6)
                return ""
            self.initialize_received = True
            response_payload = {
                "protocolVersion": "2024-11-05",
                "capabilities": {
                    "tools": {}
                },
                "serverInfo": {
                    "name": "braid-latent-primitive-server",
                    "version": __version__
                }
            }
            return json.dumps({
                "jsonrpc": "2.0",
                "result": response_payload,
                "id": msg_id
            })

        if method == "notifications/initialized":
            self.ready_after_initialized = True
            print_log("Lifecycle handshake completed. Standard MCP initialized and ready.")
            return "" # Notifications require NO response

        # Enforce lifecycle sequence (P0-6)
        if not self.initialize_received or (method != "notifications/initialized" and not self.ready_after_initialized):
            if is_notification:
                return ""
            return json.dumps({
                "jsonrpc": "2.0",
                "error": {"code": -32002, "message": "Server not initialized or ready. Call 'initialize' first."},
                "id": msg_id
            })

        # Do not respond to notifications sent to ordinary methods (P1-6)
        if is_notification:
            return ""

        # Process Tool listing
        if method == "tools/list":
            tools_list = [
                {
                    "name": "verify_and_ingest_state",
                    "description": "Enforces 3 strict validation gates on an incoming Braid envelope using local role-separated spaces, maps and specs.",
                    "inputSchema": ENVELOPE_INPUT_SCHEMA
                }
            ]
            return json.dumps({
                "jsonrpc": "2.0",
                "result": {"tools": tools_list},
                "id": msg_id
            })

        # Process Tool execution
        if method == "tools/call":
            if not isinstance(params, dict):
                return json.dumps({
                    "jsonrpc": "2.0",
                    "error": {"code": -32602, "message": "Invalid params: Params must be an object."},
                    "id": msg_id
                })

            tool_name = params.get("name")
            arguments = params.get("arguments", {})

            if not tool_name or not isinstance(arguments, dict):
                return json.dumps({
                    "jsonrpc": "2.0",
                    "error": {"code": -32602, "message": "Invalid params: Missing tool name or arguments."},
                    "id": msg_id
                })

            if tool_name == "verify_and_ingest_state":
                # Real JSON Schema validation
                try:
                    jsonschema.validate(instance=arguments, schema=ENVELOPE_INPUT_SCHEMA)
                except jsonschema.ValidationError as ve:
                    return json.dumps({
                        "jsonrpc": "2.0",
                        "error": {"code": -32602, "message": f"Schema Validation Error: {ve.message}"},
                        "id": msg_id
                    })
                
                res = self.execute_verify_and_ingest_state(arguments)
                return json.dumps({
                    "jsonrpc": "2.0",
                    "result": res,
                    "id": msg_id
                })

            else:
                return json.dumps({
                    "jsonrpc": "2.0",
                    "error": {"code": -32601, "message": f"Tool not found: {tool_name}"},
                    "id": msg_id
                })

        return json.dumps({
            "jsonrpc": "2.0",
            "error": {"code": -32601, "message": f"Method not found: {method}"},
            "id": msg_id
        })

    def execute_verify_and_ingest_state(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Inbounds and evaluates an incoming envelope across all three validation gates using local registry policy."""
        try:
            envelope_dict = args.get("envelope")

            # Initialize validator (loading local trusted registry policies)
            validator = BraidValidator(self.registry, self.ledger, local_audience_id="node_b_receiver")
            
            # 1. Non-mutating Check Stage (Gate 1 Authenticated Envelope Integrity)
            gate1_res = validator.validate_byte_integrity(envelope_dict)
            if not gate1_res.is_valid:
                return {
                    "isError": True,
                    "content": [{"type": "text", "text": f"Ingestion Blocked at Gate 1 (AuthenticatedEnvelopeIntegrityGate): {gate1_res.message}"}]
                }

            # 2. Gate 2 check (Representation Compatibility)
            gate2_res = validator.validate_representation_compatibility(envelope_dict)
            if not gate2_res.is_valid:
                return {
                    "isError": True,
                    "content": [{"type": "text", "text": f"Ingestion Blocked at Gate 2 (RepresentationCompatibilityGate): {gate2_res.message}"}]
                }

            # 3. Gate 3 check (this executes the transport map Φ internally and evaluates invariants)
            gate3_res = validator.validate_semantic_preservation(envelope_dict)
            if not gate3_res.is_valid:
                return {
                    "isError": True,
                    "content": [
                        {"type": "text", "text": f"Ingestion Blocked at Gate 3 (ConfiguredTargetProbeCompatibilityGate): {gate3_res.message}"},
                        {"type": "text", "text": json.dumps(gate3_res.diagnostic_payload)}
                    ]
                }

            # 4. Atomic Commit Stage (Write to replay ledger ONLY after all gates pass and checking expiry/timestamp P1-2)
            is_committed, commit_msg = self.ledger.commit_replay(
                envelope_dict["audience"],
                envelope_dict["signer_key_id"],
                envelope_dict["object_id"],
                envelope_dict["nonce"],
                envelope_dict["timestamp"],
                envelope_dict["expiry"]
            )
            if not is_committed:
                return {
                    "isError": True,
                    "content": [{"type": "text", "text": f"Ingestion Blocked at Post-Validation Commit: {commit_msg}"}]
                }

            # Success response exposing verified target vector in legacy text fallback!
            success_payload = {
                "byte_integrity": gate1_res.to_dict(),
                "representation_compatibility": gate2_res.to_dict(),
                "semantic_preservation": gate3_res.to_dict(),
                "replay_commit": {"status": "COMMITTED", "message": commit_msg}
            }

            return {
                "isError": False,
                # Delivering target state under legacy-compliant text block
                "content": [{"type": "text", "text": json.dumps(success_payload)}]
            }

        except Exception as e:
            return {
                "isError": True,
                "content": [{"type": "text", "text": f"Unexpected ingestion execution failure: {str(e)}"}]
            }

    def start_stdio_loop(self):
        """Starts processing stdio streams line-by-line for JSON-RPC 2.0 with bounded reading to prevent OOM DOS (P1-8)."""
        print_log("Braid Stdio MCP Server running. Ingestion pipeline active.")
        while True:
            try:
                line = read_bounded_line(sys.stdin, max_bytes=10 * 1024 * 1024)
                if not line:
                    break
                line = line.strip()
                if not line:
                    continue
                res_str = self.handle_message(line)
                if res_str:
                    sys.stdout.write(res_str + "\n")
                    sys.stdout.flush()
            except Exception as e:
                print_log(f"Forced termination due to stream integrity error: {str(e)}")
                sys.exit(1)


def load_receiver_policies_from_config(config_path: str = "receiver_config.json") -> TrustedRegistry:
    """Loads and returns trusted spaces, specs, and maps from local file registry configuration."""
    if not os.path.exists(config_path):
        print_log(f"Failing Closed: No local config found at {config_path}. Startup aborted.")
        sys.exit(1)
        
    registry = TrustedRegistry()
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            # Parse using strict JCS loads to reject duplicate keys and non-finite constants (P0-5, P0-7)
            raw_text = f.read()
            data = jcs_loads(raw_text)
            
        # Strict schema-bound receiver configuration validation (P1-5)
        jsonschema.validate(instance=data, schema=RECEIVER_CONFIG_SCHEMA)
            
        # Parse and register signers
        for signer_data in data.get("signers", []):
            routes = []
            for r in signer_data.get("authorized_routes", []):
                routes.append(AuthorizedRoute(
                    audience=r["audience"],
                    source_space_id=r["source_space_id"],
                    target_space_id=r["target_space_id"],
                    transport_map_id=r["transport_map_id"],
                    feature_spec_id=r["feature_spec_id"]
                ))
            signer = AuthorizedSigner(
                signer_key_id=signer_data["signer_key_id"],
                public_key_hex=signer_data["public_key_hex"],
                authorized_routes=routes
            )
            registry.register_signer(signer)
            
        # Parse and register spaces (strict role separation P0-3)
        for s_id, s_data in data.get("spaces", {}).items():
            space = RepresentationSpace(
                model_revision=s_data["model_revision"],
                layer=s_data["layer"],
                pooling=s_data["pooling"],
                dimension=s_data.get("dimension", 384),
                dtype=s_data.get("dtype", "float32"),
                normalization=s_data.get("normalization", "unit"),
                adapter_id=s_data.get("adapter_id", "none"),
                adapter_digest=s_data.get("adapter_digest", "none"),
                tokenizer_hash=s_data.get("tokenizer_hash", "none"),
                semantic_label=s_data.get("semantic_label", "none")
            )
            if s_data.get("is_source", True):
                registry.register_source_space(s_id, space)
            else:
                registry.register_target_space(s_id, space)
            
        # Parse and register specs
        for sp_id, sp_data in data.get("specs", {}).items():
            spec = FeatureSpec(
                feature_spec_id=sp_id,
                target_space_digest=sp_data["target_space_digest"],
                probes=sp_data["probes"],
                weights=sp_data["weights"],
                aggregate_threshold=sp_data.get("aggregate_threshold", 0.30),
                per_probe_thresholds=sp_data.get("per_probe_thresholds"),
                version=sp_data.get("version", "1.0.0")
            )
            registry.register_feature_spec(sp_id, spec)
            
        # Parse and register maps
        for m_id, m_data in data.get("maps", {}).items():
            import numpy as np
            map_obj = TransportMap(
                algorithm=m_data["algorithm"],
                rotation_matrix=np.array(m_data["R"], dtype=np.float64),
                translation_vector=np.array(m_data["t"], dtype=np.float64),
                source_space_digest=m_data["source_space_digest"],
                target_space_digest=m_data["target_space_digest"],
                normalization_policy=m_data.get("normalization_policy", "unit"),
                map_digest=m_data.get("map_digest"),
                elm_W_in=np.array(m_data["elm_W_in"], dtype=np.float64) if "elm_W_in" in m_data else None,
                elm_b_in=np.array(m_data["elm_b_in"], dtype=np.float64) if "elm_b_in" in m_data else None
            )
            # Startup validation: recompute map digests and assert exact match (P0-1)
            computed_map_digest = map_obj.compute_digest()
            if m_data.get("map_digest") and m_data.get("map_digest") != computed_map_digest:
                raise ValueError(f"Startup Blocked: Map '{m_id}' declared digest '{m_data.get('map_digest')}' differs from locally computed digest '{computed_map_digest}'.")
            
            registry.register_transport_map(m_id, map_obj)
            
        # Freeze registry strictly after population (P1-3 deep immutability & route-graph coherence P1-1)
        registry.freeze_registry()
        
        # Enforce strict fail closed if config lists zero entries
        if not registry.signers or not registry.source_spaces or not registry.target_spaces or not registry.transport_maps or not registry.feature_specs:
            print_log("Failing Closed: Incomplete configuration registry maps. Startup aborted.")
            sys.exit(1)
            
        print_log(f"Loaded receiver policies successfully from {config_path}.")
        return registry
    except Exception as e:
        print_log(f"Fatal Startup Error loading local config: {str(e)}")
        sys.exit(1)


def main() -> None:
    global REPLAY_LEDGER
    # Absolute fail closed: No fallback memory policies (P0-1 and P0-2!)
    config_file_name = "receiver_config.json"
    registry = load_receiver_policies_from_config(config_file_name)
    
    # Initialize ReplayLedger only AFTER successful configuration validation (P1-11)
    REPLAY_LEDGER = ReplayLedger(db_path=REPLAY_LEDGER_DB_PATH)
    
    server = McpServer(registry, REPLAY_LEDGER)
    server.start_stdio_loop()


if __name__ == "__main__":
    main()
