import json
import math
import struct
import hashlib
import numpy as np
from typing import Any, Dict, List, Tuple, Optional

def reject_duplicate_keys(pairs):
    """Custom JSON object hook that strictly rejects duplicate keys at parse time."""
    keys = set()
    for k, v in pairs:
        if k in keys:
            raise ValueError(f"Duplicate key detected in JSON payload: {k}")
        keys.add(k)
    return dict(pairs)


def reject_nonfinite_constant(value: str) -> None:
    """Rejects non-finite constants (NaN/Infinity) at JSON parse time (RFC 8785 constraint)."""
    raise ValueError(f"Forbidden JCS constant number: {value}")


def rfc8785_format_number(val: Any) -> str:
    """
    Formats integers and floats according to IEEE-754 double precision rules 
    specified in RFC 8785 (JCS) and enforces I-JSON numeric limits.
    """
    if isinstance(val, bool):
        return "true" if val else "false"
    
    if isinstance(val, int):
        if not (-(2**53 - 1) <= val <= (2**53 - 1)):
            raise ValueError(f"Integer {val} exceeds I-JSON compatible numeric bounds.")
        return str(val)
        
    if isinstance(val, float):
        if math.isnan(val) or math.isinf(val):
            raise ValueError("RFC 8785 and I-JSON rule out non-standard float representations (NaN/Infinity).")
            
        if val == 0.0:
            return "0"

        sign = "-" if val < 0.0 else ""
        val = abs(val)

        s = repr(val).replace('E', 'e')
        if 'e' in s:
            mantissa, exp = s.split('e')
            exp_val = int(exp)
            
            if -6 <= exp_val < 21:
                if '.' in mantissa:
                    left, right = mantissa.split('.')
                else:
                    left, right = mantissa, ''
                    
                combined = left + right
                if exp_val >= 0:
                    zeros_needed = exp_val - len(right)
                    if zeros_needed >= 0:
                        dec = combined + ('0' * zeros_needed)
                    else:
                        split_idx = len(left) + exp_val
                        dec = combined[:split_idx] + '.' + combined[split_idx:]
                else:
                    zeros_needed = abs(exp_val) - len(left)
                    if zeros_needed >= 0:
                        dec = '0.' + ('0' * zeros_needed) + combined
                    else:
                        split_idx = len(left) + exp_val
                        dec = combined[:split_idx] + '.' + combined[split_idx:]
                
                if '.' in dec:
                    dec = dec.rstrip('0')
                    if dec.endswith('.'):
                        dec = dec[:-1]
                return sign + dec
            else:
                exp_sign = '+' if exp_val > 0 else '-'
                if '.' in mantissa:
                    mantissa = mantissa.rstrip('0')
                    if mantissa.endswith('.'):
                        mantissa = mantissa[:-1]
                return f"{sign}{mantissa}e{exp_sign}{abs(exp_val)}"
        else:
            if '.' in s:
                left, right = s.split('.')
                if right == '0' or set(right) == {'0'}:
                    return sign + left
                else:
                    s = s.rstrip('0')
                    if s.endswith('.'):
                        s = s[:-1]
                    return sign + s
            return sign + s
        
    return str(val)


def utf16_sort_key(s: str) -> bytes:
    """Computes a sorting key for a string based on its UTF-16 code units (RFC 8785 constraint)."""
    return s.encode('utf-16-be')


def _jcs_serialize_to_str(val: Any) -> str:
    """Internal helper to build the JCS-compliant string representation."""
    if isinstance(val, bool):
        return "true" if val else "false"
    if val is None:
        return "null"
    if isinstance(val, str):
        return json.dumps(val, ensure_ascii=False)
    if isinstance(val, (int, float)):
        return rfc8785_format_number(val)
    if isinstance(val, dict):
        parts = []
        for k in sorted(val.keys(), key=utf16_sort_key):
            if not isinstance(k, str):
                raise ValueError("JSON keys must be strings.")
            parts.append(f"{json.dumps(k, ensure_ascii=False)}:{_jcs_serialize_to_str(val[k])}")
        return "{" + ",".join(parts) + "}"
    if isinstance(val, list):
        parts = [_jcs_serialize_to_str(x) for x in val]
        return "[" + ",".join(parts) + "]"
        
    raise ValueError(f"Unsupported JCS serialization type: {type(val)}")


def jcs_serialize(val: Any) -> bytes:
    """Recursively serializes Python data types into JCS (RFC 8785) byte sequence."""
    return _jcs_serialize_to_str(val).encode('utf-8')


def jcs_loads(text: str) -> Any:
    """Parses a JCS/JSON payload while strictly rejecting duplicate keys and non-finite constants."""
    return json.loads(text, object_pairs_hook=reject_duplicate_keys, parse_constant=reject_nonfinite_constant)


# =====================================================================
# CONTRACT v1.4.1-rc1 WIRE & ARTIFACT FUNCTIONS
# =====================================================================

HEADER_FORMAT = ">4sBBHHH"
HEADER_SIZE = 12

def build_outer_header(manifest_length: int, payload_length: int = 768, flags: int = 0) -> bytes:
    """Constructs the 12-byte binary outer header in big-endian network byte order."""
    if flags != 0:
        raise ValueError(f"Core v1.4 profile flags MUST equal 0. Got: {flags}")
    if not (2 <= manifest_length <= 16384):
        raise ValueError(f"Manifest length {manifest_length} exceeds permitted bounds [2, 16384].")
    if payload_length != 768:
        raise ValueError(f"Core v1.4 profile payload_length MUST equal 768. Got: {payload_length}")

    return struct.pack(HEADER_FORMAT, b"BRAD", 1, 4, flags, manifest_length, payload_length)


def parse_outer_header(header_bytes: bytes) -> Dict[str, Any]:
    """Parses and validates the 12-byte outer header strictly."""
    if len(header_bytes) != HEADER_SIZE:
        raise ValueError(f"Outer header must be exactly 12 bytes. Got: {len(header_bytes)}")

    magic, major, minor, flags, manifest_len, payload_len = struct.unpack(HEADER_FORMAT, header_bytes)

    if magic != b"BRAD":
        raise ValueError(f"ERR_BAD_MAGIC: Magic bytes mismatch. Expected b'BRAD', got {magic}")
    if major != 1 or minor != 4:
        raise ValueError(f"ERR_UNSUPPORTED_VERSION: Unsupported wire version {major}.{minor}. Expected 1.4")
    if flags != 0:
        raise ValueError(f"ERR_UNKNOWN_FLAGS: Unknown flags set: {flags}. Must be 0")
    if not (2 <= manifest_len <= 16384):
        raise ValueError(f"ERR_FRAME_LENGTH: Manifest length {manifest_len} outside [2, 16384]")
    if payload_len != 768:
        raise ValueError(f"ERR_FRAME_LENGTH: Payload length {payload_len} must equal 768")

    return {
        "magic": magic.decode("ascii"),
        "major_version": major,
        "minor_version": minor,
        "flags": flags,
        "manifest_length": manifest_len,
        "payload_length": payload_len,
        "raw_header": header_bytes
    }


def build_signature_preimage(header_bytes: bytes, manifest_jcs_bytes: bytes) -> bytes:
    """Constructs Ed25519 signature preimage binding 12-byte header and JCS manifest bytes."""
    return b"BRAID-SIG-v1.4\x00" + header_bytes + manifest_jcs_bytes


def compute_object_digest(header_bytes: bytes, manifest_jcs_bytes: bytes) -> str:
    """Computes object digest: SHA256(ASCII("BRAID-OBJECT-v1.4") || 0x00 || H || M)."""
    hasher = hashlib.sha256()
    hasher.update(b"BRAID-OBJECT-v1.4\x00")
    hasher.update(header_bytes)
    hasher.update(manifest_jcs_bytes)
    return hasher.hexdigest()


def compute_payload_digest(raw_768_bytes: bytes) -> str:
    """Computes lowercase 64-hex SHA-256 digest over raw 768 payload bytes."""
    if len(raw_768_bytes) != 768:
        raise ValueError(f"ERR_PAYLOAD_DIGEST: Raw payload length must be exactly 768 bytes. Got {len(raw_768_bytes)}")
    return hashlib.sha256(raw_768_bytes).hexdigest()


def compute_json_artifact_digest(artifact_type: str, artifact_dict: Dict[str, Any]) -> str:
    """Computes json_artifact_digest over JCS artifact representation."""
    canonical_jcs = jcs_serialize(artifact_dict)
    hasher = hashlib.sha256()
    hasher.update(b"BRAID-JSON-ARTIFACT-v1.4\x00")
    hasher.update(artifact_type.encode("utf-8"))
    hasher.update(b"\x00")
    hasher.update(canonical_jcs)
    return hasher.hexdigest()


def build_bart_container(
    artifact_type: int,
    data_array: np.ndarray,
    metadata_dict: Dict[str, Any],
    dtype_enum: int = 1 # 1=f32, 2=f16, 3=i8
) -> bytes:
    """Constructs a BART v1 binary container byte stream for dense tensor artifacts."""
    if dtype_enum == 1:
        data_bytes = data_array.astype(np.float32).tobytes()
    elif dtype_enum == 2:
        data_bytes = data_array.astype(np.float16).tobytes()
    elif dtype_enum == 3:
        data_bytes = data_array.astype(np.int8).tobytes()
    else:
        raise ValueError(f"Unknown BART dtype enum: {dtype_enum}")

    meta_jcs = jcs_serialize(metadata_dict)
    rank = len(data_array.shape)
    shape_bytes = struct.pack(f">{rank}I", *data_array.shape)

    header = struct.pack(
        ">4sBBBB3sI",
        b"BART",
        1, # container_version
        artifact_type,
        dtype_enum,
        1, # endianness = little
        bytes([0, 0, 0]),
        len(meta_jcs)
    )

    data_len_header = struct.pack(">Q", len(data_bytes))
    return header + shape_bytes + meta_jcs + data_len_header + data_bytes


def compute_bart_digest(bart_bytes: bytes) -> str:
    """Computes binary_artifact_digest over BART container bytes."""
    hasher = hashlib.sha256()
    hasher.update(b"BRAID-BINARY-ARTIFACT-v1.4\x00")
    hasher.update(bart_bytes)
    return hasher.hexdigest()


def serialize_fp16_payload(vector: List[float]) -> bytes:
    """Serializes a 384-float vector into canonical little-endian IEEE-754 FP16.

    FP16 conversion can underflow a tiny negative finite value to the distinct
    bit pattern ``-0.0`` (0x8000).  The wire contract forbids negative zero so
    there is only one canonical encoding for mathematical zero.  Canonicalize
    zero *after* FP16 rounding and before hashing/signing the payload.
    """
    if len(vector) != 384:
        raise ValueError(f"Vector dimension must be 384. Got {len(vector)}")

    arr = np.asarray(vector, dtype="<f2")
    if not np.isfinite(arr).all():
        raise ValueError("ERR_VECTOR_NONFINITE: Payload contains non-finite float values.")

    # Equality intentionally matches both +0.0 and -0.0. Assignment writes the
    # canonical positive-zero bit pattern (0x0000) without disturbing nonzero
    # components. Copy first so this remains safe if NumPy returns a view.
    if np.equal(arr, 0).any():
        arr = arr.copy()
        arr[np.equal(arr, 0)] = np.float16(0.0)

    payload = arr.astype("<f2", copy=False).tobytes(order="C")
    if (np.frombuffer(payload, dtype="<u2") == 0x8000).any():
        raise ValueError("ERR_VECTOR_NEGATIVE_ZERO_INTERNAL: Sender emitted non-canonical negative zero.")
    return payload


def deserialize_fp16_payload(
    payload_bytes: bytes,
    expected_dim: int = 384,
    norm_tolerance: float = 0.01
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Deserializes FP16 payload with strict contract requirements:
      1. Exact 768 byte length.
      2. Rejection of NaN and +/- Infinity.
      3. Rejection of negative zero encodings (0x8000).
      4. Accumulation of L2 norm in float64 and tolerance check abs(norm - 1.0) <= 0.01.
      5. Deterministic unit renormalization in float32.
    """
    expected_bytes = expected_dim * 2
    if len(payload_bytes) != expected_bytes:
        raise ValueError(f"ERR_FRAME_LENGTH: Payload length mismatch {len(payload_bytes)} != {expected_bytes}")

    # Check for negative zero bit patterns (0x8000) in FP16 little-endian
    raw_u16 = np.frombuffer(payload_bytes, dtype='<u2')
    if (raw_u16 == 0x8000).any():
        raise ValueError("ERR_VECTOR_NEGATIVE_ZERO: Payload contains forbidden negative-zero float16 encoding (0x8000).")

    arr = np.frombuffer(payload_bytes, dtype='<f2').astype(np.float64)
    if not np.isfinite(arr).all():
        raise ValueError("ERR_VECTOR_NONFINITE: Decoded payload contains non-finite float values (NaN/Infinity).")

    norm = np.linalg.norm(arr)
    if norm <= 1e-12 or not math.isfinite(norm):
        raise ValueError(f"ERR_VECTOR_NORM: Decoded payload norm {norm} is zero or non-finite.")

    if abs(norm - 1.0) > norm_tolerance:
        raise ValueError(f"ERR_VECTOR_NORM: Decoded payload norm {norm:.4f} outside permitted unit tolerance [0.99, 1.01]")

    normalized_arr = (arr / norm).astype(np.float32)
    return normalized_arr, arr
