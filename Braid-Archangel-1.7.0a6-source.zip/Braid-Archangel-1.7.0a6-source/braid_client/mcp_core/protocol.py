import json
import hmac
import hashlib
import time
import uuid
import sqlite3
import os
import struct
import numpy as np
from typing import List, Dict, Any, Tuple, Optional
from cryptography.hazmat.primitives.asymmetric import ed25519

from braid_client.mcp_core.canonical import (
    jcs_serialize,
    jcs_loads,
    build_outer_header,
    parse_outer_header,
    build_signature_preimage,
    compute_object_digest,
    compute_payload_digest,
    serialize_fp16_payload,
    deserialize_fp16_payload
)

def get_signing_key(priv_hex: str) -> ed25519.Ed25519PrivateKey:
    return ed25519.Ed25519PrivateKey.from_private_bytes(bytes.fromhex(priv_hex))

def get_verification_key(pub_hex: str) -> ed25519.Ed25519PublicKey:
    return ed25519.Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub_hex))


def resolve_effective_authority(
    local_policy: Dict[str, Any],
    sender_requested: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Computes receiver-derived effective authority: P_effective = P_local intersect P_sender_requested.
    P0-5 Security Fix:
      - Evaluates booleans before numeric types (Python bool is subclass of int)
      - Numerical limits compute min(local, requested)
      - String constraints never overwrite receiver authority
      - Unknown sender fields fail closed (omitted from effective authority)
    """
    effective = {}
    for k, local_val in local_policy.items():
        if k in sender_requested:
            requested_val = sender_requested[k]
            
            # 1. Booleans (evaluated BEFORE numeric types)
            if isinstance(local_val, bool) or isinstance(requested_val, bool):
                if isinstance(local_val, bool) and isinstance(requested_val, bool):
                    effective[k] = local_val and requested_val
                else:
                    effective[k] = False  # Type mismatch fails closed

            # 2. Numeric Limits (min of local and requested)
            elif isinstance(local_val, (int, float)) and isinstance(requested_val, (int, float)):
                effective[k] = float(min(float(local_val), float(requested_val)))

            # 3. Sets / Lists (intersection)
            elif isinstance(local_val, (list, tuple)) and isinstance(requested_val, (list, tuple)):
                effective[k] = [x for x in requested_val if x in local_val]

            # 4. Strings / Opaque Identifiers (must match local policy)
            elif isinstance(local_val, str) and isinstance(requested_val, str):
                if local_val == requested_val:
                    effective[k] = local_val
                else:
                    effective[k] = local_val  # Local policy takes precedence over sender string

            else:
                effective[k] = local_val
        else:
            # Sender did not request specific override; retain local policy limit
            effective[k] = local_val

    return effective


class ReplayLedger:
    """
    Multi-process safe, persistent sqlite-backed replay prevention and state sequence ledger.
    Executes check-then-write of sequence, predecessor object digest, and capability state
    inside a single BEGIN IMMEDIATE ... COMMIT transaction block.
    """
    def __init__(
        self,
        db_path: str = "braid_replay_ledger.db",
        clock_skew_allowance_s: int = 5,
        max_envelope_age_s: int = 300,
        max_permitted_ttl_s: int = 600
    ):
        self.db_path = db_path
        self.clock_skew = clock_skew_allowance_s
        self.max_age = max_envelope_age_s
        self.max_ttl = max_permitted_ttl_s
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=5.0)
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    @staticmethod
    def _is_busy_error(exc: sqlite3.Error) -> bool:
        code = getattr(exc, "sqlite_errorcode", None)
        return code in {getattr(sqlite3, "SQLITE_BUSY", 5), getattr(sqlite3, "SQLITE_LOCKED", 6)} or "locked" in str(exc).lower() or "busy" in str(exc).lower()

    def _init_db(self):
        conn = None
        try:
            conn = self._connect()
            if self.db_path != ":memory:":
                try:
                    os.chmod(self.db_path, 0o600)
                except OSError:
                    pass
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS replay_ledger_v3 (
                    receiver_node_id TEXT NOT NULL,
                    signer_key_id TEXT NOT NULL,
                    route_id TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    sequence_num INTEGER NOT NULL,
                    object_id TEXT NOT NULL,
                    nonce TEXT NOT NULL,
                    expiry INTEGER NOT NULL,
                    PRIMARY KEY (receiver_node_id, signer_key_id, route_id, session_id, sequence_num)
                )
            """)
            # Retain the v3 table for upgrade migration only. v1.4.9 uses v4,
            # which scopes session heads to the same receiver/signer/route namespace
            # as replay entries. This prevents a signer or route from colliding with
            # another authorized session merely by reusing its session_id.
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS session_state_ledger_v3 (
                    session_id TEXT PRIMARY KEY,
                    last_sequence_num INTEGER NOT NULL,
                    last_object_digest TEXT NOT NULL,
                    last_vector_blob BLOB,
                    updated_at INTEGER NOT NULL
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS session_state_ledger_v4 (
                    receiver_node_id TEXT NOT NULL,
                    signer_key_id TEXT NOT NULL,
                    route_id TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    last_sequence_num INTEGER NOT NULL,
                    last_object_digest TEXT NOT NULL,
                    last_vector_blob BLOB,
                    updated_at INTEGER NOT NULL,
                    PRIMARY KEY (receiver_node_id, signer_key_id, route_id, session_id)
                )
            """)

            # Best-effort upgrade of unambiguous v1.4.8 session heads. If a legacy
            # session_id was already shared across multiple scopes, it is unsafe to
            # guess ownership; such a session must restart rather than inherit mixed
            # provenance.
            cursor.execute("SELECT session_id, last_sequence_num, last_object_digest, last_vector_blob, updated_at FROM session_state_ledger_v3")
            for session_id, last_seq, last_digest, last_blob, updated_at in cursor.fetchall():
                cursor.execute(
                    "SELECT DISTINCT receiver_node_id, signer_key_id, route_id FROM replay_ledger_v3 WHERE session_id=?",
                    (session_id,),
                )
                scopes = cursor.fetchall()
                if len(scopes) == 1:
                    receiver_node_id, signer_key_id, route_id = scopes[0]
                    cursor.execute("""
                        INSERT OR IGNORE INTO session_state_ledger_v4
                        (receiver_node_id, signer_key_id, route_id, session_id, last_sequence_num, last_object_digest, last_vector_blob, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (receiver_node_id, signer_key_id, route_id, session_id, last_seq, last_digest, last_blob, updated_at))
            conn.commit()
        except sqlite3.Error as e:
            raise RuntimeError(f"Failed to initialize SQLite Replay Ledger at {self.db_path}: {str(e)}")
        finally:
            if conn is not None:
                conn.close()

    def check_replay_phase_a(
        self,
        receiver_node_id: str,
        signer_key_id: str,
        route_id: str,
        session_id: str,
        sequence_num: int,
        issued_at: int,
        expires_at: int
    ) -> Tuple[bool, str]:
        """
        Non-locking Phase A pre-validation check before CPU-heavy probes run.
        """
        now = int(time.time())
        ttl = expires_at - issued_at
        if not (0 < ttl <= self.max_ttl):
            return False, f"ERR_EXPIRED: Envelope TTL {ttl}s must be positive and <= {self.max_ttl}s."
        if issued_at > now + self.clock_skew:
            return False, f"ERR_FUTURE_TIMESTAMP: Timestamp in future beyond clock skew: {issued_at} (Now: {now})"
        if now - issued_at > self.max_age:
            return False, f"ERR_STALE: Envelope stale! Age {now - issued_at}s exceeds max age {self.max_age}s."
        if now >= expires_at:
            return False, f"ERR_EXPIRED: Envelope expired! Expiry time {expires_at} (Now: {now})"

        conn = None
        try:
            conn = self._connect()
            cursor = conn.cursor()
            cursor.execute(
                "SELECT 1 FROM replay_ledger_v3 WHERE receiver_node_id=? AND signer_key_id=? AND route_id=? AND session_id=? AND sequence_num=?",
                (receiver_node_id, signer_key_id, route_id, session_id, sequence_num)
            )
            row = cursor.fetchone()
            if row is not None:
                return False, f"ERR_REPLAY: Sequence {sequence_num} already processed for session {session_id}."
            return True, "Phase A replay check passed."
        except sqlite3.Error as e:
            if self._is_busy_error(e):
                return False, "ERR_DB_BUSY: Replay ledger is busy."
            return False, f"ERR_DB_QUERY: {str(e)}"
        finally:
            if conn is not None:
                conn.close()

    def commit_atomic_transaction(
        self,
        receiver_node_id: str,
        signer_key_id: str,
        route_id: str,
        session_id: str,
        sequence_num: int,
        issued_at: int,
        expires_at: int,
        predecessor_object_digest: str,
        current_object_digest: str,
        object_id: str,
        nonce: str,
        vector: Optional[np.ndarray] = None,
        max_transition_velocity: Optional[float] = None,
        capability_revoked: bool = False
    ) -> Tuple[bool, str]:
        """
        Phase B atomic commit executed inside BEGIN IMMEDIATE ... COMMIT block.
        Re-reads clock AFTER lock acquisition and verifies sequence monotonicity,
        predecessor digest continuity, and capability revocation state.
        """
        conn = None
        try:
            conn = self._connect()
            conn.execute("BEGIN IMMEDIATE")
            cursor = conn.cursor()

            # Read clock AFTER lock acquisition
            now = int(time.time())

            # Re-check temporal guards inside transaction
            ttl = expires_at - issued_at
            if not (0 < ttl <= self.max_ttl):
                conn.rollback()
                return False, f"ERR_EXPIRED: Envelope TTL {ttl}s invalid at commit."
            if issued_at > now + self.clock_skew:
                conn.rollback()
                return False, f"ERR_FUTURE_TIMESTAMP: Future issued_at {issued_at} beyond clock skew."
            if now - issued_at > self.max_age:
                conn.rollback()
                return False, f"ERR_STALE: Envelope stale at commit ({now - issued_at}s > {self.max_age}s)."
            if now >= expires_at:
                conn.rollback()
                return False, f"ERR_EXPIRED: Envelope expired at commit time {expires_at} (Now: {now})."

            # Capability revocation check inside commit phase
            if capability_revoked:
                conn.rollback()
                return False, "ERR_CAPABILITY: Referenced capability has been revoked."

            # Re-verify session sequence head and predecessor
            cursor.execute(
                "SELECT last_sequence_num, last_object_digest, last_vector_blob FROM session_state_ledger_v4 WHERE receiver_node_id=? AND signer_key_id=? AND route_id=? AND session_id=?",
                (receiver_node_id, signer_key_id, route_id, session_id)
            )
            row = cursor.fetchone()

            if sequence_num == 1:
                if row is not None:
                    conn.rollback()
                    return False, f"ERR_SEQUENCE: Genesis sequence 1 received for existing active session {session_id}."
                if predecessor_object_digest != "0" * 64:
                    conn.rollback()
                    return False, "ERR_PREDECESSOR: Sequence 1 predecessor_object_digest MUST be 64 zeroes."
            else:
                if row is None:
                    conn.rollback()
                    return False, f"ERR_SEQUENCE: Non-genesis sequence {sequence_num} received for unknown session."
                last_seq, last_digest, last_blob = row

                if sequence_num != last_seq + 1:
                    conn.rollback()
                    return False, f"ERR_SEQUENCE: Out-of-order sequence {sequence_num}! Expected exactly {last_seq + 1}."

                if predecessor_object_digest != last_digest:
                    conn.rollback()
                    return False, f"ERR_PREDECESSOR: Predecessor digest mismatch! Received {predecessor_object_digest[:16]}..., expected {last_digest[:16]}..."

                if vector is not None and last_blob is not None and max_transition_velocity is not None:
                    prev_vec = np.frombuffer(last_blob, dtype=np.float32)
                    delta = float(np.linalg.norm(vector - prev_vec))
                    if delta > max_transition_velocity:
                        conn.rollback()
                        return False, f"ERR_VELOCITY: State transition delta {delta:.4f} exceeds ceiling {max_transition_velocity:.4f}."

            # Insert replay entry
            cursor.execute(
                "INSERT INTO replay_ledger_v3 VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (receiver_node_id, signer_key_id, route_id, session_id, sequence_num, object_id, nonce, expires_at)
            )

            # Update session head
            vec_blob = vector.astype(np.float32).tobytes() if vector is not None else None
            cursor.execute("""
                INSERT INTO session_state_ledger_v4
                (receiver_node_id, signer_key_id, route_id, session_id, last_sequence_num, last_object_digest, last_vector_blob, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(receiver_node_id, signer_key_id, route_id, session_id) DO UPDATE SET
                    last_sequence_num = excluded.last_sequence_num,
                    last_object_digest = excluded.last_object_digest,
                    last_vector_blob = excluded.last_vector_blob,
                    updated_at = excluded.updated_at
            """, (receiver_node_id, signer_key_id, route_id, session_id, sequence_num, current_object_digest, vec_blob, now))
            conn.commit()
            return True, "Transaction committed successfully."
        except sqlite3.Error as e:
            if conn is not None:
                try:
                    conn.rollback()
                except sqlite3.Error:
                    pass
            if self._is_busy_error(e):
                return False, "ERR_DB_BUSY: Replay ledger commit could not acquire the write lock."
            if isinstance(e, sqlite3.IntegrityError):
                return False, f"ERR_REPLAY_CONFLICT: {str(e)}"
            return False, f"ERR_DB_COMMIT: {str(e)}"
        finally:
            if conn is not None:
                conn.close()


class BraidFrame:
    """
    Encapsulates a full Braid v1.4 binary frame:
      12-byte header + M-byte JCS Manifest + 64-byte Ed25519 signature + 768-byte FP16 vector
    """
    def __init__(
        self,
        manifest_dict: Dict[str, Any],
        vector_384: List[float],
        signer_private_key: Optional[ed25519.Ed25519PrivateKey] = None,
        signature_hex: Optional[str] = None,
        flags: int = 0
    ):
        self.manifest = manifest_dict
        self.vector = vector_384
        self.flags = flags

        # Serialize vector to FP16 Little-Endian (768 bytes)
        self.raw_payload = serialize_fp16_payload(vector_384)
        self.manifest["payload_digest"] = compute_payload_digest(self.raw_payload)

        # JCS manifest bytes
        self.manifest_jcs = jcs_serialize(self.manifest)
        self.manifest_len = len(self.manifest_jcs)

        # Build 12-byte outer header
        self.header_bytes = build_outer_header(self.manifest_len, payload_length=768, flags=flags)

        # Compute signature preimage: ASCII("BRAID-SIG-v1.4") || 0x00 || H || M
        self.signature_preimage = build_signature_preimage(self.header_bytes, self.manifest_jcs)

        if signer_private_key is not None:
            sig_bytes = signer_private_key.sign(self.signature_preimage)
            self.signature_bytes = sig_bytes
            self.signature_hex = sig_bytes.hex()
        elif signature_hex is not None:
            self.signature_bytes = bytes.fromhex(signature_hex)
            self.signature_hex = signature_hex
        else:
            raise ValueError("Frame requires either a private key for signing or an explicit signature_hex.")

        self.object_digest = compute_object_digest(self.header_bytes, self.manifest_jcs)

    def to_bytes(self) -> bytes:
        """Serializes the complete frame into a binary stream buffer."""
        return self.header_bytes + self.manifest_jcs + self.signature_bytes + self.raw_payload

    @classmethod
    def from_bytes(cls, frame_bytes: bytes) -> 'BraidFrame':
        """Parses a complete Braid binary frame stream buffer."""
        if len(frame_bytes) < 12 + 2 + 64 + 768:
            raise ValueError("ERR_FRAME_LENGTH: Binary frame stream shorter than minimum frame length.")

        header = parse_outer_header(frame_bytes[:12])
        m_len = header["manifest_length"]

        expected_total = 12 + m_len + 64 + 768
        if len(frame_bytes) != expected_total:
            raise ValueError(f"ERR_FRAME_LENGTH: Total frame size mismatch: got {len(frame_bytes)}, expected {expected_total}")

        manifest_jcs = frame_bytes[12 : 12 + m_len]
        sig_bytes = frame_bytes[12 + m_len : 12 + m_len + 64]
        raw_payload = frame_bytes[12 + m_len + 64 :]

        # Verify JCS byte-for-byte canonical equality
        manifest_dict = jcs_loads(manifest_jcs.decode("utf-8"))
        reserialized_jcs = jcs_serialize(manifest_dict)
        if reserialized_jcs != manifest_jcs:
            raise ValueError("ERR_MANIFEST_NONCANONICAL: Manifest bytes do not equal RFC 8785 canonical reserialization.")

        norm_arr, raw_arr = deserialize_fp16_payload(raw_payload)

        # Construct frame object
        frame = cls.__new__(cls)
        frame.header_bytes = frame_bytes[:12]
        frame.manifest_jcs = manifest_jcs
        frame.manifest = manifest_dict
        frame.signature_bytes = sig_bytes
        frame.signature_hex = sig_bytes.hex()
        frame.raw_payload = raw_payload
        frame.vector = norm_arr.tolist()
        frame.flags = header["flags"]
        frame.manifest_len = m_len
        frame.signature_preimage = build_signature_preimage(frame.header_bytes, manifest_jcs)
        frame.object_digest = compute_object_digest(frame.header_bytes, manifest_jcs)

        return frame

class BraidEnvelope:
    """Backward-compatibility wrapper for BraidFrame."""
    def __init__(self, **kwargs):
        self._data = kwargs

    def build_signing_body(self):
        return self._data

    @classmethod
    def from_dict(cls, data):
        return cls(**data)

class BraidEnvelopeCompat:
    """Full compatibility envelope class for mcp_test_client."""
    def __init__(
        self,
        vector: List[float],
        semantic_label: str,
        source_representation: Dict[str, Any],
        target_representation: Dict[str, Any],
        cluster_id: int = 0,
        activation_threshold: float = 0.0,
        source_space_id: str = "none",
        source_space_digest: str = "none",
        target_space_id: str = "none",
        target_space_digest: str = "none",
        transport_map_id: str = "none",
        transport_map_digest: str = "none",
        feature_spec_id: str = "none",
        feature_spec_digest: str = "none",
        signer_key_id: str = "signer_node_a",
        algorithm_id: str = "ed25519",
        audience: str = "node_b_receiver",
        schema_version: str = "1.3.0",
        object_id: Optional[str] = None,
        nonce: Optional[str] = None,
        timestamp: Optional[int] = None,
        expiry: Optional[int] = None,
        signature: Optional[str] = None
    ):
        self.vector = vector
        self.semantic_label = semantic_label
        self.source_representation = source_representation
        self.target_representation = target_representation
        self.cluster_id = cluster_id
        self.activation_threshold = activation_threshold
        self.source_space_id = source_space_id
        self.source_space_digest = source_space_digest
        self.target_space_id = target_space_id
        self.target_space_digest = target_space_digest
        self.transport_map_id = transport_map_id
        self.transport_map_digest = transport_map_digest
        self.feature_spec_id = feature_spec_id
        self.feature_spec_digest = feature_spec_digest
        self.signer_key_id = signer_key_id
        self.algorithm_id = algorithm_id
        self.audience = audience
        self.schema_version = schema_version
        self.object_id = object_id or str(uuid.uuid4())
        self.nonce = nonce or hashlib.sha256(str(uuid.uuid4()).encode()).hexdigest()[:16]
        self.timestamp = timestamp or int(time.time())
        self.expiry = expiry or (self.timestamp + 300)
        self.signature = signature

    def build_signing_body(self) -> Dict[str, Any]:
        return {
            "object_id": self.object_id,
            "nonce": self.nonce,
            "schema_version": self.schema_version,
            "timestamp": self.timestamp,
            "expiry": self.expiry,
            "source_space_id": self.source_space_id,
            "source_space_digest": self.source_space_digest,
            "target_space_id": self.target_space_id,
            "target_space_digest": self.target_space_digest,
            "transport_map_id": self.transport_map_id,
            "transport_map_digest": self.transport_map_digest,
            "feature_spec_id": self.feature_spec_id,
            "feature_spec_digest": self.feature_spec_digest,
            "signer_key_id": self.signer_key_id,
            "algorithm_id": self.algorithm_id,
            "audience": self.audience,
            "source_representation": self.source_representation,
            "target_representation": self.target_representation,
            "semantic_label": self.semantic_label,
            "cluster_id": self.cluster_id,
            "activation_threshold": self.activation_threshold,
            "vector": self.vector
        }

    def sign_envelope(self, private_key: ed25519.Ed25519PrivateKey) -> None:
        body = self.build_signing_body()
        canonical_bytes = jcs_serialize(body)
        SIGNING_PREFIX = b"BRAID-MCP-ENVELOPE-v1\x00"
        sig_bytes = private_key.sign(SIGNING_PREFIX + canonical_bytes)
        self.signature = sig_bytes.hex()

    def to_dict(self) -> Dict[str, Any]:
        body = self.build_signing_body()
        if not self.signature:
            raise ValueError("Signature required.")
        body["signature"] = self.signature
        return body

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BraidEnvelopeCompat':
        return cls(
            vector=data["vector"],
            semantic_label=data["semantic_label"],
            source_representation=data["source_representation"],
            target_representation=data["target_representation"],
            cluster_id=data.get("cluster_id", 0),
            activation_threshold=data.get("activation_threshold", 0.0),
            source_space_id=data.get("source_space_id", "none"),
            source_space_digest=data.get("source_space_digest", "none"),
            target_space_id=data.get("target_space_id", "none"),
            target_space_digest=data.get("target_space_digest", "none"),
            transport_map_id=data.get("transport_map_id", "none"),
            transport_map_digest=data.get("transport_map_digest", "none"),
            feature_spec_id=data.get("feature_spec_id", "none"),
            feature_spec_digest=data.get("feature_spec_digest", "none"),
            signer_key_id=data.get("signer_key_id", "signer_node_a"),
            algorithm_id=data.get("algorithm_id", "ed25519"),
            audience=data.get("audience", "node_b_receiver"),
            schema_version=data.get("schema_version", "1.3.0"),
            object_id=data.get("object_id"),
            nonce=data.get("nonce"),
            timestamp=data.get("timestamp"),
            expiry=data.get("expiry"),
            signature=data.get("signature")
        )

BraidEnvelope = BraidEnvelopeCompat

# Compatibility method on ReplayLedger
def _commit_replay_legacy(self, audience: str, signer_key_id: str, object_id: str, nonce: str, timestamp: int, expiry: int) -> Tuple[bool, str]:
    return self.commit_atomic_transaction(
        receiver_node_id=audience,
        signer_key_id=signer_key_id,
        route_id="route_generic",
        session_id=object_id,
        sequence_num=1,
        issued_at=timestamp,
        expires_at=expiry,
        predecessor_object_digest="0"*64,
        current_object_digest="0"*64,
        object_id=object_id,
        nonce=nonce
    )

ReplayLedger.commit_replay = _commit_replay_legacy

# Legacy compatibility commit method returning expected error substring
def _commit_replay_legacy(self, audience: str, signer_key_id: str, object_id: str, nonce: str, timestamp: int, expiry: int) -> Tuple[bool, str]:
    success, msg = self.commit_atomic_transaction(
        receiver_node_id=audience,
        signer_key_id=signer_key_id,
        route_id="route_generic",
        session_id=object_id,
        sequence_num=1,
        issued_at=timestamp,
        expires_at=expiry,
        predecessor_object_digest="0"*64,
        current_object_digest="0"*64,
        object_id=object_id,
        nonce=nonce
    )
    if not success:
        return False, f"Replay check failed: {msg}"
    return True, msg

ReplayLedger.commit_replay = _commit_replay_legacy
