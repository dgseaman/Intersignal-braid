import hashlib
import json
import numpy as np
from typing import Dict, Any, List, Optional, Set, Tuple, Union
from types import MappingProxyType

from braid_client.mcp_core.alignment import RepresentationSpace, TransportMap, ImmutableArtifact
from braid_client.mcp_core.validation import FeatureSpec
from braid_client.mcp_core.canonical import (
    jcs_serialize,
    compute_json_artifact_digest,
    compute_bart_digest,
    build_bart_container
)

class RouteContract(ImmutableArtifact):
    """Represents a frozen route contract entry in Node B's local registry."""
    def __init__(
        self,
        route_id: str,
        sender_node_id: str,
        receiver_node_id: str,
        signer_key_id: str,
        source_space_id: str,
        target_space_id: str,
        transport_map_id: str,
        feature_spec_id: str,
        source_space_digest: str,
        target_space_digest: str,
        source_extraction_adapter_digest: str,
        source_expansion_adapter_digest: str,
        target_extraction_adapter_digest: str,
        target_expansion_adapter_digest: str,
        transport_map_digest: str,
        feature_spec_digest: str,
        canonical_space_spec_digest: str,
        quantization_spec_digest: str,
        subspace_residual_ceiling: float = 0.50,
        mahalanobis_ood_ceiling: float = 3.50,
        max_ttl_s: int = 600,
        max_clock_skew_s: int = 5,
        max_age_s: int = 300
    ):
        self.route_id = route_id
        self.sender_node_id = sender_node_id
        self.receiver_node_id = receiver_node_id
        self.signer_key_id = signer_key_id
        self.source_space_id = source_space_id
        self.target_space_id = target_space_id
        self.transport_map_id = transport_map_id
        self.feature_spec_id = feature_spec_id

        self.source_space_digest = source_space_digest
        self.target_space_digest = target_space_digest
        self.source_extraction_adapter_digest = source_extraction_adapter_digest
        self.source_expansion_adapter_digest = source_expansion_adapter_digest
        self.target_extraction_adapter_digest = target_extraction_adapter_digest
        self.target_expansion_adapter_digest = target_expansion_adapter_digest
        self.transport_map_digest = transport_map_digest
        self.feature_spec_digest = feature_spec_digest
        self.canonical_space_spec_digest = canonical_space_spec_digest
        self.quantization_spec_digest = quantization_spec_digest

        self.subspace_residual_ceiling = subspace_residual_ceiling
        self.mahalanobis_ood_ceiling = mahalanobis_ood_ceiling
        self.max_ttl_s = max_ttl_s
        self.max_clock_skew_s = max_clock_skew_s
        self.max_age_s = max_age_s

        self.route_contract_digest = self.compute_route_contract_digest()
        self._freeze()

    def compute_route_contract_digest(self) -> str:
        meta = {
            "route_id": self.route_id,
            "sender_node_id": self.sender_node_id,
            "receiver_node_id": self.receiver_node_id,
            "signer_key_id": self.signer_key_id,
            "source_space_id": self.source_space_id,
            "target_space_id": self.target_space_id,
            "transport_map_id": self.transport_map_id,
            "feature_spec_id": self.feature_spec_id,
            "source_space_digest": self.source_space_digest,
            "target_space_digest": self.target_space_digest,
            "source_extraction_adapter_digest": self.source_extraction_adapter_digest,
            "source_expansion_adapter_digest": self.source_expansion_adapter_digest,
            "target_extraction_adapter_digest": self.target_extraction_adapter_digest,
            "target_expansion_adapter_digest": self.target_expansion_adapter_digest,
            "transport_map_digest": self.transport_map_digest,
            "feature_spec_digest": self.feature_spec_digest,
            "canonical_space_spec_digest": self.canonical_space_spec_digest,
            "quantization_spec_digest": self.quantization_spec_digest,
            "subspace_residual_ceiling": self.subspace_residual_ceiling,
            "mahalanobis_ood_ceiling": self.mahalanobis_ood_ceiling,
            "max_ttl_s": self.max_ttl_s,
            "max_clock_skew_s": self.max_clock_skew_s,
            "max_age_s": self.max_age_s
        }
        return compute_json_artifact_digest("route_contract", meta)


class AuthorizedRoute(ImmutableArtifact):
    """Represents an authorized route structure or tuple."""
    def __init__(
        self,
        audience: str,
        source_space_id: str,
        target_space_id: str,
        transport_map_id: str,
        feature_spec_id: str
    ):
        self.audience = audience
        self.source_space_id = source_space_id
        self.target_space_id = target_space_id
        self.transport_map_id = transport_map_id
        self.feature_spec_id = feature_spec_id
        self._freeze()

    def to_tuple(self) -> Tuple[str, str, str, str, str]:
        return (self.audience, self.source_space_id, self.target_space_id, self.transport_map_id, self.feature_spec_id)


class AuthorizedSigner(ImmutableArtifact):
    """Signer key identity and authorized routes/route_ids allowlist."""
    def __init__(
        self,
        signer_key_id: str,
        public_key_hex: str,
        authorized_route_ids: Optional[List[str]] = None,
        authorized_routes: Optional[List[Union[AuthorizedRoute, Dict[str, Any], str]]] = None
    ):
        pub_bytes = bytes.fromhex(public_key_hex)
        if len(pub_bytes) != 32:
            raise ValueError(f"ERR_UNKNOWN_SIGNER: Ed25519 public key must be exactly 32 bytes for '{signer_key_id}'.")

        self.signer_key_id = signer_key_id
        self.public_key_hex = public_key_hex

        routes_set = set()
        if authorized_route_ids is not None:
            for r in authorized_route_ids:
                routes_set.add(r)

        if authorized_routes is not None:
            for r in authorized_routes:
                if isinstance(r, AuthorizedRoute):
                    routes_set.add(r.transport_map_id) # map_id or route tuple
                    routes_set.add(r.to_tuple())
                elif isinstance(r, str):
                    routes_set.add(r)
                elif isinstance(r, dict):
                    routes_set.add(r.get("transport_map_id", "route_generic"))

        self.authorized_route_ids = frozenset(routes_set)
        self.authorized_routes = frozenset(routes_set)
        self._freeze()

    def is_authorized_route(self, route_id: str) -> bool:
        return (route_id in self.authorized_route_ids) or any(isinstance(r, tuple) and r[3] == route_id for r in self.authorized_routes)


class PCAModel:
    """Subspace reconstruction model for residual gate."""
    def __init__(self, principal_components: np.ndarray, mean_vector: np.ndarray):
        self.U = principal_components
        self.mean = mean_vector

    def compute_reconstruction_residual(self, vector: np.ndarray) -> float:
        diff = vector - self.mean
        proj = (diff @ self.U.T) @ self.U
        residual = diff - proj
        return float(np.linalg.norm(residual))


class CovarianceModel:
    """Covariance model for Mahalanobis OOD gate."""
    def __init__(self, covariance_matrix: np.ndarray, mean_vector: np.ndarray):
        self.covariance_matrix = covariance_matrix
        self.mean_vector = mean_vector


class TrustedRegistry:
    """
    Node B's frozen, immutable local registry.
    Recomputes all BART and JSON artifact digests at registry freeze time.
    """
    def __init__(self):
        self._signers: Dict[str, AuthorizedSigner] = {}
        self._routes: Dict[str, RouteContract] = {}
        self._source_spaces: Dict[str, RepresentationSpace] = {}
        self._target_spaces: Dict[str, RepresentationSpace] = {}
        self._transport_maps: Dict[str, TransportMap] = {}
        self._feature_specs: Dict[str, FeatureSpec] = {}
        self._bart_artifacts: Dict[str, bytes] = {}
        self._local_policies: Dict[str, Dict[str, Any]] = {}
        self._revoked_capabilities: Set[str] = set()

        self._pca_models: Dict[str, PCAModel] = {}
        self._cov_models: Dict[str, CovarianceModel] = {}

        self._frozen = False

    def freeze_registry(self) -> None:
        """
        Freezes the registry and recomputes every artifact digest independently from source bytes.
        Sets mutable construction dicts to inaccessible.
        """
        if self._frozen:
            return

        for route_id, route in self._routes.items():
            signer = self._signers.get(route.signer_key_id)
            if not signer or not signer.is_authorized_route(route_id):
                raise ValueError(f"Startup Blocked: Signer '{route.signer_key_id}' not authorized for route '{route_id}'")

            source = self._source_spaces.get(route.source_space_id)
            target = self._target_spaces.get(route.target_space_id)
            t_map = self._transport_maps.get(route.transport_map_id)
            spec = self._feature_specs.get(route.feature_spec_id)

            if not source or not target or not t_map or not spec:
                raise ValueError(f"Startup Blocked: Missing route components for '{route_id}'")

            src_digest = source.compute_digest()
            tgt_digest = target.compute_digest()
            map_digest = t_map.compute_digest()
            spec_digest = spec.compute_spec_digest()

            if route.source_space_digest != src_digest:
                raise ValueError(f"Startup Blocked: Source space digest mismatch on route '{route_id}'")
            if route.target_space_digest != tgt_digest:
                raise ValueError(f"Startup Blocked: Target space digest mismatch on route '{route_id}'")
            if route.transport_map_digest != map_digest:
                raise ValueError(f"Startup Blocked: Transport map digest mismatch on route '{route_id}'")
            if route.feature_spec_digest != spec_digest:
                raise ValueError(f"Startup Blocked: Feature spec digest mismatch on route '{route_id}'")

        # Verify all BART artifacts
        for art_id, bart_bytes in self._bart_artifacts.items():
            if len(bart_bytes) < 16 or bart_bytes[:4] != b"BART":
                raise ValueError(f"Startup Blocked: Invalid BART container header for '{art_id}'")
            _ = compute_bart_digest(bart_bytes)

        self._frozen = True

    def register_signer(self, signer: AuthorizedSigner) -> None:
        if self._frozen:
            raise TypeError("Cannot mutate a frozen registry.")
        self._signers[signer.signer_key_id] = signer

    def register_route(self, route: RouteContract) -> None:
        if self._frozen:
            raise TypeError("Cannot mutate a frozen registry.")
        self._routes[route.route_id] = route

    def register_source_space(self, space_id: str, space: RepresentationSpace) -> None:
        if self._frozen:
            raise TypeError("Cannot mutate a frozen registry.")
        self._source_spaces[space_id] = space

    def register_target_space(self, space_id: str, space: RepresentationSpace) -> None:
        if self._frozen:
            raise TypeError("Cannot mutate a frozen registry.")
        self._target_spaces[space_id] = space

    def register_transport_map(self, map_id: str, t_map: TransportMap) -> None:
        if self._frozen:
            raise TypeError("Cannot mutate a frozen registry.")
        self._transport_maps[map_id] = t_map

    def register_feature_spec(self, spec_id: str, spec: FeatureSpec) -> None:
        if self._frozen:
            raise TypeError("Cannot mutate a frozen registry.")
        self._feature_specs[spec_id] = spec

    def register_bart_artifact(self, artifact_id: str, bart_bytes: bytes) -> str:
        if self._frozen:
            raise TypeError("Cannot mutate a frozen registry.")
        digest = compute_bart_digest(bart_bytes)
        self._bart_artifacts[artifact_id] = bart_bytes
        return digest

    def set_local_policy(self, route_id: str, policy: Dict[str, Any]) -> None:
        self._local_policies[route_id] = policy

    def revoke_capability(self, capability_ref: str) -> None:
        self._revoked_capabilities.add(capability_ref)

    def is_capability_revoked(self, capability_ref: Optional[str], receiver_node_id: str) -> bool:
        if not capability_ref:
            return False
        return capability_ref in self._revoked_capabilities

    def get_signer(self, signer_id: str) -> Optional[AuthorizedSigner]:
        return self._signers.get(signer_id)

    def get_route(self, route_id: str) -> Optional[RouteContract]:
        return self._routes.get(route_id)

    def get_source_space(self, space_id: str) -> Optional[RepresentationSpace]:
        return self._source_spaces.get(space_id)

    def get_target_space(self, space_id: str) -> Optional[RepresentationSpace]:
        return self._target_spaces.get(space_id)

    def get_transport_map(self, map_id: str) -> Optional[TransportMap]:
        return self._transport_maps.get(map_id)

    def get_feature_spec(self, spec_id: str) -> Optional[FeatureSpec]:
        return self._feature_specs.get(spec_id)

    def get_local_policy_for_route(self, route_id: str) -> Dict[str, Any]:
        return self._local_policies.get(route_id, {"max_refund": 50.0})

    def get_pca_model(self, route_id: str) -> Optional[PCAModel]:
        return self._pca_models.get(route_id)

    def get_covariance_model(self, route_id: str) -> Optional[CovarianceModel]:
        return self._cov_models.get(route_id)


def compute_space_digest(space: Any) -> str:
    return space.compute_digest()


def compute_map_digest(R: Any, t: Any, algorithm_version: str, normalization_policy: str, source_space_digest: str, target_space_digest: str) -> str:
    meta = {
        "R": R.tolist() if isinstance(R, np.ndarray) else R,
        "t": t.tolist() if isinstance(t, np.ndarray) else t,
        "algorithm": algorithm_version,
        "normalization_policy": normalization_policy,
        "source_space_digest": source_space_digest,
        "target_space_digest": target_space_digest
    }
    return compute_json_artifact_digest("transport_map", meta)

# Read-only exposures on TrustedRegistry
def _get_signers(self):
    return MappingProxyType(self._signers)

def _get_source_spaces(self):
    return MappingProxyType(self._source_spaces)

def _get_target_spaces(self):
    return MappingProxyType(self._target_spaces)

def _get_transport_maps(self):
    return MappingProxyType(self._transport_maps)

def _get_feature_specs(self):
    return MappingProxyType(self._feature_specs)

TrustedRegistry.signers = property(_get_signers)
TrustedRegistry.source_spaces = property(_get_source_spaces)
TrustedRegistry.target_spaces = property(_get_target_spaces)
TrustedRegistry.transport_maps = property(_get_transport_maps)
TrustedRegistry.feature_specs = property(_get_feature_specs)
