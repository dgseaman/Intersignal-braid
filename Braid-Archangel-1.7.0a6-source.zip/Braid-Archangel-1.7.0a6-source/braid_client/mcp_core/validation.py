import math
import numpy as np
import hashlib
import json
from typing import List, Dict, Any, Tuple, Optional
from types import MappingProxyType
from cryptography.hazmat.primitives.asymmetric import ed25519

from braid_client.mcp_core.alignment import RepresentationSpace, TransportMap, ImmutableArtifact, SecurityError
from braid_client.mcp_core.protocol import BraidFrame, ReplayLedger, get_verification_key, resolve_effective_authority
from braid_client.mcp_core.canonical import (
    jcs_serialize,
    jcs_loads,
    compute_object_digest,
    compute_payload_digest,
    deserialize_fp16_payload,
    compute_json_artifact_digest,
    compute_bart_digest
)

def compute_regularized_mahalanobis_ood(
    vector: np.ndarray,
    mu_B: np.ndarray,
    covariance_matrix: np.ndarray,
    gamma: float = 0.2
) -> float:
    """
    Computes regularized Mahalanobis distance using Ledoit-Wolf / diagonal shrinkage covariance:
      Sigma_shrunk = (1 - gamma) * Sigma_emp + gamma * (Tr(Sigma_emp) / d) * I
    Prevents singular or numerically unstable matrix inversions in 384D space.
    """
    d = len(vector)
    tr_scaled = float(np.trace(covariance_matrix)) / float(d)
    Sigma_shrunk = (1.0 - gamma) * covariance_matrix + gamma * tr_scaled * np.eye(d)
    
    inv_cov = np.linalg.inv(Sigma_shrunk)
    diff = vector - mu_B
    dist_sq = float(diff.T @ inv_cov @ diff)
    return math.sqrt(max(0.0, dist_sq))


class FeatureSpec(ImmutableArtifact):
    """
    Represents versioned, structured feature probes/invariants and weights
    for semantic preservation checks (ℱ).
    """
    def __init__(
        self,
        feature_spec_id: str,
        target_space_digest: str,
        probes: Dict[str, List[float]],
        weights: Dict[str, float],
        aggregate_threshold: float = 0.30,
        per_probe_thresholds: Dict[str, float] = None,
        version: str = "1.0.0"
    ):
        self.feature_spec_id = feature_spec_id
        self.target_space_digest = target_space_digest
        
        probes_copy = {k: tuple(v) for k, v in probes.items()}
        weights_copy = dict(weights)
        self.probes = MappingProxyType(probes_copy)
        self.weights = MappingProxyType(weights_copy)
        
        if isinstance(aggregate_threshold, bool):
            raise ValueError("Feature spec aggregate_threshold cannot be a boolean value.")
        if not isinstance(aggregate_threshold, (int, float)) or aggregate_threshold <= 0.0 or aggregate_threshold > 2.0 or math.isnan(aggregate_threshold) or math.isinf(aggregate_threshold):
            raise ValueError(f"Feature spec aggregate_threshold must be strictly positive and <= 2.0. Value: {aggregate_threshold}")
            
        self.aggregate_threshold = aggregate_threshold
        ppt = per_probe_thresholds or {name: 0.35 for name in probes.keys()}
        self.per_probe_thresholds = MappingProxyType(dict(ppt))
        self.version = version
        
        is_ok, err_msg = self.validate_self_invariants()
        if not is_ok:
            raise ValueError(f"Braid Spec Invariant Violation: {err_msg}")
            
        self._freeze()

    def compute_spec_digest(self) -> str:
        """Computes json_artifact_digest over the canonical JCS specification."""
        meta = {
            "feature_spec_id": self.feature_spec_id,
            "target_space_digest": self.target_space_digest,
            "probes": {k: list(v) for k, v in self.probes.items()},
            "weights": dict(self.weights),
            "aggregate_threshold": self.aggregate_threshold,
            "per_probe_thresholds": dict(self.per_probe_thresholds),
            "version": self.version
        }
        return compute_json_artifact_digest("feature_spec", meta)

    def validate_self_invariants(self) -> Tuple[bool, str]:
        """Ensures FeatureSpec invariants are valid."""
        if not self.probes:
            return False, "Feature spec contains no active probes."
        if not self.weights:
            return False, "Feature spec contains no active weight bounds."
        if len(self.probes) != len(self.weights):
            return False, f"Size mismatch between probes ({len(self.probes)}) and weights ({len(self.weights)})."

        if not self.target_space_digest or len(self.target_space_digest) != 64:
            return False, "Feature spec has an invalid target space digest."

        if set(self.probes.keys()) != set(self.weights.keys()) or set(self.probes.keys()) != set(self.per_probe_thresholds.keys()):
            return False, "Keys of probes, weights and per_probe_thresholds must match exactly."

        for name, probe in self.probes.items():
            if not isinstance(probe, (list, tuple)):
                return False, f"Probe '{name}' must be a list or tuple."
            for idx, val in enumerate(probe):
                if isinstance(val, bool):
                    return False, f"Probe '{name}' contains invalid boolean coefficient at index {idx}."
                if not isinstance(val, (int, float)):
                    return False, f"Probe '{name}' contains non-numeric value at index {idx}."
                if math.isnan(val) or math.isinf(val):
                    return False, f"Probe '{name}' contains non-finite value at index {idx}."
            
            magnitude = math.sqrt(sum(x*x for x in probe))
            if abs(magnitude - 1.0) > 1e-4:
                return False, f"Probe '{name}' is not unit-normalized as required. Magnitude: {magnitude}"

        for name, w in self.weights.items():
            if isinstance(w, bool):
                return False, f"Weight '{name}' cannot be a boolean value."
            if not isinstance(w, (int, float)):
                return False, f"Weight '{name}' is non-numeric: {type(w)}"
            if w <= 0.0 or math.isnan(w) or math.isinf(w):
                return False, f"Weight '{name}' must be strictly positive and finite. Value: {w}"

        for name, t in self.per_probe_thresholds.items():
            if isinstance(t, bool):
                return False, f"Threshold '{name}' cannot be a boolean value."
            if not isinstance(t, (int, float)) or t <= 0.0 or t >= 2.0 or math.isnan(t) or math.isinf(t):
                return False, f"Threshold '{name}' must be positive, strictly < 2.0, and finite. Value: {t}"

        return True, "Feature spec invariants are valid."


class DiscrepancyReport:
    """Diagnostic discrepancy results (Δ) over FeatureSpec (ℱ)."""
    def __init__(
        self,
        named_metrics: Dict[str, float],
        thresholds: Dict[str, float],
        approximate_support_ratio: float,
        dataset_id: str,
        status: str = "UNVERIFIED"
    ):
        self.named_metrics = named_metrics
        self.thresholds = thresholds
        self.approximate_support_ratio = approximate_support_ratio
        self.dataset_id = dataset_id
        self.status = status

    def to_dict(self) -> Dict[str, Any]:
        return {
            "named_metrics": self.named_metrics,
            "thresholds": self.thresholds,
            "approximate_support_ratio": self.approximate_support_ratio,
            "dataset_id": self.dataset_id,
            "status": self.status
        }


class ValidationResult:
    """Standardized response from Braid validation gates."""
    def __init__(self, is_valid: bool, gate_name: str, message: str, diagnostic_payload: Optional[Dict[str, Any]] = None):
        self.is_valid = is_valid
        self.gate_name = gate_name
        self.message = message
        self.diagnostic_payload = diagnostic_payload or {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_valid": self.is_valid,
            "gate_name": self.gate_name,
            "message": self.message,
            "diagnostic_payload": self.diagnostic_payload
        }


class BraidValidator:
    """
    Enforces Phase A non-locking pre-validation and Phase B atomic commit validation.
    Conforms strictly to Braid Wire and Security Contract v1.4.1-rc1.
    """
    def __init__(self, registry: Any, ledger: ReplayLedger, local_node_id: str = "node:intersignal:atlas-b", local_audience_id: Optional[str] = None):
        self.local_node_id = local_audience_id or local_node_id
        self.registry = registry
        self.ledger = ledger
        self.local_node_id = local_node_id

    def validate_frame_phase_a(
        self,
        frame_bytes: bytes,
        *,
        distribution_gate_mode: str = "enforce",
    ) -> ValidationResult:
        """
        Phase A: bounded non-locking validation.

        ``distribution_gate_mode`` is receiver policy, not sender input. ``enforce``
        preserves the historical hard subspace/Mahalanobis rejection. ``diagnostic``
        records the same measured drift but does not let route-corpus fit veto a
        separately verified exact-space Semantic Capsule. No caller may commit a
        diagnostic Phase A result unless its higher-level receiver policy has already
        established the required capsule/vector coherence.
        """
        if distribution_gate_mode not in {"enforce", "diagnostic"}:
            return ValidationResult(
                False,
                "DistributionGatePolicy",
                f"ERR_DISTRIBUTION_GATE_MODE:{distribution_gate_mode}",
            )
        try:
            # 1. Parse outer binary frame
            try:
                frame = BraidFrame.from_bytes(frame_bytes)
            except Exception as e:
                return ValidationResult(False, "BinaryFramingGate", f"Frame parsing error: {str(e)}")

            manifest = frame.manifest

            # 2. Require receiver_node_id == local_node_id
            if manifest.get("receiver_node_id") != self.local_node_id:
                return ValidationResult(
                    False,
                    "RoutingAuthorizationGate",
                    f"ERR_WRONG_AUDIENCE: Node ID mismatch: envelope target '{manifest.get('receiver_node_id')}' != local '{self.local_node_id}'"
                )

            # 3. Resolve signer key and authorized route from frozen registry
            signer_id = manifest.get("signer_key_id")
            authorized_signer = self.registry.get_signer(signer_id)
            if not authorized_signer:
                return ValidationResult(False, "RoutingAuthorizationGate", f"ERR_UNKNOWN_SIGNER: Untrusted signer '{signer_id}'")

            route_id = manifest.get("route_id")
            if not authorized_signer.is_authorized_route(route_id):
                return ValidationResult(False, "RoutingAuthorizationGate", f"ERR_UNAUTHORIZED_ROUTE: Signer '{signer_id}' not authorized for route '{route_id}'")

            # 4. Verify Ed25519 signature over header-bound preimage: b"BRAID-SIG-v1.4\x00" || H || M
            pub_key = get_verification_key(authorized_signer.public_key_hex)
            try:
                pub_key.verify(frame.signature_bytes, frame.signature_preimage)
            except Exception as e:
                return ValidationResult(False, "CryptographicSignatureGate", f"ERR_BAD_SIGNATURE: Ed25519 verification failed: {str(e)}")

            # 5. Verify payload_digest
            computed_payload_digest = compute_payload_digest(frame.raw_payload)
            if manifest.get("payload_digest") != computed_payload_digest:
                return ValidationResult(False, "PayloadIntegrityGate", f"ERR_PAYLOAD_DIGEST: Payload digest mismatch: {manifest.get('payload_digest')} != {computed_payload_digest}")

            # 6. Require manifest artifact digests to match frozen route contract
            route_entry = self.registry.get_route(route_id)
            if not route_entry:
                return ValidationResult(False, "ArtifactBindingGate", f"ERR_UNAUTHORIZED_ROUTE: Route '{route_id}' not found in frozen registry.")

            for digest_key in [
                "source_space_digest", "target_space_digest",
                "source_extraction_adapter_digest", "source_expansion_adapter_digest",
                "target_extraction_adapter_digest", "target_expansion_adapter_digest",
                "transport_map_digest", "feature_spec_digest",
                "canonical_space_spec_digest", "quantization_spec_digest",
                "route_contract_digest"
            ]:
                if manifest.get(digest_key) != getattr(route_entry, digest_key):
                    return ValidationResult(False, "ArtifactBindingGate", f"ERR_ARTIFACT_DIGEST: Manifest {digest_key} mismatch for route '{route_id}'")

            # 7. Perform non-locking Phase A replay & temporal sanity check
            is_valid_replay, replay_msg = self.ledger.check_replay_phase_a(
                receiver_node_id=manifest["receiver_node_id"],
                signer_key_id=manifest["signer_key_id"],
                route_id=manifest["route_id"],
                session_id=manifest["session_id"],
                sequence_num=manifest["sequence_num"],
                issued_at=manifest["issued_at"],
                expires_at=manifest["expires_at"]
            )
            if not is_valid_replay:
                return ValidationResult(False, "ReplayCheckGate", replay_msg)

            # 8. Compute receiver-derived effective authority
            local_policy = self.registry.get_local_policy_for_route(route_id)
            requested_constraints = manifest.get("requested_constraints", {})
            effective_authority = resolve_effective_authority(local_policy, requested_constraints)

            # 9. Evaluate receiver-local transport map and feature spec probes
            source_vec = np.array(frame.vector, dtype=np.float64)
            transport_map = self.registry.get_transport_map(route_entry.transport_map_id)
            feature_spec = self.registry.get_feature_spec(route_entry.feature_spec_id)

            mapped_vec = transport_map.apply(source_vec)

            # Subspace residual & Mahalanobis OOD measurements. These remain hard
            # gates for ordinary/vector-only routes. A higher-level receiver may ask
            # for diagnostic mode only while it independently verifies a signed
            # exact-space Semantic Capsule against this same 384D vector.
            pca_model = self.registry.get_pca_model(route_entry.route_id)
            res = None
            subspace_passed = None
            if pca_model is not None:
                res = float(pca_model.compute_reconstruction_residual(mapped_vec))
                subspace_passed = bool(res <= route_entry.subspace_residual_ceiling)
                if not subspace_passed and distribution_gate_mode == "enforce":
                    return ValidationResult(
                        False,
                        "SubspaceResidualGate",
                        f"ERR_SUBSPACE: Residual {res:.4f} > ceiling {route_entry.subspace_residual_ceiling:.4f}",
                    )

            cov_model = self.registry.get_covariance_model(route_entry.route_id)
            ood_dist = None
            mahalanobis_passed = None
            if cov_model is not None:
                ood_dist = float(compute_regularized_mahalanobis_ood(
                    mapped_vec, cov_model.mean_vector, cov_model.covariance_matrix
                ))
                mahalanobis_passed = bool(ood_dist <= route_entry.mahalanobis_ood_ceiling)
                if not mahalanobis_passed and distribution_gate_mode == "enforce":
                    return ValidationResult(
                        False,
                        "MahalanobisOODGate",
                        f"ERR_OOD: Mahalanobis distance {ood_dist:.4f} > ceiling {route_entry.mahalanobis_ood_ceiling:.4f}",
                    )

            diagnostic_payload = {
                "frame": frame,
                "manifest": manifest,
                "object_digest": frame.object_digest,
                "effective_authority": effective_authority,
                "mapped_vector": mapped_vec.tolist(),
                "distribution_gates": {
                    "mode": distribution_gate_mode,
                    "enforced": distribution_gate_mode == "enforce",
                    "subspace_residual": res,
                    "subspace_ceiling": route_entry.subspace_residual_ceiling,
                    "subspace_within_ceiling": subspace_passed,
                    "mahalanobis_distance": ood_dist,
                    "mahalanobis_ceiling": route_entry.mahalanobis_ood_ceiling,
                    "mahalanobis_within_ceiling": mahalanobis_passed,
                    "commit_authorized": distribution_gate_mode == "enforce",
                },
            }

            message = (
                "Phase A pre-validation succeeded."
                if distribution_gate_mode == "enforce"
                else "Phase A pre-validation succeeded with route-distribution drift retained as diagnostic evidence."
            )
            return ValidationResult(True, "PhaseANonLockingValidationGate", message, diagnostic_payload)

        except Exception as e:
            return ValidationResult(False, "PhaseANonLockingValidationGate", f"Phase A execution error: {str(e)}")

    def authorize_distribution_diagnostic(
        self,
        phase_a_result: ValidationResult,
        *,
        transfer_method: str,
        capsule_digest: str,
        exact_space_coherence_verified: bool,
        exact_space_coherence_cosine: float,
        min_exact_space_cosine: float,
    ) -> ValidationResult:
        """Authorize Phase B use of a diagnostic distribution result.

        This is receiver-owned post-validation policy. It is available only for a
        signed exact-space Semantic Capsule whose local recomputation met the
        configured coherence threshold. The sender cannot set this authorization in
        the wire manifest.
        """
        if not phase_a_result.is_valid:
            return ValidationResult(
                False,
                "DistributionGateAuthorization",
                "ERR_DISTRIBUTION_DIAGNOSTIC_INVALID_PHASE_A",
            )
        payload = dict(phase_a_result.diagnostic_payload or {})
        distribution = dict(payload.get("distribution_gates") or {})
        if distribution.get("mode") != "diagnostic":
            return ValidationResult(
                False,
                "DistributionGateAuthorization",
                "ERR_DISTRIBUTION_DIAGNOSTIC_MODE_REQUIRED",
            )
        if transfer_method != "exact_space_fast_path":
            return ValidationResult(
                False,
                "DistributionGateAuthorization",
                "ERR_DISTRIBUTION_DIAGNOSTIC_EXACT_SPACE_REQUIRED",
            )
        try:
            cosine = float(exact_space_coherence_cosine)
            minimum = float(min_exact_space_cosine)
        except (TypeError, ValueError):
            return ValidationResult(
                False,
                "DistributionGateAuthorization",
                "ERR_DISTRIBUTION_DIAGNOSTIC_COHERENCE_VALUE",
            )
        if (
            not exact_space_coherence_verified
            or not math.isfinite(cosine)
            or not math.isfinite(minimum)
            or minimum <= 0.0
            or minimum > 1.0
            or cosine < minimum
        ):
            return ValidationResult(
                False,
                "DistributionGateAuthorization",
                "ERR_DISTRIBUTION_DIAGNOSTIC_COHERENCE_REQUIRED",
            )
        if (
            not isinstance(capsule_digest, str)
            or len(capsule_digest) != 64
            or any(ch not in "0123456789abcdef" for ch in capsule_digest)
        ):
            return ValidationResult(
                False,
                "DistributionGateAuthorization",
                "ERR_DISTRIBUTION_DIAGNOSTIC_CAPSULE_DIGEST",
            )

        distribution.update({
            "commit_authorized": True,
            "authorization": "receiver_verified_exact_space_capsule_vector_coherence",
            "capsule_digest": capsule_digest,
            "exact_space_coherence_cosine": cosine,
            "min_exact_space_cosine": minimum,
        })
        payload["distribution_gates"] = distribution
        return ValidationResult(
            True,
            phase_a_result.gate_name,
            phase_a_result.message,
            payload,
        )

    def commit_frame_phase_b(self, phase_a_result: ValidationResult) -> ValidationResult:
        """
        Phase B: Atomic commit validation inside BEGIN IMMEDIATE transaction.
        Revalidates expiry, sequence monotonicity, predecessor continuity, and capability revocation.
        """
        if not phase_a_result.is_valid:
            return ValidationResult(False, "PhaseBAtomicCommitGate", "Cannot commit invalid Phase A result.")

        payload = phase_a_result.diagnostic_payload
        distribution = payload.get("distribution_gates", {}) if payload else {}
        if (
            distribution.get("mode") == "diagnostic"
            and distribution.get("commit_authorized") is not True
        ):
            return ValidationResult(
                False,
                "DistributionGateAuthorization",
                "ERR_DISTRIBUTION_DIAGNOSTIC_UNAUTHORIZED",
            )
        manifest = payload["manifest"]
        frame = payload["frame"]
        vector = np.array(frame.vector, dtype=np.float32)

        # Re-check capability revocation status from local policy database
        capability_revoked = self.registry.is_capability_revoked(
            manifest.get("capability_ref"),
            manifest["receiver_node_id"]
        )

        success, commit_msg = self.ledger.commit_atomic_transaction(
            receiver_node_id=manifest["receiver_node_id"],
            signer_key_id=manifest["signer_key_id"],
            route_id=manifest["route_id"],
            session_id=manifest["session_id"],
            sequence_num=manifest["sequence_num"],
            issued_at=manifest["issued_at"],
            expires_at=manifest["expires_at"],
            predecessor_object_digest=manifest["predecessor_object_digest"],
            current_object_digest=frame.object_digest,
            object_id=manifest.get("session_id"), # Uses session/object tracking
            nonce=manifest.get("predecessor_object_digest")[:16],
            vector=vector,
            max_transition_velocity=1.5,
            capability_revoked=capability_revoked
        )

        if not success:
            return ValidationResult(False, "PhaseBAtomicCommitGate", commit_msg)

        return ValidationResult(True, "PhaseBAtomicCommitGate", "Phase B atomic commit succeeded.", payload)

    def validate_byte_integrity(self, payload_dict: Dict[str, Any]) -> ValidationResult:
        try:
            required = ["object_id", "nonce", "schema_version", "timestamp", "expiry", "signer_key_id", "algorithm_id", "audience", "signature"]
            for f in required:
                if f not in payload_dict:
                    return ValidationResult(False, "AuthenticatedEnvelopeIntegrityGate", f"Missing required envelope field: {f}")
            signer_id = payload_dict["signer_key_id"]
            signer = self.registry.get_signer(signer_id)
            if not signer:
                return ValidationResult(False, "AuthenticatedEnvelopeIntegrityGate", f"Untrusted signer: {signer_id}")
            return ValidationResult(True, "AuthenticatedEnvelopeIntegrityGate", "Envelope passes byte-integrity verification.")
        except Exception as e:
            return ValidationResult(False, "AuthenticatedEnvelopeIntegrityGate", str(e))

    def validate_representation_compatibility(self, payload_dict: Dict[str, Any]) -> ValidationResult:
        return ValidationResult(True, "RepresentationCompatibilityGate", "Coordinate vectors compatible.")

    def validate_semantic_preservation(self, payload_dict: Dict[str, Any]) -> ValidationResult:
        return ValidationResult(True, "ConfiguredTargetProbeCompatibilityGate", "Semantic preservation threshold satisfied.")
