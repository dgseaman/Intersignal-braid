"""Private storage primitives: POSIX modes or a protected Windows DACL.

On Windows, grant only this process user and SYSTEM. Fail closed if the ACL
cannot be applied; do not pretend that a POSIX mode is a Windows privacy policy.
"""
from __future__ import annotations
import os
import uuid
from pathlib import Path


def _windows_acl(handle: int | None, path: Path | None, directory: bool = False) -> None:
    import ctypes as C
    from ctypes import wintypes as W
    adv = C.WinDLL('advapi32', use_last_error=True)
    kernel = C.WinDLL('kernel32', use_last_error=True)
    kernel.GetCurrentProcess.restype = W.HANDLE
    kernel.CloseHandle.argtypes = [W.HANDLE]
    kernel.ReOpenFile.argtypes = [W.HANDLE, W.DWORD, W.DWORD, W.DWORD]
    kernel.ReOpenFile.restype = W.HANDLE
    kernel.LocalFree.argtypes = [C.c_void_p]
    kernel.LocalFree.restype = C.c_void_p
    adv.OpenProcessToken.argtypes = [W.HANDLE, W.DWORD, C.POINTER(W.HANDLE)]
    adv.GetTokenInformation.argtypes = [W.HANDLE, C.c_int, C.c_void_p, W.DWORD, C.POINTER(W.DWORD)]
    adv.ConvertSidToStringSidW.argtypes = [C.c_void_p, C.POINTER(W.LPWSTR)]
    adv.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes = [W.LPCWSTR, W.DWORD, C.POINTER(C.c_void_p), C.c_void_p]
    adv.GetSecurityDescriptorDacl.argtypes = [C.c_void_p, C.POINTER(W.BOOL), C.POINTER(C.c_void_p), C.POINTER(W.BOOL)]
    adv.SetSecurityInfo.argtypes = [W.HANDLE, C.c_int, W.DWORD, C.c_void_p, C.c_void_p, C.c_void_p, C.c_void_p]
    adv.SetSecurityInfo.restype = W.DWORD
    adv.SetNamedSecurityInfoW.argtypes = [W.LPWSTR, C.c_int, W.DWORD, C.c_void_p, C.c_void_p, C.c_void_p, C.c_void_p]
    adv.SetNamedSecurityInfoW.restype = W.DWORD
    security_handle = None
    token = W.HANDLE()
    descriptor = C.c_void_p()
    sid_string = W.LPWSTR()
    def check(ok):
        if not ok:
            raise C.WinError(C.get_last_error())
    check(adv.OpenProcessToken(kernel.GetCurrentProcess(), 0x0008, C.byref(token)))
    try:
        length = W.DWORD()
        adv.GetTokenInformation(token, 1, None, 0, C.byref(length))
        if not length.value:
            raise C.WinError(C.get_last_error())
        buf = C.create_string_buffer(length.value)
        check(adv.GetTokenInformation(token, 1, buf, length, C.byref(length)))
        sid = C.cast(buf, C.POINTER(C.c_void_p))[0]
        check(adv.ConvertSidToStringSidW(sid, C.byref(sid_string)))
        flags = 'OICI' if directory else ''
        sddl = f'D:P(A;{flags};FA;;;{sid_string.value})(A;{flags};FA;;;SY)'
        check(adv.ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl, 1, C.byref(descriptor), None))
        present, defaulted, dacl = W.BOOL(), W.BOOL(), C.c_void_p()
        check(adv.GetSecurityDescriptorDacl(descriptor, C.byref(present), C.byref(dacl), C.byref(defaulted)))
        if not present or not dacl.value:
            raise OSError('Refusing an empty private-file DACL')
        info = 0x00000004 | 0x80000000  # DACL + protected from parent inheritance
        if handle is not None:
            # CRT data handles need not carry WRITE_DAC. Reopen the SAME object
            # for ACL access rather than a race-prone pathname lookup.
            security_handle = kernel.ReOpenFile(W.HANDLE(handle), 0x00040000 | 0x00020000, 7, 0)
            if security_handle == W.HANDLE(-1).value:
                security_handle = None
                raise C.WinError(C.get_last_error())
        status = (adv.SetSecurityInfo(W.HANDLE(security_handle), 1, info, None, None, dacl, None)
                  if handle is not None else adv.SetNamedSecurityInfoW(str(path), 1, info, None, None, dacl, None))
        if status:
            raise C.WinError(status)
    finally:
        if security_handle is not None: kernel.CloseHandle(security_handle)
        if descriptor.value: kernel.LocalFree(descriptor)
        if sid_string: kernel.LocalFree(C.cast(sid_string, C.c_void_p))
        kernel.CloseHandle(token)


def secure_fd(fd: int, mode: int = 0o600) -> None:
    """Called BEFORE writing private bytes. Closes fd on failure."""
    try:
        if os.name == 'nt':
            import msvcrt
            _windows_acl(msvcrt.get_osfhandle(fd), None)
        else:
            os.fchmod(fd, mode)
    except Exception:
        os.close(fd)
        raise


def secure_path(path: Path, *, directory: bool = False) -> None:
    path = Path(path)
    if path.is_symlink():
        raise ValueError('Private storage cannot be a symlink: ' + str(path))
    if os.name == 'nt':
        _windows_acl(None, path, directory)
    else:
        path.chmod(0o700 if directory else 0o600)


def private_dir(path: Path) -> None:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    secure_path(path, directory=True)


def atomic_private_write(path: Path, data: bytes) -> None:
    path = Path(path)
    private_dir(path.parent)
    tmp = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        secure_fd(fd)
        with os.fdopen(fd, 'wb') as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)
