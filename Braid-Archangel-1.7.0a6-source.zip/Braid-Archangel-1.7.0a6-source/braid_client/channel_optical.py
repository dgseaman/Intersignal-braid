"""A self-contained, offline QR reel for one already committed signed note.

Rendering a reel is not a delivery receipt. Payload is public to a camera that
can see the display; receiver signatures/subscriptions still gate acceptance.
"""
import base64
import hashlib
import html
import json
from .qr_engine import chunk_binary_frame, StandardQRCodeEncoder


def make_reel(raw: bytes, channel_name: str, note_id: str) -> dict:
    if not isinstance(raw,bytes) or not 0<len(raw)<=130000:
        raise ValueError('Invalid signed note size for optical export.')
    chunks=chunk_binary_frame(raw,max_chunk_size=120)
    if len(chunks)>2048: raise ValueError('This note exceeds the bounded reel size.')
    frames=[]
    for chunk in chunks:
        matrix=StandardQRCodeEncoder(chunk['chunk_str']).matrix
        frames.append([''.join(str(int(v)) for v in row) for row in matrix])
    packed=base64.b64encode(json.dumps(frames,separators=(',',':')).encode()).decode()
    digest=hashlib.sha256(raw).hexdigest()
    document='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'">
<title>Braid Archangel - signed note reel</title><style>body{margin:0;background:#111820;color:#e4f0f4;font:15px system-ui,sans-serif;text-align:center;padding:22px}h1{font-size:24px}p{max-width:680px;margin:14px auto;line-height:1.6}button,select{padding:12px;margin:5px;font:inherit}#qr{width:min(68vh,90vw);margin:18px auto;background:white}svg{display:block;width:100%;height:auto;shape-rendering:crispEdges}code{overflow-wrap:anywhere;font-size:12px}small{display:block;margin:10px}</style>
<h1>#'''+html.escape(channel_name)+''' - signed note</h1><p>This file stays offline. Anyone who can scan the display can read its signed payload. On the receiving a6 rig, approve the publisher and channel, then open Advanced workspace &gt; Receive by camera.</p>
<div id="qr" role="img" aria-label="Signed note QR chunk"></div><p id="status" aria-live="polite"></p><button id="prev">Previous</button><button id="toggle">Start reel</button><button id="next">Next</button><label>Interval <select id="delay"><option value="620">620 ms</option><option value="1000" selected>1 second</option><option value="2000">2 seconds</option></select></label>
<p>Inspect the receiver's acceptance and indexing receipt. Displaying all chunks does not prove delivery.</p><small>Signed frame SHA-256<br><code>'''+digest+'''</code></small><script>
const frames=JSON.parse(atob("'''+packed+'''"));let index=0,timer=null;
function show(){const rows=frames[index],size=rows.length+8;let path='';rows.forEach((row,y)=>{for(let x=0;x<row.length;x++){if(row[x]==='1')path+='M'+(x+4)+' '+(y+4)+'h1v1h-1z';}});document.getElementById('qr').innerHTML='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+size+' '+size+'"><rect width="100%" height="100%" fill="white"/><path d="'+path+'" fill="black"/></svg>';document.getElementById('status').textContent='Chunk '+(index+1)+' of '+frames.length+(timer?' - repeating':' - paused');}
function stop(){if(timer)clearInterval(timer);timer=null;document.getElementById('toggle').textContent='Start reel';show();}
document.getElementById('toggle').onclick=()=>{if(timer)return stop();timer=setInterval(()=>{index=(index+1)%frames.length;show();},Number(document.getElementById('delay').value));document.getElementById('toggle').textContent='Pause reel';show();};
document.getElementById('prev').onclick=()=>{stop();index=(index+frames.length-1)%frames.length;show();};document.getElementById('next').onclick=()=>{stop();index=(index+1)%frames.length;show();};document.getElementById('delay').onchange=stop;document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});show();
</script></html>'''
    return {'name':'channel-note-'+note_id[:12]+'-reel.html','html':document,'chunk_count':len(chunks),
            'transport_sha256':digest,'warning':'Offline display file contains the signed payload. Optical rendering is not acceptance.'}
