"""Receiver-owned channel policy, durable notes, and deliberate publication.

No inference output, received note, or topic match grants transmission authority.
The only automatic source in a6 is a newly typed /note in an opted-in channel
conversation. Everything else is a reviewable local suggestion.
"""
from __future__ import annotations
import base64
import hashlib
import json
import re
import time
import uuid
from pathlib import Path
from typing import Any
from .channel_protocol import (canonical, label, create_channel_descriptor,
    validate_channel_descriptor, note_extension, extract_channel_note, HEX64, HEX32)
from .context_workflow import validate_context_text
from .mcp_core.protocol import BraidFrame
from .semantic_capsule import extract_semantic_capsule
from .private_files import private_dir, atomic_private_write

MAX_CHANNELS = 64
MAX_NOTES = 10000
MODES = ('manual', 'suggest', 'automatic_marked')


class ChannelMixin:
    def _init_channels(self):
        with self._db() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS c6_channels(id TEXT PRIMARY KEY, revision INTEGER NOT NULL,
                    descriptor TEXT NOT NULL, policy TEXT NOT NULL, created REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS c6_notes(id TEXT PRIMARY KEY, channel TEXT NOT NULL,
                    text TEXT NOT NULL, title TEXT NOT NULL, origin TEXT NOT NULL, state TEXT NOT NULL,
                    created REAL NOT NULL, payload TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS c6_notes_channel ON c6_notes(channel, created);
                CREATE TABLE IF NOT EXISTS c6_objects(object_digest TEXT PRIMARY KEY, channel TEXT NOT NULL,
                    note_id TEXT NOT NULL, publisher TEXT NOT NULL, local INTEGER NOT NULL,
                    created REAL NOT NULL, extension TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS c6_objects_channel ON c6_objects(channel);
                CREATE TABLE IF NOT EXISTS c6_receipts(publisher TEXT NOT NULL, note_id TEXT NOT NULL,
                    object_digest TEXT NOT NULL, PRIMARY KEY(publisher,note_id));
                CREATE TABLE IF NOT EXISTS c6_threads(id TEXT PRIMARY KEY, channel TEXT NOT NULL,
                    title TEXT NOT NULL, created REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS c6_turns(id TEXT PRIMARY KEY, thread TEXT NOT NULL,
                    question TEXT NOT NULL, state TEXT NOT NULL, created REAL NOT NULL, payload TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS c6_turns_thread ON c6_turns(thread, created);
                CREATE TABLE IF NOT EXISTS c6_activity(id INTEGER PRIMARY KEY AUTOINCREMENT, channel TEXT NOT NULL,
                    kind TEXT NOT NULL, created REAL NOT NULL, detail TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS c6_auto_events(note_id TEXT PRIMARY KEY, channel TEXT NOT NULL, created REAL NOT NULL);
            ''')
            db.execute("UPDATE c6_notes SET state='attention' WHERE state='sending'")
            db.execute("UPDATE c6_turns SET state='interrupted' WHERE state='running'")

    def _channel_activity(self, channel: str, kind: str, detail: dict):
        with self._db() as db:
            db.execute('INSERT INTO c6_activity(channel,kind,created,detail) VALUES (?,?,?,?)',
                       (channel, kind, time.time(), canonical(detail).decode()))

    def channel(self, ident: str) -> dict:
        with self._db() as db:
            row = db.execute('SELECT * FROM c6_channels WHERE id=?', (ident,)).fetchone()
        if row is None:
            raise ValueError('Unknown channel. Import its signed channel card and choose local permissions first.')
        return {**dict(row), 'descriptor': json.loads(row['descriptor']), 'policy': json.loads(row['policy'])}

    def channel_list(self) -> list[dict]:
        with self._db() as db:
            rows = db.execute('SELECT * FROM c6_channels ORDER BY created').fetchall()
            counts = {r[0]: r[1] for r in db.execute('SELECT channel, COUNT(*) FROM c6_objects GROUP BY channel')}
            drafts = {r[0]: r[1] for r in db.execute("SELECT channel,COUNT(*) FROM c6_notes WHERE state='draft' GROUP BY channel")}
        return [{**dict(r),'descriptor':json.loads(r['descriptor']),'policy':json.loads(r['policy']),
                 'object_count': counts.get(r['id'],0),'draft_count':drafts.get(r['id'],0)} for r in rows]

    def create_channel(self, name: str, description: str = '') -> dict:
        descriptor = create_channel_descriptor(self.key, name, description)
        return self.import_channel(descriptor, confirmed=True, own=True)

    def import_channel(self, descriptor: Any, *, confirmed: bool = False, own: bool = False) -> dict:
        d = validate_channel_descriptor(descriptor)
        if confirmed is not True:
            return {'review':True,'descriptor':d,'creator_fingerprint':hashlib.sha256(bytes.fromhex(d['creator_key'])).hexdigest(),
                    'warning':'A signed channel card identifies a topic, not who may send or use it. Compare its ID with the other rig.'}
        # Creating/importing never chooses remote recipients, publishers or automatic mode.
        policy = dict(send_to=[],receive_from=[],use_in_chat=False,mode='manual',keywords=[],
                      paused=False,archived=False,hourly_limit=6)
        with self.lock, self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            prior = db.execute('SELECT descriptor FROM c6_channels WHERE id=?',(d['id'],)).fetchone()
            if prior:
                if json.loads(prior[0]) != d:
                    raise ValueError('Channel identity already exists with another descriptor. No policy was changed.')
            else:
                if db.execute('SELECT COUNT(*) FROM c6_channels').fetchone()[0] >= MAX_CHANNELS:
                    raise ValueError('Channel limit reached. This compact release permits 64 retained channels.')
                db.execute('INSERT INTO c6_channels VALUES (?,?,?,?,?)',(d['id'],1,canonical(d).decode(),canonical(policy).decode(),time.time()))
        self._channel_activity(d['id'],'created' if own else 'imported',{'permissions_granted':False})
        return self.channel(d['id'])

    def update_channel(self, ident: str, changes: dict, revision: int, *, authorize_automatic: bool = False) -> dict:
        allowed = {'send_to','receive_from','use_in_chat','mode','keywords','paused','archived','hourly_limit'}
        if not isinstance(changes,dict) or set(changes)-allowed:
            raise ValueError('Unknown channel policy field.')
        with self.lock, self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT * FROM c6_channels WHERE id=?',(ident,)).fetchone()
            if not row or type(revision) is not int or row['revision'] != revision:
                raise ValueError('Channel settings changed. Refresh before saving; nothing was overwritten.')
            old = json.loads(row['policy']); p = {**old,**changes}
            contacts = {c['id'] for c in self.contacts()}
            for field in ('send_to','receive_from'):
                if not isinstance(p[field],list) or len(p[field])>16 or not all(isinstance(x,str) and x in contacts for x in p[field]):
                    raise ValueError('Channel members must be currently approved rigs. Relay enrollment is separate.')
                p[field] = sorted(set(p[field]))
            for field in ('use_in_chat','paused','archived'):
                if type(p[field]) is not bool: raise ValueError('Channel switches must be boolean.')
            if p['mode'] not in MODES: raise ValueError('Unknown channel sharing mode.')
            if type(p['hourly_limit']) is not int or not 1 <= p['hourly_limit'] <= 12:
                raise ValueError('Choose 1 to 12 automatic notes per hour.')
            if not isinstance(p['keywords'],list) or len(p['keywords'])>12:
                raise ValueError('Choose at most 12 topic phrases.')
            p['keywords'] = sorted(set(label(x,64).lower() for x in p['keywords']))
            automation_expands = (old['mode']!='automatic_marked' or old['paused'] or old['archived']
                or bool(set(p['send_to'])-set(old['send_to'])) or p['hourly_limit']>old['hourly_limit'])
            if p['mode']=='automatic_marked' and not p['paused'] and not p['archived'] and automation_expands and authorize_automatic is not True:
                raise ValueError('Explicit authorization required: only new /note messages in an opted-in channel chat may auto-share.')
            if p['mode']=='automatic_marked' and not p['paused'] and not p['archived'] and not p['send_to']:
                raise ValueError('Choose at least one approved destination before authorizing automatic notes.')
            db.execute('UPDATE c6_channels SET revision=?,policy=? WHERE id=?',(revision+1,canonical(p).decode(),ident))
        self._channel_activity(ident,'policy_changed',{'revision':revision+1,'policy':p})
        return self.channel(ident)

    def channel_view(self, ident: str) -> dict:
        ch = self.channel(ident)
        with self._db() as db:
            notes = [dict(r,payload=json.loads(r['payload'])) for r in db.execute('SELECT * FROM c6_notes WHERE channel=? ORDER BY created DESC LIMIT 100',(ident,))]
            objects = [dict(r,extension=json.loads(r['extension'])) for r in db.execute('SELECT * FROM c6_objects WHERE channel=? ORDER BY created DESC LIMIT 100',(ident,))]
            activity = [dict(r,detail=json.loads(r['detail'])) for r in db.execute('SELECT * FROM c6_activity WHERE channel=? ORDER BY id DESC LIMIT 100',(ident,))]
            threads = [dict(r) for r in db.execute('SELECT * FROM c6_threads WHERE channel=? ORDER BY created DESC LIMIT 100',(ident,))]
        from .semantic_field import load_semantic_field_bundle
        for obj in objects:
            try:
                bundle = load_semantic_field_bundle(storage_dir=self.inbox, object_digest=obj['object_digest'])
                obj.update(indexed=True, text='\n'.join(a['text'] for a in bundle.atoms))
            except Exception as exc:
                obj.update(indexed=False, index_error=str(exc)[:200])
        return dict(channel=ch,notes=notes,objects=objects,activity=activity,threads=threads)

    def new_note(self, channel: str, text: str, title: str = '', *, note_id: str = '', origin: str = 'reviewed_note') -> dict:
        ch = self.channel(channel)
        if ch['policy']['archived']: raise ValueError('This channel is archived. Restore it before adding notes.')
        text = validate_context_text(text,field='channel note')
        title = label(title or 'Channel note',80)
        note_id = note_id or uuid.uuid4().hex
        if not HEX32.fullmatch(note_id): raise ValueError('Invalid note identity.')
        extension = note_extension(ch['descriptor'],note_id,text,origin)
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT * FROM c6_notes WHERE id=?',(note_id,)).fetchone()
            if old:
                if old['channel'] != channel or old['text'] != text or old['origin'] != origin or old['title'] != title:
                    raise ValueError('A note identity cannot be reused with different content.')
            else:
                if db.execute('SELECT COUNT(*) FROM c6_notes').fetchone()[0] >= MAX_NOTES:
                    raise ValueError('Retained note limit reached. Nothing was sent.')
                db.execute('INSERT INTO c6_notes VALUES (?,?,?,?,?,?,?,?)',(note_id,channel,text,title,origin,'draft',time.time(),canonical({'extension':extension}).decode()))
        return self.get_note(note_id)

    def get_note(self, ident: str) -> dict:
        with self._db() as db:
            row = db.execute('SELECT * FROM c6_notes WHERE id=?',(ident,)).fetchone()
        if row is None: raise ValueError('Note not found.')
        return dict(row,payload=json.loads(row['payload']))

    def _save_note_result(self, ident: str, state: str, payload: dict):
        with self._db() as db:
            db.execute('UPDATE c6_notes SET state=?,payload=? WHERE id=?',(state,canonical(payload).decode(),ident))

    def discard_note(self, ident: str):
        with self._db() as db:
            db.execute("UPDATE c6_notes SET state='discarded' WHERE id=? AND state='draft'",(ident,))
        return self.get_note(ident)

    def _channel_frame_policy(self, frame: BraidFrame, publisher: str) -> dict | None:
        capsule,_ = extract_semantic_capsule(frame.manifest)
        if not capsule: return None
        extension = extract_channel_note(frame.manifest,capsule.get('content',''))
        if extension is None: return None
        ch = self.channel(extension['channel']['id'])
        if ch['descriptor'] != extension['channel']: raise ValueError('ERR_CHANNEL_DESCRIPTOR_MISMATCH')
        if ch['policy']['archived'] or publisher not in ch['policy']['receive_from']:
            raise ValueError('ERR_CHANNEL_PUBLISHER_NOT_SUBSCRIBED')
        with self._db() as db:
            duplicate = db.execute('SELECT object_digest FROM c6_receipts WHERE publisher=? AND note_id=?',(publisher,extension['note_id'])).fetchone()
        if duplicate: raise ValueError('ERR_CHANNEL_NOTE_ALREADY_RECORDED')
        return extension

    def record_channel_object(self, report: dict, frame: BraidFrame, publisher: str = '', *, local: bool = False):
        if report.get('phase_b_committed') is not True: return
        capsule,_ = extract_semantic_capsule(frame.manifest)
        if not capsule: return
        ext = extract_channel_note(frame.manifest,capsule.get('content',''))
        if ext is None: return
        # Reconciliation imports must not create a mapping based only on a JSON receipt.
        candidates = [(self.fingerprint,self.key.public_key())]
        candidates += [(c['id'], self.receivers[c['id']][0]) for c in self.contacts() if c['id'] in self.receivers]
        verified = None
        for ident, public in candidates:
            if publisher and ident != publisher: continue
            try: public.verify(frame.signature_bytes,frame.signature_preimage); verified=ident; break
            except Exception: continue
        if verified is None: return
        try: ch = self.channel(ext['channel']['id'])
        except ValueError: return
        if ch['descriptor'] != ext['channel']: return
        with self._db() as db:
            db.execute('INSERT OR IGNORE INTO c6_objects VALUES (?,?,?,?,?,?,?)',
                (frame.object_digest,ch['id'],ext['note_id'],verified,int(verified==self.fingerprint),time.time(),canonical(ext).decode()))
            db.execute('INSERT OR IGNORE INTO c6_receipts VALUES (?,?,?)',(verified,ext['note_id'],frame.object_digest))

    def _local_channel_commit(self, note: dict) -> dict:
        # Same signed capsule/route/Phase B pipeline as receiving, with own key.
        from . import messenger as core
        raw_path = self.home/'channel-outbox'/(note['id']+'.brad')
        private_dir(raw_path.parent)
        if raw_path.exists():
            frame = BraidFrame.from_bytes(raw_path.read_bytes())
            capsule,_ = extract_semantic_capsule(frame.manifest)
            if capsule.get('content') != note['text'] or extract_channel_note(frame.manifest,note['text']) != note['payload']['extension']:
                raise ValueError('Stored note frame differs from reviewed content.')
            with self._db() as db:
                prior = db.execute('SELECT object_digest FROM c6_receipts WHERE publisher=? AND note_id=?',(self.fingerprint,note['id'])).fetchone()
            if prior:
                previous=note['payload'].get('local_receipt',{})
                if previous.get('transport_sha256')!=hashlib.sha256(raw_path.read_bytes()).hexdigest():
                    raise ValueError('A prior local commit exists but its exact transport receipt is unavailable or changed. Inspect the retained receipt; nothing was resent.')
                return {**previous,'phase_b_committed':True,'object_digest':prior[0],'previously_committed':True}
        else:
            root=Path(self.settings.get('route_path') or self.home/'missing-route')
            frame,raw,_,_ = core.build_frame_from_text(root,note['text'],self.key,channel_note_extension=note['payload']['extension'])
            atomic_private_write(raw_path,raw)
        own = {'public_key':self.public_key,'route_path':self.settings['route_path']}
        _,receiver=self._receiver_for(own)
        with self.receive_lock:
            report=receiver.process_bytes(raw_path.read_bytes(),source_transport='local-channel')
            if report.get('phase_b_committed') is not True:
                raise ValueError('Local channel note was not committed: '+str(report.get('reason') or report.get('error') or report.get('result_summary')))
            self.record_channel_object(report,frame,self.fingerprint,local=True)
        return report

    def publish_note(self, ident: str, *, confirmed: bool = False, automatic: bool = False) -> dict:
        from . import messenger as core
        with self.lock:
            note=self.get_note(ident);ch=self.channel(note['channel']);policy=ch['policy']
            if note['state'] not in ('draft','attention'):
                return {**note,'already_recorded':True}
            if self.closed or policy['paused'] or policy['archived']:
                raise ValueError('Channel sharing is paused or the client is closing. Nothing new was sent.')
            if automatic:
                if note['origin']!='marked_local_note' or policy['mode']!='automatic_marked':
                    raise ValueError('This source is not authorized for automatic sharing.')
            elif confirmed is not True:
                raise ValueError('Review the exact note and confirm sharing first.')
            old_payload=note['payload']
            recipients=old_payload.get('recipients',list(policy['send_to']))
            if any(peer not in policy['send_to'] for peer in recipients):
                raise ValueError('Destination permission changed. This frozen handoff will not add or replace recipients.')
            contact_map={c['id']:c for c in self.contacts()}
            if any(peer not in contact_map or 'channels.v1' not in contact_map[peer].get('capabilities',[]) for peer in recipients):
                raise ValueError('Refresh each destination with an a6 rig card before channel sharing. No legacy downgrade.')
            if automatic:
                with self._db() as db:
                    db.execute('BEGIN IMMEDIATE')
                    if db.execute('SELECT 1 FROM c6_auto_events WHERE note_id=?',(ident,)).fetchone():
                        return {**note,'automatic_replay_blocked':True}
                    rows=db.execute('SELECT created FROM c6_auto_events WHERE channel=? AND created>?',(ch['id'],time.time()-3600)).fetchall()
                    if len(rows)>=policy['hourly_limit'] or any(time.time()-r[0]<5 for r in rows):
                        raise ValueError('Automatic note limit reached. The note remains a local draft for review.')
                    db.execute('INSERT INTO c6_auto_events VALUES (?,?,?)',(ident,ch['id'],time.time()))
            payload={**old_payload,'recipients':recipients,'policy_revision':ch['revision'],'automatic':automatic}
            self._save_note_result(ident,'sending',payload)
        try:
            payload['local_receipt']=self._local_channel_commit({**note,'payload':payload})
            self._save_note_result(ident,'sending',payload)
            outcomes=[]
            for peer in recipients:
                # Permission is rechecked before every new recipient. A pause takes
                # effect at this boundary; an already-started network call may finish.
                current=self.channel(ch['id'])['policy']
                if current['paused'] or current['archived'] or peer not in current['send_to'] or self.closed:
                    outcomes.append({'peer':peer,'stage':'blocked','error':'Channel policy changed before this destination.'});continue
                result=self.send(peer,note['text'],note['title'],handoff_id=ident,channel_note=payload['extension'])
                outcomes.append({'peer':peer,**result})
            payload['outcomes']=outcomes
            state='shared' if all(o['stage'] in ('indexed','accepted') for o in outcomes) else 'attention'
            if not recipients: state='local'
            self._save_note_result(ident,state,payload)
            self._channel_activity(ch['id'],'note_'+state,{'note_id':ident,'automatic':automatic,'outcomes':outcomes})
        except Exception as exc:
            payload['error']=str(exc)[:500]
            self._save_note_result(ident,'attention',payload)
            self._channel_activity(ch['id'],'note_attention',{'note_id':ident,'error':str(exc)[:500]})
            raise
        return self.get_note(ident)

    def export_note_frame(self, ident: str) -> dict:
        note=self.get_note(ident)
        if note['state'] in ('draft','discarded'):
            raise ValueError('Review and record the note before exporting its signed frame.')
        path=self.home/'channel-outbox'/(note['id']+'.brad')
        if not path.is_file() or note['payload'].get('local_receipt', {}).get('phase_b_committed') is not True:
            raise ValueError('No committed local note frame to export.')
        raw=path.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=note['payload']['local_receipt'].get('transport_sha256'):
            raise ValueError('Stored export bytes differ from the committed transport receipt.')
        frame=BraidFrame.from_bytes(raw)
        self.key.public_key().verify(frame.signature_bytes,frame.signature_preimage)
        capsule,_=extract_semantic_capsule(frame.manifest)
        if frame.object_digest!=note['payload']['local_receipt'].get('object_digest') or capsule.get('content')!=note['text'] or extract_channel_note(frame.manifest,note['text'])!=note['payload']['extension']:
            raise ValueError('Stored export does not match the committed note. Nothing was exported.')
        return {'name':'channel-note-'+ident[:12]+'.brad','frame_base64':base64.b64encode(raw).decode(),
                'warning':'Same signed payload for file or optical transfer; export is not a delivery receipt.'}

    def import_note_frame(self, encoded: str) -> dict:
        if not isinstance(encoded,str) or len(encoded)>180000: raise ValueError('Signed frame is too large.')
        raw=base64.b64decode(encoded,validate=True)
        return self.receive(raw,source_transport='channel-file')

    def channel_scope(self, ident: str, use_shared: bool) -> tuple[set[str],dict]:
        ch=self.channel(ident)
        if type(use_shared) is not bool: raise ValueError('use_shared must be boolean.')
        p=ch['policy'];contacts={c['id']:c for c in self.contacts()}
        snapshot={'channel':ident,'revision':ch['revision'],'use_shared':use_shared,
                  'use_in_chat':p['use_in_chat'],'archived':p['archived'],
                  'approved_publishers':sorted(set(contacts)&set(p['receive_from']))}
        if not use_shared or not p['use_in_chat'] or p['archived']: return set(),snapshot
        with self._db() as db:
            rows=db.execute('SELECT object_digest,publisher,local FROM c6_objects WHERE channel=?',(ident,)).fetchall()
        allowed={r['object_digest'] for r in rows if r['local'] or r['publisher'] in snapshot['approved_publishers']}
        return allowed,snapshot

    def source_labels(self, ident: str, objects: set[str]) -> dict:
        ch=self.channel(ident);contacts={c['id']:c['name'] for c in self.contacts()}
        with self._db() as db:
            rows=db.execute('SELECT object_digest,publisher,local,created,note_id FROM c6_objects WHERE channel=?',(ident,)).fetchall()
        return {r['object_digest']:{'channel':ch['descriptor']['name'],'channel_id':ident,
                'rig':self.settings['name'] if r['local'] else contacts.get(r['publisher'],'Previously approved rig'),
                'publisher':r['publisher'],'received_at':r['created'],'note_id':r['note_id']} for r in rows if r['object_digest'] in objects}

    def channel_action(self, action: str, data: dict):
        if action=='list': return self.channel_list()
        if action=='create': return self.create_channel(data.get('name'),data.get('description',''))
        if action=='import': return self.import_channel(data.get('descriptor'),confirmed=data.get('confirmed') is True)
        if action=='export': return self.channel(str(data.get('id','')))['descriptor']
        if action=='update': return self.update_channel(str(data.get('id','')),data.get('policy',{}),data.get('revision'),authorize_automatic=data.get('authorize_automatic') is True)
        if action=='view': return self.channel_view(str(data.get('id','')))
        if action=='note': return self.new_note(str(data.get('channel','')),data.get('text'),data.get('title',''),note_id=str(data.get('note_id') or ''))
        if action=='publish': return self.publish_note(str(data.get('note_id','')),confirmed=data.get('confirmed') is True)
        if action=='discard': return self.discard_note(str(data.get('note_id','')))
        if action=='export-frame': return self.export_note_frame(str(data.get('note_id','')))
        if action=='export-reel':
            from .channel_optical import make_reel
            note=self.get_note(str(data.get('note_id','')))
            frame=self.export_note_frame(note['id'])
            return make_reel(base64.b64decode(frame['frame_base64']),self.channel(note['channel'])['descriptor']['name'],note['id'])
        if action=='import-frame': return self.import_note_frame(data.get('frame_base64'))
        if action=='reconcile':
            from .semantic_field import reconcile_semantic_field
            ids,_=self.channel_scope(str(data.get('id','')),True)
            return reconcile_semantic_field(storage_dir=self.inbox,embedding_model=self.settings['embed_model'],include_object_digests=ids)
        raise ValueError('Unknown channel action.')
