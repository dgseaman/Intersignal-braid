"""Loopback-only desktop HTTP facade. No network authority is granted by the UI."""
from __future__ import annotations
import json
import secrets
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from . import __version__
from .messenger import MessengerService, MAX_CARD_BYTES, private_write
from .server import HardenedBraidHTTPHandler
from .context_workflow import summarize_context, list_approved_peers

STATIC = Path(__file__).parent / 'static'


class MessengerHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class MessengerHandler(HardenedBraidHTTPHandler):
    @property
    def desk(self) -> MessengerService:
        return self.server.messenger

    def _same_origin(self):
        if not self._enforce_local_browser_context():
            return False
        origin = self.headers.get('Origin')
        if origin and origin != 'http://' + self.headers.get('Host', ''):
            self._json({'error':'ERR_SAME_ORIGIN_REQUIRED'}, 403)
            return False
        if self.headers.get('Sec-Fetch-Site') == 'cross-site':
            self._json({'error':'ERR_CROSS_SITE_REQUEST'}, 403)
            return False
        return True

    def _json(self, value, code=200):
        payload = json.dumps(value, ensure_ascii=True, allow_nan=False).encode()
        self._set_security_headers('application/json; charset=utf-8', code)
        try:
            self.wfile.write(payload)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _get_receiver_automation(self):
        handler = self
        desk = self.desk
        class ChannelIntake:
            def __getattr__(self, name):
                return getattr(super(MessengerHandler, handler)._get_receiver_automation(), name)
            def process_bytes(self, payload, **source):
                from .mcp_core.protocol import BraidFrame
                frame = BraidFrame.from_bytes(payload)
                if "braid_channel_note" in (frame.manifest.get("extensions") or {}):
                    return desk.receive(payload, **source)
                return super(MessengerHandler, handler)._get_receiver_automation().process_bytes(payload, **source)
        return ChannelIntake()

    def do_GET(self):
        path = urlparse(self.path).path
        if not self._same_origin():
            return
        try:
            static = {'/':'messenger.html', '/index.html':'messenger.html',
                '/static/messenger.css':'messenger.css', '/static/messenger.js':'messenger.js',
                '/static/channels.js':'channels.js', '/static/channels.css':'channels.css'}
            if path in static:
                name = static[path]
                content = (STATIC / name).read_text('utf-8').replace('__BRAID_VERSION__', __version__)
                mime = 'text/html' if name.endswith('.html') else ('text/css' if name.endswith('.css') else 'application/javascript')
                self._set_security_headers(mime + '; charset=utf-8')
                self.wfile.write(content.encode())
            elif path == '/api/messenger/state':
                self._json(self.desk.snapshot())
            elif path == '/api/messenger/job':
                self._json(self.desk.job(parse_qs(urlparse(self.path).query).get('id',[''])[0]))
            elif path == '/api/messenger/card':
                self._json(self.desk.export_card())
            elif path == '/favicon.ico':
                self._set_security_headers('image/x-icon', 204)
            elif path == '/advanced':
                self.path = '/'
                super().do_GET()
            else:
                super().do_GET()
        except Exception as exc:
            self._json({'error':exc.__class__.__name__, 'message':str(exc)[:600]}, 400)

    def do_POST(self):
        path = urlparse(self.path).path
        if not path.startswith('/api/messenger/'):
            return super().do_POST()
        if not self._same_origin():
            return
        if not secrets.compare_digest(self.headers.get('X-Braid-CSRF',''), self.desk.csrf):
            self._json({'error':'ERR_SESSION_TOKEN_REQUIRED', 'message':'Reload Braid to refresh this local session.'}, 403)
            return
        try:
            length = int(self.headers.get('Content-Length','-1'))
            maximum = MAX_CARD_BYTES if path == '/api/messenger/inspect-card' else 102400
            if length < 0 or length > maximum:
                self._json({'error':'ERR_BODY_LIMIT'}, 413)
                return
            if self.headers.get_content_type() != 'application/json':
                self._json({'error':'ERR_JSON_REQUIRED'}, 415)
                return
            data = json.loads(self.rfile.read(length), parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))
            if not isinstance(data, dict):
                raise ValueError('JSON object required.')
            service = self.desk
            if path == '/api/messenger/shutdown':
                service.closed = True
                private_write(service.home/'shutdown-requested.json', b'{"requested":true}')
                result = {'shutting_down':True, 'message':'Receiving will stop; unfinished sends remain unconfirmed, never auto-retried.'}
                threading.Thread(target=self.server.shutdown, daemon=True).start()
            elif service.closed:
                raise ValueError('Archangel is shutting down. No new operation accepted.')
            elif path == '/api/messenger/address':
                result = service.update_address(str(data.get('host','')))
            elif path == '/api/messenger/settings':
                result = service.save_settings(data)
            elif path == '/api/messenger/prepare':
                result = service.submit('Preparing local route', service.prepare)
            elif path == '/api/messenger/inspect-card':
                result = service.submit('Checking rig card', lambda: service.inspect_card(data.get('card')))
            elif path == '/api/messenger/approve-card':
                result = service.approve_card(str(data.get('inspection_id','')), str(data.get('fingerprint','')), data.get('confirmed'))
            elif path == '/api/messenger/remove-peer':
                result = service.remove_contact(str(data.get('peer','')))
            elif path == '/api/messenger/listen':
                result = service.start_listener() if data.get('enabled') is True else service.stop_listener()
            elif path == '/api/messenger/summary':
                result = service.submit('Summarizing locally', lambda: summarize_context(data.get('text'),
                    completion_model=service.settings.get('completion_model') or None))
            elif path == '/api/messenger/send':
                if not data.get('handoff_id'):
                    raise ValueError('A durable handoff identity is required. Reload Archangel before sending.')
                result = service.submit('Sharing state', lambda: service.send(str(data.get('peer','')),
                    data.get('text'), str(data.get('title') or 'Shared summary'), str(data.get('kind') or 'summary'), str(data.get('object_digest') or ''), str(data.get('handoff_id') or '')))
            elif path == '/api/messenger/message':
                result = service.message_action(str(data.get('id','')), str(data.get('action','')))
            elif path == '/api/messenger/draft':
                draft = data.get('draft')
                if draft is not None and (not isinstance(draft, dict) or len(json.dumps(draft).encode()) > 50000):
                    raise ValueError('Draft is too large.')
                service.set_value('draft', draft)
                result = {'saved':True}
            elif path == '/api/messenger/probe':
                result = service.submit('Checking approved rigs', service.probe)
            elif path == '/api/messenger/models':
                result = service.submit('Finding local models', service.models)
            elif path == '/api/messenger/relay':
                result = service.submit('Checking Managed Relay', lambda: list_approved_peers(probe=True))
            elif path == '/api/messenger/channel':
                action = str(data.get('action','list'))
                if action in ('publish','import-frame','export-reel','reconcile'):
                    result = service.submit('Channel: ' + action, lambda: service.channel_action(action, data))
                else:
                    result = service.channel_action(action, data)
            elif path == '/api/messenger/chat':
                action = str(data.get('action','view'))
                result = service.submit('Chat: thinking locally', lambda: service.chat_action(action, data)) if action == 'turn' else service.chat_action(action, data)
            elif path == '/api/messenger/field':
                action = str(data.get('action','status'))
                result = service.submit('Shared field: ' + action, lambda: service.field_action(action, data))
            else:
                self._json({'error':'ERR_UNKNOWN_ACTION'}, 404)
                return
            self._json(result)
        except Exception as exc:
            self._json({'error':exc.__class__.__name__, 'message':str(exc)[:600]}, 400)


def create_messenger_server(address, signing_key, inbox):
    service = MessengerService(signing_key, inbox)
    try:
        server = MessengerHTTPServer(address, MessengerHandler)
        server.messenger = service
        return server
    except Exception:
        service.close()
        raise
