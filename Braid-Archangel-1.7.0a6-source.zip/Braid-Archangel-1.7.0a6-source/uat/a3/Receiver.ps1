param(
  [Parameter(Mandatory=$true)][string]$TrustedKey,
  [Parameter(Mandatory=$true)][string]$RoutePackage,
  [Parameter(Mandatory=$true)][string]$BindIp,
  [Parameter(Mandatory=$true)][string]$OutputDir,
  [int]$Port = 8745,
  [string]$EmbedModel = "all-minilm:latest"
)
$ErrorActionPreference = "Stop"
$version = (& braid-client --version).Trim()
if ($version -ne "1.7.0a3") { throw "Expected braid-client 1.7.0a3, found $version" }
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
& braid-client receive `
  --semantic-proof `
  --trusted-key $TrustedKey `
  --route-package $RoutePackage `
  --bind $BindIp `
  --allow-lan `
  --port $Port `
  --output-dir $OutputDir `
  --semantic-embed-model $EmbedModel `
  --semantic-field-model $EmbedModel
exit $LASTEXITCODE
