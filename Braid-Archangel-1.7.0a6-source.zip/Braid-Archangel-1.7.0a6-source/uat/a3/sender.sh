#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 4 ] || [ "$#" -gt 6 ]; then
  echo "Usage: $0 <route-dir> <signing-key> <receiver-host> <work-dir> [port] [ollama-url]" >&2
  exit 64
fi

ROUTE_DIR=$1
SIGNING_KEY=$2
RECEIVER_HOST=$3
WORK_DIR=$4
PORT=${5:-8745}
OLLAMA_URL=${6:-http://127.0.0.1:11434}

VERSION=$(braid-client --version)
if [ "$VERSION" != "1.7.0a3" ]; then
  echo "ERROR: expected braid-client 1.7.0a3, found $VERSION" >&2
  exit 65
fi

mkdir -p "$WORK_DIR/evidence"
cat > "$WORK_DIR/object-1.txt" <<'EOF'
Project Meridian may enter Kestrel Run only when both Finch readings are independently signed. The current Finch thermal threshold is 73.
EOF
cat > "$WORK_DIR/object-2.txt" <<'EOF'
Archive rotation and backup retention are reviewed every Friday by operations.
EOF
cat > "$WORK_DIR/object-3.txt" <<'EOF'
The Finch thermal threshold is 75. Both readings still require independent Finch signatures.
EOF

for N in 1 2 3; do
  FRAME="$WORK_DIR/object-$N-a3.brad"
  braid-client capsule-frame \
    --route-package "$ROUTE_DIR" \
    --text-file "$WORK_DIR/object-$N.txt" \
    --signing-key "$SIGNING_KEY" \
    --ollama-url "$OLLAMA_URL" \
    --output "$FRAME" \
    > "$WORK_DIR/evidence/object-$N-frame.json"
  braid-client send "$FRAME" \
    --host "$RECEIVER_HOST" \
    --port "$PORT" \
    > "$WORK_DIR/evidence/object-$N-send.json"
  python3 - "$WORK_DIR/evidence/object-$N-send.json" <<'PY'
import json
import sys
value = json.load(open(sys.argv[1], encoding="utf-8"))
if value.get("accepted_and_indexed") is not True:
    raise SystemExit("ERROR: receiver did not return accepted_and_indexed=true")
print(value["result_summary"])
PY
done
