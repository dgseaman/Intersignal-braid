param(
  [Parameter(Mandatory=$true)][string]$RoutePackage,
  [Parameter(Mandatory=$true)][string]$SigningKey,
  [Parameter(Mandatory=$true)][string]$ReceiverHost,
  [Parameter(Mandatory=$true)][string]$WorkDir,
  [int]$Port = 8745,
  [string]$OllamaUrl = "http://127.0.0.1:11434"
)
$ErrorActionPreference = "Stop"
$version = (& braid-client --version).Trim()
if ($version -ne "1.7.0a3") { throw "Expected braid-client 1.7.0a3, found $version" }
$evidence = Join-Path $WorkDir "evidence"
New-Item -ItemType Directory -Force -Path $evidence | Out-Null
$texts = @(
  "Project Meridian may enter Kestrel Run only when both Finch readings are independently signed. The current Finch thermal threshold is 73.`n",
  "Archive rotation and backup retention are reviewed every Friday by operations.`n",
  "The Finch thermal threshold is 75. Both readings still require independent Finch signatures.`n"
)
for ($i = 0; $i -lt $texts.Count; $i++) {
  $n = $i + 1
  $textPath = Join-Path $WorkDir "object-$n.txt"
  $framePath = Join-Path $WorkDir "object-$n-a3.brad"
  $frameEvidence = Join-Path $evidence "object-$n-frame.json"
  $sendEvidence = Join-Path $evidence "object-$n-send.json"
  [System.IO.File]::WriteAllText($textPath, $texts[$i], [System.Text.UTF8Encoding]::new($false))
  & braid-client capsule-frame --route-package $RoutePackage --text-file $textPath --signing-key $SigningKey --ollama-url $OllamaUrl --output $framePath | Set-Content -Encoding UTF8 $frameEvidence
  if ($LASTEXITCODE -ne 0) { throw "capsule-frame failed for object $n" }
  & braid-client send $framePath --host $ReceiverHost --port $Port | Set-Content -Encoding UTF8 $sendEvidence
  if ($LASTEXITCODE -ne 0) { throw "send failed for object $n" }
  $ack = Get-Content -Raw $sendEvidence | ConvertFrom-Json
  if ($ack.accepted_and_indexed -ne $true) { throw "Object $n was not accepted and indexed" }
  Write-Host $ack.result_summary
}
