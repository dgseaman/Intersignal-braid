#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 4 ] || [ "$#" -gt 6 ]; then
  echo "Usage: $0 <sender.pub> <route-dir> <bind-ip> <output-dir> [port] [embed-model]" >&2
  exit 64
fi

TRUSTED_KEY=$1
ROUTE_DIR=$2
BIND_IP=$3
OUTPUT_DIR=$4
PORT=${5:-8745}
EMBED_MODEL=${6:-all-minilm:latest}

VERSION=$(braid-client --version)
if [ "$VERSION" != "1.7.0a3" ]; then
  echo "ERROR: expected braid-client 1.7.0a3, found $VERSION" >&2
  exit 65
fi

mkdir -p "$OUTPUT_DIR"
exec braid-client receive \
  --semantic-proof \
  --trusted-key "$TRUSTED_KEY" \
  --route-package "$ROUTE_DIR" \
  --bind "$BIND_IP" \
  --allow-lan \
  --port "$PORT" \
  --output-dir "$OUTPUT_DIR" \
  --semantic-embed-model "$EMBED_MODEL" \
  --semantic-field-model "$EMBED_MODEL"
