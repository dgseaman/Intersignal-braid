#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 2 ] || [ "$#" -gt 4 ]; then
  echo "Usage: $0 <receiver-output-dir> <completion-model> [embed-model] [ollama-url]" >&2
  exit 64
fi

OUTPUT_DIR=$1
COMPLETION_MODEL=$2
EMBED_MODEL=${3:-all-minilm:latest}
OLLAMA_URL=${4:-http://127.0.0.1:11434}
EVIDENCE_DIR="$OUTPUT_DIR/a3-proof-evidence"
mkdir -p "$EVIDENCE_DIR"

QUESTION='What threshold and signature rule govern Kestrel Run? Explicitly state any unresolved conflict and do not silently choose between conflicting values.'

braid-client field-status --output-dir "$OUTPUT_DIR" \
  | tee "$EVIDENCE_DIR/field-status.json"
braid-client field-search "$QUESTION" \
  --output-dir "$OUTPUT_DIR" \
  --embed-model "$EMBED_MODEL" \
  --ollama-url "$OLLAMA_URL" \
  --top-k 4 \
  | tee "$EVIDENCE_DIR/field-search.json"
braid-client field-reconcile \
  --output-dir "$OUTPUT_DIR" \
  --embed-model "$EMBED_MODEL" \
  --ollama-url "$OLLAMA_URL" \
  | tee "$EVIDENCE_DIR/field-reconcile.json"
braid-client field-query "$QUESTION" \
  --output-dir "$OUTPUT_DIR" \
  --embed-model "$EMBED_MODEL" \
  --model "$COMPLETION_MODEL" \
  --ollama-url "$OLLAMA_URL" \
  --top-k 4 \
  | tee "$EVIDENCE_DIR/field-query.json"

python3 - "$EVIDENCE_DIR/field-status.json" "$EVIDENCE_DIR/field-search.json" "$EVIDENCE_DIR/field-reconcile.json" "$EVIDENCE_DIR/field-query.json" <<'PY'
import json
import sys
status, search, reconcile, query = [json.load(open(path, encoding="utf-8")) for path in sys.argv[1:]]
assert status.get("ready") is True, status
assert status.get("indexed_object_count") == 3, status
assert status.get("indexed_atom_count") == 5, status
texts = [item.get("text", "") for item in search.get("results", [])]
assert any("threshold is 73" in text for text in texts), texts
assert any("threshold is 75" in text for text in texts), texts
assert all("Archive rotation" not in text for text in texts), texts
assert reconcile.get("possible_conflict_count", 0) >= 1, reconcile
assert query.get("whole_transcript_replayed") is False, query
assert query.get("fresh_context_reconstruction") is True, query
assert query.get("reconciliation", {}).get("unresolved_conflict_count", 0) >= 1, query
assert query.get("completion_guard", {}).get("status") in {"passed", "deterministic_fallback"}, query
response = query.get("response", "")
assert "73" in response and "75" in response, query
assert "conflict" in response.lower(), query
lower = response.lower()
assert not any(unit in lower for unit in ("fahrenheit", "celsius", "kelvin", "degrees")), query
assert "governing threshold is 73" not in lower, query
assert "governing threshold is 75" not in lower, query
print("A3_SEMANTIC_FIELD_PROOF_PASS")
PY
