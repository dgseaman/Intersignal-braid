param(
  [Parameter(Mandatory=$true)][string]$OutputDir,
  [Parameter(Mandatory=$true)][string]$CompletionModel,
  [string]$EmbedModel = "all-minilm:latest",
  [string]$OllamaUrl = "http://127.0.0.1:11434"
)
$ErrorActionPreference = "Stop"
$evidence = Join-Path $OutputDir "a3-proof-evidence"
New-Item -ItemType Directory -Force -Path $evidence | Out-Null
$question = "What threshold and signature rule govern Kestrel Run? Explicitly state any unresolved conflict and do not silently choose between conflicting values."
& braid-client field-status --output-dir $OutputDir | Set-Content -Encoding UTF8 (Join-Path $evidence "field-status.json")
if ($LASTEXITCODE -ne 0) { throw "field-status failed" }
& braid-client field-search $question --output-dir $OutputDir --embed-model $EmbedModel --ollama-url $OllamaUrl --top-k 4 | Set-Content -Encoding UTF8 (Join-Path $evidence "field-search.json")
if ($LASTEXITCODE -ne 0) { throw "field-search failed" }
& braid-client field-reconcile --output-dir $OutputDir --embed-model $EmbedModel --ollama-url $OllamaUrl | Set-Content -Encoding UTF8 (Join-Path $evidence "field-reconcile.json")
if ($LASTEXITCODE -ne 0) { throw "field-reconcile failed" }
& braid-client field-query $question --output-dir $OutputDir --embed-model $EmbedModel --model $CompletionModel --ollama-url $OllamaUrl --top-k 4 | Set-Content -Encoding UTF8 (Join-Path $evidence "field-query.json")
if ($LASTEXITCODE -ne 0) { throw "field-query failed" }
$status = Get-Content -Raw (Join-Path $evidence "field-status.json") | ConvertFrom-Json
$search = Get-Content -Raw (Join-Path $evidence "field-search.json") | ConvertFrom-Json
$reconcile = Get-Content -Raw (Join-Path $evidence "field-reconcile.json") | ConvertFrom-Json
$query = Get-Content -Raw (Join-Path $evidence "field-query.json") | ConvertFrom-Json
if ($status.ready -ne $true -or $status.indexed_object_count -ne 3 -or $status.indexed_atom_count -ne 5) { throw "Field status proof failed" }
$text = ($search.results | ForEach-Object { $_.text }) -join "`n"
if ($text -notmatch "threshold is 73" -or $text -notmatch "threshold is 75" -or $text -match "Archive rotation") { throw "Retrieval proof failed" }
if ($reconcile.possible_conflict_count -lt 1) { throw "Reconciliation proof failed" }
if ($query.whole_transcript_replayed -ne $false -or $query.fresh_context_reconstruction -ne $true) { throw "Fresh query proof failed" }
if ($query.reconciliation.unresolved_conflict_count -lt 1 -or $query.response -notmatch "73" -or $query.response -notmatch "75" -or $query.response -notmatch "conflict") { throw "Grounded query proof failed" }
if ($query.completion_guard.status -notin @("passed", "deterministic_fallback")) { throw "Completion guard status is invalid" }
if ($query.response -match "fahrenheit|celsius|kelvin|degrees") { throw "Final response invented a unit" }
if ($query.response -match "governing threshold is (73|75)") { throw "Final response selected an unresolved value" }
Write-Host "A3_SEMANTIC_FIELD_PROOF_PASS"
