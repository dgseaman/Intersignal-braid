# Braid v1.7.0a1 Semantic Field UAT

Status: engineering UAT plan. Run on frozen candidate bytes before any public promotion.

## Goal

Demonstrate that the receiver's 384D field performs work that manual copy/paste does not perform automatically:

- retrieve only relevant prior state;
- detect duplicate versus possible update;
- preserve conflicting state;
- forward a bounded semantic delta;
- reconstruct a fresh answer without replaying the whole transcript.

## Preconditions

On sender and receiver:

```sh
ollama pull all-minilm
braid-client --version
braid-client doctor
```

Record:

- Braid wheel/source SHA-256;
- OS and architecture;
- Ollama version;
- `all-minilm:latest` model digest;
- receiver field-space digest after first commit;
- source route-package digest;
- sender verification-key fingerprint.

## A. Start a field-enabled receiver

```sh
braid-client receive \
  --trusted-key ./sender.pub \
  --route-package ./route \
  --bind 0.0.0.0 \
  --allow-lan \
  --port 8745 \
  --output-dir ./receiver \
  --semantic-embed-model all-minilm:latest \
  --semantic-field-model all-minilm:latest
```

Expected: listener starts; no acceptance is claimed before a receiver ACK and Phase B commit.

## B. Send three invented post-training objects

Object 1:

```text
Project Meridian may enter Kestrel Run only when both Finch readings are independently signed. The current Finch thermal threshold is 73.
```

Object 2:

```text
Archive rotation and backup retention are reviewed every Friday by operations.
```

Object 3:

```text
The Finch thermal threshold is 75. Both readings still require independent Finch signatures.
```

For each object:

```sh
braid-client capsule-frame \
  --route-package ./route \
  --text-file ./object-N.txt \
  --signing-key ./sender.key \
  --output ./object-N.brad

braid-client send ./object-N.brad --host <receiver-ip> --port 8745
```

Required receiver evidence for each:

- `accepted: true`;
- `phase_b_committed: true`;
- exact ACK `transport_sha256` matches submitted frame;
- `semantic_transfer.semantic_field.indexed: true`;
- field dimension 384;
- field/model/adapter/behavior-probe digests recorded.

Expected novelty:

- Object 1: both atoms `novel`;
- Object 2: archive atom `novel`;
- Object 3: threshold atom `possible_update` with `numeric_value_changed`; signature-requirement atom `related`, `near_duplicate`, or `exact_duplicate` depending on exact wording;
- no automatic supersession.

## C. Retrieval isolation

```sh
braid-client field-search \
  "What threshold and signature rule govern Kestrel Run?" \
  --output-dir ./receiver \
  --embed-model all-minilm:latest \
  --top-k 4
```

Pass criteria:

- threshold/signature atoms selected;
- unrelated archive atom omitted or scored lower than selected operational atoms;
- returned text exactly matches committed source spans;
- source object digests and field-manifest digests are present;
- `whole_transcript_replayed` is not required because search emits only atoms;
- no claim that cosine equals truth.

## D. Fresh receiver query

Ask the receiver model before Braid context, then run:

```sh
braid-client field-query \
  "May Meridian proceed if readings are 74 and 76 but only one is signed? Explain." \
  --output-dir ./receiver \
  --embed-model all-minilm:latest \
  --model <receiver-local-completion-model> \
  --top-k 6
```

Pass criteria:

- query artifact says `fresh_context_reconstruction: true`;
- query artifact says `whole_transcript_replayed: false`;
- prompt evidence contains selected exact atoms only;
- answer applies the signature requirement and does not silently resolve the 73/75 threshold conflict;
- output is labeled receiver-local generated text.

## E. Reconciliation

```sh
braid-client field-reconcile \
  --output-dir ./receiver \
  --embed-model all-minilm:latest
```

Pass criteria:

- 73 and 75 atoms share a related cluster or otherwise remain separately visible;
- a possible numeric conflict is reported when clustered;
- both exact texts and source object digests remain present;
- `automatic_resolution: false`.

## F. Delta forwarding

Select Object 3's digest:

```sh
braid-client field-delta-frame <object-3-digest> \
  --output-dir ./receiver \
  --route-package ./route \
  --signing-key ./sender.key \
  --output ./object-3-delta.brad
```

Send to a second clean receiver and require:

- normal signature verification and Phase B commit;
- signed delta extension present;
- exact ordered atom IDs match canonical delta material;
- source object and source field-manifest digest match the sender's selection evidence;
- received delta atoms retain `signed_semantic_delta_atom` lineage;
- no opaque vector-to-text reconstruction;
- no automatic supersession.

## G. Legacy reindex

On a receiver directory containing committed v1.6 Semantic Capsule bundles:

```sh
braid-client field-reindex \
  --output-dir ./receiver \
  --embed-model all-minilm:latest
```

Run it twice.

Pass criteria:

- first run indexes valid unindexed objects in commit chronology;
- second run reports them as already indexed and writes no replacement fields;
- material SHA mismatch fails that object without creating `field.json`;
- ordinary `state`/`query` remains available for a failed object.

## H. Negative tests

Each must fail closed or degrade without rewriting Phase B:

1. modify `atoms.json` without updating field manifest;
2. modify `novelty.json` without updating field manifest;
3. modify committed `material.txt` before reindex;
4. alter a signed delta atom while retaining the old extension digest;
5. alter signed delta source object or field digest and re-sign the outer frame;
6. query with a model whose field-space digest differs;
7. remove the field encoder before commit;
8. disable native projection for an encoder that cannot return 384D;
9. exceed atom, bundle, query, and delta byte bounds.

For case 7, required behavior is:

- Phase B remains committed;
- base `vector.npy`, `material.txt`, and `lineage.json` remain queryable;
- field reports degraded;
- later `field-reindex` repairs the field.

## I. Clipboard comparison benchmark

Run the same final question under four conditions:

1. no transferred context;
2. manual copy/paste of all source text;
3. ordinary whole-capsule `query`;
4. 384D `field-query` with a fixed atom/byte budget.

Hold receiver model, temperature, question, and scoring rubric constant. Record:

- decision accuracy;
- constraint preservation;
- conflict preservation;
- irrelevant context included;
- input bytes/tokens;
- retrieval latency and completion latency;
- exact source atoms selected.

Promotion requires condition 4 to show a measurable advantage in relevance/efficiency or conflict handling, not merely equivalent prose transfer with more machinery.
