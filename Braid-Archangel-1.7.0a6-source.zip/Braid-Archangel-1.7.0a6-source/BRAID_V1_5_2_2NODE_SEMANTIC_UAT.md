# Braid v1.5.2 Two-Node Semantic Capsule UAT

Purpose: prove the exact-space fast path and true heterogeneous receiver-local re-embedding on two physical Macs without inventing semantics.

## Equipment

- Mac A (sender)
- Mac B (receiver)
- same private LAN
- Ollama running locally on both
- one source embedding model on A
- a different embedding model/digest on B for the heterogeneous run
- optional local completion model on B
- camera/operator for the optical rerun

## Gate 0 — install/front door

On each Mac:

1. Mount the v1.5.2 DMG.
2. Drag `Braid.app` to Applications.
3. Launch Braid.
4. Confirm the local visualizer opens.
5. Confirm machine, LAN, Ollama, models, and workspace are populated accurately.
6. Confirm no remote/cloud endpoint is contacted by Braid autodetect.

Set the same-install CLI path on each node and record environment JSON:

```sh
BRAID='/Applications/Braid.app/Contents/MacOS/braid-client'
"$BRAID" environment > ~/BraidUAT-environment.json
"$BRAID" doctor
```

PASS also requires the visualizer's CLI row/generated commands to point to `/Applications/Braid.app/Contents/MacOS/braid-client`, capability-based Ollama model classification, and rejection/exclusion of any model carrying explicit cloud naming or Ollama `remote_model` / `remote_host` metadata.

## Gate 1 — source route

On Mac A, build a digest-bound source route with the source embedding model:

```sh
"$BRAID" ollama-route --embed-model <source-embed-model> --output-dir ~/BraidUAT/source-route --count 576
```

Preserve the route package for Mac B. The sender public key is created/confirmed in Gate 2 alongside the signed capsule.

## Gate 2 — signed capsule

On Mac A:

```sh
"$BRAID" capsule-frame \
  --route-package ~/BraidUAT/source-route \
  --text 'Braid semantic capsule physical UAT: explicit meaning only.' \
  --signing-key ~/BraidUAT/sender.key \
  --output ~/BraidUAT/capsule.brad
```

The command creates/repairs `~/BraidUAT/sender.pub`. Copy that public key plus the frozen source route package to Mac B before Gate 3. Do **not** copy the private key.

Record:

- object digest;
- capsule digest;
- source model digest;
- frame SHA-256.

## Gate 3 — heterogeneous receiver

On Mac B, choose a local embedding model whose digest differs from the source model and run:

```sh
"$BRAID" receive \
  --trusted-key ~/BraidUAT/sender.pub \
  --route-package ~/BraidUAT/source-route \
  --bind 0.0.0.0 --allow-lan --port 8745 \
  --output-dir ~/BraidUAT/receiver \
  --semantic-embed-model <different-receiver-embed-model>
```

From Mac A:

```sh
"$BRAID" send ~/BraidUAT/capsule.brad --host <mac-b-private-ip> --port 8745
```

PASS requires:

- Phase B committed;
- transfer method `semantic_capsule_local_reembed`;
- receiver model digest differs from source model digest;
- receiver semantic vector dimension equals the receiver model's native dimension (not assumed 384);
- `bridge_semantic_invention: false`;
- semantic `vector.npy` and `lineage.json` exist in the same object bundle;
- lineage says sender signature does not cover the derived vector.

## Gate 4 — exact-space fast path

Repeat with Mac B configured to the exact same embedding model digest as Mac A.

PASS requires:

- `exact_space_fast_path`;
- receiver dimension 384 route-space;
- no native heterogeneous re-embedding call required;
- committed finality.

Repeat the exact-space receive once with `--semantic-verify-fast-path`. PASS requires `exact_space_coherence_verified: true` and cosine >= the default 0.999 threshold before Phase B.

## Gate 5 — no-capsule negative

Create/send a valid signed route frame without a Semantic Capsule to a receiver configured with `--semantic-embed-model`.

PASS requires rejection before Phase B with a capsule-required reason.

## Gate 6 — tamper/replay negatives

- flip a frame byte -> reject;
- signed but self-inconsistent capsule -> reject before Phase B;
- replay an already committed frame -> reject;
- change capsule source-model identity and re-sign using an otherwise authorized sender -> frozen route binding must reject.

## Gate 7 — post-commit degradation

Configure an optional receiver completion model and deliberately make the completion handoff fail after semantic preflight/Phase B.

PASS requires:

- finality remains `committed`;
- receipt marks post-commit delivery degradation;
- no rollback/rejection fiction.

## Gate 8 — optical rerun

Transport the same capsule-bearing semantic object over the camera/QR path.

PASS requires the receiver to resolve the same signed semantic object/capsule and apply the same exact-vs-heterogeneous decision. The transport changes; receiver authority does not.

## Evidence to retain

- both environment JSON files;
- route package hashes;
- sender public key fingerprint;
- source frame SHA-256/object/capsule digests;
- receiver receipt(s);
- semantic lineage JSON;
- vector shape/digest;
- screen recording or camera footage for the visualizer path;
- DMG SHA-256 and `codesign`/Gatekeeper results.
