# Braid v1.5.2 - Two-Node Ollama / Legend UAT

This is the promotion gate for a public claim of real local-model-to-local-model Braid continuation.

## Claim under test

A local completion model on Node A distills source context into a signed Braid Legend; a local 384D embedding model encodes that Legend; Braid transports the signed frame to Node B; Node B independently reaches Phase B finality; only then does Node B invoke its local completion model using the signed Legend as receiver-local context.

This is **not** native hidden-state injection.

## Prerequisites on both nodes

- Python 3.10+ (3.12 recommended)
- Braid Client v1.5.2 installed
- Ollama running on loopback
- exact completion model tag present (demo default: `mistral:latest`)
- exact 384D embedding model tag present (demo default: `all-minilm:latest`)

Run on both nodes:

```bash
braid-client --version
braid-client doctor
braid-client ollama-doctor --model mistral:latest --embed-model all-minilm:latest
```

Do not proceed unless all readiness checks pass.

## Route provisioning

On Node A, create the same-space digest-bound embedding route:

```bash
braid-client ollama-route \
  --embed-model all-minilm:latest \
  --output-dir routes/all-minilm-identity
```

Require:

- `status: empirically_promotable`
- `promotion.passed: true`
- `route_kind: same_space_identity`
- exact source/target model digests equal.

Provision the exact route package to Node B and verify its files byte-for-byte. The receiver must use that explicitly configured route package.

## Trust provisioning

Node A creates/retains its signing key. Node B receives only the public verification key. Compare its SHA-256 on both machines before starting the receiver.

## Node B receiver

```bash
braid-client receive \
  --route-package routes/all-minilm-identity \
  --trusted-key sender.pub \
  --bind <NODE_B_LAN_IP> \
  --port 8745 \
  --allow-lan \
  --output-dir ollama-inbox \
  --ollama-model mistral:latest \
  --ollama-embed-model all-minilm:latest
```

## Node A frame creation

```bash
braid-client ollama-frame \
  --route-package routes/all-minilm-identity \
  --model mistral:latest \
  --text 'Continue our Braid demonstration. Preserve receiver-owned finality and explain what survived the handoff.' \
  --signing-key sender.key \
  --legend-output demo.legend.json \
  --output demo.brad
```

Record the printed object digest and Legend digest.

## Node A LAN send

```bash
braid-client send demo.brad --host <NODE_B_LAN_IP> --port 8745
```

Require sender ACK `accepted: true`.

## Node B acceptance evidence

Inspect the newest receipt and require:

- `source_transport: network`
- `accepted: true`
- `phase_b_committed: true`
- `finality: committed`
- `legend.present: true`
- `legend.authority: signed_sender_context_only`
- pipeline includes `legend_verify`, `ollama_route_bind`, `phase_b_commit`, and `ollama_handoff`
- receiver vector dimension is 384
- handoff `accepted: true`
- handoff artifact exists.

Inspect the `.ollama.json` artifact and require:

- same object digest and Legend digest;
- exact local completion/embedding model digests recorded;
- finite Legend/vector cosine;
- model response present with SHA-256;
- `authority: post_commit_receiver_local_output`;
- `generative_vector_injection: false`.

## Negative checks

1. Re-send the same frame: replay must not create a second committed state.
2. Tamper with the signed frame: signature/integrity path must fail before finality.
3. Use a different target embedding model/digest: built-in Ollama handoff must fail closed/degrade without rewriting committed Braid finality.
4. Stop Ollama after Braid starts but before post-commit model handoff: Braid finality must remain committed and the receipt must report post-commit degradation.
5. Configure `--ollama-min-alignment` above the observed alignment: model handoff must be withheld while Braid finality remains committed.

## Promotion rule

Only after a real two-physical-node positive run should the release be described as demonstrating local Mistral -> signed Legend/384D Braid -> LAN -> receiver Phase B -> local Mistral continuation.
