#!/usr/bin/env bash
set -u
cd "$(dirname "$0")"
mods=(
 tests.test_2node_qr_smoke_test
 tests.test_client_conformance
 tests.test_client_v1_4_3
 tests.test_transport_v145
 tests.test_v1_4_4_finish
 tests.test_v1_4_7_receiver
 tests.test_v1_4_8_polish
 tests.test_v1_4_9_hardening
 tests.test_v1_5_0_hetero
 tests.test_v1_5_0_ollama_legend
 tests.test_v1_5_2_frontdoor
 tests.test_v1_5_2_hobbyist_gate
 tests.test_v1_5_2_semantic_capsule
 tests.test_v1_6_1_context_workflow
 tests.test_v1_7_0_semantic_field
 tests.test_v1_7_0a2_fp16_canonicalization
 tests.test_v1_7_0a3_proof_build
)
: > SPLIT_TEST_RESULTS.txt
status=0
for mod in "${mods[@]}"; do
  echo "BEGIN $mod" | tee -a SPLIT_TEST_RESULTS.txt
  log="logs_${mod##*.}.txt"
  if python3 -m unittest -v "$mod" > "$log" 2>&1; then
    ran=$(grep -E '^Ran [0-9]+ tests?' "$log" | tail -1)
    echo "PASS $mod :: $ran" | tee -a SPLIT_TEST_RESULTS.txt
  else
    rc=$?
    echo "FAIL $mod :: rc=$rc" | tee -a SPLIT_TEST_RESULTS.txt
    tail -n 100 "$log" >> SPLIT_TEST_RESULTS.txt
    status=$rc
    break
  fi
done
if [ "$status" -eq 0 ]; then
  echo "ALL_PASS" | tee -a SPLIT_TEST_RESULTS.txt
fi
exit "$status"
