"""Live loopback HTTP + mTLS + QR-reassembly tests, with a local fixture Ollama."""
import base64
import json
import sqlite3
import threading
import time
import urllib.request
import urllib.error
import uuid
import pytest
import braid_client.channel_chat as cc
from braid_client.messenger_http import MessengerHTTPServer,MessengerHandler
from braid_client.qr_engine import chunk_binary_frame
from braid_client import server as oldserver
from braid_client.qr_engine import OpticalChunkCollector
from release import start_braid
from tests.test_v1_7_0a6_channels import pair,route,linked,policy,local_note
from tests.test_v1_5_2_semantic_capsule import COMPLETE

@pytest.fixture
def http(pair):
    a,b,f=pair
    s=MessengerHTTPServer(('127.0.0.1',0),MessengerHandler);s.messenger=b
    thread=threading.Thread(target=s.serve_forever,daemon=True);thread.start()
    base='http://127.0.0.1:'+str(s.server_port)
    def call(path,data=None,token=True,origin=None):
        headers={'Content-Type':'application/json'}
        if token:headers['X-Braid-CSRF']=b.csrf
        if origin:headers['Origin']=origin
        req=urllib.request.Request(base+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
        try:
            with urllib.request.urlopen(req,timeout=15) as res:return res.status,res.read()
        except urllib.error.HTTPError as exc:return exc.code,exc.read()
    yield call,base
    s.shutdown();s.server_close();thread.join(3)

def get_json(call,path,data=None,**kw):
    status,raw=call(path,data,**kw);return status,json.loads(raw)

def wait_job(call,r):
    for _ in range(150):
        code,v=get_json(call,'/api/messenger/job?id='+r['job_id'])
        if v['status'] in ('done','error'):return v
        time.sleep(.05)
    raise AssertionError('Test job timed out')

@pytest.mark.parametrize('path',['/','/static/channels.css','/static/channels.js','/static/messenger.js'])
def test_new_assets_served_locally(pair,http,path):
    call,_=http;status,raw=call(path)
    assert status==200 and len(raw)>100

def test_channel_api_auth_and_input_boundaries(pair,http):
    call,base=http
    status,body=get_json(call,'/api/messenger/channel',dict(action='create',name='Cobalt'),token=False)
    assert status==403
    assert get_json(call,'/api/messenger/channel',dict(action='create',name='Cobalt'),origin='https://evil.invalid')[0]==403
    status,c=get_json(call,'/api/messenger/channel',dict(action='create',name='Cobalt'))
    assert status==200 and c['policy']['send_to']==[] and not c['policy']['use_in_chat']
    assert get_json(call,'/api/messenger/channel',dict(action='create',name='x'*110000))[0]==413

def test_real_handoff_http_chat_metric_and_optout(pair,http,monkeypatch):
    a,b,f,c=linked(pair);b.start_listener()
    text='Project Cobalt launch color is amber.';n=local_note(a,c,text);assert n['state']=='shared'
    original=cc.query_channel_chat
    monkeypatch.setattr(cc,'query_channel_chat',lambda **kw:original(**kw,base_url=f.url))
    call,_=http
    _,t=get_json(call,'/api/messenger/chat',dict(action='new',channel=c['id']))
    data=dict(action='turn',thread=t['id'],request_id=uuid.uuid4().hex,question=text,model=COMPLETE,use_shared=True)
    status,job=get_json(call,'/api/messenger/chat',data);assert status==200
    outcome=wait_job(call,job);assert outcome['status']=='done',outcome
    r=outcome['result']['payload']['result'];assert r['shared_note_count']==1
    assert r['supplied_notes'][0]['text']==text
    assert r['supplied_notes'][0]['sources'][0]['rig']=='Mac fixture'
    _,next_job=get_json(call,'/api/messenger/chat',{**data,'request_id':uuid.uuid4().hex,'use_shared':False})
    done=wait_job(call,next_job);assert done['status']=='done',done
    assert done['result']['payload']['result']['shared_note_count']==0
    assert done['result']['payload']['result']['history_message_count']==0

def test_optical_chunks_enter_same_channel_gate_without_demo_receiver(pair,http,monkeypatch):
    a,b,f=pair;c=a.create_channel('Cobalt');b.import_channel(c['descriptor'],confirmed=True)
    policy(b,c,receive_from=[a.fingerprint],use_in_chat=True)
    n=local_note(a,c);raw=base64.b64decode(a.export_note_frame(n['id'])['frame_base64'])
    monkeypatch.setattr(oldserver,'CHUNK_COLLECTOR',OpticalChunkCollector())
    # No global example receiver configuration should be needed for real channel frames.
    monkeypatch.setattr(MessengerHandler,'receiver_automation',None)
    monkeypatch.setattr(MessengerHandler,'validator',None)
    chunks=chunk_binary_frame(raw,max_chunk_size=200)
    call,_=http
    for chunk in reversed(chunks):
        status,result=get_json(call,'/api/ingest_chunk',dict(chunk_str=chunk['chunk_str']))
        assert status==200,result
    assert result['is_complete'] and result['receiver']['phase_b_committed'] and result['receiver']['field_indexed']
    assert len(b.channel_scope(c['id'],True)[0])==1
    duplicate=b.import_note_frame(base64.b64encode(raw).decode())
    assert duplicate['reason']=='ERR_CHANNEL_NOTE_ALREADY_RECORDED'

def test_upgrade_marker_for_a5_does_not_skip_a6_snapshot(tmp_path):
    profile=tmp_path/'profile';profile.mkdir()
    db=sqlite3.connect(profile/'messenger.sqlite3');db.execute('CREATE TABLE original(value TEXT)');db.execute("INSERT INTO original VALUES ('untouched')");db.commit();db.close()
    (profile/'archangel-upgrade.json').write_text(json.dumps({'version':'1.7.0a5','backup':'old preserved'}))
    start_braid.backup_before_upgrade(profile)
    marker=json.loads((profile/'archangel-upgrade.json').read_text())
    assert marker['version']=='1.7.0a6'
    assert '1.7.0a6' in marker['backup']
    start_braid.backup_before_upgrade(profile)
    assert len(list((profile/'backups').iterdir()))==1

def test_exported_reel_is_offline_exact_payload_and_escaped(pair):
    import re
    from braid_client.channel_optical import make_reel
    a,b,_=pair;c=a.create_channel('Cobalt');n=local_note(a,c)
    raw=base64.b64decode(a.export_note_frame(n['id'])['frame_base64'])
    reel=make_reel(raw,'<img src=x onerror=alert(1)>',n['id'])
    assert '&lt;img' in reel['html'] and '<img src=x' not in reel['html']
    assert 'fetch(' not in reel['html'] and "default-src 'none'" in reel['html']
    assert reel['chunk_count']==len(chunk_binary_frame(raw,120))
    matrices=json.loads(base64.b64decode(re.search(r'atob\("([A-Za-z0-9+/=]+)"\)',reel['html']).group(1)))
    from braid_client.qr_engine import StandardQRCodeEncoder
    first=chunk_binary_frame(raw,120)[0]['chunk_str']
    assert matrices[0]==[''.join(str(int(v)) for v in row) for row in StandardQRCodeEncoder(first).matrix]
    assert 'Start reel' in reel['html'] and 'paused' in reel['html']

def test_uncommitted_draft_cannot_export_reel(pair):
    a,b,_=pair;c=a.create_channel('Cobalt');n=a.new_note(c['id'],'amber')
    with pytest.raises(ValueError,match='record'):a.channel_action('export-reel',{'note_id':n['id']})
