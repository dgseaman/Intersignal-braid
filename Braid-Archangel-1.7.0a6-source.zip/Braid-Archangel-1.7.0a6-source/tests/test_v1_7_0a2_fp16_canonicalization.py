import unittest

import numpy as np

from braid_client.mcp_core.canonical import (
    deserialize_fp16_payload,
    serialize_fp16_payload,
)


class CanonicalFp16SenderRegressionTests(unittest.TestCase):
    def test_tiny_negative_underflow_is_encoded_as_positive_zero(self) -> None:
        vector = np.zeros(384, dtype=np.float64)
        vector[0] = 1.0
        vector[1] = -1e-12  # rounds to FP16 zero and previously became 0x8000

        payload = serialize_fp16_payload(vector.tolist())
        words = np.frombuffer(payload, dtype="<u2")

        self.assertEqual(len(payload), 768)
        self.assertEqual(int(words[1]), 0x0000)
        self.assertFalse(bool((words == 0x8000).any()))

        normalized, raw = deserialize_fp16_payload(payload)
        self.assertTrue(np.isfinite(normalized).all())
        self.assertEqual(float(raw[1]), 0.0)
        self.assertFalse(bool(np.signbit(raw[1])))

    def test_explicit_negative_zero_is_canonicalized(self) -> None:
        vector = np.zeros(384, dtype=np.float64)
        vector[0] = 1.0
        vector[3] = -0.0

        payload = serialize_fp16_payload(vector.tolist())
        words = np.frombuffer(payload, dtype="<u2")

        self.assertEqual(int(words[3]), 0x0000)
        self.assertFalse(bool((words == 0x8000).any()))

    def test_nonzero_negative_fp16_value_is_preserved(self) -> None:
        vector = np.zeros(384, dtype=np.float64)
        vector[0] = np.sqrt(1.0 - 0.25**2)
        vector[2] = -0.25

        payload = serialize_fp16_payload(vector.tolist())
        decoded = np.frombuffer(payload, dtype="<f2")

        self.assertLess(float(decoded[2]), 0.0)
        self.assertNotEqual(int(np.frombuffer(payload, dtype="<u2")[2]), 0x8000)
        deserialize_fp16_payload(payload)

    def test_raw_negative_zero_remains_rejected_by_receiver(self) -> None:
        words = np.zeros(384, dtype="<u2")
        words[0] = np.asarray([1.0], dtype="<f2").view("<u2")[0]
        words[1] = 0x8000

        with self.assertRaisesRegex(ValueError, "ERR_VECTOR_NEGATIVE_ZERO"):
            deserialize_fp16_payload(words.tobytes(order="C"))


if __name__ == "__main__":
    unittest.main()
