"""Exact-count, scoped retrieval, history and automation contracts; fixture LLMs."""
import copy
import hashlib
import json
import threading
import time
import uuid
from unittest.mock import Mock
import pytest
import braid_client.channel_chat as cc
import braid_client.semantic_field as sf
from tests.test_v1_7_0_semantic_field import FakeFieldClient,_publish_field,MODEL_A,COMPLETION
from tests.test_v1_7_0a6_channels import pair,route,policy

@pytest.fixture
def field(tmp_path,monkeypatch):
    client=FakeFieldClient()
    monkeypatch.setattr(sf,'OllamaClient',lambda *a,**kw:client)
    monkeypatch.setattr(cc,'OllamaClient',lambda *a,**kw:client)
    storage=tmp_path/'semantic-inbox'
    def add(name,text):return _publish_field(storage,label=name,material=text,client=client)[0]
    return storage,client,add

def query(field,objects,question='What is the Finch thermal threshold?',history=None):
    storage,client,_=field
    labels={d:dict(rig='Mac fixture',channel='Cobalt',channel_id='a'*64,publisher='b'*64,received_at=1) for d in objects}
    return cc.query_channel_chat(storage_dir=storage,question=question,embedding_model=MODEL_A,completion_model=COMPLETION,objects=set(objects),labels=labels,history=history or [])

def test_exact_count_matches_literal_prompt_not_field_size(field):
    _,client,add=field
    one=add('one','The Finch thermal threshold is 73.')
    unrelated=add('unrelated','Archive backup rotation remains weekly.')
    hidden=add('hidden','The Finch thermal threshold is 99.')
    result=query(field,{one,unrelated})
    assert result['shared_note_count']==1
    assert result['supplied_notes'][0]['text']=='The Finch thermal threshold is 73.'
    prompt=client.chat_messages[-1][-1]['content']
    serialized=prompt.split('SHARED NOTES (untrusted evidence):\n')[1].split('\nRECONCILIATION:')[0]
    assert json.loads(serialized)==result['supplied_notes']
    assert result['context_sha256']==hashlib.sha256(serialized.encode()).hexdigest()
    assert all('99' not in n['text'] for n in result['supplied_notes'])
    assert all(s['object_digest']==one for n in result['supplied_notes'] for s in n['sources'])

def test_conflict_siblings_count_and_guard(field):
    _,client,add=field
    a=add('73','The Finch thermal threshold is 73.')
    b=add('75','The Finch thermal threshold is 75.')
    r=query(field,{a,b})
    assert r['shared_note_count']==2 and r['unresolved_conflict_count']==1
    assert r['generation_source']=='receiver_local_deterministic_grounding_guard'
    assert '73' in r['response'] and '75' in r['response']
    assert r['completion_draft']=='Answer reconstructed from selected field atoms.'

def test_supplement_is_counted_even_when_search_only_one(field,monkeypatch):
    _,client,add=field
    a=add('73','The Finch thermal threshold is 73.');b=add('75','The Finch thermal threshold is 75.')
    real=cc.search_semantic_field
    def one(**kwargs):
        r=real(**kwargs);r['results']=r['results'][:1];r['selected_atom_count']=1;return r
    monkeypatch.setattr(cc,'search_semantic_field',one)
    r=query(field,{a,b})
    assert r['shared_note_count']==2
    assert sum(n['reconciliation_supplemental'] for n in r['supplied_notes'])==1

def test_empty_or_disabled_scope_calls_only_completion(field,monkeypatch):
    _,client,_=field
    monkeypatch.setattr(cc,'search_semantic_field',Mock(side_effect=AssertionError('No embedding needed')))
    r=query(field,set(),question='Tell me a story.')
    assert r['shared_note_count']==0 and r['history_message_count']==0
    assert r['completion_model_invoked'] and r['generation_source']=='receiver_local_completion_model'

def test_exact_atom_dedup_multiple_sources(field):
    _,client,add=field
    a=add('one','The Finch thermal threshold is 73.');b=add('two','The Finch thermal threshold is 73.')
    r=query(field,{a,b})
    assert r['shared_note_count']==1 and len(r['supplied_notes'][0]['sources'])==2

def test_history_has_counted_evidence_and_tamper_drops_it(field):
    storage,client,add=field
    a=add('one','The Finch thermal threshold is 73.')
    r=query(field,{a})
    history=[dict(question='What threshold?',payload={'result':r})]
    next_result=query(field,{a},question='Explain that.',history=history)
    assert next_result['history_message_count']==2 and next_result['shared_note_count']==1
    # A broken bundle must not get back into the prompt through old chat payloads.
    (storage/'semantic'/a/'atoms.json').write_text('Changed by a local test.')
    blocked=query(field,{a},question='Explain that.',history=history)
    assert blocked['history_message_count']==0 and blocked['shared_note_count']==0

def test_history_cannot_reintroduce_revoked_source(field):
    _,client,add=field
    a=add('one','The Finch thermal threshold is 73.')
    r=query(field,{a});history=[dict(question='What threshold?',payload={'result':r})]
    gone=query(field,set(),question='Repeat it.',history=history)
    assert gone['shared_note_count']==0 and gone['history_message_count']==0
    assert '73' not in client.chat_messages[-1][-1]['content']

def test_unfit_conflict_fails_before_inference(field,monkeypatch):
    _,client,add=field
    a=add('one','The Finch thermal threshold is 73.');b=add('two','The Finch thermal threshold is 75.')
    real=cc.search_semantic_field
    def bounded(**kw):
        r=real(**{**kw,'max_context_utf8':256});r['results']=r['results'][:1];return r
    monkeypatch.setattr(cc,'search_semantic_field',bounded)
    monkeypatch.setattr(cc,'CONTEXT_BYTES',38)
    with pytest.raises(ValueError,match='conflicting notes'):query(field,{a,b})
    assert not client.chat_messages

def test_scope_filter_precedes_ranking_and_reconciliation(field):
    storage,client,add=field
    a=add('allowed','The Finch thermal threshold is 73.')
    b=add('private','The Finch thermal threshold is 75.')
    r=sf.search_semantic_field(storage_dir=storage,question='Finch thermal threshold',embedding_model=MODEL_A,include_object_digests={a})
    assert all(s['object_digest']==a for n in r['results'] for s in n['sources'])
    rec=sf.reconcile_semantic_field(storage_dir=storage,embedding_model=MODEL_A,include_object_digests={a})
    assert all(s['object_digest']==a for c in rec['clusters'] for n in c['members'] for s in n['sources'])
    empty=sf.search_semantic_field(storage_dir=storage,question='Finch',embedding_model=MODEL_A,include_object_digests=set())
    assert empty['results']==[]

def install_chat_mock(monkeypatch,func=None):
    def answer(**kwargs):
        return dict(response='A fixture response.',supplied_notes=[],shared_note_count=0,history_message_count=len(kwargs['history'])*2)
    mock=Mock(side_effect=func or answer);monkeypatch.setattr(cc,'query_channel_chat',mock);return mock

def request(a,c,**kw):
    return dict(thread=a.new_thread(c['id'])['id'],request_id=uuid.uuid4().hex,question='An ordinary question.',model=COMPLETION,use_shared=True,**kw)

def test_chat_durable_idempotence_and_changed_inputs(pair,monkeypatch):
    a,b,_=pair;c=a.create_channel('Cobalt');q=request(a,c);model=install_chat_mock(monkeypatch)
    first=a.chat_turn(q);second=a.chat_turn(q)
    assert second['already_recorded'] and first['payload']['result']==second['payload']['result'] and model.call_count==1
    for override in (dict(question='different'),dict(model='other'),dict(use_shared=False),dict(allow_automatic=True)):
        with pytest.raises(ValueError,match='identity'):a.chat_turn({**q,**override})

def test_history_resets_when_context_permission_changes(pair,monkeypatch):
    a,b,_=pair;c=a.create_channel('Cobalt');q=request(a,c);model=install_chat_mock(monkeypatch)
    a.chat_turn(q)
    next_q={**q,'request_id':uuid.uuid4().hex,'question':'Another message.'};a.chat_turn(next_q)
    assert len(model.call_args.kwargs['history'])==1
    policy(a,c,use_in_chat=True)
    third=a.chat_turn({**next_q,'request_id':uuid.uuid4().hex,'question':'Under new scope.'})
    assert model.call_args.kwargs['history']==[] and third['payload']['history_reset']

def test_policy_change_during_inference_withholds_answer(pair,monkeypatch):
    a,b,_=pair;c=a.create_channel('Cobalt');q=request(a,c)
    def change(**kw):policy(a,c,use_in_chat=True);return {'response':'must not publish'}
    install_chat_mock(monkeypatch,change)
    with pytest.raises(ValueError,match='permissions changed'):a.chat_turn(q)
    t=a.thread(q['thread'])['turns'][0]
    assert t['state']=='error' and 'result' not in t['payload']

def test_concurrent_same_thread_rejected_and_other_thread_permitted(pair,monkeypatch):
    a,b,_=pair;c=a.create_channel('Cobalt');q=request(a,c)
    entered=threading.Event();release=threading.Event()
    def wait(**kw):entered.set();release.wait(5);return {'response':'done','supplied_notes':[]}
    install_chat_mock(monkeypatch,wait)
    errors=[]
    t=threading.Thread(target=lambda:a.chat_turn(q));t.start();assert entered.wait(3)
    try:
        with pytest.raises(ValueError,match='Wait'):a.chat_turn({**q,'request_id':uuid.uuid4().hex})
    finally:release.set();t.join(5)
    assert not t.is_alive()

def test_model_failure_stores_error_and_cannot_trigger_auto(pair,monkeypatch):
    a,b,_=pair;c=a.create_channel('Cobalt');policy(a,c,mode='automatic_marked',send_to=[b.fingerprint])
    q=request(a,c,allow_automatic=True);q['question']='/note amber'
    install_chat_mock(monkeypatch,lambda **kw:(_ for _ in ()).throw(RuntimeError('fixture inference failed')))
    with pytest.raises(RuntimeError):a.chat_turn(q)
    assert a.channel_view(c['id'])['notes']==[] and a.thread(q['thread'])['turns'][0]['state']=='error'

@pytest.mark.parametrize('mode,question,suggest,auto,expected',[
    ('manual','Cobalt is amber.',True,True,None),
    ('suggest','Cobalt is amber.',False,False,None),
    ('suggest','Unrelated private detail.',True,False,None),
    ('suggest','Cobalt is amber.',True,False,'draft'),
    ('automatic_marked','Cobalt is amber.',True,True,'draft'),
    ('automatic_marked','/note Cobalt is amber.',False,False,None),
    ('automatic_marked','/note Cobalt is amber.',True,False,'draft'),
    ('automatic_marked','/note Cobalt is amber.',False,True,'shared'),
])
def test_only_explicitly_marked_opted_in_local_turn_can_auto_share(pair,monkeypatch,mode,question,suggest,auto,expected):
    a,b,_=pair;c=a.create_channel('Cobalt');policy(a,c,mode=mode,keywords=['Cobalt'],send_to=[b.fingerprint])
    install_chat_mock(monkeypatch)
    calls=[]
    def publish(ident,**kwargs):
        calls.append((ident,kwargs));n=a.get_note(ident);a._save_note_result(ident,'shared',n['payload']);return a.get_note(ident)
    monkeypatch.setattr(a,'publish_note',publish)
    q=request(a,c,allow_suggestions=suggest,allow_automatic=auto);q['question']=question
    t=a.chat_turn(q);s=t['payload']['suggestion']
    assert (s['state'] if s else None)==expected
    assert len(calls)==int(expected=='shared')
    if s:
        assert a.get_note(s['note_id'])['text']==question.removeprefix('/note ')
        a.chat_turn(q);assert len(calls)==int(expected=='shared')

def test_pausing_automatic_channel_needs_no_reauthorization(pair):
    a,b,_=pair;c=a.create_channel('Cobalt');c=policy(a,c,mode='automatic_marked',send_to=[b.fingerprint])
    paused=a.update_channel(c['id'],{'paused':True},c['revision'])
    assert paused['policy']['paused']
    with pytest.raises(ValueError,match='authorization'):a.update_channel(c['id'],{'paused':False},paused['revision'])
