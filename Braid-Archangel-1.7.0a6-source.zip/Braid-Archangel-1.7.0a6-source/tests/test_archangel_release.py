"""Offline-pack integrity and profile-lifecycle checks (no network required)."""
from __future__ import annotations
import hashlib
import json
import sqlite3
from pathlib import Path
import pytest
from release import offline_support, start_braid


def make_pack(root: Path):
    root.mkdir()
    spec=root.parent/'dependencies.txt';spec.write_text('example==1.0\n')
    (root/'example-1.0-py3-none-any.whl').write_bytes(b'test wheel bytes: verifier is not a wheel installer')
    digest=hashlib.sha256((root/'example-1.0-py3-none-any.whl').read_bytes()).hexdigest()
    (root/'requirements.lock').write_text('example==1.0 --hash=sha256:'+digest+'\n')
    meta={'schema':'braid.offline-pack.v1','target':offline_support.target(),
          'dependency_spec_sha256':hashlib.sha256(spec.read_bytes()).hexdigest(),
          'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir()}}
    write_meta(root,meta)
    return spec,meta


def write_meta(root,meta):
    (root/'wheelhouse-manifest.json').write_text(json.dumps(meta))


def test_offline_pack_matches_target_and_spec(tmp_path):
    root=tmp_path/'pack';spec,meta=make_pack(root)
    assert offline_support.verify_pack(root,spec)==meta


def test_offline_pack_rejects_target_mismatch(tmp_path):
    root=tmp_path/'pack';spec,meta=make_pack(root)
    meta['target']['python']='0.0';write_meta(root,meta)
    with pytest.raises(ValueError,match='target'):offline_support.verify_pack(root,spec)


def test_offline_pack_rejects_changed_spec(tmp_path):
    root=tmp_path/'pack';spec,_=make_pack(root);spec.write_text('example==2.0\n')
    with pytest.raises(ValueError,match='specification'):offline_support.verify_pack(root,spec)


def test_offline_pack_rejects_tampered_bytes(tmp_path):
    root=tmp_path/'pack';spec,_=make_pack(root)
    (root/'example-1.0-py3-none-any.whl').write_bytes(b'changed')
    with pytest.raises(ValueError,match='hash'):offline_support.verify_pack(root,spec)


def test_offline_pack_rejects_unmanifested_wheels(tmp_path):
    root=tmp_path/'pack';spec,_=make_pack(root)
    (root/'extra-1.0-py3-none-any.whl').write_bytes(b'not allowed')
    with pytest.raises(ValueError,match='Unmanifested'):offline_support.verify_pack(root,spec)


def test_offline_pack_rejects_symlinks(tmp_path):
    root=tmp_path/'pack';spec,_=make_pack(root)
    wheel=root/'example-1.0-py3-none-any.whl';target=tmp_path/'elsewhere.whl'
    wheel.rename(target)
    try:wheel.symlink_to(target)
    except OSError:pytest.skip('No symlink privilege on this platform')
    with pytest.raises(ValueError,match='Unsafe'):offline_support.verify_pack(root,spec)


@pytest.mark.parametrize('line',['--index-url https://example.invalid','example @ https://example.invalid/a.whl','example==1.0','-r elsewhere.txt'])
def test_offline_pack_rejects_requirements_directives(tmp_path,line):
    root=tmp_path/'pack';spec,meta=make_pack(root)
    req=root/'requirements.lock';req.write_text(line+'\n')
    meta['files'][req.name]=hashlib.sha256(req.read_bytes()).hexdigest();write_meta(root,meta)
    with pytest.raises(ValueError,match='pinned'):offline_support.verify_pack(root,spec)


def test_lock_is_os_ownership_not_filename(tmp_path):
    path=tmp_path/'launcher.lock'
    first=start_braid.acquire_lock(path);assert first is not None
    try:assert start_braid.acquire_lock(path) is None
    finally:first.close()
    assert path.exists()
    second=start_braid.acquire_lock(path);assert second is not None;second.close()


def test_backup_is_consistent_and_idempotent(tmp_path):
    profile=tmp_path/'profile';profile.mkdir()
    db=sqlite3.connect(profile/'messenger.sqlite3')
    try:
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('CREATE TABLE fixture (value TEXT)')
        db.execute("INSERT INTO fixture VALUES ('kept')");db.commit()
        (profile/'identity.pem').write_text('FAKE TEST KEY - NOT A PRIVATE KEY')
        (profile/'inbox').mkdir();(profile/'inbox'/'semantic-fixture').write_bytes(b'untouched')
        start_braid.backup_before_upgrade(profile)
        meta=json.loads((profile/'archangel-upgrade.json').read_text())
        copy=Path(meta['backup']);saved=sqlite3.connect(copy/'messenger.sqlite3')
        try:assert saved.execute('SELECT value FROM fixture').fetchone()[0]=='kept'
        finally:saved.close()
        assert (copy/'identity.pem').read_text()=='FAKE TEST KEY - NOT A PRIVATE KEY'
        assert not (copy/'inbox').exists()
        assert (profile/'inbox'/'semantic-fixture').read_bytes()==b'untouched'
        start_braid.backup_before_upgrade(profile)
        assert len(list((profile/'backups').iterdir()))==1
    finally:db.close()


def test_default_profile_preserves_a4_only_when_database_present(tmp_path,monkeypatch):
    monkeypatch.setattr(start_braid.Path,'home',classmethod(lambda cls:tmp_path))
    monkeypatch.setattr(start_braid.platform,'system',lambda:'Linux')
    assert start_braid.default_profile()==tmp_path/'.braid'/'messenger'
    old=tmp_path/'.braid'/'messenger-a4';old.mkdir(parents=True)
    assert start_braid.default_profile()==tmp_path/'.braid'/'messenger'
    (old/'messenger.sqlite3').touch()
    assert start_braid.default_profile()==old
