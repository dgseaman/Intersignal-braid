from __future__ import annotations

import json
import os
import stat
import tempfile
import unittest
from pathlib import Path

import numpy as np

from braid_client.keys import get_raw_public_bytes, load_or_create_signing_key
from braid_client.receiver import AutomatedReceiver, ReceiverAutomationConfig
from braid_client.sensing import ProximityField
from braid_client.server import create_authoritative_validator, generate_frame_object
from braid_client.transport.client import send_frame
from braid_client.transport.server import ReceiverConfig, TransportServer


class AutomatedReceiverV147Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.sk, _, self.pub_path = load_or_create_signing_key(str(self.root / "sender.key"))
        self.vk = self.sk.public_key()
        self.validator, self.registry, self.ledger = create_authoritative_validator(get_raw_public_bytes(self.vk).hex())

    def tearDown(self):
        self.tmp.cleanup()

    def receiver(self) -> AutomatedReceiver:
        return AutomatedReceiver(
            validator=self.validator,
            registry=self.registry,
            ledger=self.ledger,
            verification_key=self.vk,
            config=ReceiverAutomationConfig(storage_dir=self.root / "inbox", auto_commit=True),
        )

    def test_file_intake_commits_and_emits_384d(self):
        frame, raw, _ = generate_frame_object(signing_key=self.sk)
        report = self.receiver().process_bytes(raw, source_transport="file", source_name="state.brad", peer="local")
        self.assertTrue(report["accepted"], report)
        self.assertTrue(report["phase_b_committed"])
        self.assertEqual(report["receiver_vector"]["dimension"], 384)
        self.assertEqual(report["pipeline"][:4], ["quarantine", "parse_384d", "phase_a", "phase_b_commit"])
        self.assertIn("emit_384d", report["pipeline"])
        vec = np.load(report["vector_path"], allow_pickle=False)
        self.assertEqual(vec.shape, (384,))
        self.assertTrue(np.allclose(vec, frame.vector, atol=1e-3))
        receipt = json.loads(Path(report["receipt_path"]).read_text())
        self.assertEqual(receipt["object_digest"], frame.object_digest)

    def test_phase_a_only_never_reports_acceptance_or_emits_state(self):
        _, raw, _ = generate_frame_object(signing_key=self.sk)
        receiver = AutomatedReceiver(
            validator=self.validator,
            registry=self.registry,
            ledger=self.ledger,
            verification_key=self.vk,
            config=ReceiverAutomationConfig(storage_dir=self.root / "phase-a-only", auto_commit=False),
        )
        report = receiver.process_bytes(raw, source_transport="file", source_name="review.brad", peer="local")
        self.assertTrue(report["phase_a_validated"], report)
        self.assertFalse(report["phase_b_committed"], report)
        self.assertFalse(report["accepted"], report)
        self.assertEqual(report["reason"], "PHASE_A_VALIDATED_NOT_COMMITTED")
        self.assertIn("quarantine_hold", report["pipeline"])
        self.assertNotIn("accepted_store", report["pipeline"])
        self.assertNotIn("emit_384d", report["pipeline"])
        self.assertTrue(Path(report["stored_path"]).is_file())
        self.assertIn("quarantine", Path(report["stored_path"]).parts)
        self.assertFalse((self.root / "phase-a-only" / "accepted").exists())
        self.assertFalse((self.root / "phase-a-only" / "state").exists())

    def test_accepted_artifacts_are_private_mode(self):
        _, raw, _ = generate_frame_object(signing_key=self.sk)
        report = self.receiver().process_bytes(raw, source_transport="file", source_name="private.brad", peer="local")
        self.assertTrue(report["accepted"], report)
        for key in ("stored_path", "vector_path", "receipt_path"):
            mode = stat.S_IMODE(os.stat(report[key]).st_mode)
            self.assertEqual(mode, 0o600, (key, oct(mode)))

    def test_replay_is_rejected_after_first_commit(self):
        _, raw, _ = generate_frame_object(signing_key=self.sk)
        receiver = self.receiver()
        first = receiver.process_bytes(raw, source_transport="file", source_name="a.brad")
        second = receiver.process_bytes(raw, source_transport="file", source_name="a-again.brad")
        self.assertTrue(first["accepted"])
        self.assertFalse(second["accepted"])
        self.assertIn("replay", second["reason"].lower())

    def test_network_transport_terminates_in_same_receiver(self):
        frame_path = self.root / "network.brad"
        _, raw, _ = generate_frame_object(signing_key=self.sk)
        frame_path.write_bytes(raw)
        receiver = self.receiver()
        config = ReceiverConfig(
            bind="127.0.0.1",
            port=0,
            output_dir=self.root / "network-inbox",
            receiver_callback=receiver.process_bytes,
        )
        with TransportServer(config) as server:
            host, port = server.address
            result = send_frame(frame_path, host, port)
        self.assertTrue(result.ack.accepted, result.ack)
        self.assertTrue(result.ack.validated)
        accepted = list((self.root / "inbox" / "accepted").glob("*.brad"))
        self.assertEqual(len(accepted), 1)


class LocalSensingV147Tests(unittest.TestCase):
    def test_rssi_is_smoothed_and_relative_only(self):
        field = ProximityField()
        for value in (-74, -69, -63, -57, -52):
            record = field.observe("node-x", value, label="BRAID NODE X")
        self.assertEqual(record["distance_claim"], "relative_only")
        self.assertEqual(record["trust"], "untrusted_discovery_hint")
        self.assertGreater(record["smoothed_rssi"], -74)
        self.assertIn(record["band"], {"room", "near", "immediate"})


class CohesiveUIV147Tests(unittest.TestCase):
    def test_field_ui_keeps_qr_engine_and_receiver_language(self):
        html = (Path(__file__).resolve().parent.parent / "braid_client" / "static" / "braid_visualizer.html").read_text()
        self.assertIn("const QRCodeStandard =", html)
        self.assertIn("window.__BraidQR = QRCodeStandard;", html)
        self.assertIn("Automated receiver", html)
        self.assertIn("Atomic replay-safe commit", html)
        self.assertIn("Local field", html)
        self.assertIn("384", html)


if __name__ == "__main__":
    unittest.main()
