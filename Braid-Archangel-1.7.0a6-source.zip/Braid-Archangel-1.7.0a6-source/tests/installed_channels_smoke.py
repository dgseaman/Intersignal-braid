"""Exact wheel, explicit host-dependency runtime and real loopback HTTP smoke.
No test packages/models are shipped or auto-installed. Host mode is not isolation.
"""
import hashlib,json,os,sqlite3,subprocess,sys,tempfile,time,urllib.request,urllib.error
from pathlib import Path
if len(sys.argv) != 3:
 raise SystemExit('Usage: python installed_channels_smoke.py RELEASE_DIRECTORY OUTPUT_DIRECTORY')
ROOT=Path(sys.argv[1]).resolve()
OUT=Path(sys.argv[2]).resolve();OUT.mkdir(parents=True,exist_ok=True)
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
checks=[]
def check(name,result):
 assert result,name
 checks.append(name);print('PASS',name,flush=True)
def run(*args):return subprocess.run([sys.executable,str(ROOT/'start_braid.py'),*map(str,args)],cwd=tempfile.gettempdir(),env=env,text=True,capture_output=True,timeout=120)
def ready(profile,process):
 for i in range(1200):
  if process.poll() is not None:raise RuntimeError('Launcher exited '+str(process.returncode))
  try:
   m=json.loads((profile/'session.json').read_text());url='http://127.0.0.1:'+str(m['port'])
   with urllib.request.urlopen(url+'/api/messenger/state',timeout=2) as r:state=json.load(r)
   return url,state
  except (OSError,ValueError,KeyError):time.sleep(.1)
 raise RuntimeError('No ready service')
def post(url,state,endpoint,data):
 req=urllib.request.Request(url+'/api/messenger/'+endpoint,data=json.dumps(data).encode(),headers={'Content-Type':'application/json','X-Braid-CSRF':state['csrf']})
 with urllib.request.urlopen(req,timeout=10) as r:return json.load(r)
with tempfile.TemporaryDirectory(prefix='a6-installed-') as tmp:
 profile=Path(tmp)/'profile';log=open(OUT/'installed-launcher-log.txt','w')
 p=subprocess.Popen([sys.executable,str(ROOT/'start_braid.py'),'--profile',str(profile),'--no-browser','--offline','--use-existing-env'],cwd=tempfile.gettempdir(),env=env,stdout=log,stderr=subprocess.STDOUT)
 try:
  url,state=ready(profile,p)
  check('exact installed version',state['version']=='1.7.0a6')
  check('empty channels and inbox by default',not state['channels'] and not state['messages'])
  check('receiving paused by default',not state['listener']['running'])
  for route,needle in [('/','chatInput'),('/static/channels.js','shared_note_count'),('/static/channels.css','.channel-main')]:
   with urllib.request.urlopen(url+route,timeout=5) as r:raw=r.read().decode()
   check('live installed asset '+route,needle in raw)
  c=post(url,state,'channel',{'action':'create','name':'Installed wheel check'})
  check('installed channel starts with no grants',not c['policy']['send_to'] and not c['policy']['receive_from'] and not c['policy']['use_in_chat'])
  t=post(url,state,'chat',{'action':'new','channel':c['id']})
  check('installed chat thread persists',bool(t['id']) and not t['turns'])
  duplicate=run('--profile',profile,'--no-browser','--offline')
  check('duplicate launcher uses existing session',duplicate.returncode==0 and 'already running' in duplicate.stdout)
  identity=hashlib.sha256((profile/'identity.pem').read_bytes()).hexdigest()
  stop=run('--profile',profile,'--stop');check('cooperative stop',stop.returncode==0 and p.wait(timeout=30)==0)
  check('session removed',not (profile/'session.json').exists())
  p=subprocess.Popen([sys.executable,str(ROOT/'start_braid.py'),'--profile',str(profile),'--no-browser','--offline'],cwd=tempfile.gettempdir(),env=env,stdout=log,stderr=subprocess.STDOUT)
  url,state=ready(profile,p)
  check('restart preserves channel and private identity',state['channels'][0]['id']==c['id'] and hashlib.sha256((profile/'identity.pem').read_bytes()).hexdigest()==identity)
  check('restart preserves thread',post(url,state,'chat',{'action':'view','thread':t['id']})['id']==t['id'])
  check('a6 pre-open backup recorded',json.loads((profile/'archangel-upgrade.json').read_text())['version']=='1.7.0a6')
  stop=run('--profile',profile,'--stop');check('second cooperative stop',stop.returncode==0 and p.wait(timeout=30)==0)
  check('bundle integrity command',run('--check').returncode==0)
  (OUT/'installed-smoke.json').write_text(json.dumps({'passed':True,'checks':checks,'method':'Exact built wheel installed by actual launcher in explicit host-dependency mode on Linux CPython 3.13; real loopback HTTP, duplicate launch and restart. Not a fresh isolated dependency download or native Mac/Windows run.','wheel_sha256':hashlib.sha256((ROOT/'braid_client-1.7.0a6-py3-none-any.whl').read_bytes()).hexdigest()},indent=2))
 finally:
  if p.poll() is None:
   try:run('--profile',profile,'--stop');p.wait(timeout=25)
   except Exception:p.kill();p.wait()
  log.close()
