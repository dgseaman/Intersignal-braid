from __future__ import annotations

import hashlib
import json
import os
import stat
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest import mock

import numpy as np

from braid_client.context_workflow import (
    ContextWorkflowError,
    ManagedRelayProfile,
    _redact,
    list_approved_peers,
    load_managed_relay_profile,
    prepare_context_frame,
    send_prepared_frame,
    summarize_context,
    validate_context_text,
)
from braid_client.keys import get_raw_public_bytes, load_or_create_signing_key
from braid_client.receiver import AutomatedReceiver, ReceiverAutomationConfig
from braid_client.server import HardenedBraidHTTPHandler, create_authoritative_validator


class DummyFrame:
    object_digest = "d" * 64
    manifest = {"route_id": "route:test"}


def make_profile(root: Path, command: Path | None = None, *, configured: bool = True) -> ManagedRelayProfile:
    jumpkit = root / "jumpkit"
    jumpkit.mkdir(parents=True, exist_ok=True)
    route = root / "route"
    route.mkdir(parents=True, exist_ok=True)
    (route / "route.json").write_text("{}", encoding="utf-8")
    ca = jumpkit / "relay-ca.crt.pem"
    token = jumpkit / "relay-token.txt"
    identity = jumpkit / "device.json"
    for path, value in ((ca, "CA"), (token, "TOP-SECRET-TOKEN"), (identity, "{}")):
        path.write_text(value, encoding="utf-8")
    return ManagedRelayProfile(
        schema="intersignal.braid.managed-relay.v1",
        name="Braid Managed Relay / Jump Kit",
        provider="DigitalOcean",
        region="NYC1",
        host="relay.intersignal.test" if configured else "",
        port=8750,
        server_name="relay.intersignal.test" if configured else "",
        certificate_sha256="a" * 64 if configured else "",
        ca_file=ca,
        token_file=token,
        identity_file=identity,
        jumpkit_command=str(command or root / "missing-jumpkit"),
        enabled=True,
        route_package=route,
        sender_key=root / "sender.key",
        ollama_url="http://127.0.0.1:11434",
    )


def write_fake_jumpkit(root: Path) -> Path:
    script = root / "fake-braid-jumpkit"
    script.write_text(
        """#!/usr/bin/env python3
import hashlib
import json
import os
import pathlib
import sys

command = sys.argv[1]
mode = os.environ.get('FAKE_JUMPKIT_MODE', 'accept')
if command == 'peers':
    print(json.dumps({'peers': [
        {'device_id': 'device-b', 'name': 'Node B', 'status': 'approved'},
        {'device_id': 'device-x', 'name': 'Unapproved', 'status': 'pending'}
    ]}))
elif command == 'peer-status':
    print(json.dumps({'status': 'online', 'online': True, 'relay_tls_version': 'TLSv1.3'}))
elif command == 'send-peer':
    frame = pathlib.Path(sys.argv[2]).read_bytes()
    digest = hashlib.sha256(frame).hexdigest()
    if mode == 'noack':
        print(json.dumps({'relay_tls_version': 'TLSv1.3', 'status': 'sent'}))
    else:
        accepted = mode != 'reject'
        if mode == 'bad-digest':
            digest = 'f' * 64
        print(json.dumps({
            'relay_tls_version': 'TLSv1.3',
            'receiver_ack': {
                'stored': accepted,
                'validated': accepted,
                'accepted': accepted,
                'reason': 'OK' if accepted else 'POLICY_REJECTED',
                'transport_sha256': digest,
                'destination': 'accepted' if accepted else 'rejected'
            }
        }))
else:
    print(json.dumps({'error': 'unknown command'}))
    raise SystemExit(2)
""",
        encoding="utf-8",
    )
    script.chmod(script.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return script


class ContextWorkflowV161Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_context_limit_is_exact_utf8_bytes(self):
        self.assertEqual(len(validate_context_text("a" * 6000).encode("utf-8")), 6000)
        with self.assertRaises(ContextWorkflowError) as raised:
            validate_context_text("a" * 6001)
        self.assertEqual(raised.exception.code, "ERR_CONTEXT_TOO_LARGE")
        self.assertEqual(raised.exception.status, 413)
        with self.assertRaises(ContextWorkflowError):
            validate_context_text("🙂" * 1501)

    def test_local_summary_has_source_preserving_fallback(self):
        source = "Node Finch is authoritative. Project Meridian must wait until two signed readings are below 73."
        with mock.patch("braid_client.context_workflow.OllamaClient", side_effect=RuntimeError("ERR_OLLAMA_CONNECT")):
            result = summarize_context(source)
        self.assertEqual(result["method"], "extractive_fallback")
        self.assertTrue(result["local_only"])
        self.assertFalse(result["sent"])
        self.assertIn("Node Finch is authoritative", result["summary"])
        self.assertLessEqual(result["summary_utf8_bytes"], 6000)

    def test_local_ollama_summary_is_reviewable_and_bounded(self):
        client = mock.Mock()
        client.model_digest.return_value = "b" * 64
        client.chat.return_value = {"message": {"content": "ORIENTATION\nNode B should retain explicit context only."}}
        with mock.patch("braid_client.context_workflow.OllamaClient", return_value=client), mock.patch(
            "braid_client.context_workflow._choose_completion_model", return_value="local-chat:latest"
        ):
            result = summarize_context("Explicit context for Node B.")
        self.assertEqual(result["method"], "local_ollama_completion")
        self.assertEqual(result["completion_model_digest"], "b" * 64)
        self.assertEqual(result["authority"], "human_review_required_before_send")

    def test_packaged_profile_uses_platform_workspace_defaults_and_no_endpoint_fiction(self):
        with mock.patch("braid_client.context_workflow.default_workspace", return_value=self.root), mock.patch.dict(
            os.environ, {}, clear=True
        ):
            profile = load_managed_relay_profile()
        self.assertEqual(profile.provider, "DigitalOcean")
        self.assertEqual(profile.region, "NYC1")
        self.assertEqual(profile.port, 8750)
        self.assertEqual(profile.route_package, self.root / "route")
        self.assertEqual(profile.token_file, self.root / "jumpkit" / "relay-token.txt")
        self.assertFalse(profile.endpoint_ready)
        self.assertEqual(profile.vcpu_count, 2)
        self.assertEqual(profile.memory_gb, 4)
        self.assertEqual(profile.disk_gb, 120)

    def test_public_profile_and_redaction_do_not_leak_secret_contents_or_hide_digests(self):
        profile = make_profile(self.root)
        public = profile.public_dict()
        serialized = json.dumps(public, sort_keys=True)
        self.assertNotIn("TOP-SECRET-TOKEN", serialized)
        self.assertTrue(public["enrollment_token_present"])
        self.assertEqual(public["certificate_sha256"], "a" * 64)
        redacted = _redact({
            "object_digest": "d" * 64,
            "transport_sha256": "e" * 64,
            "enrollment_token_present": True,
            "relay_token": "TOP-SECRET-TOKEN",
            "pairing_words": "one two three",
        })
        self.assertEqual(redacted["object_digest"], "d" * 64)
        self.assertEqual(redacted["transport_sha256"], "e" * 64)
        self.assertTrue(redacted["enrollment_token_present"])
        self.assertEqual(redacted["relay_token"], "[REDACTED]")
        self.assertEqual(redacted["pairing_words"], "[REDACTED]")

    def test_prepare_context_writes_exact_private_frame_and_reports_sha(self):
        profile = make_profile(self.root)
        raw = b"BTP1-prepared-context-frame"
        with mock.patch("braid_client.context_workflow.default_workspace", return_value=self.root), mock.patch(
            "braid_client.context_workflow.build_frame_from_text",
            return_value=(DummyFrame(), raw, np.zeros(384), {"source_model": "embed", "source_model_digest": "c" * 64}),
        ):
            prepared = prepare_context_frame("Reviewed context", profile=profile, signing_key=object())
        path = Path(prepared["frame_path"])
        self.assertEqual(path.read_bytes(), raw)
        self.assertEqual(prepared["frame_sha256"], hashlib.sha256(raw).hexdigest())
        self.assertEqual(prepared["finality"], "not_committed")
        self.assertFalse(prepared["phase_b_committed"])

    def _prepared(self) -> dict[str, object]:
        outbox = self.root / "outbox"
        outbox.mkdir(parents=True, exist_ok=True)
        path = outbox / "context-test.brad"
        raw = b"signed-braid-context-frame"
        path.write_bytes(raw)
        return {
            "status": "sender_ready",
            "finality": "not_committed",
            "phase_b_committed": False,
            "object_digest": "d" * 64,
            "frame_path": str(path),
            "frame_sha256": hashlib.sha256(raw).hexdigest(),
            "frame_bytes": len(raw),
        }

    def test_peer_listing_and_acceptance_require_real_receiver_ack(self):
        command = write_fake_jumpkit(self.root)
        profile = make_profile(self.root, command)
        with mock.patch("braid_client.context_workflow.default_workspace", return_value=self.root):
            peers = list_approved_peers(profile, probe=True)
            receipt = send_prepared_frame(self._prepared(), peer="device-b", profile=profile)
        self.assertEqual([peer["device_id"] for peer in peers["peers"]], ["device-b"])
        self.assertTrue(peers["peers"][0]["online"])
        self.assertTrue(receipt["transport"]["relay_round_trip_complete"])
        self.assertTrue(receipt["transport"]["delivered_to_receiver"])
        self.assertTrue(receipt["phase_b_committed"])
        self.assertEqual(receipt["finality"], "committed")
        self.assertNotIn("frame_path", receipt["sender"])

    def test_no_ack_or_rejection_never_becomes_phase_b_success(self):
        command = write_fake_jumpkit(self.root)
        profile = make_profile(self.root, command)
        with mock.patch("braid_client.context_workflow.default_workspace", return_value=self.root), mock.patch.dict(
            os.environ, {"FAKE_JUMPKIT_MODE": "noack"}
        ):
            noack = send_prepared_frame(self._prepared(), peer="device-b", profile=profile)
        self.assertFalse(noack["phase_b_committed"])
        self.assertEqual(noack["status"], "transport_unproven")
        self.assertFalse(noack["transport"]["delivered_to_receiver"])

        with mock.patch("braid_client.context_workflow.default_workspace", return_value=self.root), mock.patch.dict(
            os.environ, {"FAKE_JUMPKIT_MODE": "reject"}
        ):
            rejected = send_prepared_frame(self._prepared(), peer="device-b", profile=profile)
        self.assertFalse(rejected["phase_b_committed"])
        self.assertEqual(rejected["finality"], "rejected")
        self.assertFalse(rejected["receiver"]["accepted"])

    def test_ack_digest_mismatch_fails_closed(self):
        command = write_fake_jumpkit(self.root)
        profile = make_profile(self.root, command)
        with mock.patch("braid_client.context_workflow.default_workspace", return_value=self.root), mock.patch.dict(
            os.environ, {"FAKE_JUMPKIT_MODE": "bad-digest"}
        ):
            with self.assertRaises(ContextWorkflowError) as raised:
                send_prepared_frame(self._prepared(), peer="device-b", profile=profile)
        self.assertEqual(raised.exception.code, "ERR_RELAY_ACK_DIGEST_MISMATCH")

    def test_visualizer_contains_real_context_workflow_and_finality_guard(self):
        html = (Path(__file__).parents[1] / "braid_client" / "static" / "braid_visualizer.html").read_text(encoding="utf-8")
        self.assertIn("Summarize Context", html)
        self.assertIn("Send Context →", html)
        self.assertIn("/api/context/summary", html)
        self.assertIn("/api/context/send", html)
        self.assertIn("/api/context/peers", html)
        self.assertIn("phase_b_committed===true", html)
        self.assertIn("successful TLS round trip alone", html)
        self.assertIn("6000 UTF-8 bytes", html)
        self.assertIn('type="file"', html)


class QuietHandler(HardenedBraidHTTPHandler):
    def log_message(self, _format, *_args):
        return


class ContextWorkflowHTTPV161Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name)
        cls.sk, _, _ = load_or_create_signing_key(str(cls.root / "sender.key"))
        cls.vk = cls.sk.public_key()
        cls.validator, cls.registry, cls.ledger = create_authoritative_validator(get_raw_public_bytes(cls.vk).hex())
        QuietHandler.signing_key = cls.sk
        QuietHandler.verification_key = cls.vk
        QuietHandler.validator = cls.validator
        QuietHandler.registry = cls.registry
        QuietHandler.ledger = cls.ledger
        QuietHandler.receiver_automation = AutomatedReceiver(
            validator=cls.validator,
            registry=cls.registry,
            ledger=cls.ledger,
            verification_key=cls.vk,
            config=ReceiverAutomationConfig(storage_dir=cls.root / "inbox"),
        )
        QuietHandler.last_receiver_report = {}
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), QuietHandler)
        cls.base = f"http://127.0.0.1:{cls.httpd.server_address[1]}"
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.thread.join(timeout=3)
        cls.temp.cleanup()

    def _post(self, path: str, payload: dict[str, object]) -> tuple[int, dict[str, object]]:
        request = urllib.request.Request(
            self.base + path,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=5) as response:
                return response.status, json.loads(response.read())
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read())

    def test_config_endpoint_exposes_non_secret_droplet_profile(self):
        profile = make_profile(self.root, write_fake_jumpkit(self.root))
        with mock.patch("braid_client.server.load_managed_relay_profile", return_value=profile):
            with urllib.request.urlopen(self.base + "/api/context/config", timeout=5) as response:
                payload = json.loads(response.read())
        self.assertEqual(payload["relay"]["provider"], "DigitalOcean")
        self.assertEqual(payload["relay"]["region"], "NYC1")
        self.assertEqual(payload["relay"]["infrastructure_profile"]["vcpu_count"], 2)
        self.assertTrue(payload["summary"]["local_only"])
        self.assertNotIn("TOP-SECRET-TOKEN", json.dumps(payload))

    def test_summary_endpoint_and_utf8_limit(self):
        expected = {
            "status": "ready_for_review",
            "summary": "Reviewed local summary",
            "summary_utf8_bytes": 22,
            "method": "extractive_fallback",
        }
        with mock.patch("braid_client.server.summarize_context", return_value=expected):
            status, payload = self._post("/api/context/summary", {"text": "source"})
        self.assertEqual(status, 200)
        self.assertEqual(payload["summary"], "Reviewed local summary")

        status, payload = self._post("/api/context/summary", {"text": "a" * 6001})
        self.assertEqual(status, 413)
        self.assertEqual(payload["error"], "ERR_CONTEXT_TOO_LARGE")

    def test_send_endpoint_only_returns_200_for_phase_b_commit(self):
        accepted = {
            "status": "accepted",
            "phase_b_committed": True,
            "finality": "committed",
            "receiver": {"stored": True, "validated": True, "accepted": True},
        }
        with mock.patch("braid_client.server.send_context", return_value=accepted):
            status, payload = self._post("/api/context/send", {"reviewed_text": "x", "peer": "device-b"})
        self.assertEqual(status, 200)
        self.assertTrue(payload["phase_b_committed"])

        rejected = {
            "status": "rejected",
            "phase_b_committed": False,
            "finality": "rejected",
            "receiver": {"stored": False, "validated": False, "accepted": False},
        }
        with mock.patch("braid_client.server.send_context", return_value=rejected):
            status, payload = self._post("/api/context/send", {"reviewed_text": "x", "peer": "device-b"})
        self.assertEqual(status, 409)
        self.assertFalse(payload["phase_b_committed"])


if __name__ == "__main__":
    unittest.main()
