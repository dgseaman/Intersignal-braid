"""Archangel regressions. Loopback TLS is real; model embeddings use fixtures."""
from __future__ import annotations
import hashlib
import importlib.util
import json
import os
import socket
import sqlite3
import ssl
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import pytest
from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
import braid_client.messenger as messenger
import braid_client.private_files as private_files
from braid_client.messenger import MessengerService, canonical, certificate_hash
from braid_client.local_network import local_address, address_available, local_addresses
from braid_client.transport.policy import enforce_bind_policy, BindScope
from braid_client.transport.server import ReceiverConfig, TransportServer
from braid_client.transport.client import send_frame
from braid_client.transport.errors import PolicyError
from tests.test_v1_7_0a4_messenger import route, services, approve, free_port, resign


@pytest.fixture
def desk(tmp_path):
    value=MessengerService(ed25519.Ed25519PrivateKey.generate(),tmp_path/'inbox',tmp_path/'profile')
    yield value
    value.close()


def test_database_closes_and_rolls_back(desk):
    with desk._db() as conn:
        conn.execute('INSERT INTO kv VALUES (?,?)',('a','1'))
    with pytest.raises(sqlite3.ProgrammingError): conn.execute('SELECT 1')
    with pytest.raises(RuntimeError):
        with desk._db() as conn:
            conn.execute('INSERT INTO kv VALUES (?,?)',('b','2'))
            raise RuntimeError('rollback')
    with pytest.raises(sqlite3.ProgrammingError): conn.execute('SELECT 1')
    assert desk.get_value('b') is None
    assert desk.get_value('a')==1
    renamed=desk.db_path.with_suffix('.move')
    desk.db_path.rename(renamed);renamed.rename(desk.db_path)


def test_many_database_operations_do_not_hold_descriptors(desk):
    directory=Path('/proc/self/fd')
    if not directory.exists(): pytest.skip('Linux FD counter')
    before=len(list(directory.iterdir()))
    for n in range(150): desk.set_value('counter',n);desk.get_value('counter')
    assert len(list(directory.iterdir())) <= before+2


@pytest.mark.parametrize('host',['100.64.0.1','100.127.255.254','169.254.10.20','10.1.2.3','fd12:3456::1','::1'])
def test_local_network_supported_addresses(host):
    assert local_address(host)==host


@pytest.mark.parametrize('host',['100.128.0.1','169.254.169.254','169.254.170.2','100.100.100.200','169.254.0.4','169.254.255.3','fe80::1%en0','::','0.0.0.0','ff02::1','2001:4860:4860::8888','localhost','8.8.8.8'])
def test_local_network_rejects_metadata_wildcard_public_or_ambiguous_scope(host):
    with pytest.raises(ValueError):local_address(host)


def test_overlay_policy_is_explicit_not_allow_public():
    kwargs=dict(allow_lan=True,allow_public=False,tls_enabled=True,insecure_public=False)
    with pytest.raises(PolicyError): enforce_bind_policy('100.85.1.2',**kwargs)
    assert enforce_bind_policy('100.85.1.2',allow_overlay=True,**kwargs).scope==BindScope.OVERLAY
    with pytest.raises(PolicyError): enforce_bind_policy('100.85.1.2',allow_overlay=True,**dict(kwargs,tls_enabled=False))
    with pytest.raises(PolicyError): enforce_bind_policy('8.8.8.8',allow_overlay=True,**kwargs)


def test_ip_discovery_understands_overlay_and_v6(monkeypatch):
    import braid_client.local_network as net
    monkeypatch.setattr(net.platform,'system',lambda:'Linux')
    monkeypatch.setattr(net.shutil,'which',lambda _: '/usr/bin/ip')
    monkeypatch.setattr(net.subprocess,'run',lambda *a,**kw:SimpleNamespace(stdout=json.dumps([{'addr_info':[{'local':'100.85.1.2'},{'local':'fd12::8'},{'local':'8.8.8.8'}]}])))
    values=net.local_addresses(refresh=True)
    assert '100.85.1.2' in values and 'fd12::8' in values and '8.8.8.8' not in values
    net._cache=(0,[])


def test_address_change_keeps_identity_route_and_history(services):
    a,b=services
    approve(a,b);approve(b,a)
    original=b.contacts()[0]; identity=a.fingerprint
    a.put_message('fixture','in',b.fingerprint,'old','keep me','indexed',{})
    a.update_address('127.0.0.2')
    updated=a.export_card()
    inspected=b.inspect_card(updated)
    assert inspected['update_kind']=='address'
    b.approve_card(inspected['inspection_id'],a.fingerprint,True)
    current=b.contacts()[0]
    assert current['host']=='127.0.0.2'
    assert current['route_path']==original['route_path']
    assert current['tls_sha256']==original['tls_sha256']
    assert a.fingerprint==identity and a.messages()[0]['text']=='keep me'


def test_stale_card_and_review_race_are_rejected(services):
    a,b=services
    old=a.export_card(); old_review=b.inspect_card(old)
    newer=a.export_card(); review=b.inspect_card(newer)
    b.approve_card(review['inspection_id'],a.fingerprint,True)
    with pytest.raises(ValueError,match='newer'): b.approve_card(old_review['inspection_id'],a.fingerprint,True)
    with pytest.raises(ValueError,match='Stale'): b.inspect_card(old)
    b.remove_contact(a.fingerprint)
    with pytest.raises(ValueError,match='Stale'): b.inspect_card(old)


def test_certificate_rotation_is_not_address_update(services):
    a,b=services;approve(b,a)
    old=a.export_card()
    a.tls_cert.unlink();a.tls_key.unlink();a._tls_identity()
    changed=a.export_card()
    assert changed['tls_certificate']!=old['tls_certificate']
    with pytest.raises(ValueError,match='Certificate or route changed'): b.inspect_card(changed)


def test_legacy_card_does_not_silently_downgrade(services):
    a,b=services;card=a.export_card();card.pop('mtls_required');resign(card,a.key)
    with pytest.raises(ValueError,match='Legacy cards'): b.inspect_card(card)


def test_missing_network_address_explains_repair(services,monkeypatch):
    a,b=services
    monkeypatch.setattr(messenger,'address_available',lambda _:False)
    with pytest.raises(ValueError,match='changed networks'):a.start_listener()
    assert a.snapshot()['network']['available'] is False
    assert a.listener is None


def test_durable_send_no_duplicate_after_reload_or_restart(services):
    a,b=services;approve(a,b);approve(b,a);b.start_listener()
    handoff='d'*32; text='The launch color is amber.'
    first=a.send(b.fingerprint,text,'Launch',handoff_id=handoff)
    assert first['stage']=='indexed'
    second=a.send(b.fingerprint,text,'Launch',handoff_id=handoff)
    assert second['already_recorded'] and second['message_id']==first['message_id']
    assert len(list((a.home/'outbox').glob('*.brad')))==1
    assert b.snapshot()['field']['indexed_object_count']==1
    a.close()
    replacement=MessengerService(a.key,a.inbox,a.home)
    try:
        result=replacement.send(b.fingerprint,text,'Launch',handoff_id=handoff)
        assert result['already_recorded']
        assert len(list((a.home/'outbox').glob('*.brad')))==1
    finally:replacement.close()


def test_handoff_content_is_immutable(desk,monkeypatch):
    monkeypatch.setattr(desk,'_send_once',lambda *args:{'stage':'indexed','message_id':args[-1]})
    desk.send('rig-a','First','Subject',handoff_id='c'*32)
    with pytest.raises(ValueError,match='changed'):desk.send('rig-a','Second','Subject',handoff_id='c'*32)


def test_partial_delivery_retries_only_confirmed_failure(desk,monkeypatch):
    calls=[]
    def fake(peer,text,title,kind,digest,ident):
        calls.append(peer)
        return {'stage':'indexed' if peer=='a' or calls.count('b')>1 else 'rejected','message_id':ident}
    monkeypatch.setattr(desk,'_send_once',fake)
    for peer in ['a','b','a','b']:desk.send(peer,'Body','Subject',handoff_id='p'*32)
    assert calls==['a','b','b']


def test_unknown_outcome_blocks_retry_and_survives_restart(desk,monkeypatch):
    calls=[]
    def fake(peer,text,title,kind,digest,ident):
        calls.append(peer)
        desk.put_message(ident,'out',peer,title,text,'outcome_unknown',{})
        raise TimeoutError('receipt lost')
    monkeypatch.setattr(desk,'_send_once',fake)
    first=desk.send('a','Body','Subject',handoff_id='u'*32)
    assert first['stage']=='outcome_unknown'
    second=desk.send('a','Body','Subject',handoff_id='u'*32)
    assert second['already_recorded'] and len(calls)==1


def test_concurrent_same_handoff_is_single_attempt(desk,monkeypatch):
    entered,finish=threading.Event(),threading.Event();calls=[]
    def fake(*args):
        calls.append(args);entered.set();finish.wait(2)
        return {'stage':'indexed','message_id':args[-1]}
    monkeypatch.setattr(desk,'_send_once',fake)
    thread=threading.Thread(target=lambda:desk.send('a','Body','Subject',handoff_id='x'*32));thread.start()
    assert entered.wait(2)
    result=desk.send('a','Body','Subject',handoff_id='x'*32)
    assert result['stage']=='sending' and result['already_recorded']
    finish.set();thread.join(3)
    assert len(calls)==1


def test_interrupted_send_recovery_never_resends(desk):
    with desk._db() as db:
        db.execute('INSERT INTO deliveries VALUES (?,?,?,?,?,?,?)',('i'*32,'a',hashlib.sha256(canonical(['Body','Subject','summary',''])).hexdigest(),'out-i','sending','{}',time.time()))
    desk.close()
    again=MessengerService(desk.key,desk.inbox,desk.home)
    try:
        result=again.send('a','Body','Subject',handoff_id='i'*32)
        assert result['stage']=='outcome_unknown' and result['already_recorded']
    finally:again.close()


def test_scan_is_bounded_and_detects_in_place_change(desk,monkeypatch):
    receipts=desk.inbox/'receipts';receipts.mkdir()
    for i in range(300):
        (receipts/f'{i}.json').write_text(json.dumps({'schema':'braid.receiver.receipt.v1','transfer_id':str(i),'phase_b_committed':True,'field_indexed':False}))
    desk.scan_receipts(force=True,budget=64)
    with desk._db() as db: assert db.execute('SELECT COUNT(*) FROM receipt_files').fetchone()[0]==64
    for _ in range(6):desk.scan_receipts(force=True,budget=64)
    with desk._db() as db: assert db.execute('SELECT COUNT(*) FROM receipt_files').fetchone()[0]==300
    desk.scan_due=time.monotonic()+60
    with patch('braid_client.messenger.os.scandir',side_effect=AssertionError('unexpected poll enumeration')):
        for _ in range(5):desk.scan_receipts()
    # Parent directory mtime remains unchanged when a child is edited in place.
    stamp=receipts.stat().st_mtime_ns
    path=receipts/'0.json';report=json.loads(path.read_text());report['field_indexed']=True;path.write_text(json.dumps(report))
    assert receipts.stat().st_mtime_ns==stamp
    for _ in range(12):desk.scan_receipts(force=True,budget=64)
    assert next(m for m in desk.messages() if m['id']=='in-0')['stage']=='indexed'


def test_scan_skips_symlink_and_oversized_receipt(desk,tmp_path):
    root=desk.inbox/'receipts';root.mkdir()
    target=tmp_path/'external.json';target.write_text('{"schema":"braid.receiver.receipt.v1"}')
    try:(root/'link.json').symlink_to(target)
    except OSError:pytest.skip('symlink privilege unavailable')
    (root/'huge.json').write_bytes(b' '*600000)
    desk.scan_receipts(force=True)
    assert not desk.messages()


def test_mtls_rejects_unapproved_before_frame_parser(services,monkeypatch):
    a,b=services;approve(a,b);approve(b,a);b.start_listener()
    calls=[]
    original=messenger.BraidFrame.from_bytes
    monkeypatch.setattr(messenger.BraidFrame,'from_bytes',lambda raw: (calls.append(raw),original(raw))[1])
    context=ssl.create_default_context(cafile=str(b.tls_cert));context.minimum_version=ssl.TLSVersion.TLSv1_3
    with socket.create_connection(('127.0.0.1',b.settings['port']),timeout=2) as raw:
        with context.wrap_socket(raw,server_hostname=b.server_name) as tls:
            with pytest.raises((OSError,ssl.SSLError)):
                tls.sendall(b'untrusted');tls.recv(1)
    assert not calls


def test_certificate_and_frame_signer_must_match(services):
    a,b=services;approve(a,b);approve(b,a);b.start_listener()
    wrong=ed25519.Ed25519PrivateKey.generate()
    frame,raw,_,_=messenger.build_frame_from_text(Path(a.settings['route_path']),'A different signer cannot borrow TLS authority.',wrong)
    path=a.home/'wrong.brad';path.write_bytes(raw)
    result=send_frame(path,'127.0.0.1',b.settings['port'],use_tls=True,ca_file=b.tls_cert,server_name=b.server_name,client_cert=a.tls_cert,client_key=a.tls_key)
    assert not result.ack.accepted and not b.messages()


def test_tls_exact_server_certificate_pin(services):
    a,b=services;approve(a,b);approve(b,a);b.start_listener()
    frame,raw,_,_=messenger.build_frame_from_text(Path(a.settings['route_path']),'The pin must match.',a.key)
    path=a.home/'pin.brad';path.write_bytes(raw)
    with pytest.raises(PolicyError,match='CERTIFICATE_PIN'):
        send_frame(path,'127.0.0.1',b.settings['port'],use_tls=True,ca_file=b.tls_cert,server_name=b.server_name,client_cert=a.tls_cert,client_key=a.tls_key,pinned_cert_sha256='0'*64)
    assert not b.messages()


def test_stalled_handshake_does_not_block_second_and_stop_is_bounded(desk):
    server=TransportServer(ReceiverConfig(bind='127.0.0.1',port=0,output_dir=desk.home/'test-server',
        tls_cert=desk.tls_cert,tls_key=desk.tls_key,handshake_timeout_seconds=.4,max_connections=2)).start()
    raw=socket.create_connection(server.address,timeout=1)
    try:
        started=time.monotonic()
        context=ssl.create_default_context(cafile=str(desk.tls_cert))
        with socket.create_connection(server.address,timeout=1) as other:
            with context.wrap_socket(other,server_hostname=desk.server_name) as tls:
                assert tls.version()=='TLSv1.3'
        assert time.monotonic()-started < 1.0
        started=time.monotonic();server.stop()
        assert time.monotonic()-started < 1.2
    finally:
        raw.close();server.stop()


def test_connection_admission_is_bounded(desk):
    server=TransportServer(ReceiverConfig(bind='127.0.0.1',port=0,output_dir=desk.home/'test-server',
        tls_cert=desk.tls_cert,tls_key=desk.tls_key,handshake_timeout_seconds=2,max_connections=2)).start()
    sockets=[]
    try:
        sockets=[socket.create_connection(server.address,timeout=1) for _ in range(6)]
        time.sleep(.1)
        with server._server._active_lock:assert len(server._server._active)<=2
    finally:
        server.stop()
        for sock in sockets:sock.close()


def test_ipv6_loopback_listener(desk):
    if not address_available('::1'):pytest.skip('IPv6 loopback unavailable')
    desk.save_settings({'host':'::1','port':free_port()})
    desk.start_listener()
    assert desk.listener.address[0]=='::1'
    desk.stop_listener()


def test_private_atomic_write_has_no_leftovers(tmp_path):
    target=tmp_path/'secret'
    private_files.atomic_private_write(target,b'first')
    private_files.atomic_private_write(target,b'second')
    assert target.read_bytes()==b'second'
    assert list(tmp_path.iterdir())==[target]
    if os.name!='nt':assert target.stat().st_mode & 0o777 == 0o600


def test_windows_fd_path_does_not_call_fchmod(monkeypatch):
    calls=[]
    monkeypatch.setattr(private_files,'os',SimpleNamespace(name='nt',close=lambda fd:calls.append(('close',fd))))
    monkeypatch.setitem(sys.modules,'msvcrt',SimpleNamespace(get_osfhandle=lambda fd:fd+1000))
    monkeypatch.setattr(private_files,'_windows_acl',lambda handle,path:calls.append(('acl',handle)))
    private_files.secure_fd(17)
    assert calls==[('acl',1017)]


def test_windows_acl_failure_is_closed_not_ignored(monkeypatch):
    closed=[]
    monkeypatch.setattr(private_files,'os',SimpleNamespace(name='nt',close=closed.append))
    monkeypatch.setitem(sys.modules,'msvcrt',SimpleNamespace(get_osfhandle=lambda fd:fd))
    monkeypatch.setattr(private_files,'_windows_acl',lambda *args:(_ for _ in ()).throw(PermissionError('ACL failure')))
    with pytest.raises(PermissionError):private_files.secure_fd(17)
    assert closed==[17]


def test_recovery_removes_only_ephemeral_inspections(desk):
    temporary=desk.home/'pending'/'interrupted';temporary.mkdir(parents=True)
    (temporary/'route.json').write_text('{}')
    keep=desk.home/'peers'/'retained';keep.mkdir(parents=True)
    (keep/'route.json').write_text('{}')
    desk.close();again=MessengerService(desk.key,desk.inbox,desk.home)
    try:
        assert not (desk.home/'pending').exists()
        assert (keep/'route.json').exists()
    finally:again.close()


def test_legacy_receiver_config_positional_order_is_preserved():
    cert,key=Path('cert.pem'),Path('key.pem')
    cfg=ReceiverConfig('127.0.0.1',8745,Path('inbox'),True,False,False,cert,key)
    assert cfg.tls_cert==cert and cfg.tls_key==key
    assert cfg.allow_overlay is False and cfg.handshake_timeout_seconds==3.0
