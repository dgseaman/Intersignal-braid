from __future__ import annotations

import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from braid_client.cli import (
    _ack_payload_for_cli,
    _semantic_handoff_from_args,
    build_parser,
    main,
)
from braid_client.keys import load_or_create_signing_key
from braid_client.server import generate_frame_object
from braid_client.semantic_field import query_semantic_field
from braid_client.transport.client import send_frame
from braid_client.transport.errors import ProtocolError
from braid_client.transport.protocol import Ack, decode_ack_from_socket, encode_ack
from braid_client.transport.server import ReceiverConfig, TransportServer
from tests.test_v1_7_0_semantic_field import (
    COMPLETION,
    MODEL_A,
    FakeFieldClient,
    _publish_field,
)


class _FakeSocket:
    def __init__(self, data: bytes):
        self.data = bytearray(data)

    def recv(self, length: int) -> bytes:
        if not self.data:
            return b""
        chunk = bytes(self.data[:length])
        del self.data[:length]
        return chunk


class _BadCompletionClient(FakeFieldClient):
    def chat(self, model, messages, *, temperature=0.0):
        self.chat_messages.append(messages)
        return {
            "message": {
                "role": "assistant",
                "content": "The governing threshold is 73 degrees Fahrenheit. Both readings require signatures.",
            }
        }


class _GoodCompletionClient(FakeFieldClient):
    def chat(self, model, messages, *, temperature=0.0):
        self.chat_messages.append(messages)
        return {
            "message": {
                "role": "assistant",
                "content": (
                    "The retrieved evidence contains an unresolved conflict between threshold "
                    "values 73 and 75. Both Finch readings require independent signatures. "
                    "No unit is specified, and neither value is treated as superseding the other."
                ),
            }
        }


class _ChoosingCompletionClient(FakeFieldClient):
    def chat(self, model, messages, *, temperature=0.0):
        self.chat_messages.append(messages)
        return {
            "message": {
                "role": "assistant",
                "content": (
                    "The governing threshold is 73, although the evidence also contains an "
                    "unresolved conflict with 75. Both readings require independent signatures."
                ),
            }
        }


class SemanticProofModeTests(unittest.TestCase):
    def test_proof_mode_enables_safe_semantic_defaults(self):
        parser = build_parser()
        args = parser.parse_args([
            "receive",
            "--trusted-key", "sender.pub",
            "--route-package", "route",
            "--semantic-proof",
        ])
        handoff = _semantic_handoff_from_args(args)
        self.assertIsNotNone(handoff)
        self.assertEqual(handoff.embedding_model, "all-minilm:latest")
        self.assertTrue(handoff.verify_exact_space_coherence)
        self.assertIsNotNone(handoff.semantic_field)
        self.assertTrue(handoff.semantic_field.enabled)
        self.assertEqual(handoff.semantic_field.embedding_model, "all-minilm:latest")

    def test_proof_mode_requires_route_and_field(self):
        parser = build_parser()
        no_route = parser.parse_args([
            "receive", "--trusted-key", "sender.pub", "--semantic-proof",
        ])
        with self.assertRaisesRegex(ValueError, "ERR_SEMANTIC_PROOF_REQUIRES_ROUTE_PACKAGE"):
            _semantic_handoff_from_args(no_route)

        no_field = parser.parse_args([
            "receive",
            "--trusted-key", "sender.pub",
            "--route-package", "route",
            "--semantic-proof",
            "--no-semantic-field",
        ])
        with self.assertRaisesRegex(ValueError, "ERR_SEMANTIC_PROOF_REQUIRES_FIELD"):
            _semantic_handoff_from_args(no_field)


class InspectLedgerRegressionTests(unittest.TestCase):
    def test_route_inspect_uses_file_backed_temporary_ledger(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            sk, _, pub = load_or_create_signing_key(str(root / "sender.key"))
            _, raw, _ = generate_frame_object(signing_key=sk)
            frame = root / "frame.brad"
            frame.write_bytes(raw)
            route = root / "route"
            route.mkdir()
            validator = SimpleNamespace(
                validate_frame_phase_a=lambda _raw: SimpleNamespace(
                    is_valid=True,
                    gate_name="AllGates",
                    message="VALIDATOR_ACCEPTED",
                )
            )
            with patch(
                "braid_client.cli.create_validator_from_route_package",
                return_value=(validator, object(), object(), {}),
            ) as factory, contextlib.redirect_stdout(io.StringIO()):
                rc = main([
                    "inspect", str(frame),
                    "--trusted-key", str(pub),
                    "--route-package", str(route),
                ])
            self.assertEqual(rc, 0)
            ledger_arg = factory.call_args.args[2]
            self.assertIsInstance(ledger_arg, Path)
            self.assertEqual(ledger_arg.name, "replay_ledger.db")
            self.assertNotEqual(str(ledger_arg), ":memory:")


class LegacyAckCompatibilityTests(unittest.TestCase):
    def test_legacy_accepted_ack_is_not_mislabeled_as_rejected(self):
        legacy = Ack(
            stored=True,
            validated=True,
            accepted=True,
            reason="RECEIVER_ACCEPTED",
            transport_sha256="b" * 64,
            destination="accepted",
        )
        payload = _ack_payload_for_cli(legacy)
        self.assertTrue(payload["phase_a_validated"])
        self.assertTrue(payload["phase_b_committed"])
        self.assertIsNone(payload["field_indexed"])
        self.assertIsNone(payload["accepted_and_indexed"])
        self.assertEqual(
            payload["result_summary"],
            "PHASE_B_COMMITTED_FIELD_STATUS_UNREPORTED",
        )
        self.assertEqual(
            payload["phase_fields_source"],
            "legacy_ack_compatibility_inference",
        )


class RichAckTests(unittest.TestCase):
    def test_rich_ack_round_trip_preserves_phase_and_field_facts(self):
        ack = Ack(
            stored=True,
            validated=True,
            accepted=True,
            reason="RECEIVER_ACCEPTED",
            transport_sha256="a" * 64,
            destination="accepted",
            transport_completed=True,
            phase_a_validated=True,
            phase_b_committed=True,
            field_indexed=True,
            accepted_and_indexed=True,
            post_commit_complete=True,
        )
        decoded = decode_ack_from_socket(_FakeSocket(encode_ack(ack)))
        self.assertTrue(decoded.transport_completed)
        self.assertTrue(decoded.phase_a_validated)
        self.assertTrue(decoded.phase_b_committed)
        self.assertTrue(decoded.field_indexed)
        self.assertTrue(decoded.accepted_and_indexed)
        self.assertEqual(decoded.to_dict()["result_summary"], "ACCEPTED_AND_INDEXED")

    def test_ack_decoder_rejects_string_booleans_and_header_mismatch(self):
        malformed = Ack(
            stored="false",  # type: ignore[arg-type]
            validated=True,
            accepted=False,
            reason="RECEIVER_REJECTED",
            transport_sha256="c" * 64,
        )
        with self.assertRaisesRegex(ProtocolError, "ERR_ACK_BOOLEAN:stored"):
            decode_ack_from_socket(_FakeSocket(encode_ack(malformed)))

        valid = Ack(
            stored=True,
            validated=True,
            accepted=True,
            reason="RECEIVER_ACCEPTED",
            transport_sha256="d" * 64,
        )
        raw = bytearray(encode_ack(valid))
        raw[4] = 0
        with self.assertRaisesRegex(ProtocolError, "ERR_ACK_STATUS_MISMATCH"):
            decode_ack_from_socket(_FakeSocket(bytes(raw)))

    def test_network_callback_reports_actual_phase_a_not_transport_parse(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            frame = root / "sample.brad"
            frame.write_bytes(b"not-a-real-frame-but-callback-controls-this-test")

            def rejected_callback(*_args, **_kwargs):
                return {
                    "stored": True,
                    "accepted": False,
                    "phase_a_validated": False,
                    "phase_b_committed": False,
                    "finality": "rejected",
                    "reason": "ERR_VECTOR_NEGATIVE_ZERO",
                }

            config = ReceiverConfig(
                bind="127.0.0.1",
                port=0,
                output_dir=root / "inbox",
                receiver_callback=rejected_callback,
            )
            with TransportServer(config) as server:
                result = send_frame(frame, *server.address)
            self.assertFalse(result.ack.validated)
            self.assertFalse(result.ack.phase_a_validated)
            self.assertFalse(result.ack.phase_b_committed)
            self.assertFalse(result.ack.accepted_and_indexed)

    def test_network_callback_reports_accepted_and_indexed(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            frame = root / "sample.brad"
            frame.write_bytes(b"callback-test-frame")

            def accepted_callback(*_args, **_kwargs):
                return {
                    "stored": True,
                    "accepted": True,
                    "phase_a_validated": True,
                    "phase_b_committed": True,
                    "finality": "committed",
                    "post_commit_complete": True,
                    "reason": "RECEIVER_ACCEPTED",
                    "semantic_transfer": {
                        "semantic_field": {"indexed": True}
                    },
                }

            config = ReceiverConfig(
                bind="127.0.0.1",
                port=0,
                output_dir=root / "inbox",
                receiver_callback=accepted_callback,
            )
            with TransportServer(config) as server:
                result = send_frame(frame, *server.address)
            self.assertTrue(result.ack.validated)
            self.assertTrue(result.ack.phase_a_validated)
            self.assertTrue(result.ack.phase_b_committed)
            self.assertTrue(result.ack.field_indexed)
            self.assertTrue(result.ack.accepted_and_indexed)
            self.assertEqual(result.ack.to_dict()["result_summary"], "ACCEPTED_AND_INDEXED")


class ReconciliationAwareQueryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.storage = Path(self.tmp.name) / "inbox"

    def tearDown(self):
        self.tmp.cleanup()

    def _publish_kestrel_field(self, client: FakeFieldClient):
        _publish_field(
            self.storage,
            label="kestrel-73",
            material=(
                "Project Meridian may enter Kestrel Run only when both Finch readings "
                "are independently signed. The current Finch thermal threshold is 73."
            ),
            client=client,
        )
        _publish_field(
            self.storage,
            label="archive",
            material="Archive rotation and backup retention are reviewed every Friday by operations.",
            client=client,
        )
        _publish_field(
            self.storage,
            label="kestrel-75",
            material=(
                "The Finch thermal threshold is 75. Both readings still require "
                "independent Finch signatures."
            ),
            client=client,
        )

    def test_bad_completion_is_replaced_by_deterministic_guard(self):
        client = _BadCompletionClient()
        self._publish_kestrel_field(client)
        with patch("braid_client.semantic_field.OllamaClient", return_value=client):
            result = query_semantic_field(
                storage_dir=self.storage,
                question=(
                    "What threshold and signature rule govern Kestrel Run? State any "
                    "unresolved conflict."
                ),
                embedding_model=MODEL_A,
                completion_model=COMPLETION,
                top_k=4,
                min_cosine=0.15,
            )
        self.assertEqual(result["reconciliation"]["unresolved_conflict_count"], 1)
        self.assertEqual(result["completion_guard"]["status"], "deterministic_fallback")
        self.assertIn("missing_conflicting_value:75", result["completion_guard"]["violations"])
        self.assertIn("unsupported_unit:fahrenheit", result["completion_guard"]["violations"])
        self.assertEqual(
            result["generation_source"],
            "receiver_local_deterministic_grounding_guard",
        )
        self.assertFalse(result["generative_output"])
        self.assertIn("Unresolved conflict", result["response"])
        self.assertIn("73", result["response"])
        self.assertIn("75", result["response"])
        self.assertNotIn("Fahrenheit", result["response"])
        self.assertIn("Fahrenheit", result["completion_draft"])
        prompt = client.chat_messages[-1][1]["content"]
        self.assertIn("DETERMINISTIC RECONCILIATION ENVELOPE", prompt)
        self.assertIn("do not silently select", prompt)

    def test_completion_cannot_choose_one_value_while_mentioning_both(self):
        client = _ChoosingCompletionClient()
        self._publish_kestrel_field(client)
        with patch("braid_client.semantic_field.OllamaClient", return_value=client):
            result = query_semantic_field(
                storage_dir=self.storage,
                question=(
                    "What threshold and signature rule govern Kestrel Run? State any "
                    "unresolved conflict."
                ),
                embedding_model=MODEL_A,
                completion_model=COMPLETION,
                top_k=4,
                min_cosine=0.15,
            )
        self.assertEqual(result["completion_guard"]["status"], "deterministic_fallback")
        self.assertIn(
            "unsupported_conflict_selection:73",
            result["completion_guard"]["violations"],
        )
        self.assertEqual(
            result["generation_source"],
            "receiver_local_deterministic_grounding_guard",
        )
        self.assertIn("73", result["response"])
        self.assertIn("75", result["response"])
        self.assertNotIn("The governing threshold is 73", result["response"])

    def test_compliant_completion_passes_guard(self):
        client = _GoodCompletionClient()
        self._publish_kestrel_field(client)
        with patch("braid_client.semantic_field.OllamaClient", return_value=client):
            result = query_semantic_field(
                storage_dir=self.storage,
                question=(
                    "What threshold and signature rule govern Kestrel Run? State any "
                    "unresolved conflict."
                ),
                embedding_model=MODEL_A,
                completion_model=COMPLETION,
                top_k=4,
                min_cosine=0.15,
            )
        self.assertEqual(result["completion_guard"]["status"], "passed")
        self.assertEqual(result["generation_source"], "receiver_local_completion_model")
        self.assertTrue(result["generative_output"])
        self.assertEqual(result["response"], result["completion_draft"])
        self.assertIn("73", result["response"])
        self.assertIn("75", result["response"])


if __name__ == "__main__":
    unittest.main()
