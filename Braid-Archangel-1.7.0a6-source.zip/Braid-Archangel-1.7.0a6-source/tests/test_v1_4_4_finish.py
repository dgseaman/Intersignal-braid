"""Finish-line regression tests for Braid Client v1.4.4."""

import base64
import json
import shutil
import subprocess
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from braid_client.keys import (
    get_raw_private_bytes,
    get_raw_public_bytes,
    load_or_create_signing_key,
    load_signing_key,
    load_verification_key,
)
from braid_client.mcp_core.protocol import BraidFrame
from braid_client.qr_engine import (
    QRCapacityError,
    StandardQRCodeEncoder,
    chunk_binary_frame,
    decode_qr_raster,
    rasterize_qr_matrix,
)
from braid_client.server import (
    CHUNK_COLLECTOR,
    HardenedBraidHTTPHandler,
    create_authoritative_validator,
    evaluate_normative_receiver_gates,
    generate_frame_object,
    serve_http_app,
)


class TestFinishLineV144(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.sk, _, _ = load_or_create_signing_key(str(Path(self.tmp.name) / "sender.key"))
        self.vk = self.sk.public_key()
        self.validator, self.registry, _ = create_authoritative_validator(
            get_raw_public_bytes(self.vk).hex()
        )

    def tearDown(self):
        self.tmp.cleanup()

    def test_raw_private_key_whitespace_bytes_are_not_stripped(self):
        raw = (b"\x01" * 31) + b"\n"
        path = Path(self.tmp.name) / "raw-private.key"
        path.write_bytes(raw)
        path.chmod(0o600)
        loaded = load_signing_key(str(path))
        self.assertEqual(get_raw_private_bytes(loaded), raw)

    def test_raw_public_key_whitespace_bytes_are_not_stripped(self):
        raw = b" " + (b"\x01" * 31)
        path = Path(self.tmp.name) / "raw-public.pub"
        path.write_bytes(raw)
        loaded = load_verification_key(str(path))
        self.assertEqual(get_raw_public_bytes(loaded), raw)

    def test_companion_public_key_is_repaired_atomically(self):
        key_path = Path(self.tmp.name) / "repair.key"
        sk, _, pub_path = load_or_create_signing_key(str(key_path))
        expected = get_raw_public_bytes(sk.public_key())
        pub = Path(pub_path)

        pub.write_bytes(b"malformed")
        loaded, _, repaired_path = load_or_create_signing_key(str(key_path))
        self.assertEqual(get_raw_private_bytes(loaded), get_raw_private_bytes(sk))
        self.assertEqual(Path(repaired_path).read_bytes(), expected)

        other = load_or_create_signing_key(str(Path(self.tmp.name) / "other.key"))[0]
        pub.write_bytes(get_raw_public_bytes(other.public_key()))
        loaded_again, _, repaired_again = load_or_create_signing_key(str(key_path))
        self.assertEqual(get_raw_private_bytes(loaded_again), get_raw_private_bytes(sk))
        self.assertEqual(Path(repaired_again).read_bytes(), expected)

    def test_repeated_raw_key_generation_and_reload_is_stable(self):
        for index in range(96):
            path = Path(self.tmp.name) / f"loop-{index}.key"
            sk, _, pub_path = load_or_create_signing_key(str(path))
            self.assertEqual(
                get_raw_private_bytes(load_signing_key(str(path))),
                get_raw_private_bytes(sk),
            )
            self.assertEqual(
                get_raw_public_bytes(load_verification_key(pub_path)),
                get_raw_public_bytes(sk.public_key()),
            )

    def test_qr_capacity_fails_closed(self):
        with self.assertRaises(QRCapacityError):
            StandardQRCodeEncoder("X" * 5000)

    def test_chunk_size_validation(self):
        raw = b"a" * 1024
        for invalid in (0, -4, 121, 3, True, 4.5):
            with self.subTest(invalid=invalid):
                with self.assertRaises((ValueError, TypeError, QRCapacityError)):
                    chunk_binary_frame(raw, max_chunk_size=invalid)

    def test_python_qr_image_channel_exact_decode_and_quiet_zone(self):
        text = "BRAD1:deadbeef:1:0:00000000:QUJDRA=="
        qr = StandardQRCodeEncoder(text)
        image = rasterize_qr_matrix(qr.matrix, module_scale=8, quiet_zone_modules=4)
        self.assertEqual(decode_qr_raster(image), text)
        border = 4 * 8
        self.assertTrue(np.all(image[:border, :] == 255))
        self.assertTrue(np.all(image[-border:, :] == 255))
        self.assertTrue(np.all(image[:, :border] == 255))
        self.assertTrue(np.all(image[:, -border:] == 255))

    def test_independent_gate_evidence_on_ood_rejection(self):
        frame, _, _ = generate_frame_object(noise_std=1.5, signing_key=self.sk)
        gates = evaluate_normative_receiver_gates(
            frame, self.vk, self.validator, self.registry
        )
        self.assertTrue(gates["gate1_signature"]["passed"])
        self.assertTrue(gates["gate2_representation"]["passed"])
        self.assertFalse(gates["gate3_anomaly"]["passed"])
        self.assertFalse(gates["overall_accepted"])
        self.assertEqual(gates["validation_phase"], "phase_a_non_locking")
        self.assertFalse(gates["phase_a"]["replay_safe_commit"])
        self.assertIsInstance(gates["gate3_anomaly"]["subspace_residual"], float)
        self.assertIsInstance(gates["gate3_anomaly"]["mahalanobis_dist"], float)
        self.assertNotEqual(gates["gate3_anomaly"]["subspace_residual"], 0.75)
        self.assertNotEqual(gates["gate3_anomaly"]["mahalanobis_dist"], 0.51)

    def test_browser_camera_receiver_native_decode_and_dedupe(self):
        if not shutil.which("node"):
            self.skipTest("node is not installed")
        module_path = ROOT / "braid_client" / "static" / "camera_receiver.js"
        script = f"""
const Receiver = require({json.dumps(str(module_path))});
let ingested = [];
let statuses = [];
const chunk = 'BRAD1:deadbeef:1:0:00000000:QUJDRA==';
class Detector {{
  static async getSupportedFormats() {{ return ['qr_code']; }}
  async detect() {{ return [{{rawValue: chunk}}]; }}
}}
const video = {{videoWidth:640, videoHeight:480, srcObject:null, async play(){{}}}};
const ctx = {{drawImage(){{}}}};
const canvas = {{width:1,height:1,getContext(){{return ctx;}},toDataURL(){{return 'data:image/jpeg;base64,';}}}};
const stream = {{getTracks(){{return [{{stop(){{}}}}];}}}};
const r = new Receiver({{
  video, canvas, BarcodeDetectorCtor:Detector,
  mediaDevices:{{async getUserMedia(){{return stream;}}}},
  schedule:() => 1, cancelSchedule:() => {{}},
  ingest:async text => ingested.push(text),
  onStatus:s => statuses.push(s), now:(() => {{let n=1000; return () => ++n;}})()
}});
(async() => {{
  await r.start();
  await r._scanOnce();
  await r._scanOnce();
  r.stop();
  console.log(JSON.stringify({{ingested, metrics:r.metrics, backend:r.backend, statuses}}));
}})().catch(e => {{console.error(e); process.exit(1);}});
"""
        result = subprocess.run(["node", "-e", script], capture_output=True, text=True, check=True)
        data = json.loads(result.stdout.strip())
        self.assertEqual(data["backend"], "native-barcode-detector")
        self.assertEqual(data["ingested"], ["BRAD1:deadbeef:1:0:00000000:QUJDRA=="])
        self.assertEqual(data["metrics"]["accepted"], 1)
        self.assertGreaterEqual(data["metrics"]["duplicates"], 1)

    def test_python_qr_renderer_decodes_versions_11_and_12(self):
        for text, expected_version in (("A" * 230, 11), ("B" * 270, 12)):
            qr = StandardQRCodeEncoder(text)
            self.assertEqual(qr.version, expected_version)
            image = rasterize_qr_matrix(qr.matrix, module_scale=8, quiet_zone_modules=4)
            self.assertEqual(decode_qr_raster(image), text)

    def test_full_field_ui_inline_javascript_parses(self):
        if not shutil.which("node"):
            self.skipTest("node is not installed")
        html = (ROOT / "braid_client" / "static" / "braid_visualizer.html").read_text(encoding="utf-8")
        inline = []
        pos = 0
        while True:
            start = html.find("<script", pos)
            if start < 0:
                break
            tag_end = html.find(">", start)
            end = html.find("</script>", tag_end)
            tag = html[start:tag_end + 1]
            if "src=" not in tag:
                inline.append(html[tag_end + 1:end])
            pos = end + len("</script>")
        self.assertTrue(inline)
        result = subprocess.run(["node", "--check", "-"], input="\n".join(inline), capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_field_ui_refuses_non_loopback_bind(self):
        with self.assertRaisesRegex(ValueError, "ERR_FIELD_UI_LOOPBACK_ONLY"):
            serve_http_app("0.0.0.0", 0)

    def test_browser_qr_renderer_decodes_v1_to_v12_and_oversize_rejects(self):
        if not shutil.which("node"):
            self.skipTest("node is not installed")
        html_path = ROOT / "braid_client" / "static" / "braid_visualizer.html"
        html = html_path.read_text(encoding="utf-8")
        start = html.index("const QRCodeStandard =")
        end = html.index("window.__BraidQR = QRCodeStandard;") + len("window.__BraidQR = QRCodeStandard;")
        engine = html[start:end]
        texts = [
            "BRAD1:deadbeef:1:0:00000000:QUJDRA==",
            "A" * 230,  # Version 11-M
            "B" * 270,  # Version 12-M
        ]
        script = f"""
let rects = [];
const ctx = {{fillStyle:'#fff', imageSmoothingEnabled:true, fillRect(x,y,w,h){{if(this.fillStyle === '#000000') rects.push([x,y,w,h]);}}}};
global.document = {{createElement(){{return {{width:0,height:0,dataset:{{}},getContext(){{return ctx;}}}};}}}};
global.window = {{}};
{engine}
let oversized = false;
try {{ QRCodeStandard.createQR('X'.repeat(5000)); }} catch(e) {{ oversized = String(e.message).includes('ERR_QR_CAPACITY'); }}
const outputs = [];
for (const text of {json.dumps(texts)}) {{
  rects = [];
  const canvas = QRCodeStandard.createQR(text);
  outputs.push({{width:canvas.width,height:canvas.height,dataset:canvas.dataset,rects:[...rects],text}});
}}
console.log(JSON.stringify({{outputs,oversized}}));
"""
        result = subprocess.run(["node", "-e", script], capture_output=True, text=True, check=True)
        data = json.loads(result.stdout.strip())
        self.assertTrue(data["oversized"])
        versions = []
        for output in data["outputs"]:
            self.assertEqual(output["width"], 292)
            self.assertGreaterEqual(int(output["dataset"]["quietZoneModules"]), 4)
            versions.append(int(output["dataset"]["qrVersion"]))
            image = np.full((output["height"], output["width"]), 255, dtype=np.uint8)
            for x, y, w, h in output["rects"]:
                self.assertTrue(all(float(v).is_integer() for v in (x, y, w, h)))
                x, y, w, h = map(int, (x, y, w, h))
                image[y:y+h, x:x+w] = 0
            self.assertEqual(decode_qr_raster(image), output["text"])
        self.assertEqual(versions[-2:], [11, 12])


class TestFinishLineHTTPV144(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.sk, _, _ = load_or_create_signing_key(str(Path(cls.tmp.name) / "sender.key"))
        cls.vk = cls.sk.public_key()
        cls.validator, cls.registry, _ = create_authoritative_validator(
            get_raw_public_bytes(cls.vk).hex()
        )
        Handler = HardenedBraidHTTPHandler
        Handler.signing_key = cls.sk
        Handler.verification_key = cls.vk
        Handler.validator = cls.validator
        Handler.registry = cls.registry
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.base = f"http://127.0.0.1:{cls.httpd.server_address[1]}"
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.thread.join(timeout=3)
        cls.tmp.cleanup()

    def setUp(self):
        CHUNK_COLLECTOR.reset_session()

    def post(self, path, payload):
        req = urllib.request.Request(
            self.base + path,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=5) as response:
                return response.status, json.loads(response.read())
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read())

    def test_malformed_completed_stream_returns_bounded_400(self):
        chunks = chunk_binary_frame(b"not-a-braid-frame", max_chunk_size=120)
        status = None
        body = None
        for chunk in chunks:
            status, body = self.post("/api/ingest_chunk", {"chunk_str": chunk["chunk_str"]})
        self.assertEqual(status, 400)
        self.assertEqual(body["error"], "ERR_REASSEMBLED_FRAME_INVALID")
        # Handler remains alive after the rejection.
        with urllib.request.urlopen(self.base + "/", timeout=5) as response:
            self.assertEqual(response.status, 200)

    def test_loopback_camera_decoder_accepts_real_jpeg_qr(self):
        import cv2
        text = "BRAD1:deadbeef:1:0:00000000:QUJDRA=="
        qr = StandardQRCodeEncoder(text)
        image = rasterize_qr_matrix(qr.matrix, module_scale=8, quiet_zone_modules=4)
        ok, encoded = cv2.imencode(".jpg", image, [int(cv2.IMWRITE_JPEG_QUALITY), 82])
        self.assertTrue(ok)
        self.assertLess(len(encoded), 75000)
        status, body = self.post(
            "/api/decode_qr",
            {"image_base64": base64.b64encode(encoded.tobytes()).decode("ascii")},
        )
        self.assertEqual(status, 200)
        self.assertEqual(body["status"], "success")
        self.assertEqual(body["text"], text)

    def test_local_ui_rejects_cross_origin_browser_context(self):
        req = urllib.request.Request(self.base + "/", headers={"Origin": "https://evil.example"})
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=5)
        self.assertEqual(ctx.exception.code, 403)
        body = json.loads(ctx.exception.read())
        self.assertEqual(body["error"], "ERR_LOCAL_UI_CONTEXT")

    def test_post_requires_json_content_type(self):
        req = urllib.request.Request(
            self.base + "/api/reset_collector",
            data=b"{}",
            headers={"Content-Type": "text/plain"},
            method="POST",
        )
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=5)
        self.assertEqual(ctx.exception.code, 415)
        body = json.loads(ctx.exception.read())
        self.assertEqual(body["error"], "ERR_JSON_CONTENT_TYPE_REQUIRED")

    def test_oversized_qr_returns_400_not_fallback(self):
        status, body = self.post("/api/qr", {"data": "X" * 5000})
        self.assertEqual(status, 400)
        self.assertEqual(body["error"], "ERR_QR_CAPACITY")


if __name__ == "__main__":
    unittest.main()
