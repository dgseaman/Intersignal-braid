"""Offline Chromium + real service bridge. Synthetic fields and local model fixture.
This is not a physical rig run, camera scan, native browser, or browser HTTP test.
"""
import copy,json,shutil,sys,tempfile,time,uuid
from pathlib import Path
from playwright.sync_api import sync_playwright
from cryptography.hazmat.primitives.asymmetric import ed25519
import braid_client.channel_chat as cc
import braid_client.semantic_field as sf
from braid_client.messenger import MessengerService
from tests.test_v1_7_0_semantic_field import FakeFieldClient,_publish_field,MODEL_A,COMPLETION
ROOT=Path(__file__).resolve().parents[1]/'braid_client/static'
OUT=Path(sys.argv[1]);OUT.mkdir(parents=True,exist_ok=True)
checks=[];errors=[]
def check(name,value):
    checks.append({'name':name,'passed':bool(value)})
    assert value,name
class Model(FakeFieldClient):
    def chat(self,model,messages,**kwargs):
        self.chat_messages.append(copy.deepcopy(messages))
        return {'message':{'content':'The Finch thermal threshold is 73. Both readings require independent Finch signatures before Project Meridian may enter Kestrel Run.'}}
client=Model();cc.OllamaClient=lambda *a,**k:client;sf.OllamaClient=lambda *a,**k:client
with tempfile.TemporaryDirectory() as tmp:
    service=MessengerService(ed25519.Ed25519PrivateKey.generate(),Path(tmp)/'inbox',Path(tmp)/'home')
    service.settings.update(name='Linux lab - UI fixture',embed_model=MODEL_A,completion_model=COMPLETION)
    peer={'id':'a'*64,'name':'MacBook Air - fixture','host':'127.0.0.1','port':8746,'capabilities':['channels.v1'],'public_key':'b'*64}
    service.contacts=lambda:[peer]
    c=service.create_channel('Cobalt','Decisions, constraints, and the evidence behind them.')
    c=service.update_channel(c['id'],dict(receive_from=[peer['id']],use_in_chat=True),c['revision'])
    texts=['The Finch thermal threshold is 73.','Both Finch readings require independent signatures.',
           'Project Meridian may enter Kestrel Run only after both Finch readings are independently signed.']
    for i,text in enumerate(texts):
        digest,_,_=_publish_field(service.inbox,label=str(i),material=text,client=client)
        with service._db() as db:db.execute('INSERT INTO c6_objects VALUES (?,?,?,?,?,?,?)',(digest,c['id'],uuid.uuid4().hex,peer['id'],0,time.time(),'{}'))
    def api(path,data=None):
        endpoint=path.split('/api/messenger/')[-1];data=data or {}
        try:
            if endpoint=='state':result=service.snapshot()
            elif endpoint.startswith('job?'):result=service.job(endpoint.split('id=')[-1])
            elif endpoint=='channel':
                action=data.get('action');result=service.submit('channel fixture',lambda:service.channel_action(action,data)) if action in ('publish','reconcile','import-frame') else service.channel_action(action,data)
            elif endpoint=='chat':
                action=data.get('action');result=service.submit('chat fixture',lambda:service.chat_action(action,data)) if action=='turn' else service.chat_action(action,data)
            elif endpoint=='models':result={'models':[{'name':COMPLETION,'local_eligible':True}]}
            elif endpoint=='draft':service.set_value('draft',data['draft']);result={'saved':True}
            else:result={}
            return {'status':200,'data':result}
        except Exception as e:return {'status':400,'data':{'message':str(e)}}
    with sync_playwright() as pw:
        browser=pw.chromium.launch(headless=True,executable_path=shutil.which('chromium'),args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1280,'height':900})
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.on('dialog',lambda d:d.accept())
        page.expose_function('channelFixtureAPI',api)
        html=(ROOT/'messenger.html').read_text()
        for name in ('messenger','channels'):
            html=html.replace('<link rel="stylesheet" href="/static/'+name+'.css">','<style>'+(ROOT/(name+'.css')).read_text()+'</style>')
            html=html.replace('<script src="/static/'+name+'.js"></script>','')
        page.set_content(html)
        page.evaluate('''() => {
            window.fetch=async(url,options={})=>{const r=await window.channelFixtureAPI(String(url),options.body?JSON.parse(options.body):null);return new Response(JSON.stringify(r.data),{status:r.status,headers:{'Content-Type':'application/json'}});};
            if(!crypto.randomUUID)Object.defineProperty(crypto,'randomUUID',{value:()=>Array.from(crypto.getRandomValues(new Uint8Array(16))).map(x=>x.toString(16).padStart(2,'0')).join('')});
        }''')
        for name in ('messenger','channels'):page.add_script_tag(content=(ROOT/(name+'.js')).read_text())
        page.wait_for_selector('[data-channel]')
        # Visible test-only banner, never packaged as a real network claim.
        page.evaluate("document.querySelector('#previewBanner').hidden=false;document.querySelector('#previewBanner').textContent='INTERFACE TEST - synthetic notes and local model fixture; not a new physical rig demonstration.'")
        page.click('[data-channel="'+c['id']+'"]')
        check('channel chat is visible',page.locator('#channelChat').is_visible())
        check('outgoing automation is not enabled',not page.locator('#autoChat').is_checked())
        page.fill('#chatInput','What are the Finch threshold and signature requirements for Kestrel Run?')
        page.click('#sendChat')
        page.wait_for_function("document.querySelector('.shared-notes summary')?.textContent.includes('Using 3 shared notes')",timeout=15000)
        check('three actual atoms supplied',len(client.chat_messages)==1)
        page.screenshot(path=str(OUT/'channels-desktop.png'),full_page=True)
        page.click('.shared-notes summary')
        check('exact sources expand',page.locator('.evidence-note').count()==3)
        check('source rig is visible','MacBook Air - fixture' in page.locator('.evidence-body').inner_text())
        page.screenshot(path=str(OUT/'channels-evidence.png'),full_page=True)
        # Check note-writing/review without transmitting fixture material.
        page.click('#writeChannelNote');page.fill('#channelNoteText','A locally authored note for UI testing.')
        page.click('#reviewChannelNote')
        page.wait_for_function("document.querySelector('#channelNoteText').readOnly")
        check('review freezes exact text',page.locator('#channelNoteText').get_attribute('readonly') is not None)
        check('destinations explicit','No outgoing destinations' in page.locator('#noteDestinations').inner_text())
        page.click('#channelNoteDialog [data-channel-close]')
        # Create a new channel via production UI and save local policies.
        page.click('#newChannel');page.fill('#channelName','Labnotes');page.fill('#channelDescription','Focused experiments')
        page.click('#createChannelButton');page.wait_for_selector('#channelPolicy:not([hidden])')
        check('import/create grants no send access',not page.locator('[data-send-peer]').is_checked())
        check('import/create grants no receive access',not page.locator('[data-receive-peer]').is_checked())
        check('context initially off',not page.locator('#channelUse').is_checked())
        page.check('#channelUse');page.select_option('#channelMode','suggest');page.fill('#channelKeywords','Labnotes')
        page.click('#saveChannelPolicy');page.wait_for_function("!document.querySelector('#channelDialog').open")
        new=next(x for x in service.channel_list() if x['descriptor']['name']=='Labnotes')
        check('UI policy persisted',new['policy']['use_in_chat'] and new['policy']['mode']=='suggest')
        # Return to existing thread, opt out of shared context, inspect real zero count.
        page.click('[data-channel="'+c['id']+'"]');page.uncheck('#useShared')
        page.fill('#chatInput','What is a good next step?');page.click('#sendChat')
        page.wait_for_function("document.querySelectorAll('.shared-notes').length===2 && document.querySelector('#sendChat').textContent==='Send'",timeout=15000)
        check('optout produces zero shared context','No shared notes used' in page.locator('.shared-notes').last.inner_text())
        t=service.thread(service.channel_view(c['id'])['threads'][0]['id'])
        check('history resets on optout',t['turns'][-1]['payload']['result']['history_message_count']==0)
        for width in (320,390,768,1024,1280):
            page.set_viewport_size({'width':width,'height':900 if width>500 else 844})
            check('no page overflow '+str(width),page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
            check('composer visible '+str(width),page.locator('#chatInput').is_visible())
        page.set_viewport_size({'width':390,'height':844})
        page.screenshot(path=str(OUT/'channels-mobile.png'),full_page=True)
        page.click('#channelSettings')
        check('mobile policy panel visible',page.locator('#channelPolicy').is_visible())
        check('mobile policy no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
        page.screenshot(path=str(OUT/'channel-policy-mobile.png'),full_page=True)
        check('no JavaScript exceptions',not errors)
        browser.close()
    service.close()
(OUT/'browser-results.json').write_text(json.dumps({'checks':checks,'passed':sum(x['passed'] for x in checks),'javascript_errors':errors,'method':'Production UI offline in Chromium with a direct test bridge into the actual service and SQLite. Synthetic source records and fixture LLM. Browser HTTP navigation is blocked; live HTTP tested separately.'},indent=2))
print('PASS',len(checks),'browser checks')
