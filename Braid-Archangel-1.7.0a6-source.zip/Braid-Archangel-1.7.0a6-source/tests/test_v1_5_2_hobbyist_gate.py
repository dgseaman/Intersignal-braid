from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from braid_client import environment
from braid_client.ollama_adapter import OllamaClient, is_explicit_cloud_model


class HobbyistGateV152Tests(unittest.TestCase):
    def test_cloud_model_names_are_rejected_even_through_loopback(self):
        self.assertTrue(is_explicit_cloud_model("gpt-oss:120b-cloud"))
        self.assertTrue(is_explicit_cloud_model("example:cloud"))
        self.assertFalse(is_explicit_cloud_model("deepseek-v4-flash:latest"))
        client = OllamaClient("http://127.0.0.1:11434", timeout_seconds=0.1)
        with self.assertRaisesRegex(ValueError, "ERR_OLLAMA_CLOUD_MODEL_REJECTED"):
            client.inspect_local_model("gpt-oss:120b-cloud", capability="completion")

    def test_ollama_reported_remote_markers_are_rejected_even_for_local_looking_aliases(self):
        model = "friendly-local-name:latest"
        digest = "a" * 64
        client = OllamaClient("http://127.0.0.1:11434", timeout_seconds=0.1)
        with mock.patch.object(client, "tags", return_value=[{"name": model, "digest": digest, "remote_host": "https://ollama.com"}]):
            with self.assertRaisesRegex(RuntimeError, "ERR_OLLAMA_REMOTE_MODEL_REJECTED"):
                client.inspect_local_model(model, capability="completion")
        with mock.patch.object(client, "tags", return_value=[{"name": model, "digest": digest}]), \
             mock.patch.object(client, "show", return_value={"capabilities": ["completion"], "remote_model": "upstream"}):
            with self.assertRaisesRegex(RuntimeError, "ERR_OLLAMA_REMOTE_MODEL_REJECTED"):
                client.inspect_local_model(model, capability="completion")

    def test_runtime_response_remote_marker_fails_closed(self):
        model = "friendly-local-name:latest"
        client = OllamaClient("http://127.0.0.1:11434", timeout_seconds=0.1)
        with mock.patch.object(client, "inspect_local_model", return_value={}), \
             mock.patch.object(client, "_request", return_value={"remote_host": "https://ollama.com", "message": {"content": "nope"}}):
            with self.assertRaisesRegex(RuntimeError, "ERR_OLLAMA_REMOTE_MODEL_REJECTED"):
                client.chat(model, [{"role": "user", "content": "hello"}])

    def test_environment_classifies_models_from_api_show_capabilities_not_name_heuristics(self):
        class FakeClient:
            def __init__(self, *_a, **_k): pass
            def tags(self):
                return [
                    {"name": "totally-not-named-like-an-embedder:latest", "digest": "1" * 64},
                    {"name": "embed-looking-chat:latest", "digest": "2" * 64},
                    {"name": "gpt-oss:120b-cloud", "digest": "3" * 64},
                    {"name": "innocent-alias:latest", "digest": "4" * 64, "remote_host": "https://ollama.com"},
                ]
            def show(self, name):
                if name.startswith("totally"):
                    return {"capabilities": ["embedding"], "details": {"format": "gguf"}}
                return {"capabilities": ["completion"], "details": {"format": "gguf"}}
        with mock.patch("braid_client.environment.OllamaClient", FakeClient), \
             mock.patch("braid_client.environment._ollama_cloud_config_snapshot", return_value={"local_only_configuration_detected": False}):
            snap = environment._ollama_snapshot()
        self.assertEqual(snap["embedding_candidates"], ["totally-not-named-like-an-embedder:latest"])
        self.assertEqual(snap["completion_candidates"], ["embed-looking-chat:latest"])
        self.assertEqual(snap["rejected_cloud_models"], ["gpt-oss:120b-cloud", "innocent-alias:latest"])
        self.assertEqual(snap["classification"], "api_show_capabilities")

    def test_cli_commands_use_actual_same_install_invocation(self):
        with tempfile.TemporaryDirectory() as td:
            app_bin = Path(td) / "Braid.app" / "Contents" / "MacOS"
            app_bin.mkdir(parents=True)
            gui = app_bin / "Braid"
            cli = app_bin / "braid-client"
            gui.write_text("")
            cli.write_text("")
            cli.chmod(0o755)
            with mock.patch.object(environment.sys, "frozen", True, create=True), \
                 mock.patch.object(environment.sys, "executable", str(gui)):
                argv = environment._cli_argv()
            self.assertEqual(argv, [str(cli.resolve())])

    def test_release_packaging_builds_real_cli_and_pins_inputs(self):
        root = Path(__file__).parents[1]
        script = (root / "packaging/macos/build_standalone_app.sh").read_text()
        req = (root / "packaging/macos/release-requirements.txt").read_text()
        pyproject = (root / "pyproject.toml").read_text()
        self.assertIn("--onefile --console --name braid-client", script.replace("\\\n", " "))
        self.assertIn('cp "$BUILDROOT/cli-dist/braid-client" "$APP/Contents/MacOS/braid-client"', script)
        self.assertIn("CPython 3.12.10", script)
        self.assertIn("pip==26.1.2", req)
        self.assertIn("pyinstaller==6.21.0", req)
        self.assertIn("pyinstaller-hooks-contrib==2026.6", req)
        self.assertIn("opencv-python-headless==4.13.0.92", req)
        self.assertIn("bleak==3.0.2", req)
        self.assertIn('arm64) MIN_OS=13.0', script)
        self.assertIn('x86_64) MIN_OS=14.0', script)
        self.assertIn('release-wheelhouse-sha256.txt', script)
        self.assertIn('pip download', script)
        self.assertIn('--no-index --find-links', script)
        self.assertIn('"jsonschema>=4.18.0"', pyproject)
        verifier = (root / "packaging/macos/verify_release_macos.sh").read_text()
        release = (root / "packaging/macos/build_release_macos.sh").read_text()
        self.assertIn('Contents/MacOS/braid-client', verifier)
        self.assertIn('release-wheelhouse-sha256.txt', verifier)
        self.assertIn('"$CLI" environment', verifier)
        self.assertIn('verify_release_macos.sh', release)


    def test_generated_commands_are_executable_same_install_and_route_count_is_valid(self):
        class FakeClient:
            def __init__(self, *_a, **_k): pass
            def tags(self):
                return [{"name": "odd-name:latest", "digest": "1" * 64}]
            def show(self, _name):
                return {"capabilities": ["embedding", "completion"], "details": {}}
        with mock.patch("braid_client.environment.OllamaClient", FakeClient), \
             mock.patch("braid_client.environment._cli_argv", return_value=["/Applications/Braid.app/Contents/MacOS/braid-client"]), \
             mock.patch("braid_client.environment._ollama_cloud_config_snapshot", return_value={"local_only_configuration_detected": True}):
            report = environment.detect_environment()
        commands = {item["label"]: item["command"] for item in report["commands"]}
        self.assertTrue(all(cmd.startswith("/Applications/Braid.app/Contents/MacOS/braid-client ") for cmd in commands.values()))
        self.assertIn("--count 576", commands["Build exact source route"])
        self.assertIn("demo --port 0", commands["Open field UI"])
        self.assertIn("Send capsule to this node", commands)
        self.assertEqual(report["cli"]["argv"], ["/Applications/Braid.app/Contents/MacOS/braid-client"])

    def test_visualizer_surfaces_cli_locality_and_optional_hardware_status(self):
        root = Path(__file__).parents[1]
        html = (root / "braid_client/static/braid_visualizer.html").read_text()
        self.assertIn("<span>CLI</span>", html)
        self.assertIn("<span>local policy</span>", html)
        self.assertIn("<span>camera</span>", html)
        self.assertIn("<span>BLE</span>", html)
        self.assertIn("No capsule, no guess.", html)

    def test_bootstrap_contains_sibling_cli(self):
        root = Path(__file__).parents[1]
        cli = root / "packaging/macos/bootstrap/Braid.app/Contents/MacOS/braid-client"
        self.assertTrue(cli.is_file())
        self.assertTrue(os.access(cli, os.X_OK))
        manifest = (root / "MANIFEST.in").read_text()
        self.assertIn("Contents/MacOS/braid-client", manifest)

    def test_cloud_disable_config_is_reported_without_claiming_server_attestation(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            (home / ".ollama").mkdir()
            (home / ".ollama/server.json").write_text(json.dumps({"disable_ollama_cloud": True}))
            with mock.patch("pathlib.Path.home", return_value=home), mock.patch.dict(os.environ, {}, clear=True):
                from braid_client.ollama_adapter import _ollama_cloud_config_snapshot
                snap = _ollama_cloud_config_snapshot()
            self.assertTrue(snap["disabled_by_config_file"])
            self.assertTrue(snap["local_only_configuration_detected"])


if __name__ == "__main__":
    unittest.main()
