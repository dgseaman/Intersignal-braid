"""a6 protocol/policy and real loopback handoffs. Embeddings are test fixtures."""
import base64
import copy
import hashlib
import json
import time
import uuid
from pathlib import Path
from unittest.mock import Mock

import pytest
from cryptography.hazmat.primitives.asymmetric import ed25519

import braid_client.messenger as core
from braid_client.context_workflow import ContextWorkflowError
from braid_client.channel_protocol import (create_channel_descriptor, validate_channel_descriptor,
    note_extension, extract_channel_note, validate_note_extension, label, EXTENSION)
from braid_client.messenger import MessengerService
from braid_client.semantic_capsule import SemanticCapsuleHandoffConfig
from braid_client.semantic_transfer import build_frame_from_text
from braid_client.mcp_core.protocol import BraidFrame
from braid_client.semantic_field import inspect_semantic_field
from tests.test_v1_7_0a4_messenger import route, approve, free_port
from tests.test_v1_5_2_semantic_capsule import FakeOllama, SOURCE

@pytest.fixture
def pair(tmp_path, monkeypatch, route):
    fake=FakeOllama()
    monkeypatch.setattr(core,'SemanticCapsuleHandoffConfig',lambda **kw: SemanticCapsuleHandoffConfig(base_url=fake.url,timeout_seconds=5,**kw))
    monkeypatch.setattr(core,'build_frame_from_text',lambda path,text,key,**kw: build_frame_from_text(path,text,key,ollama_url=fake.url,**kw))
    vals=[]
    for name in ('Mac fixture','Linux fixture'):
        s=MessengerService(ed25519.Ed25519PrivateKey.generate(),tmp_path/name/'inbox',tmp_path/name/'desk')
        s.save_settings(dict(name=name,host='127.0.0.1',port=free_port(),embed_model=SOURCE,route_path=str(route)))
        vals.append(s)
    a,b=vals;approve(a,b);approve(b,a)
    yield a,b,fake
    for s in vals:s.close()
    fake.close()

def policy(s,ch,**changes):
    current=s.channel(ch['id'])
    return s.update_channel(ch['id'],changes,current['revision'],authorize_automatic=changes.get('mode')=='automatic_marked')

def linked(pair):
    a,b,f=pair;c=a.create_channel('Cobalt','Project decisions')
    b.import_channel(c['descriptor'],confirmed=True)
    c=policy(a,c,send_to=[b.fingerprint],use_in_chat=True)
    policy(b,c,receive_from=[a.fingerprint],use_in_chat=True)
    return a,b,f,c

def local_note(a,c,text='Project Cobalt launch color is amber.'):
    return a.publish_note(a.new_note(c['id'],text)['id'],confirmed=True)

def test_descriptor_signature_identity_and_no_name_collision():
    k=ed25519.Ed25519PrivateKey.generate()
    d=create_channel_descriptor(k,'#Cobalt','Decisions');other=create_channel_descriptor(k,'Cobalt','Decisions')
    assert validate_channel_descriptor(d)==d and d['id']!=other['id']
    assert d['name']=='Cobalt'

@pytest.mark.parametrize('field,value',[('name','Other'),('description','Another scope'),('id','0'*64),('nonce','0'*32),('creator_key','f'*64),('signature','0'*128),('schema','unknown')])
def test_descriptor_tampering(field,value):
    d=create_channel_descriptor(ed25519.Ed25519PrivateKey.generate(),'Cobalt');d[field]=value
    with pytest.raises(ValueError):validate_channel_descriptor(d)

@pytest.mark.parametrize('value',['','#','###','\nsecret','x'*65,None,42])
def test_label_bounds(value):
    with pytest.raises(ValueError):label(value)

def test_note_content_binding_and_no_policy_embedded():
    d=create_channel_descriptor(ed25519.Ed25519PrivateKey.generate(),'Cobalt')
    e=note_extension(d,uuid.uuid4().hex,'amber')
    assert extract_channel_note({'extensions':{EXTENSION:e}},'amber')==e
    assert extract_channel_note({'extensions':{}},'amber') is None
    for altered in ({**e,'content_sha256':'f'*64},{**e,'origin':'model-output'},{**e,'note_id':'oops'},{**e,'send_to':['attacker']}):
        with pytest.raises(ValueError):validate_note_extension(altered,'amber')
    with pytest.raises(ValueError):validate_note_extension(e,'blue')

def test_default_import_is_review_no_grants(pair):
    a,b,_=pair;c=a.create_channel('Cobalt')
    assert c['policy']==dict(send_to=[],receive_from=[],use_in_chat=False,mode='manual',keywords=[],paused=False,archived=False,hourly_limit=6)
    r=b.import_channel(c['descriptor']);assert r['review'] and b.channel_list()==[]
    b.import_channel(c['descriptor'],confirmed=True)
    assert b.channel_scope(c['id'],True)[0]==set()
    ch=policy(b,c,receive_from=[a.fingerprint],use_in_chat=True)
    b.import_channel(c['descriptor'],confirmed=True)
    assert b.channel(c['id'])['policy']==ch['policy']

@pytest.mark.parametrize('changes',[{'send_to':['unknown']},{'receive_from':['unknown']},{'use_in_chat':1},{'paused':'false'},{'hourly_limit':0},{'hourly_limit':13},{'keywords':['x']*13},{'mode':'all-chats'},{'surprise':True}])
def test_invalid_policy_does_not_change_state(pair,changes):
    a,b,_=pair;c=a.create_channel('Cobalt')
    with pytest.raises(ValueError):a.update_channel(c['id'],changes,c['revision'])
    assert a.channel(c['id'])==c

def test_policy_revision_and_automation_explicit(pair):
    a,b,_=pair;c=a.create_channel('Cobalt')
    with pytest.raises(ValueError):a.update_channel(c['id'],{'mode':'automatic_marked','send_to':[b.fingerprint]},c['revision'])
    new=policy(a,c,mode='automatic_marked',send_to=[b.fingerprint],hourly_limit=2)
    with pytest.raises(ValueError):a.update_channel(c['id'],{'paused':True},c['revision'])
    # Pausing must always remain possible without granting anything. See dedicated gate.
    assert new['policy']['mode']=='automatic_marked'

def test_note_immutability_discard_and_limits(pair):
    a,b,_=pair;c=a.create_channel('Cobalt');nid=uuid.uuid4().hex
    n=a.new_note(c['id'],'amber','one',note_id=nid)
    assert a.new_note(c['id'],'amber','one',note_id=nid)==n
    with pytest.raises(ValueError):a.new_note(c['id'],'blue','one',note_id=nid)
    with pytest.raises(ValueError):a.new_note(c['id'],'amber','two',note_id=nid)
    assert a.discard_note(nid)['state']=='discarded'
    assert a.publish_note(nid,confirmed=True)['already_recorded']
    with pytest.raises(ContextWorkflowError):a.new_note(c['id'],'x'*6001)

def test_real_local_commit_index_and_signed_export(pair):
    a,b,_=pair;c=a.create_channel('Cobalt');n=local_note(a,c)
    assert n['state']=='local' and n['payload']['local_receipt']['phase_b_committed']
    assert inspect_semantic_field(storage_dir=a.inbox)['indexed_object_count']==1
    v=a.channel_view(c['id']);assert v['objects'][0]['indexed']
    assert not a.channel_scope(c['id'],True)[0]
    policy(a,c,use_in_chat=True)
    assert len(a.channel_scope(c['id'],True)[0])==1
    exported=a.export_note_frame(n['id']);raw=base64.b64decode(exported['frame_base64'])
    f=BraidFrame.from_bytes(raw);a.key.public_key().verify(f.signature_bytes,f.signature_preimage)
    assert f.manifest['extensions'][EXTENSION]['channel']==c['descriptor']
    assert a.publish_note(n['id'],confirmed=True)['already_recorded']
    assert inspect_semantic_field(storage_dir=a.inbox)['indexed_object_count']==1

def test_real_mtls_note_received_and_no_auto_forward(pair,monkeypatch):
    a,b,_,c=linked(pair);b.start_listener()
    fail=Mock(side_effect=AssertionError('Incoming notes must not auto-forward'))
    monkeypatch.setattr(b,'send',fail)
    n=local_note(a,c)
    assert n['state']=='shared',n
    assert n['payload']['outcomes'][0]['stage']=='indexed'
    assert len(b.channel_scope(c['id'],True)[0])==1
    assert b.channel_view(c['id'])['objects'][0]['indexed']
    assert not fail.called
    assert b.channel_view(c['id'])['notes']==[]

def test_unknown_channel_and_disallowed_publisher_fail_before_commit(pair):
    a,b,_,=pair;c=a.create_channel('Cobalt');n=local_note(a,c)
    encoded=a.export_note_frame(n['id'])['frame_base64']
    unknown=b.import_note_frame(encoded)
    assert unknown['phase_b_committed'] is False and 'Unknown channel' in unknown['reason']
    b.import_channel(c['descriptor'],confirmed=True)
    denied=b.import_note_frame(encoded)
    assert denied['reason']=='ERR_CHANNEL_PUBLISHER_NOT_SUBSCRIBED'
    policy(b,c,receive_from=[a.fingerprint])
    accepted=b.import_note_frame(encoded)
    assert accepted['phase_b_committed'] and accepted['field_indexed']
    again=b.import_note_frame(encoded)
    assert again['reason']=='ERR_CHANNEL_NOTE_ALREADY_RECORDED'
    assert not b.channel_scope(c['id'],True)[0]  # receiving never implicitly grants model context

def test_same_name_different_channel_cannot_cross_subscribe(pair):
    a,b,_=pair;ca=a.create_channel('Cobalt');cb=b.create_channel('Cobalt')
    policy(b,cb,receive_from=[a.fingerprint],use_in_chat=True)
    n=local_note(a,ca)
    assert b.import_note_frame(a.export_note_frame(n['id'])['frame_base64'])['phase_b_committed'] is False
    assert b.channel_scope(cb['id'],True)[0]==set()

def test_revocation_excludes_old_notes_and_rejects_new(pair):
    a,b,_,c=linked(pair);b.start_listener();first=local_note(a,c)
    assert first['state']=='shared'
    policy(b,c,receive_from=[])
    assert b.channel_scope(c['id'],True)[0]==set()
    second=local_note(a,c,'A second note about Cobalt.')
    assert second['state']=='attention' and second['payload']['outcomes'][0]['stage']=='rejected'
    assert len(b.channel_view(c['id'])['objects'])==1

def test_unconfirmed_delivery_cannot_be_replayed(pair,monkeypatch):
    a,b,_,c=linked(pair)
    calls=[]
    def unknown(*args,**kwargs):calls.append(1);return {'stage':'outcome_unknown','receipt':{}}
    monkeypatch.setattr(a,'_send_once',unknown)
    n=local_note(a,c)
    assert n['state']=='attention'
    again=a.publish_note(n['id'],confirmed=True)
    assert again['state']=='attention' and len(calls)==1

def test_channel_auto_rate_and_per_note_replay(pair,monkeypatch):
    a,b,_,c=linked(pair);c=policy(a,c,mode='automatic_marked',send_to=[b.fingerprint],hourly_limit=1)
    calls=[]
    monkeypatch.setattr(a,'_send_once',lambda *args,**kw:(calls.append(1) or {'stage':'indexed'}))
    plain=a.new_note(c['id'],'A plain note.')
    with pytest.raises(ValueError):a.publish_note(plain['id'],automatic=True)
    marked=a.new_note(c['id'],'A marked note.',origin='marked_local_note')
    result=a.publish_note(marked['id'],automatic=True)
    assert result['state']=='shared' and len(calls)==1
    assert a.publish_note(marked['id'],automatic=True)['already_recorded']
    another=a.new_note(c['id'],'Another marked note.',origin='marked_local_note')
    with pytest.raises(ValueError,match='limit'):a.publish_note(another['id'],automatic=True)
    assert a.get_note(another['id'])['state']=='draft' and len(calls)==1

def test_no_old_peer_downgrade_or_permission_bypass(pair,monkeypatch):
    a,b,_,c=linked(pair)
    contacts=a.contacts();contacts[0]['capabilities']=[]
    monkeypatch.setattr(a,'contacts',lambda:contacts)
    note=a.new_note(c['id'],'amber')
    with pytest.raises(ValueError,match='a6 rig card'):a.publish_note(note['id'],confirmed=True)
    assert inspect_semantic_field(storage_dir=a.inbox)['indexed_object_count']==0

def test_paused_archived_and_review_guards(pair):
    a,b,_=pair;c=a.create_channel('Cobalt');n=a.new_note(c['id'],'amber')
    with pytest.raises(ValueError,match='Review'):a.publish_note(n['id'])
    policy(a,c,paused=True)
    with pytest.raises(ValueError,match='paused'):a.publish_note(n['id'],confirmed=True)
    policy(a,c,archived=True)
    with pytest.raises(ValueError,match='archived'):a.new_note(c['id'],'blue')
    assert a.channel_scope(c['id'],True)[0]==set()

def test_attention_without_commit_cannot_export(pair,monkeypatch):
    a,b,_=pair;c=a.create_channel('Cobalt');n=a.new_note(c['id'],'amber')
    def fail(note):
        p=a.home/'channel-outbox'/(note['id']+'.brad');p.parent.mkdir(exist_ok=True);p.write_bytes(b'not committed')
        raise ValueError('fixture local commit failed')
    monkeypatch.setattr(a,'_local_channel_commit',fail)
    with pytest.raises(ValueError):a.publish_note(n['id'],confirmed=True)
    with pytest.raises(ValueError,match='committed'):a.export_note_frame(n['id'])

def test_restart_keeps_policy_notes_and_does_not_send(pair,monkeypatch):
    a,b,_,c=linked(pair);b.start_listener();n=local_note(a,c)
    key=b.key;inbox=b.inbox;home=b.home;b.close()
    reopened=MessengerService(key,inbox,home)
    try:
        assert reopened.channel(c['id'])['policy']['receive_from']==[a.fingerprint]
        assert len(reopened.channel_scope(c['id'],True)[0])==1
        assert reopened.channel_view(c['id'])['objects'][0]['indexed']
        assert reopened.channel_view(c['id'])['notes']==[]
    finally:reopened.close()

def test_interrupted_work_is_not_replayed(pair):
    a,b,_=pair;c=a.create_channel('Cobalt');n=a.new_note(c['id'],'amber');t=a.new_thread(c['id'])
    with a._db() as db:
        db.execute("UPDATE c6_notes SET state='sending' WHERE id=?",(n['id'],))
        db.execute('INSERT INTO c6_turns VALUES (?,?,?,?,?,?)',(uuid.uuid4().hex,t['id'],'question','running',time.time(),'{}'))
    a._init_channels()
    assert a.get_note(n['id'])['state']=='attention'
    assert a.thread(t['id'])['turns'][0]['state']=='interrupted'

def test_changed_local_frame_cannot_be_exported(pair):
    a,b,_=pair;c=a.create_channel('Cobalt');n=local_note(a,c)
    path=a.home/'channel-outbox'/(n['id']+'.brad')
    raw=bytearray(path.read_bytes());raw[-1]^=1;path.write_bytes(raw)
    with pytest.raises(Exception):a.export_note_frame(n['id'])
