import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from braid_client.keys import get_raw_public_bytes, load_or_create_signing_key
from braid_client.mcp_core.protocol import BraidFrame
from braid_client.receiver import AutomatedReceiver, ReceiverAutomationConfig
from braid_client.semantic_transfer import (
    OllamaEmbeddingClient,
    build_conformance_corpus,
    calibrate_route,
    create_manifest_for_route,
    create_validator_from_route_package,
    load_route_package,
)


class HeterogeneousSemanticTransferV150Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.tmp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.tmp.name)
        cls.rows = build_conformance_corpus(768)
        n = len(cls.rows)
        d = 384
        rng = np.random.default_rng(1500)

        # Construct a synthetic heterogeneous pair whose latent semantics are
        # explicitly label-bearing, then rotate the target coordinate system.
        basis = {}
        for row in cls.rows:
            for key, value in row["labels"].items():
                token = f"{key}={value}"
                if token not in basis:
                    seed = int(hashlib.sha256(token.encode()).hexdigest()[:16], 16)
                    basis[token] = np.random.default_rng(seed).normal(size=d)
        latent = []
        for row in cls.rows:
            z = np.zeros(d)
            for key, value in row["labels"].items():
                z += basis[f"{key}={value}"]
            z += rng.normal(scale=0.4, size=d)
            latent.append(z)
        latent = np.asarray(latent)
        latent /= np.linalg.norm(latent, axis=1, keepdims=True)

        q, _ = np.linalg.qr(rng.normal(size=(d, d)))
        cls.source = latent + rng.normal(scale=0.01, size=(n, d))
        cls.target = latent @ q + rng.normal(scale=0.01, size=(n, d))
        cls.source /= np.linalg.norm(cls.source, axis=1, keepdims=True)
        cls.target /= np.linalg.norm(cls.target, axis=1, keepdims=True)

        cls.package_dir = cls.root / "route"
        cls.report = calibrate_route(
            rows=cls.rows,
            source_raw=cls.source,
            target_raw=cls.target,
            source_model="synthetic-source-v1",
            target_model="synthetic-target-v1",
            output_dir=cls.package_dir,
            corpus_sha256="a" * 64,
        )

    @classmethod
    def tearDownClass(cls) -> None:
        cls.tmp.cleanup()

    def test_conformance_corpus_is_large_and_split(self) -> None:
        counts = {name: sum(row["split"] == name for row in self.rows) for name in ("train", "validation", "test")}
        self.assertGreater(counts["train"], 384)
        self.assertGreater(counts["validation"], 50)
        self.assertGreater(counts["test"], 50)
        self.assertIn("polarity", self.rows[0]["labels"])
        self.assertIn("temporal", self.rows[0]["labels"])

    def test_calibration_uses_held_out_data_and_passes_on_known_mapping(self) -> None:
        self.assertTrue(self.report["promotion"]["passed"], self.report["held_out_test"])
        test = self.report["held_out_test"]
        self.assertGreater(test["mapped"]["paired_cosine_mean"], test["baseline_unaligned"]["paired_cosine_mean"] + 0.5)
        self.assertGreater(test["mapped"]["mrr"], 0.95)
        self.assertGreater(test["semantic_probes"]["summary"]["mapped_source_accuracy_mean"], 0.95)
        self.assertGreater(self.report["splits"]["test"], 0)

    def test_route_package_detects_artifact_tamper(self) -> None:
        package = load_route_package(self.package_dir)
        self.assertEqual(package["status"], "empirically_promotable")
        artifact = self.package_dir / "transport_t.npy"
        original = artifact.read_bytes()
        try:
            artifact.write_bytes(original + b"tamper")
            with self.assertRaisesRegex(ValueError, "ERR_HETERO_ROUTE_ARTIFACT_DIGEST"):
                load_route_package(self.package_dir)
        finally:
            artifact.write_bytes(original)

    def test_receiver_emits_mapped_target_state_not_signed_source_state(self) -> None:
        package = load_route_package(self.package_dir)
        test_index = next(i for i, row in enumerate(self.rows) if row["split"] == "test")
        source_vector = self.source[test_index].astype(np.float32)

        sk, _, _ = load_or_create_signing_key(str(self.root / "sender.key"))
        vk = sk.public_key()
        manifest = create_manifest_for_route(package, session_id="hetero-test-session")
        frame = BraidFrame(manifest, source_vector, signer_private_key=sk)

        validator, registry, ledger, _ = create_validator_from_route_package(
            self.package_dir,
            get_raw_public_bytes(vk).hex(),
            self.root / "hetero-ledger.db",
        )
        receiver = AutomatedReceiver(
            validator=validator,
            registry=registry,
            ledger=ledger,
            verification_key=vk,
            config=ReceiverAutomationConfig(storage_dir=self.root / "receiver"),
        )
        report = receiver.process_bytes(frame.to_bytes(), source_transport="test", source_name="hetero.brad")
        self.assertTrue(report["accepted"], report)
        self.assertTrue(report["phase_b_committed"], report)
        self.assertEqual(report["derived_target_vector"]["authority"], "receiver_local_evidence_only")

        emitted = np.load(report["vector_path"], allow_pickle=False)
        route_map = registry.get_transport_map(package["route"]["transport_map_id"])
        parsed = BraidFrame.from_bytes(frame.to_bytes())
        expected = route_map.apply(np.asarray(parsed.vector, dtype=np.float64)).astype(np.float32)
        self.assertTrue(np.allclose(emitted, expected, atol=1e-6))
        self.assertFalse(np.allclose(emitted, np.asarray(parsed.vector, dtype=np.float32), atol=1e-3))

        lineage = json.loads(Path(report["lineage_path"]).read_text())
        self.assertFalse(lineage["sender_signature_covers_derived_artifact"])
        self.assertEqual(lineage["transport_map_digest"], package["route"]["transport_map_digest"])
        self.assertEqual(lineage["target_space_digest"], package["route"]["target_space_digest"])

    def test_ollama_backend_is_loopback_only(self) -> None:
        with self.assertRaisesRegex(ValueError, "ERR_HETERO_OLLAMA_LOOPBACK_REQUIRED"):
            OllamaEmbeddingClient("http://example.com:11434")
        with self.assertRaisesRegex(ValueError, "ERR_HETERO_OLLAMA_LOOPBACK_REQUIRED"):
            OllamaEmbeddingClient("http://localhost.evil.example:11434")


if __name__ == "__main__":
    unittest.main()
