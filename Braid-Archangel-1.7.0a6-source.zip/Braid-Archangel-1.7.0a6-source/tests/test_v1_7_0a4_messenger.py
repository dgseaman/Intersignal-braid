"""Messenger contract tests. Network tests use real loopback TLS sockets and fixture embeddings.

These are not evidence of macOS/Windows packaging or physical multi-rig Ollama UAT.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import io
import json
import socket
import ssl
import threading
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

import numpy as np
import pytest
from cryptography.hazmat.primitives.asymmetric import ed25519

import braid_client.messenger as messenger
from braid_client.messenger import MessengerService, canonical, local_address, receipt_stage, unpack_route
from braid_client.messenger_http import MessengerHTTPServer, MessengerHandler
from braid_client.semantic_capsule import SemanticCapsuleHandoffConfig
from braid_client.semantic_transfer import build_conformance_corpus, calibrate_route, build_frame_from_text
from braid_client.transport.client import send_frame
from tests.test_v1_5_2_semantic_capsule import FakeOllama, SOURCE, SOURCE_DIGEST, deterministic_embedding


@pytest.fixture(scope='module')
def route(tmp_path_factory):
    root = tmp_path_factory.mktemp('messenger-route')
    rows = build_conformance_corpus(768)
    vectors = np.vstack([deterministic_embedding(SOURCE, row['text'], 384) for row in rows])
    report = calibrate_route(rows=rows, source_raw=vectors, target_raw=vectors.copy(),
        source_model=SOURCE, target_model=SOURCE, source_model_digest=SOURCE_DIGEST,
        target_model_digest=SOURCE_DIGEST, same_space_identity=True, output_dir=root, corpus_sha256='7'*64)
    assert report['promotion']['passed']
    return root


def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


@pytest.fixture
def services(tmp_path, monkeypatch, route):
    fake = FakeOllama()
    monkeypatch.setattr(messenger, 'SemanticCapsuleHandoffConfig',
        lambda **kw: SemanticCapsuleHandoffConfig(base_url=fake.url, timeout_seconds=5, **kw))
    monkeypatch.setattr(messenger, 'build_frame_from_text',
        lambda path, text, key, **kw: build_frame_from_text(path,text,key,ollama_url=fake.url,**kw))
    values = []
    for name in ['Atlas', 'Mariana']:
        service = MessengerService(ed25519.Ed25519PrivateKey.generate(), tmp_path/name/'inbox', tmp_path/name/'desk')
        service.save_settings({'name':name, 'host':'127.0.0.1','port':free_port(),
            'embed_model':SOURCE,'route_path':str(route)})
        values.append(service)
    yield values
    for service in values:
        service.close()
    fake.close()


def approve(receiver, sender):
    inspected = receiver.inspect_card(sender.export_card())
    return receiver.approve_card(inspected['inspection_id'], sender.fingerprint, True)


def resign(card, key):
    card.pop('signature', None)
    card['signature'] = key.sign(b'BRAID-RIG-CARD-v1\0'+canonical(card)).hex()
    return card


@pytest.mark.parametrize('value,expected', [
    ({'validated':True},'rejected'),
    ({'phase_a_validated':True,'field_indexed':True},'rejected'),
    ({'accepted_and_indexed':True},'rejected'),
    ({'result_summary':'ACCEPTED_AND_INDEXED'},'rejected'),
    ({'phase_b_committed':False,'field_indexed':True},'rejected'),
    ({'phase_b_committed':True,'accepted':False,'field_indexed':True},'rejected'),
    ({'phase_b_committed':True,'semantic_transfer':None},'accepted'),
    ({'phase_b_committed':True,'field_indexed':False},'accepted'),
    ({'phase_b_committed':True,'field_indexed':True},'indexed'),
    ({'phase_b_committed':True,'semantic_transfer':{'semantic_field':{'indexed':True}}},'indexed'),
    ({'accepted':True,'stored':True,'validated':True},'accepted_legacy'),
    ({'status':'transport_unproven','phase_b_committed':False},'outcome_unknown'),
    ({'accepted':True,'stored':True,'validated':True,'phase_b_committed':None},'accepted_legacy'),
    ({'phase_b_committed':True,'field_indexed':False,'semantic_transfer':{'semantic_field':{'indexed':True}}},'accepted'),
])
def test_receipt_stage_does_not_invent_acceptance(value, expected):
    assert receipt_stage(value) == expected


@pytest.mark.parametrize('host', ['0.0.0.0','8.8.8.8','169.254.169.254','224.0.0.1','evil.example'])
def test_card_endpoint_is_bounded_private_numeric_ipv4(host):
    with pytest.raises(ValueError):
        local_address(host)


def test_card_has_no_private_material_and_requires_consent(services):
    a,b = services
    card = a.export_card()
    assert 'PRIVATE KEY' not in json.dumps(card)
    assert 'source_model' not in card  # The model identity is validated from the included route.
    inspected = b.inspect_card(card)
    assert not b.contacts()
    assert b.listener is None
    with pytest.raises(ValueError,match='confirm'):
        b.approve_card(inspected['inspection_id'], a.fingerprint, False)
    with pytest.raises(ValueError,match='confirm'):
        b.approve_card(inspected['inspection_id'], '0'*64, True)
    b.approve_card(inspected['inspection_id'],a.fingerprint,True)
    assert b.contacts()[0]['id'] == a.fingerprint
    assert a.fingerprint in b.receivers
    assert not b.messages()


def test_modified_self_unsupported_or_public_cards_are_rejected(services):
    a,b=services
    with pytest.raises(ValueError,match='this rig'):
        a.inspect_card(a.export_card())
    card=a.export_card(); card['name']='Attacker changed the label'
    with pytest.raises(Exception): b.inspect_card(card)
    card=resign(dict(a.export_card(),host='203.0.113.9'),a.key)
    with pytest.raises(ValueError,match='private'): b.inspect_card(card)
    card=dict(a.export_card(),schema='future.unknown.v900')
    with pytest.raises(ValueError,match='not supported'): b.inspect_card(card)
    assert not b.contacts()


def test_zip_traversal_unreferenced_members_and_declared_arrays_are_rejected(tmp_path):
    for name in ['../escape.npy','/tmp/escape.npy','nested/escape.npy']:
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w') as z:
            z.writestr('route.json','{}'); z.writestr(name,b'bad')
        with pytest.raises(ValueError,match='Unsafe'):
            unpack_route(base64.b64encode(buf.getvalue()).decode(),tmp_path/name.replace('/','_'))
    buf=io.BytesIO(); array=io.BytesIO()
    np.lib.format.write_array_header_1_0(array,{'descr':'<f8','fortran_order':False,'shape':(1000000000,)})
    data=array.getvalue()
    report={'artifacts':{'evil.npy':hashlib.sha256(data).hexdigest()}}
    with zipfile.ZipFile(buf,'w') as z:
        z.writestr('route.json',json.dumps(report));z.writestr('evil.npy',data)
    with pytest.raises(ValueError,match='shape'):
        unpack_route(base64.b64encode(buf.getvalue()).decode(),tmp_path/'oversized')


def test_bidirectional_tls_send_commit_index_replay_and_revocation(services):
    a,b=services
    approve(a,b);approve(b,a)
    a.start_listener();b.start_listener()
    assert a.probe()[b.fingerprint]['reachable']
    material='The Finch thermal threshold is 73. Both readings require independent Finch signatures.'
    result=a.send(b.fingerprint,material,'Kestrel handoff')
    assert result['stage']=='indexed',result
    assert result['receipt']['tls_peer_verified']
    assert result['receipt']['phase_b_committed'] is True
    incoming=b.messages()[0]
    assert incoming['text']==material
    assert incoming['peer']==a.fingerprint
    assert incoming['stage']=='indexed'
    assert b.snapshot()['field']['indexed_atom_count']==2
    raw_path=next((a.home/'outbox').glob('*.brad'))
    replay=send_frame(raw_path,'127.0.0.1',b.settings['port'],use_tls=True,
        ca_file=b.tls_cert,server_name=b.server_name,client_cert=a.tls_cert,client_key=a.tls_key)
    assert replay.ack.accepted is False
    assert b.snapshot()['field']['indexed_object_count']==1
    reverse=b.send(a.fingerprint,'Archive rotation remains weekly.','Return handoff')
    assert reverse['stage']=='indexed'
    b.remove_contact(a.fingerprint)
    # Archangel rejects revoked certificates before parsing a Braid frame.
    with pytest.raises((OSError, ValueError)):
        a.send(b.fingerprint,'Revoked identities cannot commit new state.','Revoked')
    assert a.messages()[0]['stage']=='outcome_unknown'
    assert b.snapshot()['field']['indexed_object_count']==1


def test_receipt_digest_binding_is_enforced(services,monkeypatch):
    from types import SimpleNamespace
    from braid_client.transport.protocol import Ack
    a,b=services;approve(a,b)
    ack=Ack(stored=True,validated=True,accepted=True,reason='OK',transport_sha256='f'*64,
        phase_b_committed=True,field_indexed=True)
    monkeypatch.setattr(messenger,'send_frame',lambda *args,**kwargs:SimpleNamespace(ack=ack))
    with pytest.raises(ValueError,match='exact sent bytes'):
        a.send(b.fingerprint,'A receipt must identify the exact sent bytes.','Mismatch')
    assert a.messages()[0]['stage']=='outcome_unknown'


def test_tls_pin_rejects_another_rig_certificate(services):
    a,b=services;approve(a,b);approve(b,a);b.start_listener()
    contact=a.contacts()[0]
    (Path(contact['route_path'])/'certificate.pem').write_bytes(a.tls_cert.read_bytes())
    with pytest.raises(ssl.SSLError):
        a.send(b.fingerprint,'A mismatched TLS certificate must not be accepted.','Wrong certificate')
    assert not b.messages()
    assert a.messages()[0]['stage']=='outcome_unknown'


def test_drafts_unread_archive_and_persistence_do_not_delete_field_state(services):
    a,b=services;approve(a,b);approve(b,a);b.start_listener()
    a.send(b.fingerprint,'The Finch threshold is 73.','Persistence')
    message=b.messages()[0]
    b.message_action(message['id'],'read');b.message_action(message['id'],'archive')
    b.set_value('draft',{'source':'A private unsent draft','recipients':[a.fingerprint]})
    b.stop_listener();b.close()
    again=MessengerService(b.key,b.inbox,b.home)
    try:
        assert again.messages()[0]['archived']==1
        assert again.messages()[0]['unread']==0
        assert again.get_value('draft')['source']=='A private unsent draft'
        assert again.snapshot()['field']['indexed_object_count']==1
        assert again.contacts()[0]['id']==a.fingerprint
        assert not again.listener
    finally: again.close()


def test_preflight_failure_is_not_labeled_sent(services,monkeypatch):
    a,b=services;approve(a,b)
    def fail(*args,**kwargs):raise ValueError('Local embedding unavailable')
    monkeypatch.setattr(messenger,'build_frame_from_text',fail)
    with pytest.raises(ValueError):a.send(b.fingerprint,'Do not claim a network send.','Preflight')
    assert a.messages()[0]['stage']=='failed'
    assert a.messages()[0]['payload']['network_attempted'] is False


def test_resume_marks_interrupted_sends_unknown_without_resending(services):
    a,_=services
    a.put_message('out-interrupted','out','x','Pending','text','sending',{},unread=False)
    a.close()
    again=MessengerService(a.key,a.inbox,a.home)
    try:
        assert again.messages()[0]['stage']=='outcome_unknown'
        assert again.jobs=={}
    finally:again.close()


def test_http_assets_csrf_origin_and_local_draft(services):
    a,_=services
    server=MessengerHTTPServer(('127.0.0.1',0),MessengerHandler);server.messenger=a
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    base='http://127.0.0.1:'+str(server.server_port)
    def request(path,data=None,headers=None):
        body=None if data is None else json.dumps(data).encode()
        req=urllib.request.Request(base+path,data=body,headers={'Content-Type':'application/json',**(headers or {})})
        return urllib.request.urlopen(req,timeout=5)
    try:
        for asset in ['/','/static/messenger.css','/static/messenger.js','/advanced']:
            with request(asset) as response:
                assert response.status==200
                assert 'Content-Security-Policy' in response.headers
                assert response.read()
        with request('/api/messenger/state') as response:snapshot=json.load(response)
        token=snapshot['csrf']
        for headers in [{},{'X-Braid-CSRF':token,'Origin':'https://evil.example'},
                {'X-Braid-CSRF':token,'Origin':'http://localhost:9999'},
                {'X-Braid-CSRF':token,'Sec-Fetch-Site':'cross-site'}]:
            with pytest.raises(urllib.error.HTTPError) as caught:
                request('/api/messenger/draft',{'draft':{'source':'not approved'}},headers)
            assert caught.value.code==403
        with request('/api/messenger/draft',{'draft':{'source':'Private local draft'}},
            {'X-Braid-CSRF':token,'Origin':base}) as response:assert json.load(response)['saved']
        assert a.get_value('draft')['source']=='Private local draft'
        assert not a.messages()
        with pytest.raises(urllib.error.HTTPError) as caught:
            request('/api/messenger/state',headers={'Host':'evil.example'})
        assert caught.value.code==403
    finally:
        server.shutdown();server.server_close();thread.join(5)
