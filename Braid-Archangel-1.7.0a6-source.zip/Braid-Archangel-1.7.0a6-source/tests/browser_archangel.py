"""Production HTML/JS browser regressions with explicitly simulated API outcomes.

Run from source with Playwright/Chromium installed; this is NOT multi-rig evidence.
"""
import json
import sys
import shutil
import tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright
from braid_client.messenger import MessengerService
from cryptography.hazmat.primitives.asymmetric import ed25519

OUT=Path(sys.argv[1] if len(sys.argv)>1 else '/tmp/archangel-browser');OUT.mkdir(parents=True,exist_ok=True)
ROOT=Path(__file__).resolve().parents[1]/'braid_client'/'static'
with tempfile.TemporaryDirectory() as temp:
    desk=MessengerService(ed25519.Ed25519PrivateKey.generate(),Path(temp)/'inbox',Path(temp)/'home')
    state=desk.snapshot();desk.close()
state['settings']['name']='Archangel UI fixture'
state['peers']=[{'id':p,'name':n,'host':'127.0.0.1','port':8746,'presence':{'reachable':True},'capabilities':[]} for p,n in [('a'*64,'Atlas fixture'),('b'*64,'Mariana fixture')]]
state['route_ready']=True
calls=[];errors=[];outcomes={'a'*64:['indexed'],'b'*64:['rejected','indexed','outcome_unknown']}
def api(path,data):
    path=path.split('/api/messenger/')[-1]
    data=data or {}
    if path=='state':result=state
    elif path=='draft':state['draft']=data['draft'];result={'saved':True}
    elif path=='send':
        peer=data['peer'];calls.append(peer)
        stage=outcomes[peer].pop(0)
        result={'stage':stage,'message_id':'out-'+str(len(calls))}
        state['deliveries']=[d for d in state['deliveries'] if not(d['handoff']==data['handoff_id'] and d['peer']==peer)]
        state['deliveries'].append({'handoff':data['handoff_id'],'peer':peer,'stage':stage,'result':result})
    else:result={}
    return json.loads(json.dumps(result))
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path=shutil.which('chromium'),args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1220,'height':860})
    page.on('pageerror',lambda err:errors.append(str(err)))
    page.expose_function('archangelTestAPI', api)
    html=(ROOT/'messenger.html').read_text().replace('__BRAID_VERSION__','1.7.0a6').replace('<link rel="stylesheet" href="/static/messenger.css">','<style>'+(ROOT/'messenger.css').read_text()+'</style>')
    html=html.replace('<link rel="stylesheet" href="/static/channels.css">','<style>'+(ROOT/'channels.css').read_text()+'</style>')
    html=html.replace('<script src="/static/messenger.js"></script>','').replace('<script src="/static/channels.js"></script>','')
    def load_document():
        global page
        page.close()
        page=browser.new_page(viewport={'width':1220,'height':860})
        page.on('pageerror',lambda err:errors.append(str(err)))
        page.expose_function('archangelTestAPI',api)
        # Browser network navigation is administratively unavailable here.
        # Execute the real document/JS offline, with only fetch and the
        # secure-context UUID API bridged to explicit test fixtures.
        page.set_content(html)
        page.evaluate("""() => {
            window.fetch=async(url,options={})=>new Response(JSON.stringify(await window.archangelTestAPI(String(url),options.body?JSON.parse(options.body):null)),{status:200,headers:{'Content-Type':'application/json'}});
            if(!crypto.randomUUID)Object.defineProperty(crypto,'randomUUID',{value:()=>Array.from(crypto.getRandomValues(new Uint8Array(16))).map(x=>x.toString(16).padStart(2,'0')).join('')});
        }""")
        page.add_script_tag(content=(ROOT/'messenger.js').read_text())
        page.add_script_tag(content=(ROOT/'channels.js').read_text())
        page.wait_for_function("document.querySelector('#localName').textContent==='Archangel UI fixture'")
    load_document()
    page.click('#composeButton');page.fill('#sourceText','The launch color is amber.');page.fill('#composeTitle','Handoff fixture')
    page.check('#recipientList input[value="'+('a'*64)+'"]');page.check('#recipientList input[value="'+('b'*64)+'"]')
    page.click('#useExact');page.click('#sendButton')
    page.wait_for_function("document.querySelector('#composeResult').textContent.includes('Not accepted') && !document.querySelector('#saveDraft').disabled")
    assert page.locator('#recipientList input[value="'+('a'*64)+'"]').is_disabled()
    assert page.locator('#recipientList input[value="'+('b'*64)+'"]').is_checked()
    assert page.locator('#reviewText').get_attribute('readonly') is not None
    assert 'Nothing has been' not in page.locator('#summaryMethod').inner_text()
    page.screenshot(path=str(OUT/'partial-delivery.png'),full_page=True)
    load_document();page.click('#composeButton')
    assert page.locator('#recipientList input[value="'+('a'*64)+'"]').is_disabled()
    page.click('#sendButton');page.wait_for_function("!document.querySelector('#composeDialog').open")
    assert calls==['a'*64,'b'*64,'b'*64],calls
    page.click('#composeButton');page.fill('#sourceText','Unknown receipt fixture.');page.check('#recipientList input[value="'+('b'*64)+'"]')
    page.click('#useExact');page.click('#sendButton')
    page.wait_for_function("document.querySelector('#composeResult').textContent.includes('Receipt not confirmed') && !document.querySelector('#saveDraft').disabled")
    assert page.locator('#sendButton').is_disabled()
    load_document();page.click('#composeButton')
    assert page.locator('#recipientList input[value="'+('b'*64)+'"]').is_disabled()
    assert page.locator('#sendButton').is_disabled()
    page.keyboard.press('Control+Enter');page.wait_for_timeout(100)
    assert len(calls)==4
    page.screenshot(path=str(OUT/'unknown-outcome.png'),full_page=True)
    page.click('[aria-label="Close composer"]');page.click('#settingsButton')
    assert page.locator('#updateAddress').is_visible()
    page.screenshot(path=str(OUT/'settings-desktop.png'),full_page=True)
    page.set_viewport_size({'width':390,'height':844})
    overflow=page.evaluate('document.documentElement.scrollWidth > window.innerWidth')
    assert not overflow,'Mobile horizontal overflow'
    page.screenshot(path=str(OUT/'settings-mobile.png'),full_page=True)
    assert not errors,errors
    (OUT/'browser.json').write_text(json.dumps({'passed':True,'scope':'Production HTML/CSS/JS in offline Chromium document; simulated fetch API and UUID shim. Network navigation unavailable by environment policy.','send_sequence':calls,'refresh_preserves_recipient_states':True,'unknown_outcomes_blocked':True,'javascript_errors':errors,'mobile_horizontal_overflow':overflow},indent=2))
    browser.close()
