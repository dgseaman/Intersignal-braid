import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from braid_client.cli import build_parser
from braid_client.semantic_field import (
    FIELD_ATOMS_FILE,
    FIELD_DELTA_FILE,
    FIELD_MANIFEST_FILE,
    FIELD_NOVELTY_FILE,
    FIELD_SPACE_PROBE,
    FIELD_VECTORS_FILE,
    SEMANTIC_DELTA_EXTENSION_SCHEMA,
    SEMANTIC_DELTA_MATERIAL_SCHEMA,
    SEMANTIC_FIELD_SCHEMA,
    SemanticFieldConfig,
    attach_semantic_delta_extension,
    atomize_semantic_material,
    build_semantic_delta_extension,
    build_semantic_field_artifacts,
    extract_semantic_delta_extension,
    inspect_semantic_field,
    load_semantic_field_bundle,
    parse_semantic_delta_material,
    query_semantic_field,
    reindex_semantic_fields,
    reconcile_semantic_field,
    render_semantic_delta_material,
    search_semantic_field,
    validate_semantic_delta_extension,
)


MODEL_A = "field-embed-a:latest"
MODEL_B = "field-embed-b:latest"
MODEL_NATIVE = "field-embed-native:latest"
COMPLETION = "field-answer:latest"
DIGEST_A = "a" * 64
DIGEST_B = "b" * 64
NATIVE_DIGEST = "d" * 64
COMPLETION_DIGEST = "c" * 64


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _object_digest(label: str) -> str:
    return hashlib.sha256(("object:" + label).encode("utf-8")).hexdigest()


def _feature_vector(text: str, model: str) -> np.ndarray:
    """Small deterministic semantic fixture with deliberate related geometry."""
    lower = text.lower()
    vector = np.zeros(384, dtype=np.float64)

    topic_features = {
        0: ("finch", 1.0),
        1: ("thermal", 0.90),
        2: ("temperature", 0.90),
        3: ("threshold", 0.80),
        4: ("kestrel", 0.65),
        5: ("meridian", 0.55),
        20: ("archive", 1.0),
        21: ("backup", 0.85),
        22: ("rotation", 0.75),
        40: ("revenue", 1.0),
        41: ("sales", 0.80),
        42: ("forecast", 0.70),
    }
    for index, (token, weight) in topic_features.items():
        if token in lower:
            vector[index] += weight

    # Decision vocabulary shares one topic axis while retaining a weak polarity.
    if any(token in lower for token in ("proceed", "approved", "allow", "passed")):
        vector[60] += 0.55
        vector[61] += 0.22
    if any(token in lower for token in ("stop", "rejected", "deny", "failed")):
        vector[60] += 0.55
        vector[61] -= 0.22
    if any(token in lower for token in ("not ", " no ", "never", "cannot")):
        vector[62] -= 0.22

    # Different values remain close enough to compare but below near-duplicate.
    for number in ("68", "70", "72", "73", "74", "75", "99"):
        if number in lower:
            vector[80 + int(number) % 19] += 0.35

    # Separate model spaces even when fixtures happen to share terms.
    vector[150 if model == MODEL_A else 151] += 0.08

    if not np.any(vector):
        seed = int.from_bytes(hashlib.sha256((model + "\0" + text).encode()).digest()[:4], "big")
        vector[200 + seed % 150] = 1.0
    else:
        # Tiny stable perturbation prevents accidental total ties without erasing
        # the deliberately designed semantic geometry.
        seed = int.from_bytes(hashlib.sha256((model + "\0" + text).encode()).digest()[:4], "big")
        vector[200 + seed % 150] += 0.01
    vector /= np.linalg.norm(vector)
    return vector


class FakeFieldClient:
    def __init__(self):
        self.chat_messages = []

    def model_digest(self, model: str) -> str:
        values = {
            MODEL_A: DIGEST_A,
            MODEL_B: DIGEST_B,
            MODEL_NATIVE: NATIVE_DIGEST,
            COMPLETION: COMPLETION_DIGEST,
        }
        if model not in values:
            raise ValueError("ERR_TEST_MODEL")
        return values[model]

    def embed(self, model, texts, *, dimensions=384, batch_size=16):
        if dimensions != 384 or not isinstance(texts, list):
            raise ValueError("ERR_TEST_EMBED_REQUEST")
        if model == MODEL_NATIVE:
            raise ValueError("ERR_OLLAMA_EMBED_DIM:(1,512):expected=(1,384)")
        return np.vstack([_feature_vector(text, model) for text in texts])

    def embed_native(self, model, texts, *, batch_size=16):
        if model != MODEL_NATIVE or not isinstance(texts, list):
            raise ValueError("ERR_TEST_NATIVE_EMBED_REQUEST")
        rows = []
        for text in texts:
            row = np.zeros(512, dtype=np.float64)
            row[:384] = _feature_vector(text, model)
            row[384] = 0.12
            row /= np.linalg.norm(row)
            rows.append(row)
        return np.vstack(rows)

    def chat(self, model, messages, *, temperature=0.0):
        if model != COMPLETION or temperature != 0.0:
            raise ValueError("ERR_TEST_CHAT_REQUEST")
        self.chat_messages.append(copy.deepcopy(messages))
        return {"message": {"role": "assistant", "content": "Answer reconstructed from selected field atoms."}}


class DriftedFieldClient(FakeFieldClient):
    """Same model digest, deliberately different runtime probe behavior."""

    def embed(self, model, texts, *, dimensions=384, batch_size=16):
        rows = super().embed(
            model, texts, dimensions=dimensions, batch_size=batch_size
        )
        for index, text in enumerate(texts):
            if text == FIELD_SPACE_PROBE:
                rows[index] = np.roll(rows[index], 7)
        return rows


def _publish_field(
    storage: Path,
    *,
    label: str,
    material: str,
    client: FakeFieldClient,
    model: str = MODEL_A,
    config: SemanticFieldConfig | None = None,
):
    digest = _object_digest(label)
    field_config = config or SemanticFieldConfig(embedding_model=model)
    build = build_semantic_field_artifacts(
        storage_dir=storage,
        object_digest=digest,
        material=material,
        semantic_content_sha256=_sha(material),
        client=client,
        config=field_config,
    )
    bundle = storage / "semantic" / digest
    bundle.mkdir(parents=True, mode=0o700)
    for name, payload in build.files.items():
        (bundle / name).write_bytes(payload)
    lineage = {
        "schema": "braid.semantic-capsule.receiver-lineage.v1",
        "object_digest": digest,
        "phase_b_committed": True,
        "semantic_content_sha256": _sha(material),
        "receiver_embedding_model": model,
        "receiver_embedding_model_digest": client.model_digest(model),
        "semantic_field_indexed": True,
        "semantic_field_schema": SEMANTIC_FIELD_SCHEMA,
        "semantic_field_manifest_sha256": build.manifest_sha256,
        "semantic_field_dimension": 384,
        "semantic_field_atom_count": build.manifest["atom_count"],
        "semantic_field_embedding_model": build.manifest["embedding"]["model"],
        "semantic_field_embedding_model_digest": build.manifest["embedding"]["model_digest"],
        "semantic_field_adapter_digest": build.manifest["embedding"]["adapter_digest"],
        "semantic_field_space_digest": build.manifest["embedding"]["field_space_digest"],
        "sender_signature_covers_field": False,
    }
    (bundle / "lineage.json").write_text(json.dumps(lineage, sort_keys=True), encoding="utf-8")
    (bundle / "material.txt").write_text(material, encoding="utf-8")
    return digest, build, bundle


def _publish_legacy_semantic_bundle(
    storage: Path,
    *,
    label: str,
    material: str,
    created_at: int,
) -> tuple[str, Path]:
    digest = _object_digest(label)
    bundle = storage / "semantic" / digest
    bundle.mkdir(parents=True, mode=0o700)
    lineage = {
        "schema": "braid.semantic-capsule.receiver-lineage.v1",
        "version": "1.6.1rc1",
        "object_digest": digest,
        "phase_b_committed": True,
        "semantic_content_sha256": _sha(material),
        "receiver_embedding_model": MODEL_A,
        "receiver_embedding_model_digest": DIGEST_A,
        "created_at": created_at,
    }
    (bundle / "lineage.json").write_text(
        json.dumps(lineage, sort_keys=True), encoding="utf-8"
    )
    (bundle / "material.txt").write_text(material, encoding="utf-8")
    return digest, bundle


class SemanticFieldUnitTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.storage = Path(self.tmp.name) / "inbox"
        self.client = FakeFieldClient()

    def tearDown(self):
        self.tmp.cleanup()

    def test_atomization_preserves_exact_source_spans_and_roles(self):
        material = (
            "Project Meridian must not launch before validation. "
            "The Finch thermal threshold is 73. "
            "May the Kestrel run proceed?"
        )
        atoms = atomize_semantic_material(material, max_atom_utf8=128)
        self.assertGreaterEqual(len(atoms), 3)
        self.assertEqual([item["role"] for item in atoms], ["constraint", "claim", "question"])
        for atom in atoms:
            self.assertTrue(atom["source_preserving"])
            self.assertLessEqual(len(atom["text"].encode("utf-8")), 128)
            span = atom["span"]
            self.assertEqual(atom["text"], material[span["start_char"]:span["end_char"]])
            self.assertEqual(atom["text_sha256"], _sha(atom["text"]))

    def test_long_material_splits_without_paraphrase_or_loss_inside_spans(self):
        material = "Evidence " + ("thermal telemetry remained within the validated operating envelope " * 8) + "."
        atoms = atomize_semantic_material(material, max_atom_utf8=128)
        self.assertGreater(len(atoms), 2)
        for atom in atoms:
            span = atom["span"]
            self.assertEqual(atom["text"], material[span["start_char"]:span["end_char"]])
            self.assertLessEqual(len(atom["text"].encode("utf-8")), 128)

    def test_novelty_distinguishes_update_and_exact_duplicate(self):
        first, first_build, _ = _publish_field(
            self.storage,
            label="threshold-73",
            material="The Finch thermal threshold is 73.",
            client=self.client,
        )
        second, second_build, _ = _publish_field(
            self.storage,
            label="threshold-75",
            material="The Finch thermal threshold is 75.",
            client=self.client,
        )
        third, third_build, _ = _publish_field(
            self.storage,
            label="threshold-75-again",
            material="The Finch thermal threshold is 75.",
            client=self.client,
        )
        self.assertEqual(first_build.summary["novelty_counts"]["novel"], 1)
        self.assertEqual(second_build.summary["novelty_counts"]["possible_update"], 1)
        second_bundle = load_semantic_field_bundle(storage_dir=self.storage, object_digest=second)
        update = second_bundle.novelty["atoms"][0]
        self.assertIn("numeric_value_changed", update["change_signals"])
        self.assertFalse(update["automatic_supersession"])
        self.assertEqual(third_build.summary["novelty_counts"]["exact_duplicate"], 1)
        third_bundle = load_semantic_field_bundle(storage_dir=self.storage, object_digest=third)
        self.assertEqual(third_bundle.delta["selected_atom_count"], 0)
        with self.assertRaisesRegex(ValueError, "ERR_DELTA_EMPTY"):
            render_semantic_delta_material(storage_dir=self.storage, object_digest=third)

    def test_model_digest_isolation_blocks_cross_space_comparison(self):
        _, first, _ = _publish_field(
            self.storage,
            label="space-a",
            material="The Finch thermal threshold is 73.",
            client=self.client,
            model=MODEL_A,
        )
        _, second, _ = _publish_field(
            self.storage,
            label="space-b",
            material="The Finch thermal threshold is 75.",
            client=self.client,
            model=MODEL_B,
        )
        self.assertEqual(first.summary["prior_bundle_count"], 0)
        self.assertEqual(second.summary["prior_bundle_count"], 0)
        status = inspect_semantic_field(storage_dir=self.storage)
        self.assertEqual(len(status["model_spaces"]), 2)
        self.assertFalse(status["cross_model_comparison"])

        with patch("braid_client.semantic_field.OllamaClient", return_value=self.client):
            result = search_semantic_field(
                storage_dir=self.storage,
                question="What is the Finch thermal threshold?",
                embedding_model=MODEL_A,
                top_k=8,
                min_cosine=-1.0,
            )
        self.assertEqual(result["candidate_object_count"], 1)
        sources = {source["object_digest"] for row in result["results"] for source in row["sources"]}
        self.assertEqual(sources, {_object_digest("space-a")})

    def test_behavior_probe_isolates_same_digest_runtime_drift(self):
        _, first, _ = _publish_field(
            self.storage,
            label="stable-runtime",
            material="The Finch thermal threshold is 73.",
            client=self.client,
            model=MODEL_A,
        )
        drifted = DriftedFieldClient()
        _, second, _ = _publish_field(
            self.storage,
            label="drifted-runtime",
            material="The Finch thermal threshold is 75.",
            client=drifted,
            model=MODEL_A,
        )
        self.assertEqual(first.summary["embedding_model_digest"], DIGEST_A)
        self.assertEqual(second.summary["embedding_model_digest"], DIGEST_A)
        self.assertNotEqual(
            first.summary["field_space_digest"],
            second.summary["field_space_digest"],
        )
        self.assertEqual(second.summary["prior_bundle_count"], 0)
        status = inspect_semantic_field(storage_dir=self.storage)
        self.assertEqual(len(status["model_spaces"]), 2)

    def test_native_embedding_fallback_projects_deterministically_into_384d(self):
        digest, build, _ = _publish_field(
            self.storage,
            label="native-projection",
            material="The Finch thermal threshold is 73.",
            client=self.client,
            model=MODEL_NATIVE,
        )
        embedding = build.manifest["embedding"]
        self.assertEqual(embedding["source_dimension"], 512)
        self.assertEqual(
            embedding["adapter"]["algorithm"],
            "digest_seeded_signed_feature_hash_v1",
        )
        self.assertTrue(embedding["direct_384_fallback"])
        bundle = load_semantic_field_bundle(
            storage_dir=self.storage, object_digest=digest
        )
        self.assertEqual(bundle.vectors.shape, (1, 384))
        self.assertAlmostEqual(float(np.linalg.norm(bundle.vectors[0])), 1.0, places=6)

        with patch("braid_client.semantic_field.OllamaClient", return_value=self.client):
            result = search_semantic_field(
                storage_dir=self.storage,
                question="What is the Finch thermal threshold?",
                embedding_model=MODEL_NATIVE,
                top_k=1,
                min_cosine=0.0,
            )
        self.assertEqual(result["selected_atom_count"], 1)
        self.assertEqual(
            result["embedding_adapter"],
            "digest_seeded_signed_feature_hash_v1",
        )
        self.assertEqual(result["field_space_digest"], embedding["field_space_digest"])

        with self.assertRaisesRegex(ValueError, "ERR_OLLAMA_EMBED_DIM"):
            build_semantic_field_artifacts(
                storage_dir=self.storage,
                object_digest=_object_digest("native-no-fallback"),
                material="The Finch thermal threshold is 74.",
                semantic_content_sha256=_sha("The Finch thermal threshold is 74."),
                client=self.client,
                config=SemanticFieldConfig(
                    embedding_model=MODEL_NATIVE,
                    allow_native_projection=False,
                ),
            )

    def test_vector_search_and_query_use_selected_atoms_not_whole_transcript(self):
        material = (
            "The Finch thermal threshold is 73 and it governs Kestrel launch validation. "
            "Archive rotation and backup retention are reviewed every Friday by operations."
        )
        _publish_field(self.storage, label="mixed", material=material, client=self.client)
        with patch("braid_client.semantic_field.OllamaClient", return_value=self.client):
            search = search_semantic_field(
                storage_dir=self.storage,
                question="What thermal threshold governs Kestrel?",
                embedding_model=MODEL_A,
                top_k=1,
                min_cosine=0.20,
            )
            query = query_semantic_field(
                storage_dir=self.storage,
                question="What thermal threshold governs Kestrel?",
                embedding_model=MODEL_A,
                completion_model=COMPLETION,
                top_k=1,
                min_cosine=0.20,
            )
        self.assertEqual(search["selected_atom_count"], 1)
        self.assertIn("threshold is 73", search["results"][0]["text"])
        self.assertNotIn("Archive rotation", search["results"][0]["text"])
        self.assertTrue(query["fresh_context_reconstruction"])
        self.assertFalse(query["whole_transcript_replayed"])
        self.assertTrue(Path(query["query_path"]).is_file())
        user_prompt = self.client.chat_messages[-1][1]["content"]
        self.assertIn("whole_transcript_replayed=false", user_prompt)
        self.assertIn("threshold is 73", user_prompt)
        self.assertNotIn("Archive rotation", user_prompt)

    def test_reconciliation_preserves_numeric_conflict_without_resolution(self):
        _publish_field(
            self.storage,
            label="reconcile-73",
            material="The Finch thermal threshold is 73.",
            client=self.client,
        )
        _publish_field(
            self.storage,
            label="reconcile-75",
            material="The Finch thermal threshold is 75.",
            client=self.client,
        )
        with patch("braid_client.semantic_field.OllamaClient", return_value=self.client):
            result = reconcile_semantic_field(
                storage_dir=self.storage,
                embedding_model=MODEL_A,
                cluster_cosine=0.80,
            )
        self.assertGreaterEqual(result["possible_conflict_count"], 1)
        cluster = next(item for item in result["clusters"] if item["status"] == "possible_conflict")
        self.assertEqual(cluster["member_count"], 2)
        texts = {item["text"] for item in cluster["members"]}
        self.assertEqual(texts, {"The Finch thermal threshold is 73.", "The Finch thermal threshold is 75."})
        self.assertFalse(cluster["automatic_resolution"])
        self.assertTrue(result["heuristic_only"])

    def test_delta_material_is_bounded_and_extension_binds_exact_atoms(self):
        digest, _, _ = _publish_field(
            self.storage,
            label="delta-source",
            material=(
                "The Finch thermal threshold is 73. "
                "Archive rotation and backup retention are reviewed every Friday."
            ),
            client=self.client,
        )
        material, extension, evidence = render_semantic_delta_material(
            storage_dir=self.storage,
            object_digest=digest,
            max_atoms=1,
        )
        document = parse_semantic_delta_material(material)
        self.assertEqual(document["schema"], SEMANTIC_DELTA_MATERIAL_SCHEMA)
        self.assertEqual(len(document["atoms"]), 1)
        self.assertEqual(document["omitted_atom_count"], 1)
        self.assertEqual(extension["schema"], SEMANTIC_DELTA_EXTENSION_SCHEMA)
        self.assertEqual(extension["atom_ids"], [document["atoms"][0]["atom_id"]])
        self.assertEqual(evidence["selected_atom_count"], 1)

        manifest = {"extensions": {}}
        attach_semantic_delta_extension(manifest, extension, material=material)
        extracted = extract_semantic_delta_extension(manifest, material=material)
        self.assertTrue(extracted["present"])
        self.assertEqual(extracted["source_object_digest"], digest)
        self.assertFalse(extracted["automatic_supersession"])

        tampered = material.replace("73", "99")
        with self.assertRaisesRegex(ValueError, "ERR_DELTA_EXTENSION_MATERIAL_DIGEST"):
            validate_semantic_delta_extension(extension, material=tampered)

    def test_delta_material_atoms_reindex_as_explicit_signed_delta_atoms(self):
        digest, _, _ = _publish_field(
            self.storage,
            label="delta-reindex-source",
            material="The Finch thermal threshold is 73.",
            client=self.client,
        )
        material, extension, _ = render_semantic_delta_material(
            storage_dir=self.storage, object_digest=digest
        )
        parsed = parse_semantic_delta_material(material)
        atoms = atomize_semantic_material(material)
        self.assertEqual(len(atoms), len(parsed["atoms"]))
        self.assertEqual(atoms[0]["source_kind"], "signed_semantic_delta_atom")
        self.assertEqual(atoms[0]["source_object_digest"], digest)
        self.assertEqual(atoms[0]["source_relation"], "novel")
        self.assertEqual(
            build_semantic_delta_extension(document=parsed, material=material),
            extension,
        )

    def test_field_loader_rejects_artifact_tamper(self):
        digest, _, bundle = _publish_field(
            self.storage,
            label="tamper",
            material="The Finch thermal threshold is 73.",
            client=self.client,
        )
        with (bundle / FIELD_ATOMS_FILE).open("ab") as handle:
            handle.write(b" ")
        with self.assertRaisesRegex(ValueError, "ERR_FIELD_ARTIFACT_DIGEST:atoms.json"):
            load_semantic_field_bundle(storage_dir=self.storage, object_digest=digest)
        status = inspect_semantic_field(storage_dir=self.storage)
        self.assertEqual(status["invalid_field_count"], 1)
        self.assertFalse(status["ready"])

    def test_reindex_builds_legacy_fields_in_commit_chronology_and_is_idempotent(self):
        first_digest, _ = _publish_legacy_semantic_bundle(
            self.storage,
            label="legacy-threshold-73",
            material="The Finch thermal threshold is 73.",
            created_at=100,
        )
        second_digest, _ = _publish_legacy_semantic_bundle(
            self.storage,
            label="legacy-threshold-75",
            material="The Finch thermal threshold is 75.",
            created_at=200,
        )
        report = reindex_semantic_fields(
            storage_dir=self.storage,
            embedding_model=MODEL_A,
            client=self.client,
        )
        self.assertEqual(report["indexed_object_count"], 2)
        self.assertEqual(report["failed_object_count"], 0)
        self.assertEqual(report["embedding_model_digests"], [DIGEST_A])
        first = load_semantic_field_bundle(
            storage_dir=self.storage, object_digest=first_digest
        )
        second = load_semantic_field_bundle(
            storage_dir=self.storage, object_digest=second_digest
        )
        self.assertEqual(first.novelty["counts"]["novel"], 1)
        self.assertEqual(second.novelty["counts"]["possible_update"], 1)
        self.assertEqual(second.novelty["prior_bundle_count"], 1)

        rerun = reindex_semantic_fields(
            storage_dir=self.storage,
            embedding_model=MODEL_A,
            client=self.client,
        )
        self.assertEqual(rerun["indexed_object_count"], 0)
        self.assertEqual(rerun["already_indexed_count"], 2)
        self.assertEqual(rerun["failed_object_count"], 0)

    def test_reindex_rejects_tampered_legacy_material_without_field_marker(self):
        digest, bundle = _publish_legacy_semantic_bundle(
            self.storage,
            label="legacy-tamper",
            material="The Finch thermal threshold is 73.",
            created_at=100,
        )
        (bundle / "material.txt").write_text(
            "The Finch thermal threshold is 99.", encoding="utf-8"
        )
        report = reindex_semantic_fields(
            storage_dir=self.storage,
            embedding_model=MODEL_A,
            client=self.client,
        )
        self.assertEqual(report["indexed_object_count"], 0)
        self.assertEqual(report["failed_object_count"], 1)
        self.assertIn("ERR_FIELD_REINDEX_MATERIAL_DIGEST", report["results"][0]["reason"])
        self.assertFalse((bundle / FIELD_MANIFEST_FILE).exists())
        self.assertFalse((bundle / FIELD_ATOMS_FILE).exists())
        status = inspect_semantic_field(storage_dir=self.storage)
        self.assertEqual(status["unindexed_semantic_object_count"], 1)

    def test_cli_exposes_field_workflow_and_receive_defaults_to_indexing(self):
        parser = build_parser()
        receive = parser.parse_args([
            "receive", "--route-package", "route", "--trusted-key", "00" * 32,
            "--semantic-embed-model", MODEL_A,
        ])
        self.assertTrue(receive.semantic_field)
        disabled = parser.parse_args([
            "receive", "--route-package", "route", "--trusted-key", "00" * 32,
            "--semantic-embed-model", MODEL_A, "--no-semantic-field",
        ])
        self.assertFalse(disabled.semantic_field)
        search = parser.parse_args(["field-search", "threshold?", "--embed-model", MODEL_A])
        self.assertEqual(search.command, "field-search")
        reindex = parser.parse_args(["field-reindex", "--embed-model", MODEL_A])
        self.assertEqual(reindex.command, "field-reindex")
        self.assertTrue(reindex.native_projection)
        delta = parser.parse_args([
            "field-delta-frame", "d" * 64, "--route-package", "route",
        ])
        self.assertEqual(delta.command, "field-delta-frame")


class SemanticFieldReceiverIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from tests.test_v1_5_2_semantic_capsule import (
            FakeOllama,
            SOURCE,
            SOURCE_DIGEST,
            TARGET,
            TARGET_DIGEST,
            deterministic_embedding,
        )
        from braid_client.semantic_transfer import build_conformance_corpus, calibrate_route

        cls.SOURCE = SOURCE
        cls.SOURCE_DIGEST = SOURCE_DIGEST
        cls.TARGET = TARGET
        cls.TARGET_DIGEST = TARGET_DIGEST
        cls.deterministic_embedding = staticmethod(deterministic_embedding)
        cls.tmp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.tmp.name)
        cls.fake = FakeOllama()
        rows = build_conformance_corpus(768)
        texts = [row["text"] for row in rows]
        source = np.vstack([deterministic_embedding(SOURCE, item, 384) for item in texts])
        cls.route_dir = cls.root / "source-route"
        report = calibrate_route(
            rows=rows,
            source_raw=source,
            target_raw=source.copy(),
            source_model=SOURCE,
            target_model=SOURCE,
            source_model_digest=SOURCE_DIGEST,
            target_model_digest=SOURCE_DIGEST,
            same_space_identity=True,
            output_dir=cls.route_dir,
            corpus_sha256="7" * 64,
        )
        if not report["promotion"]["passed"]:
            raise AssertionError(report)

    @classmethod
    def tearDownClass(cls):
        cls.fake.close()
        cls.tmp.cleanup()

    def _receiver(
        self,
        root: Path,
        signing_key,
        *,
        semantic_model: str | None = None,
        field_model: str | None = None,
        verify_exact: bool = True,
    ):
        from braid_client.keys import get_raw_public_bytes
        from braid_client.receiver import AutomatedReceiver, ReceiverAutomationConfig
        from braid_client.semantic_capsule import SemanticCapsuleHandoffConfig
        from braid_client.semantic_transfer import create_validator_from_route_package

        validator, registry, ledger, _ = create_validator_from_route_package(
            self.route_dir,
            get_raw_public_bytes(signing_key.public_key()).hex(),
            root / "ledger.db",
        )
        return AutomatedReceiver(
            validator=validator,
            registry=registry,
            ledger=ledger,
            verification_key=signing_key.public_key(),
            config=ReceiverAutomationConfig(
                storage_dir=root / "inbox",
                semantic_capsule_handoff=SemanticCapsuleHandoffConfig(
                    embedding_model=semantic_model or self.SOURCE,
                    base_url=self.fake.url,
                    timeout_seconds=5,
                    verify_exact_space_coherence=verify_exact,
                    semantic_field=SemanticFieldConfig(
                        embedding_model=field_model or self.SOURCE
                    ),
                ),
            ),
        )

    def test_receive_commit_atomically_publishes_operational_field(self):
        from braid_client.keys import load_or_create_signing_key
        from braid_client.semantic_capsule import inspect_committed_semantic_state
        from braid_client.semantic_transfer import build_frame_from_text

        root = self.root / "field-integration"
        root.mkdir(parents=True, exist_ok=True)
        signing_key, _, _ = load_or_create_signing_key(str(root / "sender.key"))
        material = (
            "The Finch thermal threshold is 73 and it governs Kestrel launch validation. "
            "Archive rotation and backup retention are reviewed every Friday by operations."
        )
        frame, raw, _, _ = build_frame_from_text(
            self.route_dir,
            material,
            signing_key,
            ollama_url=self.fake.url,
            session_id="field-integration-1",
        )
        receiver = self._receiver(root, signing_key)
        report = receiver.process_bytes(
            raw,
            source_transport="network",
            source_name="field.brad",
            peer="192.168.1.50",
        )
        self.assertTrue(report["accepted"], report)
        self.assertTrue(report["phase_b_committed"])
        field = report["semantic_transfer"]["semantic_field"]
        self.assertTrue(field["indexed"])
        self.assertEqual(field["dimension"], 384)
        self.assertEqual(field["atom_count"], 2)
        self.assertEqual(field["novelty_counts"]["novel"], 2)
        for key in (
            "field_manifest_path", "field_atoms_path", "field_vectors_path",
            "field_novelty_path", "field_delta_path",
        ):
            self.assertTrue(Path(report["semantic_transfer"][key]).is_file())

        bundle = load_semantic_field_bundle(
            storage_dir=root / "inbox", object_digest=frame.object_digest
        )
        self.assertEqual(bundle.vectors.shape, (2, 384))
        self.assertEqual(bundle.manifest["embedding"]["model_digest"], self.SOURCE_DIGEST)
        self.assertFalse(bundle.manifest["sender_signature_covers_field"])
        state = inspect_committed_semantic_state(
            storage_dir=root / "inbox", object_digest=frame.object_digest
        )
        self.assertTrue(state["semantic_field"]["indexed"])
        self.assertFalse(state["semantic_field"]["automatic_supersession"])

    def test_field_index_failure_preserves_queryable_committed_capsule_and_can_reindex(self):
        from braid_client.keys import load_or_create_signing_key
        from braid_client.semantic_capsule import inspect_committed_semantic_state
        from braid_client.semantic_transfer import build_frame_from_text

        root = self.root / "field-degraded-recovery"
        root.mkdir(parents=True, exist_ok=True)
        signing_key, _, _ = load_or_create_signing_key(str(root / "sender.key"))
        frame, raw, _, _ = build_frame_from_text(
            self.route_dir,
            "The Finch thermal threshold is 73.",
            signing_key,
            ollama_url=self.fake.url,
            session_id="field-degraded-recovery",
        )
        receiver = self._receiver(
            root,
            signing_key,
            field_model="missing-field-encoder:latest",
        )
        report = receiver.process_bytes(
            raw,
            source_transport="network",
            source_name="field-degraded.brad",
            peer="192.168.1.53",
        )
        self.assertTrue(report["accepted"], report)
        self.assertTrue(report["phase_b_committed"])
        self.assertFalse(report["post_commit_complete"])
        self.assertEqual(report["reason"], "RECEIVER_COMMITTED_HANDOFF_DEGRADED")
        handoff = report["semantic_transfer"]
        self.assertTrue(handoff["accepted"])
        self.assertTrue(handoff["degraded"])
        self.assertFalse(handoff["semantic_field"]["indexed"])
        self.assertIn("ERR_OLLAMA_MODEL_DIGEST", handoff["semantic_field"]["reason"])

        state = inspect_committed_semantic_state(
            storage_dir=root / "inbox", object_digest=frame.object_digest
        )
        self.assertTrue(state["queryable"])
        self.assertFalse(state["semantic_field"]["indexed"])
        self.assertTrue(state["semantic_field"]["degraded"])
        self.assertTrue(Path(handoff["material_path"]).is_file())
        self.assertTrue(Path(handoff["vector_path"]).is_file())

        recovery = reindex_semantic_fields(
            storage_dir=root / "inbox",
            embedding_model=self.SOURCE,
            base_url=self.fake.url,
            timeout_seconds=5,
        )
        self.assertEqual(recovery["indexed_object_count"], 1)
        recovered = inspect_committed_semantic_state(
            storage_dir=root / "inbox", object_digest=frame.object_digest
        )
        self.assertTrue(recovered["semantic_field"]["indexed"])

    def test_signed_delta_frame_is_verified_and_reindexed_without_text_invention(self):
        from braid_client.keys import load_or_create_signing_key
        from braid_client.mcp_core.protocol import BraidFrame
        from braid_client.semantic_transfer import build_frame_from_text

        root = self.root / "delta-integration"
        root.mkdir(parents=True, exist_ok=True)
        signing_key, _, _ = load_or_create_signing_key(str(root / "sender.key"))
        receiver = self._receiver(root, signing_key)
        source_material = (
            "The Finch thermal threshold is 73. "
            "Archive rotation and backup retention are reviewed every Friday."
        )
        source_frame, source_raw, _, _ = build_frame_from_text(
            self.route_dir,
            source_material,
            signing_key,
            ollama_url=self.fake.url,
            session_id="delta-source",
        )
        source_report = receiver.process_bytes(
            source_raw, source_transport="file", source_name="source.brad", peer="local"
        )
        self.assertTrue(source_report["accepted"], source_report)

        delta_material, extension, _ = render_semantic_delta_material(
            storage_dir=root / "inbox",
            object_digest=source_frame.object_digest,
            max_atoms=1,
        )
        delta_frame, delta_raw, _, _ = build_frame_from_text(
            self.route_dir,
            delta_material,
            signing_key,
            ollama_url=self.fake.url,
            session_id="delta-forward",
            semantic_delta_extension=extension,
        )
        signed_evidence = extract_semantic_delta_extension(
            delta_frame.manifest, material=delta_material
        )
        self.assertTrue(signed_evidence["present"])
        self.assertEqual(signed_evidence["atom_count"], 1)

        delta_report = receiver.process_bytes(
            delta_raw, source_transport="network", source_name="delta.brad", peer="192.168.1.51"
        )
        self.assertTrue(delta_report["accepted"], delta_report)
        self.assertTrue(delta_report["semantic_capsule"]["semantic_delta"]["present"])
        delta_bundle = load_semantic_field_bundle(
            storage_dir=root / "inbox", object_digest=delta_frame.object_digest
        )
        self.assertEqual(len(delta_bundle.atoms), 1)
        self.assertEqual(delta_bundle.atoms[0]["source_kind"], "signed_semantic_delta_atom")
        parsed = parse_semantic_delta_material(delta_material)
        self.assertEqual(delta_bundle.atoms[0]["text"], parsed["atoms"][0]["text"])

        tampered_manifest = copy.deepcopy(delta_frame.manifest)
        tampered_manifest["extensions"]["braid_semantic_delta"]["source_object_digest"] = "f" * 64
        tampered = BraidFrame(
            tampered_manifest, delta_frame.vector, signer_private_key=signing_key
        ).to_bytes()
        tamper_root = self.root / "delta-tamper-receiver"
        tamper_root.mkdir(parents=True, exist_ok=True)
        tamper_receiver = self._receiver(tamper_root, signing_key)
        rejected = tamper_receiver.process_bytes(
            tampered, source_transport="file", source_name="delta-tampered.brad", peer="local"
        )
        self.assertFalse(rejected["accepted"], rejected)
        self.assertFalse(rejected["phase_b_committed"])
        self.assertIn("ERR_DELTA_EXTENSION_SOURCE_OBJECT", rejected["reason"])

    def test_heterogeneous_receiver_can_project_native_512d_field_encoder(self):
        from braid_client.keys import load_or_create_signing_key
        from braid_client.semantic_transfer import build_frame_from_text

        root = self.root / "native-projection-integration"
        root.mkdir(parents=True, exist_ok=True)
        signing_key, _, _ = load_or_create_signing_key(str(root / "sender.key"))
        frame, raw, _, _ = build_frame_from_text(
            self.route_dir,
            "The Finch thermal threshold is 73.",
            signing_key,
            ollama_url=self.fake.url,
            session_id="native-projection-integration",
        )
        receiver = self._receiver(
            root,
            signing_key,
            semantic_model=self.TARGET,
            field_model=self.TARGET,
            verify_exact=False,
        )
        report = receiver.process_bytes(
            raw,
            source_transport="network",
            source_name="native-field.brad",
            peer="192.168.1.52",
        )
        self.assertTrue(report["accepted"], report)
        self.assertEqual(
            report["semantic_transfer"]["transfer_method"],
            "semantic_capsule_local_reembed",
        )
        field = report["semantic_transfer"]["semantic_field"]
        self.assertEqual(field["embedding_model_digest"], self.TARGET_DIGEST)
        self.assertEqual(
            field["embedding_adapter"],
            "digest_seeded_signed_feature_hash_v1",
        )
        bundle = load_semantic_field_bundle(
            storage_dir=root / "inbox", object_digest=frame.object_digest
        )
        self.assertEqual(bundle.manifest["embedding"]["source_dimension"], 512)
        self.assertEqual(bundle.vectors.shape, (1, 384))


if __name__ == "__main__":
    unittest.main()
