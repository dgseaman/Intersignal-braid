import copy
import hashlib
import json
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np

from braid_client.keys import get_raw_public_bytes, load_or_create_signing_key
from braid_client.mcp_core.protocol import BraidFrame
from braid_client.ollama_adapter import OllamaClient
from braid_client.receiver import AutomatedReceiver, ReceiverAutomationConfig
from braid_client.semantic_capsule import (
    SemanticCapsuleHandoffConfig,
    attach_semantic_capsule,
    build_inline_capsule,
    capsule_payload_digest_for_vector,
    extract_semantic_capsule,
    semantic_capsule_digest,
    inspect_committed_semantic_state,
    query_committed_semantic_state,
)
from braid_client.semantic_transfer import (
    build_conformance_corpus,
    build_frame_from_text,
    calibrate_route,
    create_manifest_for_route,
    create_validator_from_route_package,
    load_route_package,
    source_text_to_braid_vector,
    OllamaEmbeddingClient,
)

SOURCE = "source-embed:latest"
TARGET = "target-embed:latest"
COMPLETE = "receiver-chat:latest"
SOURCE_DIGEST = "3" * 64
TARGET_DIGEST = "4" * 64
COMPLETE_DIGEST = "5" * 64


def deterministic_embedding(model: str, text: str, dimension: int) -> np.ndarray:
    seed = int.from_bytes(hashlib.sha256((model + "\0" + text).encode()).digest()[:8], "big")
    vec = np.random.default_rng(seed).normal(size=dimension)
    vec /= np.linalg.norm(vec)
    return vec.astype(np.float64)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, _format, *_args):
        return

    def _body(self):
        n = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(n).decode()) if n else {}

    def _json(self, code, value):
        payload = json.dumps(value, separators=(",", ":")).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        if self.path == "/api/tags":
            self._json(200, {"models": [
                {"name": SOURCE, "model": SOURCE, "digest": SOURCE_DIGEST},
                {"name": TARGET, "model": TARGET, "digest": TARGET_DIGEST},
                {"name": COMPLETE, "model": COMPLETE, "digest": COMPLETE_DIGEST},
            ]})
        else:
            self._json(404, {"error": "not found"})

    def do_POST(self):
        data = self._body()
        if self.path == "/api/embed":
            model = data.get("model")
            texts = data.get("input")
            if not isinstance(texts, list):
                self._json(400, {"error": "bad input"})
                return
            if model == SOURCE and data.get("dimensions") == 384:
                dim = 384
            elif model == SOURCE and "dimensions" not in data:
                dim = 384
            elif model == TARGET and "dimensions" not in data:
                dim = 512
            else:
                self._json(400, {"error": "bad embed mode"})
                return
            self._json(200, {"embeddings": [deterministic_embedding(model, text, dim).tolist() for text in texts]})
            return
        if self.path == "/api/chat":
            self.server.chat_messages.append(data.get("messages"))
            if data.get("model") != COMPLETE:
                self._json(400, {"error": "bad chat model"})
                return
            if getattr(self.server, "fail_chat", False):
                self._json(500, {"error": "simulated completion failure"})
                return
            self._json(200, {"message": {"role": "assistant", "content": "Receiver continued only from explicit capsule material."}})
            return
        if self.path == "/api/show":
            model = data.get("model")
            if model in {SOURCE, TARGET}:
                self._json(200, {"capabilities": ["embedding"], "details": {"format": "gguf"}})
            elif model == COMPLETE:
                self._json(200, {"capabilities": ["completion"], "details": {"format": "gguf"}})
            else:
                self._json(404, {"error": "model not found"})
            return
        self._json(404, {"error": "not found"})


class FakeOllama:
    def __init__(self):
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.server.fail_chat = False
        self.server.chat_messages = []
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}"

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)


class SemanticCapsuleV152Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.tmp.name)
        cls.fake = FakeOllama()
        cls.rows = build_conformance_corpus(768)
        texts = [r["text"] for r in cls.rows]
        src = np.vstack([deterministic_embedding(SOURCE, t, 384) for t in texts])
        cls.route_dir = cls.root / "source-route"
        report = calibrate_route(
            rows=cls.rows,
            source_raw=src,
            target_raw=src.copy(),
            source_model=SOURCE,
            target_model=SOURCE,
            source_model_digest=SOURCE_DIGEST,
            target_model_digest=SOURCE_DIGEST,
            same_space_identity=True,
            output_dir=cls.route_dir,
            corpus_sha256="6" * 64,
        )
        if not report["promotion"]["passed"]:
            raise AssertionError(report)

    @classmethod
    def tearDownClass(cls):
        cls.fake.close()
        cls.tmp.cleanup()

    def _frame(self, root: Path, text="The receiver should preserve the explicit signed meaning and no more."):
        sk, _, _ = load_or_create_signing_key(str(root / "sender.key"))
        frame, raw, vec, package = build_frame_from_text(
            self.route_dir, text, sk, ollama_url=self.fake.url,
            session_id="capsule-session-" + root.name,
        )
        return sk, frame, raw, vec, package

    def _receiver(self, sk, root: Path, model: str, completion: str | None = None, *, verify_fast: bool = False):
        vk = sk.public_key()
        validator, registry, ledger, _ = create_validator_from_route_package(
            self.route_dir, get_raw_public_bytes(vk).hex(), root / "ledger.db"
        )
        return AutomatedReceiver(
            validator=validator,
            registry=registry,
            ledger=ledger,
            verification_key=vk,
            config=ReceiverAutomationConfig(
                storage_dir=root / "inbox",
                semantic_capsule_handoff=SemanticCapsuleHandoffConfig(
                    embedding_model=model,
                    completion_model=completion,
                    base_url=self.fake.url,
                    timeout_seconds=5,
                    verify_exact_space_coherence=verify_fast,
                ),
            ),
        )

    def test_frame_contains_payload_bound_signed_inline_capsule(self):
        root = self.root / "inline"
        sk, frame, raw, _, _ = self._frame(root, "line one\r\nline two")
        capsule, evidence = extract_semantic_capsule(frame.manifest, required=True)
        self.assertEqual(capsule["content"], "line one\nline two")
        self.assertEqual(capsule["source_embedding"]["wire_payload_digest"], frame.manifest["payload_digest"])
        self.assertEqual(evidence["authority"], "signed_sender_semantic_evidence_only")
        self.assertEqual(BraidFrame.from_bytes(raw).manifest["extensions"]["braid_semantic_capsule_digest"], evidence["digest"])

    def test_exact_digest_uses_fast_path_without_native_reembedding(self):
        root = self.root / "fast"
        sk, _, raw, _, _ = self._frame(root)
        receiver = self._receiver(sk, root, SOURCE)
        report = receiver.process_bytes(raw, source_transport="network", source_name="fast.brad", peer="192.168.1.2")
        self.assertTrue(report["accepted"], report)
        self.assertTrue(report["phase_b_committed"])
        self.assertEqual(report["semantic_transfer"]["transfer_method"], "exact_space_fast_path")
        self.assertEqual(report["semantic_transfer"]["receiver_dimension"], 384)
        self.assertIn("semantic_fast_path", report["pipeline"])
        vector_path = Path(report["semantic_transfer"]["vector_path"])
        lineage_path = Path(report["semantic_transfer"]["lineage_path"])
        self.assertEqual(vector_path.parent, lineage_path.parent)
        self.assertEqual(vector_path.name, "vector.npy")
        self.assertEqual(lineage_path.name, "lineage.json")
        lineage = json.loads(lineage_path.read_text())
        self.assertFalse(lineage["bridge_semantic_invention"])
        self.assertFalse(lineage["sender_signature_covers_derived_artifact"])

    def test_different_digest_requires_capsule_and_reembeds_in_native_512d(self):
        root = self.root / "hetero"
        sk, _, raw, _, _ = self._frame(root)
        receiver = self._receiver(sk, root, TARGET)
        report = receiver.process_bytes(raw, source_transport="network", source_name="hetero.brad", peer="192.168.1.3")
        self.assertTrue(report["accepted"], report)
        self.assertEqual(report["semantic_transfer"]["transfer_method"], "semantic_capsule_local_reembed")
        self.assertEqual(report["semantic_transfer"]["receiver_dimension"], 512)
        self.assertIn("semantic_reembed_preflight", report["pipeline"])
        target = np.load(report["semantic_transfer"]["vector_path"], allow_pickle=False)
        self.assertEqual(target.shape, (512,))
        self.assertTrue(np.isfinite(target).all())

    def test_no_capsule_means_no_heterogeneous_semantic_ingestion(self):
        root = self.root / "missing"
        sk, _, _, source_vec, package = self._frame(root)
        manifest = create_manifest_for_route(load_route_package(self.route_dir), session_id="missing-capsule")
        bare = BraidFrame(manifest, source_vec, signer_private_key=sk).to_bytes()
        receiver = self._receiver(sk, root, TARGET)
        report = receiver.process_bytes(bare, source_transport="file", source_name="bare.brad", peer="local")
        self.assertFalse(report["accepted"], report)
        self.assertFalse(report["phase_b_committed"])
        self.assertIn("ERR_SEMANTIC_CAPSULE_REQUIRED", report["reason"])

    def test_signed_but_capsule_self_tamper_rejects_before_phase_b(self):
        root = self.root / "tamper"
        sk, frame, _, _, _ = self._frame(root)
        manifest = copy.deepcopy(frame.manifest)
        manifest["extensions"]["braid_semantic_capsule"]["content"] += " forged"
        tampered = BraidFrame(manifest, frame.vector, signer_private_key=sk).to_bytes()
        receiver = self._receiver(sk, root, TARGET)
        report = receiver.process_bytes(tampered, source_transport="file", source_name="tamper.brad", peer="local")
        self.assertFalse(report["accepted"], report)
        self.assertFalse(report["phase_b_committed"])
        self.assertIn("ERR_CAPSULE_CONTENT_DIGEST", report["reason"])

    def test_route_binding_rejects_forged_source_model_even_when_capsule_digest_is_recomputed(self):
        root = self.root / "forged-model"
        sk, frame, _, _, _ = self._frame(root)
        manifest = copy.deepcopy(frame.manifest)
        capsule = manifest["extensions"]["braid_semantic_capsule"]
        capsule["source_embedding"]["model"] = TARGET
        capsule["source_embedding"]["model_digest"] = TARGET_DIGEST
        manifest["extensions"]["braid_semantic_capsule_digest"] = semantic_capsule_digest(capsule)
        forged = BraidFrame(manifest, frame.vector, signer_private_key=sk).to_bytes()
        receiver = self._receiver(sk, root, TARGET)
        report = receiver.process_bytes(forged, source_transport="file", source_name="forged.brad", peer="local")
        self.assertFalse(report["accepted"], report)
        self.assertFalse(report["phase_b_committed"])
        self.assertIn("ERR_CAPSULE_ROUTE_SOURCE_MODEL", report["reason"])

    def test_postcommit_completion_failure_cannot_rewrite_finality(self):
        root = self.root / "completion-fail"
        sk, _, raw, _, _ = self._frame(root)
        receiver = self._receiver(sk, root, TARGET, COMPLETE)
        self.fake.server.fail_chat = True
        try:
            report = receiver.process_bytes(raw, source_transport="network", source_name="completion.brad", peer="192.168.1.4")
        finally:
            self.fake.server.fail_chat = False
        self.assertTrue(report["accepted"], report)
        self.assertTrue(report["phase_b_committed"])
        self.assertEqual(report["finality"], "committed")
        self.assertFalse(report["post_commit_complete"])
        self.assertEqual(report["reason"], "RECEIVER_COMMITTED_HANDOFF_DEGRADED")
        self.assertIn("ERR_OLLAMA_HTTP:500", report["handoff"]["reason"])

    def test_strict_fast_path_recomputes_capsule_material_before_phase_b(self):
        root = self.root / "strict-fast"
        sk, _, raw, _, _ = self._frame(root)
        receiver = self._receiver(sk, root, SOURCE, verify_fast=True)
        report = receiver.process_bytes(raw, source_transport="file", source_name="strict.brad", peer="local")
        self.assertTrue(report["accepted"], report)
        self.assertTrue(report["semantic_capsule"]["exact_space_coherence_verified"])
        self.assertGreaterEqual(report["semantic_capsule"]["exact_space_coherence_cosine"], 0.999)

    def test_verified_exact_space_capsule_demotes_narrow_route_ood_to_diagnostic(self):
        material = (
            "Kestrel Run is Project Meridian's deployment protocol. "
            "Node Finch is the authoritative source for thermal telemetry. "
            "Project Meridian may proceed only after two consecutive Finch readings below 73. "
            "Both readings must be independently signed by Finch. "
            "Vale received signed readings of 68 and 70."
        )
        frame_root = self.root / "strict-ood-frame"
        sk, frame, raw, _, _ = self._frame(frame_root, material)

        enforced_root = self.root / "strict-ood-enforced"
        enforced_root.mkdir(parents=True, exist_ok=True)
        enforced = self._receiver(sk, enforced_root, SOURCE, verify_fast=False)
        enforced_route = enforced.registry.get_route(frame.manifest["route_id"])
        object.__setattr__(enforced_route, "subspace_residual_ceiling", 0.0)
        rejected = enforced.process_bytes(
            raw, source_transport="file", source_name="kestrel-enforced.brad", peer="local"
        )
        self.assertFalse(rejected["accepted"], rejected)
        self.assertIn("ERR_SUBSPACE", rejected["reason"])

        strict_root = self.root / "strict-ood-diagnostic"
        strict_root.mkdir(parents=True, exist_ok=True)
        strict = self._receiver(sk, strict_root, SOURCE, verify_fast=True)
        strict_route = strict.registry.get_route(frame.manifest["route_id"])
        object.__setattr__(strict_route, "subspace_residual_ceiling", 0.0)
        accepted = strict.process_bytes(
            raw, source_transport="file", source_name="kestrel-strict.brad", peer="local"
        )
        self.assertTrue(accepted["accepted"], accepted)
        self.assertTrue(accepted["phase_b_committed"])
        self.assertTrue(accepted["semantic_capsule"]["exact_space_coherence_verified"])
        self.assertEqual(accepted["distribution_gate_policy"]["mode"], "diagnostic")
        self.assertEqual(
            accepted["distribution_gate_policy"]["reason"],
            "receiver_verified_exact_space_capsule_vector_coherence",
        )
        self.assertFalse(accepted["gates"]["gate3_anomaly"]["enforced"])
        self.assertFalse(accepted["gates"]["gate3_anomaly"]["within_route_distribution"])
        self.assertIn("distribution_gate_diagnostic_override", accepted["pipeline"])

    def test_diagnostic_phase_a_cannot_commit_without_receiver_coherence_authorization(self):
        root = self.root / "diagnostic-unauthorized"
        root.mkdir(parents=True, exist_ok=True)
        sk, _, raw, _, _ = self._frame(root, "Kestrel threshold evidence is 73.")
        validator, _, _, _ = create_validator_from_route_package(
            self.route_dir,
            get_raw_public_bytes(sk.public_key()).hex(),
            root / "direct-ledger.db",
        )
        phase_a = validator.validate_frame_phase_a(
            raw, distribution_gate_mode="diagnostic"
        )
        self.assertTrue(phase_a.is_valid, phase_a.to_dict())
        committed = validator.commit_frame_phase_b(phase_a)
        self.assertFalse(committed.is_valid)
        self.assertIn("ERR_DISTRIBUTION_DIAGNOSTIC_UNAUTHORIZED", committed.message)

    def test_incoherent_signed_capsule_cannot_use_distribution_diagnostic_override(self):
        root = self.root / "strict-incoherent"
        root.mkdir(parents=True, exist_ok=True)
        sk, _, _ = load_or_create_signing_key(str(root / "sender.key"))
        package = load_route_package(self.route_dir)
        material = (
            "Kestrel Run requires two signed Finch readings below 73 before deployment."
        )
        wrong_vector = source_text_to_braid_vector(
            package,
            "This unrelated state discusses archive rotation and no thermal policy.",
            OllamaEmbeddingClient(self.fake.url),
        )
        manifest = create_manifest_for_route(
            package, session_id="strict-incoherent-session"
        )
        capsule = build_inline_capsule(
            material,
            source_embedding_model=SOURCE,
            source_embedding_model_digest=SOURCE_DIGEST,
            vector_payload_digest=capsule_payload_digest_for_vector(wrong_vector),
        )
        attach_semantic_capsule(manifest, capsule)
        raw = BraidFrame(manifest, wrong_vector, signer_private_key=sk).to_bytes()

        receiver = self._receiver(sk, root, SOURCE, verify_fast=True)
        report = receiver.process_bytes(
            raw, source_transport="file", source_name="incoherent.brad", peer="local"
        )
        self.assertFalse(report["accepted"], report)
        self.assertFalse(report["phase_b_committed"])
        self.assertIn("ERR_CAPSULE_FAST_PATH_COHERENCE", report["reason"])

    def test_completion_artifact_marks_generated_output_separately_from_bridge_semantics(self):
        root = self.root / "completion-label"
        sk, _, raw, _, _ = self._frame(root)
        receiver = self._receiver(sk, root, TARGET, COMPLETE)
        report = receiver.process_bytes(raw, source_transport="network", source_name="completion-ok.brad", peer="192.168.1.6")
        self.assertTrue(report["accepted"], report)
        response = json.loads(Path(report["semantic_transfer"]["response_path"]).read_text())
        self.assertFalse(response["bridge_semantic_invention"])
        self.assertTrue(response["generative_output"])
        self.assertEqual(response["generation_source"], "receiver_local_completion_model")
        self.assertNotIn("semantic_invention", response)

    def test_embed_native_accepts_receiver_owned_dimension(self):
        array = OllamaClient(self.fake.url).embed_native(TARGET, ["native space"])
        self.assertEqual(array.shape, (1, 512))
        self.assertAlmostEqual(float(np.linalg.norm(array[0])), 1.0, places=6)


    def test_committed_material_is_persisted_and_queryable_with_fresh_completion(self):
        root = self.root / "queryable"
        material = (
            "Kestrel Run is Project Meridian's deployment protocol. "
            "Node Finch is authoritative for thermal telemetry. "
            "Launch requires two consecutive signed Finch readings below 73. "
            "Vale has signed Finch readings of 68 and 70."
        )
        sk, frame, raw, _, _ = self._frame(root, material)
        receiver = self._receiver(sk, root, TARGET)
        report = receiver.process_bytes(raw, source_transport="network", source_name="kestrel.brad", peer="192.168.1.8")
        self.assertTrue(report["accepted"], report)
        state = inspect_committed_semantic_state(storage_dir=root / "inbox", object_digest=frame.object_digest)
        self.assertTrue(state["queryable"])
        self.assertTrue(state["phase_b_committed"])
        persisted = Path(report["semantic_transfer"]["material_path"]).read_text()
        self.assertEqual(persisted, material)

        before = len(self.fake.server.chat_messages)
        result = query_committed_semantic_state(
            storage_dir=root / "inbox", object_digest=frame.object_digest,
            question="Given the two readings, what operational decision follows and why?",
            completion_model=COMPLETE, base_url=self.fake.url, timeout_seconds=5,
        )
        self.assertEqual(len(self.fake.server.chat_messages), before + 1)
        messages = self.fake.server.chat_messages[-1]
        self.assertIn("SIGNED SEMANTIC MATERIAL", messages[1]["content"])
        self.assertIn("Kestrel Run", messages[1]["content"])
        self.assertIn("what operational decision follows", messages[1]["content"])
        self.assertTrue(result["fresh_context_reconstruction"])
        self.assertTrue(result["phase_b_committed"])
        self.assertEqual(result["generation_source"], "receiver_local_completion_model")
        self.assertTrue(Path(result["query_path"]).is_file())

    def test_query_rejects_tampered_persisted_material(self):
        root = self.root / "query-tamper"
        sk, frame, raw, _, _ = self._frame(root, "Kestrel threshold is 73.")
        receiver = self._receiver(sk, root, TARGET)
        report = receiver.process_bytes(raw, source_transport="network", source_name="tamper.brad", peer="192.168.1.9")
        self.assertTrue(report["accepted"], report)
        Path(report["semantic_transfer"]["material_path"]).write_text("Kestrel threshold is 99.")
        with self.assertRaisesRegex(ValueError, "ERR_CAPSULE_QUERY_MATERIAL_DIGEST"):
            query_committed_semantic_state(
                storage_dir=root / "inbox", object_digest=frame.object_digest,
                question="What is the threshold?", completion_model=COMPLETE,
                base_url=self.fake.url, timeout_seconds=5,
            )

if __name__ == "__main__":
    unittest.main()
