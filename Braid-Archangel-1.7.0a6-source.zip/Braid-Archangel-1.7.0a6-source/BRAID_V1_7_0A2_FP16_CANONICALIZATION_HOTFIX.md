# Braid v1.7.0a2 — FP16 Canonicalization Hotfix

## Physical UAT finding

A macOS-generated Semantic Capsule containing an `all-minilm:latest` vector was
correctly rejected on Linux with:

`ERR_VECTOR_NEGATIVE_ZERO: Payload contains forbidden negative-zero float16 encoding (0x8000).`

NumPy FP16 conversion can underflow a tiny negative finite component to `-0.0`.
The v1.7.0a1 receiver correctly enforced the existing canonical wire rule, but
the sender did not canonicalize zeros before hashing and signing the payload.

## Fix

v1.7.0a2 canonicalizes every FP16 zero to the single positive-zero encoding
`0x0000` after FP16 rounding and before payload digest computation and Ed25519
signature generation. Receiver rejection of incoming `0x8000` is retained.

No tolerance, acceptance, signature, replay, or finality rule was weakened.
Previously created `.brad` frames are immutable signed objects and must be
regenerated with v1.7.0a2.
