#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
"$ROOT/packaging/macos/build_standalone_app.sh"
"$ROOT/packaging/macos/build_dmg.sh" "$ROOT/dist/macos-standalone/Braid.app"
"$ROOT/packaging/macos/verify_release_macos.sh"
