#!/bin/sh
set -eu

if [ "$(uname -s)" != "Darwin" ]; then
  echo "macOS release verification must run on Darwin." >&2
  exit 2
fi

ROOT=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
APP=${BRAID_APP_PATH:-"$ROOT/dist/macos-standalone/Braid.app"}
DMG=${BRAID_DMG_PATH:-}

if [ -z "$DMG" ]; then
  DMG=$(find "$ROOT/dist" -maxdepth 1 -type f -name 'Braid-1.6.1rc1-macOS-*.dmg' | head -1 || true)
fi

[ -d "$APP" ] || { echo "Missing standalone app: $APP" >&2; exit 1; }
[ -n "$DMG" ] && [ -f "$DMG" ] || { echo "Missing Braid 1.6.1rc1 DMG under $ROOT/dist (or set BRAID_DMG_PATH)." >&2; exit 1; }
CLI="$APP/Contents/MacOS/braid-client"
RELEASE_RES="$APP/Contents/Resources/BraidRelease"
[ -x "$CLI" ] || { echo "Missing executable bundled CLI: $CLI" >&2; exit 1; }
for required in release-runtime-lock.txt release-pip-inspect.json release-requirements.txt release-wheelhouse-sha256.txt release-python-version.txt release-architecture.txt THIRD_PARTY_NOTICES.md; do
  [ -s "$RELEASE_RES/$required" ] || { echo "Missing release evidence in app: $required" >&2; exit 1; }
done

EVIDENCE_DIR=${BRAID_GATE_EVIDENCE_DIR:-"$ROOT/dist/release-gate-evidence"}
mkdir -p "$EVIDENCE_DIR"
REPORT="$EVIDENCE_DIR/native-macos-verification.txt"
: > "$REPORT"

log() {
  printf '%s\n' "$*" | tee -a "$REPORT"
}

run() {
  log "+ $*"
  "$@" >> "$REPORT" 2>&1
}

log "Braid v1.6.1rc1 native macOS release verification"
log "Generated: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
log "Host: $(sw_vers -productName) $(sw_vers -productVersion) / $(uname -m)"
log "App: $APP"
log "DMG: $DMG"
log ""

run /usr/bin/codesign --verify --deep --strict --verbose=2 "$APP"
run /usr/bin/codesign -dv --verbose=4 "$APP"
run /usr/bin/hdiutil verify "$DMG"
run "$CLI" --version
run "$CLI" doctor
ENV_JSON="$EVIDENCE_DIR/environment.json"
"$CLI" environment > "$ENV_JSON"
/usr/bin/grep -F "$CLI" "$ENV_JSON" >/dev/null || { log "FAIL: environment commands are not bound to bundled CLI path"; exit 1; }
log "PASS: bundled CLI executes and environment points back to same-install CLI"

PYVER=$(cat "$RELEASE_RES/release-python-version.txt")
[ "$PYVER" = "3.12.10" ] || { log "FAIL: unexpected frozen Python: $PYVER"; exit 1; }
BUILD_ARCH=$(cat "$RELEASE_RES/release-architecture.txt")
[ "$BUILD_ARCH" = "$(uname -m)" ] || { log "FAIL: app architecture evidence $BUILD_ARCH != host $(uname -m)"; exit 1; }
for pin in 'numpy==2.5.1' 'cryptography==49.0.0' 'jsonschema==4.26.0' 'bleak==3.0.2' 'opencv-python-headless==4.13.0.92' 'pyinstaller==6.21.0'; do
  /usr/bin/grep -F "$pin" "$RELEASE_RES/release-runtime-lock.txt" >/dev/null || { log "FAIL: runtime lock missing $pin"; exit 1; }
done
log "PASS: frozen Python and direct runtime pins match reviewed release inputs"

BUNDLE_ID=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APP/Contents/Info.plist")
VERSION=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$APP/Contents/Info.plist")
MIN_OS=$(/usr/libexec/PlistBuddy -c 'Print :LSMinimumSystemVersion' "$APP/Contents/Info.plist")
[ "$BUNDLE_ID" = "ai.intersignal.braid" ] || { log "FAIL: unexpected bundle id: $BUNDLE_ID"; exit 1; }
[ "$VERSION" = "1.6.1" ] || { log "FAIL: unexpected app version: $VERSION"; exit 1; }
case "$BUILD_ARCH" in
  arm64) EXPECTED_MIN_OS=13.0 ;;
  x86_64) EXPECTED_MIN_OS=14.0 ;;
  *) log "FAIL: unsupported release architecture $BUILD_ARCH"; exit 1 ;;
esac
[ "$MIN_OS" = "$EXPECTED_MIN_OS" ] || { log "FAIL: LSMinimumSystemVersion $MIN_OS != $EXPECTED_MIN_OS for $BUILD_ARCH"; exit 1; }
log "PASS: bundle id/version/minimum OS = $BUNDLE_ID / $VERSION / $MIN_OS"

run /usr/bin/file "$APP/Contents/MacOS/Braid"
run /usr/bin/file "$CLI"
run /usr/bin/shasum -a 256 "$DMG"

MOUNT_DIR=$(mktemp -d "${TMPDIR:-/tmp}/braid161rc1-dmg.XXXXXX")
cleanup() {
  /usr/bin/hdiutil detach "$MOUNT_DIR" -quiet >/dev/null 2>&1 || true
  rmdir "$MOUNT_DIR" >/dev/null 2>&1 || true
}
trap cleanup EXIT HUP INT TERM

run /usr/bin/hdiutil attach -nobrowse -readonly -mountpoint "$MOUNT_DIR" "$DMG"
[ -d "$MOUNT_DIR/Braid.app" ] || { log "FAIL: mounted DMG missing Braid.app"; exit 1; }
[ -L "$MOUNT_DIR/Applications" ] || { log "FAIL: mounted DMG missing Applications symlink"; exit 1; }
[ -f "$MOUNT_DIR/README.md" ] || { log "FAIL: mounted DMG missing README.md"; exit 1; }
[ -f "$MOUNT_DIR/LICENSE" ] || { log "FAIL: mounted DMG missing LICENSE"; exit 1; }
run /usr/bin/codesign --verify --deep --strict --verbose=2 "$MOUNT_DIR/Braid.app"
log "PASS: mounted DMG layout and app signature verify"

if [ -n "${BRAID_CODESIGN_IDENTITY:-}" ]; then
  log "Developer ID identity was supplied to the build; running Gatekeeper app assessment."
  run /usr/sbin/spctl --assess --type execute --verbose=4 "$APP"
else
  log "NOTE: no BRAID_CODESIGN_IDENTITY in this verification environment; ad-hoc/local UAT signature is not a public Gatekeeper/notarization claim."
fi

if [ -n "${BRAID_NOTARY_PROFILE:-}" ]; then
  run /usr/bin/xcrun stapler validate "$DMG"
fi

log ""
log "PASS: native package integrity gate complete."
log "MANUAL RELEASE-BLOCKING FOLLOW-UP: launch the installed app from /Applications and execute FINAL_MACOS_RELEASE_GATE_v1.6.1rc1.md plus BRAID_V1_5_2_2NODE_SEMANTIC_UAT.md plus BRAID_V1_6_0RC2_KESTREL_QUERY_UAT.md on the physical Macs."
log "Evidence: $REPORT"
