"""Console entry bundled inside Braid.app."""
from __future__ import annotations
import sys
from braid_client.cli import main
if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
