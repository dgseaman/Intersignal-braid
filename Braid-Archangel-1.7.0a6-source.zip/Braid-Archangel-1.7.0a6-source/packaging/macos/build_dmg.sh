#!/bin/sh
set -eu
if [ "$(uname -s)" != "Darwin" ]; then
  echo "DMG creation requires macOS hdiutil. Run this script on the release Mac." >&2
  exit 2
fi
ROOT=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
APP=${1:-"$ROOT/dist/macos-standalone/Braid.app"}
OUT=${2:-"$ROOT/dist/Braid-1.6.1rc1-macOS-$(uname -m).dmg"}
[ -d "$APP" ] || { echo "Missing app: $APP" >&2; exit 1; }
STAGE="$ROOT/build/dmg-stage"
rm -rf "$STAGE" "$OUT"
mkdir -p "$STAGE"
cp -R "$APP" "$STAGE/Braid.app"
ln -s /Applications "$STAGE/Applications"
cp "$ROOT/README.md" "$ROOT/LICENSE" "$STAGE/"
hdiutil create -quiet -volname "Braid 1.6.1rc1" -fs HFS+ -format UDZO -srcfolder "$STAGE" "$OUT"
hdiutil verify "$OUT" >/dev/null
if [ -n "${BRAID_CODESIGN_IDENTITY:-}" ]; then
  codesign --timestamp --sign "$BRAID_CODESIGN_IDENTITY" "$OUT"
  codesign --verify --verbose=2 "$OUT"
fi
if [ -n "${BRAID_NOTARY_PROFILE:-}" ]; then
  if [ -z "${BRAID_CODESIGN_IDENTITY:-}" ]; then
    echo "BRAID_NOTARY_PROFILE requires a Developer ID signing identity." >&2
    exit 3
  fi
  xcrun notarytool submit "$OUT" --keychain-profile "$BRAID_NOTARY_PROFILE" --wait
  xcrun stapler staple "$OUT"
  xcrun stapler validate "$OUT"
fi
shasum -a 256 "$OUT"
echo "$OUT"
