# Braid Legend v1.5.2

## Purpose

A **Braid Legend** is a bounded semantic/temporal sidecar carried inside the signed Braid manifest. The 384D state carries a compact gestalt; the Legend names the relationships, constraints, provenance-sensitive facts, temporal conditions, and anchors whose loss would materially change the handoff.

A Legend is **sender context, not receiver authority**. Its presence, quality, model confidence, salience weights, or semantic similarity can never create Braid acceptance or expand effective authority.

## Signature binding

The normalized Legend is stored at:

- `manifest.extensions.braid_legend`
- `manifest.extensions.braid_legend_digest`
- `manifest.extensions.braid_legend_authority = "signed_sender_context_only"`

The manifest is part of the existing Braid Ed25519 signature preimage. Therefore the Legend, its digest, and its authority label are covered by the sender signature. The Legend digest is domain separated as:

`SHA256("BRAID-LEGEND-v1\\0" || JCS(normalized_legend))`

The Braid wire profile remains the 1.4 frame profile; v1.5.2 adds semantics inside the signed extension object rather than inventing a second acceptance path.

## Bounded schema

`braid.legend.v1` contains:

- `objective` - current objective;
- `active_intent` - immediate continuation intent;
- `constraints[]` - typed operational/safety/policy/budget/technical/temporal constraints, each optionally critical;
- `branch_conditions[]` - explicit `if -> then` branch conditions;
- `provenance_facts[]` - facts with bounded provenance and confidence labels;
- `temporal_salience[]` - session/immediate/durable significance and optional expiry;
- `significance[]` - consequence-weighted concepts (1-5);
- `must_preserve[]` - concepts whose loss would materially invalidate the handoff;
- `archive_refs[]` - optional references to durable local material;
- `generator` - exact local completion model tag, model digest, and `ollama:/api/chat` backend;
- `source_text_sha256` - digest of the source text distilled into the Legend;
- `created_at` - source-side creation time.

The canonical Legend is capped at 7168 JCS bytes, with per-field length and list-count ceilings. Unknown fields, control characters, malformed enum values, invalid digests, and malformed temporal values fail closed.

## Provenance language

The built-in distiller deliberately avoids claiming provenance it cannot independently verify. Supported provenance labels include:

- `source_text_explicit`
- `model_inference`
- `source_claimed_tool_result`
- `source_claimed_document`
- `unknown`

A source text saying "tool X returned Y" can be preserved as a source claim, but the Legend does not transform that claim into verified receiver evidence.

## 384D binding

For the built-in Ollama path, Braid renders a deterministic semantic view of the Legend using JCS and embeds that canonical text with the configured route source embedding model. The route then produces the signed 384D source-space state.

On the receiver, the route's target-space 384D result is derived during Phase A. After Phase B, the built-in Ollama handoff independently embeds the same signed Legend using the configured target embedding model and records the cosine alignment between that target Legend embedding and the receiver-derived target vector.

That alignment is receiver-local evidence. It is never authority.

## Finality invariant

Legend handling preserves the Braid constitution:

`accepted == (finality == "committed")`

`accepted => phase_b_committed`

A structurally present Legend with an incorrect Legend digest is rejected before Phase B. A valid Legend cannot make an otherwise invalid frame acceptable. A receiver-side Ollama failure after Phase B can mark delivery degraded, but cannot rewrite committed finality as rejection.
