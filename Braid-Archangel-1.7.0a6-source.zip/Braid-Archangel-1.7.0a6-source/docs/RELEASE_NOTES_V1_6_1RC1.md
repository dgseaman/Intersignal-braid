# Braid Light Client v1.6.1rc1 Release Notes

Release status: **source release candidate**. v1.6.1rc1 turns the proven Kestrel sender/relay/receiver path into an operator-facing context workflow. The release is not a claim that an unconfigured relay is live: the packaged DigitalOcean profile contains no invented hostname, certificate pin, enrollment token, or private identity material. A physical two-node UAT against the exact production relay identity remains required before a final v1.6.1 stamp.

## Flag-plant feature: Summarize Context -> Send Context

The loopback Field UI now exposes the complete human-facing path:

1. paste or load up to 6,000 UTF-8 bytes of source context;
2. select **Summarize Context**;
3. review and edit the local distillation;
4. choose an approved Jump Kit receiver;
5. select **Send Context ->**;
6. distinguish relay reachability from the remote receiver acknowledgement;
7. show success only when the returned acknowledgement says `stored: true`, `validated: true`, and `accepted: true`.

The success state is intentionally explicit: `Context accepted by <receiver>` and `Verified · Phase B committed · <latency>`. A TLS connection, relay round trip, or successful sender-side capsule build is never rendered as acceptance.

## Local, reviewable distillation

`/api/context/summary` uses an eligible loopback-only Ollama completion model when one is available. The model is instructed to preserve identifiers, numbers, thresholds, negations, constraints, provenance, and uncertainty without adding facts. If no eligible local completion model is available, Braid returns a deterministic extractive fallback made from source text. In both cases:

- no context is sent during summarization;
- the result is bounded by the Semantic Capsule 6,000-byte limit;
- the operator may edit the result;
- the exact reviewed text, after Braid's documented NFC/LF canonicalization, is what is signed.

## Real Managed Relay / Jump Kit handoff

The send path invokes an installed `braid-jumpkit` executable with `shell=False` and the existing signed-device/approved-peer relay contract. It passes the configured identity file, relay host and port, CA, TLS server name, SHA-256 certificate pin, and enrollment-token file by path. Secret contents are never returned through the UI/API or written into the transfer audit.

The packaged non-secret infrastructure profile records:

- provider: DigitalOcean;
- region: NYC1;
- operating system: Ubuntu 24.04 LTS x64;
- reference droplet class: Basic Premium Intel, 2 vCPU, 4 GB RAM, 120 GB disk;
- relay policy: TLS 1.3 on port 8750;
- transport role: opaque reach only.

The live host, SNI/server name, and certificate pin are blank by design until an operator supplies the exact provisioned identity. The UI reports `configuration required` and refuses to enable sending rather than fabricating readiness.

## Capacity and operator controls

The managed path includes:

- `BRAID_MANAGED_RELAY_ENABLED` as a local kill switch;
- `BRAID_MANAGED_RELAY_MAX_CONCURRENT_SENDS` with a bounded default of 4;
- bounded peer/status and send timeouts;
- a private local outbox for retryable signed frames;
- a private JSONL transfer audit;
- no recurring browser-side peer polling beyond initial/manual refresh.

This allows the current droplet to remain the initial managed path while preserving a clean operational stop/upgrade boundary if usage grows.

## New local API surface

- `GET /api/context/config` — non-secret relay readiness and infrastructure facts;
- `GET /api/context/peers?probe=1` — approved receivers with optional presence probe;
- `POST /api/context/summary` — local-only, bounded context distillation;
- `POST /api/context/send` — signed Semantic Capsule preparation plus Jump Kit `send-peer` handoff.

`POST /api/context/send` returns HTTP 200 only for a receiver-owned Phase B commit. Rejection or unproven finality returns a non-200 response with a structured receipt.

## Security and claim boundary

The existing invariant remains unchanged:

```text
Jump Kit changes reach, not authority.
transport arrival != acceptance
only successful receiver-owned Phase B commit == accepted
```

The relay profile is non-secret configuration. Enrollment-token contents, private keys, and pairing codes remain local. The sender binds the receiver ACK to the exact prepared `.brad` bytes through `transport_sha256`; a mismatch fails closed.

## Promotion gate

Before final v1.6.1 promotion:

- supply and independently verify the exact production relay hostname, SNI/server name, CA, and SHA-256 certificate pin;
- run `BRAID_V1_6_1RC1_CONTEXT_UAT.md` on two approved physical nodes across different networks;
- confirm one click-path produces a receiver-owned `stored + validated + accepted` ACK and a fresh receiver query uses the committed material;
- execute wrong-pin, wrong-token, offline-peer, unapproved-peer, Braid-down, payload-tamper, and ACK-digest-mismatch negatives;
- complete the automated regression suite and native package verification.

## Inherited v1.6.0rc2 baseline

Release status: **source release candidate**. The core physical Kestrel A-to-B orientation proof has passed across a public WAN. A separate material-tamper negative, an explicit authority-recovery query, and native package signing/validation remain before promotion to a final public v1.6.0 stamp.

## Flag-plant feature: queryable committed semantic state

v1.6.0rc2 turns an accepted Semantic Capsule into a reusable receiver-local context object rather than only an accepted vector plus optional one-shot continuation.

After Phase B commits, the receiver atomically retains:

- `vector.npy` — receiver-local semantic representation;
- `lineage.json` — capsule/source/receiver/finality provenance;
- `material.txt` — canonical committed semantic material;
- optional `response.json` — one-shot receiver completion when configured;
- `queries/*.json` — later fresh local inference results.

`material.txt` is re-canonicalized and SHA-256 checked against the committed semantic lineage before every inspection or query. Tampering fails closed with `ERR_CAPSULE_QUERY_MATERIAL_DIGEST`.


## rc2 correction: exact-space capsule novelty versus route-corpus fit

The first physical Kestrel WAN attempt transported and authenticated correctly but was rejected by the historical hard subspace gate (`residual 0.8863 > 0.4672`). The route gate was trained on Braid's deliberately narrow synthetic conformance corpus, so it was incorrectly acting as a universal natural-language domain boundary.

v1.6.0rc2 preserves the hard subspace and Mahalanobis gates for vector-only state, ordinary routes, heterogeneous routes, and exact-space capsules whose receiver-side coherence check is disabled or fails. A route-distribution miss becomes diagnostic evidence only when all of the following are true before Phase B:

- the Semantic Capsule schema, digest, payload binding, and frozen source-route binding validate;
- source and receiver embedding-model digests are identical;
- the receiver has enabled strict exact-space verification;
- the receiver independently re-embeds the signed material and verifies cosine coherence against the signed 384D vector at the configured threshold.

The receipt records the measured residual/Mahalanobis values, whether the route distribution was exceeded, the receiver-owned override reason, and that semantic evidence does not grant authority. An incoherent signed capsule still fails closed with `ERR_CAPSULE_FAST_PATH_COHERENCE`; no Phase B commit occurs.

## New CLI surface

- `braid-client state <object_digest> --output-dir <receiver-inbox>`
- `braid-client query <object_digest> <question> --model <receiver-local-model> --output-dir <receiver-inbox>`

Every `query` call reconstructs context from the persisted committed bundle. It does not rely on a lingering chat session. The completion endpoint remains loopback-only and generated answers remain receiver-local, untrusted output.

## Physical Kestrel result

On August 30, 2026, a Mac sender transmitted an invented Kestrel operating situation through the authenticated Jump Kit relay path to an independent Linux Braid receiver. Before transfer, the receiver-local completion model confidently reached the wrong decision. After receiver-owned Phase B commitment, two fresh inference calls correctly applied the transferred threshold, two-reading condition, and signature requirement. Both retained query artifacts reported `fresh_context_reconstruction: true` and `phase_b_committed: true`.

The committed object digest was `5f81e8a4578f4b766644e95c08a26f8e22e82b6ff03bcad87c71b2efd49e08cb`. See `BRAID_V1_6_0RC2_KESTREL_PROOF.md` for the public proof summary.

## Kestrel Run UAT

`BRAID_V1_6_0RC2_KESTREL_QUERY_UAT.md` defines the first cognition-facing conformance test using information invented after model training:

1. establish receiver ignorance before transfer;
2. send the signed Kestrel/Finch/Vale situation through Braid;
3. require Phase B commit and queryable semantic state;
4. ask paraphrased rule/relationship questions in fresh inference calls;
5. verify the receiver gains factual orientation from committed Braid state;
6. tamper with persisted material and require fail-closed rejection.

The claim boundary remains precise: this is **semantic-state transport plus receiver-side contextual hydration into fresh inference**, not transfer of hidden activations, KV cache, weights, or native transformer state.

## Compatibility and authority

The signed Semantic Capsule, exact-space fast path, heterogeneous receiver-local re-embedding, Phase A/Phase B finality, replay protection, LAN/optical transport, and local Ollama security boundaries from v1.5.2 remain intact. Queryability is downstream of committed receiver state and cannot create or rewrite acceptance.

## Promotion gate

A stable public v1.6.0 should require:

- complete automated regression/conformance pass;
- physical Mac-to-Windows or Mac-to-Mac Kestrel Run showing pre-transfer ignorance and post-transfer factual/rule coherence;
- query tamper negative on physical hardware;
- native macOS package verification and, if distributed publicly, Developer ID signing/notarization.
