# Braid Semantic Field v1

Status: **v1.7.0a3 experimental receiver-local operational layer and proof candidate**.

## Purpose

The signed Semantic Capsule established authenticated explicit meaning across identical or heterogeneous embedding models. The Semantic Field makes the receiver's vectors operational after receiver-owned Phase B finality.

It answers a different question from transport:

> Given many committed semantic objects, which exact pieces matter now, which are genuinely new, which may update prior state, and what minimum state should be forwarded next?

The field never turns similarity into truth or acceptance authority.

## Invariants

```text
transport arrival != acceptance
only successful receiver-owned Phase B commit == accepted
field similarity != truth
possible update != automatic supersession
receiver-local vector != sender-signed artifact
opaque foreign vector != interoperable semantics
```

Every field atom retains exact explicit text. Braid does not decode an embedding into invented language.

## Field construction

For each committed Semantic Capsule object:

1. canonical committed material is SHA-256 checked against lineage;
2. material is split into bounded source-preserving spans;
3. each span receives a heuristic role label;
4. each exact span is embedded with the configured receiver-local field encoder;
5. vectors are normalized into the field's 384D coordinate system;
6. compatible prior committed fields are scanned;
7. novelty/update evidence and a local delta selection are computed;
8. all files are published atomically with `field.json` as the discovery marker.

Default bounds:

- 96 atoms per object;
- 1,200 UTF-8 bytes per atom;
- 8,192 prior atoms considered for novelty;
- 4,096 semantic bundles scanned;
- 6,000 UTF-8 bytes maximum canonical delta material.

## Source-preserving atoms

Ordinary material is split on sentence, question, exclamation, semicolon, and newline boundaries, with bounded whitespace-aware splits for long spans. The `text` value is an exact substring of canonical committed material. Braid does not summarize or paraphrase during atomization.

Each atom records:

- domain-separated atom ID derived from exact text;
- exact text SHA-256;
- original character span when applicable;
- position;
- heuristic role;
- source kind and delta lineage when applicable;
- `source_preserving: true`.

Heuristic roles are informational only: `claim`, `constraint`, `decision`, `objective`, `evidence`, `question`, `uncertainty`, `instruction`, or `observation`.

A received canonical semantic delta is atomized from the exact signed delta entries rather than from its JSON punctuation. The receiver retains source object and source relation evidence.

## 384D field space

The field is receiver-local and uses a dedicated configurable embedding encoder. This is intentionally separate from the receiver-native Semantic Capsule handoff representation.

A field space is identified by a SHA-256 over:

- exact model digest;
- adapter digest;
- target dimension 384;
- normalization method.

The adapter digest includes:

- direct 384D or deterministic native-to-384D algorithm;
- source dimension;
- exact model digest;
- canonical behavior-probe fingerprint;
- normalization parameters.

The behavior probe prevents a changed backend/runtime from silently reusing a coordinate-space identity merely because the model weights have the same digest.

### Direct 384D path

Braid requests `dimensions=384` from local Ollama and verifies finite, nonzero, correctly shaped rows. This path uses adapter algorithm `ollama_dimensions_384`.

### Native projection path

When direct 384D output is unsupported and receiver policy permits fallback, Braid requests the model's native embedding and applies `digest_seeded_signed_feature_hash_v1`:

- every native coordinate maps to one of 384 buckets;
- bucket and sign are derived from SHA-256 over a domain tag, exact model digest, and coordinate index;
- projected rows are L2-normalized;
- the adapter and field-space digests differ from the direct path.

This is a deterministic interoperability adapter, not a learned universal latent translator. It may lose information and must be evaluated empirically.

## Novelty analysis

For each atom, Braid first checks exact atom identity. Otherwise it finds the nearest compatible prior atom by cosine similarity.

Default policy:

- exact same atom ID: `exact_duplicate`;
- cosine at or above 0.985: `near_duplicate`;
- cosine at or above 0.80 plus a detected numeric, negation, or antonym change: `possible_update`;
- cosine at or above 0.80 without a change signal: `related`;
- otherwise: `novel`.

Only `novel` and `possible_update` are locally delta-eligible. No classification automatically modifies prior state.

Comparisons are restricted to identical `field_space_digest` values. Invalid field bundles are reported and skipped. Unindexed committed Semantic Capsule objects are counted but not treated as semantic evidence.

## Vector-governed retrieval

`field-search` embeds the operator question into the exact same field space and scores all compatible atom vectors by cosine similarity. Exact duplicate texts are grouped across source objects. Braid then applies maximal marginal relevance so a small context set balances relevance with redundancy.

Returned entries contain exact atom text, role, similarity, selection score, support count, source object digests, and field-manifest digests.

`field-query` constructs a fresh receiver-local completion request from only those selected atoms. It records `whole_transcript_replayed: false`. The generated answer remains untrusted model output.

## Cautious reconciliation

`field-reconcile` deduplicates exact atoms and greedily clusters compatible vectors. Within each cluster it checks exact text for numeric changes, negation changes, and selected antonym pairs.

Possible conflicts are preserved as member pairs with explicit signals. Braid does not choose a winner. Cluster status can be:

- `possible_conflict`;
- `exact_corroboration`;
- `corroborated_variants`;
- `related_variants`;
- `singleton`.

This is a bounded heuristic inspection layer, not formal logical theorem proving.

## Semantic delta

`field-delta` selects the current object's `novel` and `possible_update` atoms and emits bounded canonical JSON material with schema `braid.semantic-delta-material.v1`.

`field-delta-frame` additionally creates a normal signed Semantic Capsule frame and attaches `braid.semantic-delta.v1`. The signed extension binds:

- source object digest;
- source field-manifest SHA-256;
- selection policy;
- exact atom count and ordered IDs;
- canonical delta material SHA-256;
- `automatic_supersession: false`;
- sender selection-evidence authority label.

The receiver validates extension/material consistency before Phase B. The extension proves what the sender signed and selected; it does not independently prove that the sender's local field classification was correct or truthful.

## Reindexing older committed state

`field-reindex` upgrades already committed Semantic Capsule bundles that contain `lineage.json` and `material.txt` but no `field.json`.

The migration:

- requires committed Phase B lineage;
- re-canonicalizes material and verifies its committed SHA-256;
- processes objects by lineage creation time, bundle modification time, then digest;
- compares each object only with successfully indexed earlier objects in that chronology;
- writes subordinate artifacts first;
- updates lineage atomically;
- publishes `field.json` last;
- never overwrites an existing valid field;
- is safe to rerun.

A failed object remains queryable through the ordinary Semantic Capsule path and can be retried after repairing the local encoder or stored material.

## Failure behavior

Field construction is post-commit derived work. If the field encoder is absent or fails:

- Phase B remains committed;
- exact capsule material and the receiver-native semantic vector are still atomically persisted;
- the handoff reports a degraded semantic field;
- `state` remains queryable;
- `field-reindex` can repair the missing field later.

This prevents an optional indexing failure from erasing authenticated state.

## Artifact authority

The sender signature covers the signed Braid frame and Semantic Capsule, including a signed semantic delta extension when present. It does not cover:

- receiver-created atom embeddings;
- novelty classifications;
- reconciliation clusters;
- local delta selection files;
- field query responses.

Those artifacts are receiver-local evidence. Local filesystem compromise can rewrite them; Braid's internal digests primarily detect incomplete or accidental modification and fail closed during normal loading.


## v1.7.0a3 proof workflow

Use `receive --semantic-proof` for the reproducible same-space proof profile. It combines strict receiver-local capsule/vector coherence verification with post-commit field indexing and refuses to run without a route package.

`field-query` now consumes reconciliation evidence before generation. Its query artifact contains the selected atoms, supplemental conflicting siblings, deterministic reconciliation envelope, raw completion draft, completion-guard result, and final response. A draft that drops a conflict value, invents a unit, claims unsupported supersession, or selects one unresolved value is replaced by a deterministic source-preserving response.

See `docs/SEMANTIC_FIELD_QUERY_GUARD.md` and `BRAID_V1_7_0A3_SEMANTIC_FIELD_PROOF_UAT.md`.
