# Local Sensing v1.5.2

Local sensing is intentionally subordinate to Braid trust.

The optional BLE scanner only surfaces devices that intentionally advertise the Braid service UUID or a `BRAID` local-name hint. RSSI observations are smoothed and classified into relative proximity bands. No meters/feet estimate is produced.

A sensing record is always labeled `untrusted_discovery_hint`. Its purpose is human guidance and receiver-local context without turning radio proximity into an authentication primitive.

v1.4.9 bounds stored sensing keys/labels, removes control characters, caps the number of in-memory tracks, and prunes stale observations. These are resource/logging hygiene measures only; they do not increase the authority of sensing evidence.
