# Receiver Automation v1.5.2

Every deliberate authoritative transport path terminates at the same receiver pipeline:

1. Quarantine exact bytes.
2. Parse the signed Braid frame and require a finite 384-dimensional state.
3. Run Phase A: routing, signature, payload/artifact binding, replay pre-check, effective authority, and receiver-local anomaly evidence.
4. If all independent evidence passes and receiver policy allows finality, preflight local destinations and execute the Phase B atomic replay/state commit.
5. Mark the receipt `finality: committed`, `phase_b_committed: true`, and `accepted: true`.
6. Move exact signed bytes to the accepted store.
7. Optionally emit a receiver-local 384D float32 vector artifact and a lineage sidecar binding that derived artifact to the signed source object.
8. Write a unique per-transfer receipt.
9. Optionally invoke a receiver-owned local adapter without a shell.

If auto-commit is disabled, the object remains quarantined with `finality: quarantined` and `accepted: false`.

If validation or Phase B fails, the object has `finality: rejected` and `accepted: false`.

If Phase B succeeds but a later local artifact/handoff step fails, finality remains `committed`; `post_commit_complete` becomes false and the receipt reports the degraded downstream state. The receiver never rewrites committed history as rejection.

## Transport callback invariant

Network transport may only mirror acceptance when all three statements agree:

- `accepted: true`
- `phase_b_committed: true`
- `finality: committed`

Any inconsistent callback result is converted to a negative acknowledgement with `ERR_FINALITY_INVARIANT`.

## Legacy validator boundary

`validator_command` is non-authoritative prevalidation. Success means only that a receiver-owned external check passed. The frame remains quarantined with `accepted: false` until the automated receiver executes Phase B.

## v1.5.2 Semantic Capsule stage

When `--semantic-embed-model` is configured, the receiver adds a mandatory pre-Phase-B semantic stage:

1. require a signed Semantic Capsule;
2. validate capsule self-digest and exact source wire-payload binding;
3. bind capsule source model/digest to the frozen route source space;
4. resolve the capsule's explicit canonical material;
5. independently resolve the receiver-local embedding model digest;
6. choose exact-space fast path when digests match, otherwise preflight native receiver re-embedding.

No successful Phase B is attempted for a configured semantic receiver that lacks a valid capsule.

After Phase B, the prepared receiver semantic vector and its lineage are published together under `semantic/<object_digest>/`. An optional local completion response is downstream delivery only.
