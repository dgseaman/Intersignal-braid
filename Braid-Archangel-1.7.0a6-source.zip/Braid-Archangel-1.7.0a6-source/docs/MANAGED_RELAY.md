# Braid v1.6.1 Managed Relay context workflow

Braid v1.6.1 adds a human-facing workflow around the existing Semantic Capsule and Jump Kit paths:

```text
source context
  -> local summary
  -> human review/edit
  -> signed Semantic Capsule
  -> approved Jump Kit peer over TLS 1.3
  -> remote Braid receiver
  -> receiver-owned Phase B commit
  -> fresh receiver-local query
```

## Authority boundary

The relay is an opaque reach service. It does not parse semantic material, grant Braid Trust, validate the signed capsule on behalf of the receiver, or manufacture success.

The UI displays transport and acceptance separately. It reports a committed transfer only when the remote acknowledgement contains strict JSON booleans:

```json
{
  "stored": true,
  "validated": true,
  "accepted": true,
  "transport_sha256": "<sha256 of exact prepared .brad bytes>"
}
```

Braid also requires the acknowledgement digest to equal the SHA-256 of the exact private-outbox frame submitted to Jump Kit. Any mismatch fails closed.

## Packaged DigitalOcean profile

The package includes `braid_client/config/managed-relay.digitalocean.json`. It records non-secret operating facts only:

- DigitalOcean / NYC1;
- Ubuntu 24.04 LTS x64;
- Basic Premium Intel reference profile;
- 2 vCPU, 4 GB RAM, 120 GB disk;
- TLS 1.3;
- port 8750;
- opaque reach-only role.

The package deliberately does not guess the live relay hostname, TLS server name, or certificate pin. Those fields remain blank until the operator verifies the provisioned relay.

On first local UI launch, Braid copies the profile to the private workspace as `managed-relay.json`. Blank path fields resolve to platform-specific workspace defaults.

## Required local files

The default workspace layout is:

```text
<Braid workspace>/
  managed-relay.json
  sender.key
  route/route.json
  jumpkit/
    device.json
    relay-ca.crt.pem
    relay-token.txt
  outbox/
  audit/context-transfers.jsonl
```

`relay-token.txt`, `sender.key`, and any private identity material should remain private-mode and must never be embedded in a webpage, source bundle, screenshot, or support transcript.

## Configure the exact relay identity

Edit the private local `managed-relay.json`, or provide environment overrides:

```text
BRAID_RELAY_HOST
BRAID_RELAY_PORT
BRAID_RELAY_SERVER_NAME
BRAID_RELAY_FINGERPRINT
BRAID_RELAY_CA
BRAID_RELAY_TOKEN_FILE
BRAID_JUMPKIT_IDENTITY_FILE
BRAID_JUMPKIT_COMMAND
BRAID_ROUTE_PACKAGE
BRAID_SENDER_KEY
```

`BRAID_RELAY_FINGERPRINT` is the lowercase, colon-free SHA-256 of the expected relay certificate. The profile is not considered endpoint-ready without a host, server name, and valid 64-hex pin.

## Capacity controls

- `BRAID_MANAGED_RELAY_ENABLED=0` disables managed sends without removing local Braid features.
- `BRAID_MANAGED_RELAY_MAX_CONCURRENT_SENDS=<1..64>` controls concurrent sends; default 4.
- `status_timeout_seconds` is bounded to 0.5-60 seconds.
- `send_timeout_seconds` is bounded to 1-300 seconds.

The browser performs one initial peer load and manual refreshes. It does not continuously poll the public relay.

## Loopback API

### Read configuration

```text
GET /api/context/config
```

Returns only non-secret readiness facts. Presence booleans may indicate that credential files exist; their contents are never returned.

### List approved peers

```text
GET /api/context/peers?probe=1
```

Runs local Jump Kit `peers`, filters to approved rows, and optionally runs `peer-status` for bounded online/offline status.

### Summarize locally

```text
POST /api/context/summary
Content-Type: application/json

{"text":"... up to 6000 UTF-8 bytes ..."}
```

The response is editable and has no send side effect.

### Send reviewed context

```text
POST /api/context/send
Content-Type: application/json

{"reviewed_text":"...","peer":"<approved device id or unambiguous name>"}
```

The endpoint:

1. canonicalizes and bounds the reviewed text;
2. builds a signed Semantic Capsule through the configured empirical route;
3. writes the exact `.brad` bytes to the private outbox;
4. calls Jump Kit `send-peer` with the pinned relay identity;
5. parses the real receiver acknowledgement;
6. returns HTTP 200 only for `stored && validated && accepted`.

A failed relay operation retains the signed frame in the private outbox for deliberate operator retry.

## Local summary behavior

Braid attempts an eligible loopback-only Ollama completion model. Explicit cloud models and Ollama metadata that reports a remote model/host remain ineligible under the existing adapter policy. If local inference is unavailable, the deterministic extractive fallback preserves selected source sentences verbatim.

The operator must review the summary. Generated or extracted text is context evidence, not privileged instruction, and must not directly authorize tools, credentials, or shell/network actions.
