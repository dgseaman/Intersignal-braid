# Semantic Field Query Guard — v1.7.0a3

The query guard is a receiver-local grounding layer between Semantic Field retrieval/reconciliation and the final user-visible answer.

## Pipeline

```text
question
  -> receiver-local 384D retrieval
  -> receiver-local reconciliation
  -> deterministic query envelope
  -> local completion-model draft
  -> deterministic completion audit
  -> model draft OR source-preserving fallback
```

## Why it exists

During the first physical field proof, retrieval and reconciliation correctly preserved threshold values 73 and 75, but a local 7B completion model still selected 73. Prompt wording alone did not reliably prevent the collapse.

The guard therefore treats model generation as a draft, not as the authoritative rendering of the field.

## Envelope contents

The envelope records exact conflict members, numeric values, evidence units, source chronology, novelty labels, detected change signals, explicit supersession language, and mandatory answer constraints.

Chronology and `possible_update` are evidence only. They do not authorize supersession.

## Guard checks

For unresolved numeric conflicts, the draft must:

- mention every conflicting value;
- acknowledge that the conflict is unresolved;
- avoid selecting one value as governing/current/final/valid/operative;
- avoid units absent from the evidence;
- avoid unsupported supersession claims.

## Fallback

A failed draft is retained in `completion_draft` with a SHA-256. The final `response` is constructed deterministically from exact source text and conflict metadata. It does not summarize away the conflict.

## Boundary

The guard is not a fact checker, theorem prover, or general hallucination detector. It enforces a bounded set of source-preservation constraints that Braid can determine from its own committed evidence.
