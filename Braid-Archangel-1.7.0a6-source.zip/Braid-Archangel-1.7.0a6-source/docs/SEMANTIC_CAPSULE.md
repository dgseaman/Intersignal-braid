# Braid Semantic Capsule v1

Status: **v1.5.2 experimental interoperability primitive**.

## Purpose

A Semantic Capsule gives a receiver explicit signed semantic material to ingest when sender and receiver embedding spaces are not identical. It exists specifically to avoid a false claim: unrelated embedding coordinates do not become mutually meaningful just because both vectors have numbers in them.

Braid therefore separates two questions:

1. **Is this signed source route-space state authentic and acceptable?**
2. **Does the receiver have explicit semantic material from which it can create useful state in its own embedding space?**

The first is handled by the existing signed frame and receiver gates. The second requires a Semantic Capsule when embedding-model digests differ.

## Non-negotiable invariant

```text
opaque vector + different embedding space != translatable semantics
```

If no capsule is present, Braid does not synthesize text, infer a latent label, search for a nearest semantic description, or otherwise fabricate a bridge.

## Schema

Schema identifier:

```text
braid.semantic-capsule.v1
```

Two modes are defined.

### `inline_text`

Carries bounded canonical UTF-8 text directly inside the signed manifest extension.

Canonicalization:

- CRLF/CR -> LF;
- Unicode NFC;
- NUL rejected;
- empty/whitespace-only content rejected;
- maximum 6000 UTF-8 bytes.

### `legend_ref`

Does not duplicate semantic content. It references the digest of the signed Braid Legend already present in the manifest and resolves semantic material through the canonical Legend semantic view.

This mode fails if the Legend is missing, invalid, digest-mismatched, or resolves to a different semantic content digest.

## Source embedding record

A capsule records:

- source embedding backend (`ollama:/api/embed`);
- model name;
- exact model digest;
- Braid route-space dimension (`384`);
- FP16 wire vector encoding;
- exact signed frame payload digest;
- sender derivation attestation that the route vector was produced from the canonical semantic material.

The receiver treats that derivation field as signed sender evidence, not an independent cryptographic proof that the model performed the claimed embedding computation.

## Bindings

Before Phase B, the receiver validates:

1. the capsule's closed schema;
2. capsule JCS digest;
3. capsule authority label;
4. capsule source wire payload digest == signed manifest payload digest;
5. source model name == frozen source-space model revision;
6. source model digest == digest bound in the frozen source space;
7. route source dimension == 384;
8. `legend_ref`, when used, resolves to the exact signed Legend digest and semantic content digest.

A signed attacker-controlled capsule that is self-inconsistent still fails. A capsule whose digest is recomputed after forging its source model still fails the receiver's frozen route binding.

## Receiver decision

The receiver resolves the exact digest of its configured local embedding model through loopback Ollama.

### Same digest

```text
source model digest == receiver model digest
```

The receiver uses the signed source route-space 384D vector as the exact-space fast path. It does not call native heterogeneous re-embedding.

Optional strict mode (`--semantic-verify-fast-path`) recomputes the capsule material with the exact same receiver-local embedding model before Phase B and checks cosine coherence against the signed route-space vector (default threshold `0.999`). This turns the capsule/vector derivation relationship from a signer assertion into receiver-checked same-model evidence without granting it authority over Phase B.

### Different digest

```text
source model digest != receiver model digest
```

The receiver resolves canonical capsule material and calls its own loopback Ollama `/api/embed` **without** Braid's `dimensions=384` request. The result therefore belongs to the receiver model's native coordinate space and may have any positive finite dimension.

The vector is normalized and stored as receiver-local derived state.

## Authority and lineage

The sender signature covers the Semantic Capsule because the capsule lives in the signed manifest. It does not cover a receiver-created vector or response.

The receiver publishes the semantic vector and lineage as one atomic directory bundle:

```text
semantic/<object_digest>/
  vector.npy
  lineage.json
```

The lineage includes:

- object and transport digests;
- capsule and semantic content digests;
- source model name/digest;
- source wire payload digest;
- receiver model name/digest;
- receiver-native dimension;
- transfer method (`exact_space_fast_path` or `semantic_capsule_local_reembed`);
- derived artifact digest;
- Phase B finality;
- `sender_signature_covers_derived_artifact: false`;
- `bridge_semantic_invention: false`;
- receiver-local authority label.

The directory is built privately and renamed into place only after both vector and lineage exist, preventing publication of an unlineaged semantic vector during a partial write.

## Optional completion handoff

A receiver may configure a local completion model. This runs **after Phase B** and receives the explicit capsule material as user data beneath a receiver-owned system instruction.

The system instruction states that the signed material is context/evidence rather than authority and forbids claims that hidden activations, weights, or native model state were transferred.

The generated response is still untrusted model output. Braid does not convert it into receiver authority or automatic tool permission. Response lineage marks `generative_output: true`, while `bridge_semantic_invention: false` means only that Braid did not fabricate missing source semantics to cross embedding spaces.

## Threat model notes

A valid sender can sign malicious or misleading semantic content. Signatures establish provenance/integrity, not truth. Receiver policy must decide which signers, routes, and content are acceptable.

Prompt injection can exist inside semantic text. The optional completion handoff isolates capsule content from the system prompt and labels it as data, but no language-model instruction boundary is a formal security sandbox. Do not wire generated text directly to privileged actions.

The capsule never supplies a URL for the receiver to fetch. Receiver model inference is loopback-only. Braid additionally rejects explicit Ollama cloud model names and Ollama-reported non-empty `remote_model` / `remote_host` markers rather than treating loopback as sufficient proof of local execution.

## v1.6.0rc2 queryable committed state

After successful Phase B finality, Braid may persist the capsule's canonical semantic material as `material.txt` in the same private atomic receiver bundle as `vector.npy` and `lineage.json`.

`braid-client state` and `braid-client query` only operate on such committed bundles. Before use, the receiver canonicalizes `material.txt` and checks its SHA-256 against `semantic_content_sha256` in lineage. A mismatch fails closed.

Each `query` call constructs a fresh receiver-local completion context from the verified material and the operator's question. It does not depend on conversational memory. Query responses are receiver-local generated artifacts, do not inherit the sender signature, and cannot create acceptance or authority.
