# Receiver-Local Refinement — v1.4.9 Boundary

## Status

v1.4.9 ships provenance groundwork, not a universal semantic-refinement algorithm.

The receiver may emit a derived local float32 vector after Phase B. Its lineage sidecar records:

- the signed source `object_digest`
- the transport SHA-256 of the exact received bytes
- the SHA-256 of the derived local artifact
- that the sender signature does not cover the derived artifact
- that the artifact is receiver-local evidence only

## Constitutional requirements for future basin/refinement work

Any future refinement implementation must preserve all of the following:

- Never mutate or overwrite the sender-signed 384D state.
- Any refined state is explicitly receiver-derived.
- Refinement is bounded by receiver-owned limits and can fail closed.
- Basin/refinement scores are evidence, never authorization.
- No refinement result may imply or bypass Phase B finality.
- Sender-signed semantics and receiver-derived artifacts must remain separately attributable.

A concrete basin/refinement algorithm is intentionally deferred until a receiver-local target model, bounded objective, trust radius, and conformance vectors are specified. Shipping a placeholder similarity metric would overstate interoperability.
