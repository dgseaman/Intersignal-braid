# Braid v1.7.0a3 Semantic Field Proof UAT

Status: frozen-byte physical UAT procedure for macOS, Linux, and Windows.

## Goal

Prove that the exact same v1.7.0a3 wheel can:

1. create canonical signed Semantic Capsules on one operating system;
2. pass receiver-owned Phase A and Phase B on another;
3. publish a receiver-local 384D field;
4. retrieve Kestrel-relevant evidence while excluding unrelated state;
5. identify the unresolved 73/75 numeric conflict;
6. prevent a local completion model from silently selecting one unresolved value;
7. preserve replay/finality and restart persistence.

## Required artifacts

- `braid_client-1.7.0a3-py3-none-any.whl`
- `Braid-1.7.0a3-SHA256SUMS.txt`
- this UAT document
- `uat/a3/` scripts from the source/engineering kit

Every node must install the wheel whose SHA-256 matches the package manifest.

## Node requirements

- Python 3.10 or newer
- local Ollama
- `all-minilm:latest` on sender and receiver
- one local completion model on the receiver, such as `qwen:7b`
- private LAN connectivity
- no changes to existing production-like nodes such as Mariana

Use isolated virtual environments and receiver directories.

## 1. Install and verify on every node

POSIX shell:

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install ./braid_client-1.7.0a3-py3-none-any.whl
braid-client --version
braid-client doctor
```

PowerShell:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install .\braid_client-1.7.0a3-py3-none-any.whl
braid-client --version
braid-client doctor
```

Required:

```text
version: 1.7.0a3
ready: true
```

`camera_fallback` and `ble_sensing` are optional.

## 2. Create one frozen route on the sender

```sh
ollama pull all-minilm
braid-client ollama-route \
  --embed-model all-minilm:latest \
  --output-dir ./route
```

Record:

- route JSON SHA-256;
- source/target model digest;
- source/target space digest;
- route status.

Copy the exact route directory to each receiver. Do not independently regenerate the route for the same test matrix.

## 3. Establish trust material

The sender creates or reuses `sender.key` when making the first capsule. Copy only `sender.pub` to receivers. Never copy `sender.key`.

## 4. Start a proof receiver

POSIX:

```sh
./uat/a3/receiver.sh \
  ./sender.pub \
  ./route \
  <receiver-private-ip> \
  ./receiver-a3
```

PowerShell:

```powershell
.\uat\a3\Receiver.ps1 `
  -TrustedKey .\sender.pub `
  -RoutePackage .\route `
  -BindIp <receiver-private-ip> `
  -OutputDir .\receiver-a3
```

Expected listener evidence includes:

```json
{
  "status": "LISTENING",
  "operator_profile": "semantic_field_proof",
  "semantic_capsule_ingestion": true,
  "exact_space_coherence_verification": true,
  "semantic_field_indexing": true,
  "version": "1.7.0a3"
}
```

## 5. Send the three-object Kestrel corpus

POSIX:

```sh
./uat/a3/sender.sh \
  ./route \
  ./sender.key \
  <receiver-private-ip> \
  ./sender-a3
```

PowerShell:

```powershell
.\uat\a3\Sender.ps1 `
  -RoutePackage .\route `
  -SigningKey .\sender.key `
  -ReceiverHost <receiver-private-ip> `
  -WorkDir .\sender-a3
```

Each send must return:

```json
{
  "transport_completed": true,
  "phase_a_validated": true,
  "phase_b_committed": true,
  "field_indexed": true,
  "accepted_and_indexed": true,
  "result_summary": "ACCEPTED_AND_INDEXED"
}
```

The corpus is:

1. Kestrel requires independently signed Finch readings; threshold 73.
2. Unrelated archive-retention statement.
3. Threshold 75; signature requirement remains.

## 6. Verify field behavior

POSIX:

```sh
./uat/a3/verify.sh ./receiver-a3 <local-completion-model>
```

PowerShell:

```powershell
.\uat\a3\Verify.ps1 `
  -OutputDir .\receiver-a3 `
  -CompletionModel <local-completion-model>
```

Required terminal result:

```text
A3_SEMANTIC_FIELD_PROOF_PASS
```

Required evidence:

```text
field_dimension: 384
indexed_object_count: 3
indexed_atom_count: 5
invalid_field_count: 0
ready: true
```

Search must include threshold 73 and 75, include the signature rule, and exclude the archive statement.

Reconciliation must report at least one possible conflict with `numeric_value_changed` and `automatic_resolution: false`.

Query must report:

```json
{
  "fresh_context_reconstruction": true,
  "whole_transcript_replayed": false,
  "reconciliation": {
    "unresolved_conflict_count": 1
  }
}
```

The final response must contain 73, 75, and explicit conflict language. It must not invent a unit or designate either value as governing without explicit supersession evidence.

A weak local model may fail the guard. That is a valid proof result when:

```json
{
  "completion_guard": {
    "status": "deterministic_fallback"
  },
  "generation_source": "receiver_local_deterministic_grounding_guard",
  "generative_output": false
}
```

The raw model draft must remain recorded separately.

## 7. Restart persistence

Stop and restart the receiver against the same output directory. Run `field-status` and `verify` again without resending objects.

Required: three objects, five atoms, ready true, same field-space identity, and successful guarded query.

## 8. Replay rejection

Resend one previously accepted `.brad` file.

Required:

```text
phase_b_committed: false
accepted_and_indexed: false
finality: rejected
```

The existing field must remain unchanged and ready.

## 9. Cross-platform matrix

Run at minimum:

| Sender | Receiver | Required |
|---|---|---|
| macOS | Linux | full send + verify |
| Windows | Linux | full send + verify |
| Linux | Windows | full send + verify |
| macOS | macOS | same-OS control |

Optional: Windows-to-macOS and Linux-to-macOS.

Record OS version, Python version, Ollama version, hardware class, wheel SHA-256, model digests, route hash, ACKs, field status, reconciliation, query guard result, restart result, and replay result.

## 10. Promotion decision

Promote the exact bytes only when:

- every required matrix row uses the same wheel hash;
- no negative-zero or route-inspection regression occurs;
- all successful sends return `ACCEPTED_AND_INDEXED`;
- field persistence and replay rejection pass;
- the query final response never collapses the known 73/75 conflict;
- any completion-model failure is visible in `completion_draft` and contained by the deterministic guard;
- no private key, enrollment token, or sensitive frame is included in published evidence.
