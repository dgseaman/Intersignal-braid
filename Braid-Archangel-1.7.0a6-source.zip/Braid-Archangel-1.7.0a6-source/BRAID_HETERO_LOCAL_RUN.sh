#!/bin/sh
set -eu

if [ "$#" -lt 2 ]; then
  echo "usage: $0 <source-model-tag> <target-model-tag> [output-dir]" >&2
  exit 2
fi

SOURCE_MODEL=$1
TARGET_MODEL=$2
OUTPUT_DIR=${3:-"routes/$(printf '%s-to-%s' "$SOURCE_MODEL" "$TARGET_MODEL" | tr '/: ' '---')"}

python -m braid_client.cli hetero-calibrate \
  --source-model "$SOURCE_MODEL" \
  --target-model "$TARGET_MODEL" \
  --output-dir "$OUTPUT_DIR"

echo "route output: $OUTPUT_DIR"
