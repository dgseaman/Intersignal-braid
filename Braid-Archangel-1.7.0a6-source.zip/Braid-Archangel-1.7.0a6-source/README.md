# Intersignal Braid Messenger 1.7.0a6 - Archangel Channels

A compact local messenger and channel chat for owned rigs. Signed topic channels, separate sharing/context permissions, durable handoffs, receiver-local semantic retrieval, and an exact "Using N shared notes" receipt per answer.

Start with `release/START_HERE.md`. See `RELEASE_NOTES_A6.md`, `CHANNELS_ARCHITECTURE.md`, `QA.md` and `UAT_CHANNELS.md` for implementation, evidence and remaining physical gates. The same release bundle is used on every rig; private identities are created locally.

a6 builds on the frozen a5 Mac-Launcher-Fix1 source. It retains receiver-owned acceptance and adds signed channel metadata and scoped text-context chat, not native hidden-state interchange. Historical a3/a4/a5 documents and test logs in this source tree are retained inputs, not current platform certification.

---

## Retained a3 protocol guide

# Intersignal Braid Light Client v1.7.0a3 — Semantic Field Proof Build

Braid is a receiver-sovereign transport, acceptance, and semantic-state layer for signed AI state across optical, private-LAN, and explicitly enabled Internet paths.

**v1.7.0a3 is an engineering alpha prepared for cross-platform proof testing.** It preserves the v1.7 Semantic Field architecture, includes the v1.7.0a2 canonical-FP16 sender fix, and tightens the exact workflow exercised during the September 2, 2026 Mac-to-Linux field test.

The supportable claim is deliberately narrow:

> Braid can propagate authenticated explicit semantic state, commit it under receiver-owned policy, index it into a receiver-local 384D field, retrieve relevant exact source atoms without replaying a whole conversation, preserve conflicts, and constrain fresh local generation with deterministic reconciliation evidence.

It does **not** claim to transfer transformer hidden activations, KV cache, weights, consciousness, truth, or universally interchangeable native latent coordinates.

## What a3 changes

### One proof-mode receiver switch

`--semantic-proof` enables the intended safe same-space Semantic Field test profile:

- requires an explicit route package;
- enables Semantic Capsule ingestion;
- independently re-embeds signed capsule text on the receiver;
- requires exact-space cosine coherence before allowing a route-distribution miss to remain diagnostic;
- builds the post-commit receiver-local field;
- defaults the capsule and field encoder to local `all-minilm:latest` unless overridden.

```sh
braid-client receive \
  --semantic-proof \
  --trusted-key ./sender.pub \
  --route-package ./route \
  --bind <receiver-private-ip> \
  --allow-lan \
  --port 8745 \
  --output-dir ./receiver
```

Proof mode refuses to run without a route package or with field indexing disabled. It does not weaken validation for opaque vectors, different embedding spaces, or capsule/vector incoherence.

### Unambiguous receiver results

Transport completion, Phase A validation, Phase B commit, and field indexing are separate facts. A v1.7.0a3 network acknowledgment can report:

```json
{
  "transport_completed": true,
  "phase_a_validated": true,
  "phase_b_committed": true,
  "field_indexed": true,
  "accepted_and_indexed": true,
  "result_summary": "ACCEPTED_AND_INDEXED"
}
```

The sender also prints a compact phase summary to stderr while keeping stdout as machine-readable JSON.

`validated` remains in the wire acknowledgment for compatibility. New integrations should use the explicit phase fields and treat only `phase_b_committed: true` as receiver acceptance.

### Reconciliation-aware guarded queries

`field-query` now runs receiver-local retrieval and reconciliation together. It constructs a deterministic query envelope containing:

- exact selected atoms and source-object lineage;
- conflict clusters and machine-detected change signals;
- every numeric value in an unresolved conflict;
- units actually present in the evidence;
- source chronology and novelty labels, explicitly marked as non-authoritative;
- whether explicit supersession language exists;
- receiver-owned answer constraints.

If MMR retrieval selects one member of a known conflict but omits its sibling, Braid adds the exact sibling as bounded supplemental evidence before generation.

The local completion model is still invoked, and its raw draft is retained for audit. Before that draft becomes the final response, the completion guard checks that it:

- includes every value participating in an unresolved numeric conflict;
- acknowledges the conflict;
- does not call one conflicting value current, governing, final, valid, or otherwise operative;
- does not invent a unit absent from the evidence;
- does not claim unsupported supersession.

If the draft fails, Braid returns a deterministic source-preserving response instead. The JSON records both the raw model draft and the guard decision:

```json
{
  "completion_guard": {
    "status": "deterministic_fallback",
    "violations": ["unsupported_conflict_selection:73"]
  },
  "completion_draft": "...",
  "generation_source": "receiver_local_deterministic_grounding_guard",
  "generative_output": false,
  "response": "..."
}
```

The guard is conservative grounding policy, not a general truth engine. It does not resolve conflicts or establish authority.

### Reliable local inspection

`inspect --route-package` now uses a temporary file-backed replay ledger. This fixes the a2 lifecycle bug where SQLite `:memory:` tables were created on one connection and absent on the next.

### Canonical FP16 sender output

The a2 fix remains present: after conversion to IEEE-754 binary16, every mathematical zero is canonicalized to positive zero (`0x0000`) before the payload digest and signature are calculated. The receiver continues to reject forbidden negative-zero wire words (`0x8000`).

## The behavior demonstrated by the predecessor build

During physical Mac-to-Linux testing of v1.7.0a2:

1. A Mac sent three signed objects containing five semantic statements.
2. Linux committed them into a receiver-local 384D field.
3. A Kestrel query selected four relevant atoms and excluded the unrelated archive statement.
4. Reconciliation grouped threshold values 73 and 75 and flagged `numeric_value_changed` without resolving it.
5. A local Qwen 7B answered from a fresh 227-byte selected context while `whole_transcript_replayed` remained false.
6. Qwen still selected 73 despite the unresolved 73/75 conflict. That completion-layer failure is the behavior a3's reconciliation envelope and deterministic guard are designed to prevent.

The a3 bytes in this package have automated test evidence but still require frozen-byte physical UAT on macOS, Linux, and Windows before being described as the proven public preview.

## Architecture

```text
SIGNED TRANSPORT PLANE
explicit semantic material
        +
signed 384D route vector
        |
        v
Phase A validation -> receiver-owned Phase B commit
        |
        v
RECEIVER-LOCAL FIELD PLANE
exact semantic atoms -> local 384D field -> retrieval / novelty /
reconciliation / guarded fresh query / bounded semantic delta
```

Only the receiver-owned Phase B commit means accepted. Field construction and language-model output happen after finality and cannot create, rewrite, or inherit acceptance authority.

## Field-space identity

The field encoder defaults to local Ollama `all-minilm:latest`. Every comparable field is bound to:

- the exact local embedding-model digest;
- the 384D adapter algorithm and digest;
- a canonical behavior-probe fingerprint;
- L2 normalization and target dimension.

The resulting `field_space_digest` is fail-closed. Fields are compared only when that digest matches exactly.

Braid first requests direct 384D output. When a local encoder cannot provide it and receiver policy allows projection, Braid obtains the native finite embedding and applies a deterministic, model-digest-seeded signed feature-hash projection into 384D. Direct and projected fields remain distinct spaces.

## Install

Python 3.10+ and a local Ollama installation are required for the Semantic Field proof path.

```sh
python3 -m pip install braid_client-1.7.0a3-py3-none-any.whl
ollama pull all-minilm
braid-client --version
braid-client doctor
```

Expected version:

```text
1.7.0a3
```

The wheel is platform-independent Python. Native signed/notarized application installers are not claimed by this alpha.

## Create a route and signed capsule

Create a digest-bound source route on the sender:

```sh
braid-client ollama-route \
  --embed-model all-minilm:latest \
  --output-dir ./route
```

Create a signed Semantic Capsule frame:

```sh
braid-client capsule-frame \
  --route-package ./route \
  --text-file ./context.txt \
  --signing-key ./sender.key \
  --output ./context.brad
```

Copy only `sender.pub` and the exact `route/` directory to the receiver. Keep `sender.key` on the sender.

Start proof mode on the receiver:

```sh
braid-client receive \
  --semantic-proof \
  --trusted-key ./sender.pub \
  --route-package ./route \
  --bind <receiver-private-ip> \
  --allow-lan \
  --port 8745 \
  --output-dir ./receiver
```

Send the exact signed bytes:

```sh
braid-client send ./context.brad \
  --host <receiver-private-ip> \
  --port 8745
```

Require `accepted_and_indexed: true` for the complete proof-path success condition.

## Operate the field

```sh
braid-client field-status --output-dir ./receiver
```

```sh
braid-client field-search \
  "What threshold governs Kestrel Run?" \
  --output-dir ./receiver \
  --embed-model all-minilm:latest \
  --top-k 8
```

```sh
braid-client field-reconcile \
  --output-dir ./receiver \
  --embed-model all-minilm:latest
```

```sh
braid-client field-query \
  "What threshold and signature rule govern Kestrel Run? State any unresolved conflict." \
  --output-dir ./receiver \
  --embed-model all-minilm:latest \
  --model <receiver-local-completion-model> \
  --top-k 4
```

`field-query` persists its retrieval, reconciliation envelope, raw completion draft, guard result, and final response under `receiver/semantic-field-queries/`.

Index older committed Semantic Capsule bundles without replaying or re-signing them:

```sh
braid-client field-reindex \
  --output-dir ./receiver \
  --embed-model all-minilm:latest
```

Create bounded semantic-delta material or a signed delta frame:

```sh
braid-client field-delta <object-digest> \
  --output-dir ./receiver \
  --output ./semantic-delta.json
```

```sh
braid-client field-delta-frame <object-digest> \
  --output-dir ./receiver \
  --route-package ./route \
  --signing-key ./sender.key \
  --output ./semantic-delta.brad
```

## Cross-platform proof scripts

The source package includes:

```text
uat/a3/receiver.sh
uat/a3/sender.sh
uat/a3/verify.sh
uat/a3/Receiver.ps1
uat/a3/Sender.ps1
uat/a3/Verify.ps1
```

See `BRAID_V1_7_0A3_SEMANTIC_FIELD_PROOF_UAT.md` for the frozen-byte Mac/Linux/Windows procedure and expected evidence.

## Receiver artifact layout

```text
receiver/
  replay_ledger.db
  accepted/
  receipts/
  semantic/<object-digest>/
    vector.npy
    material.txt
    lineage.json
    field.json
    atoms.json
    atoms.npy
    novelty.json
    delta.json
  semantic-field-queries/
    <timestamp>-<id>.json
```

If field construction fails after Phase B, Braid preserves the accepted capsule and receiver-local semantic state, marks the field degraded, and permits later `field-reindex`. A post-commit indexing failure cannot erase acceptance.

## Security and authority boundaries

```text
transport arrival != Phase A validation
Phase A validation != Phase B commit
Phase B commit != field indexing
field similarity != truth
possible update != supersession
completion-model draft != grounded final response
```

A signature establishes integrity and provenance, not truth or command authority. Generated output must not directly authorize privileged actions.

## Test and promotion status

The a3 package contains the complete retained suite plus dedicated tests for:

- proof-mode defaults and fail-closed requirements;
- file-backed inspection ledgers;
- rich phase/index acknowledgments;
- actual Phase A failure reporting;
- accepted-and-indexed network results;
- canonical FP16 zero handling;
- reconciliation-envelope construction;
- conflict-sibling supplementation;
- missing-value, invented-unit, unsupported-supersession, and unsupported-conflict-selection guards;
- deterministic grounded fallback;
- compliant completion pass-through.

Before a public beta or stable release:

1. run the frozen a3 bytes on macOS, Linux, and Windows;
2. repeat send, restart/persistence, replay rejection, search, reconciliation, and guarded query tests;
3. run Managed Relay/WAN signed-delta UAT;
4. benchmark copy/paste versus whole-capsule versus field retrieval on larger corpora;
5. tune thresholds across multiple real embedding models and hardware classes;
6. complete adversarial review and native installer validation;
7. rerun the complete suite against the final frozen artifacts.
