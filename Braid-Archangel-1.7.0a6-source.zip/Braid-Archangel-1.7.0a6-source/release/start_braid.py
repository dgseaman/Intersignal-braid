#!/usr/bin/env python3
"""Archangel launcher: isolated default, explicit offline/host paths, cooperative stop."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import platform
import signal
import secrets
import shutil
import sqlite3
import subprocess
import sys
import sysconfig
import site
import time
import urllib.request
import venv
import webbrowser
from pathlib import Path

VERSION = '1.7.0a6'
WHEEL = 'braid_client-' + VERSION + '-py3-none-any.whl'
ROOT = Path(__file__).resolve().parent


def default_profile() -> Path:
    base = (Path.home()/'Library'/'Application Support'/'Intersignal'/'Braid'
            if platform.system() == 'Darwin' else Path.home()/'.braid')
    legacy = base/'messenger-a4'
    return legacy if (legacy/'messenger.sqlite3').is_file() else base/'messenger'


def acquire_lock(path: Path):
    handle = path.open('a+b')
    handle.seek(0)
    if not handle.read(1):
        handle.write(b'0'); handle.flush()
    handle.seek(0)
    try:
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return handle
    except OSError:
        handle.close()
        return None


def session_url(profile: Path):
    data = json.loads((profile/'session.json').read_text())
    port = int(data['port'])
    if not 1024 <= port <= 65535: raise ValueError('Invalid local session port')
    url = 'http://127.0.0.1:' + str(port)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(url+'/api/messenger/state', timeout=2) as response:
        state = json.load(response)
    if Path(state.get('inbox_path','')) != profile/'inbox':
        raise ValueError('Local session belongs to another profile')
    return url, state, opener


def existing_window(profile: Path, no_browser: bool) -> bool:
    try:
        url, state, _ = session_url(profile)
        print('This profile is already running Braid ' + str(state.get('version')) + ': ' + url)
        if state.get('version') != VERSION:
            print('Quit that version first, then launch Archangel. No concurrent profile upgrade was attempted.')
        if not no_browser: webbrowser.open(url)
        return True
    except (OSError, ValueError, KeyError):
        return False


def request_shutdown(profile: Path) -> bool:
    try:
        url, state, opener = session_url(profile)
        request = urllib.request.Request(url+'/api/messenger/shutdown',data=b'{}',
                  headers={'Content-Type':'application/json','X-Braid-CSRF':state['csrf']},method='POST')
        with opener.open(request,timeout=3) as response:
            return bool(json.load(response).get('shutting_down'))
    except (OSError, ValueError, KeyError):
        return False


def client(profile: Path, port: int, no_browser: bool) -> int:
    os.environ['BRAID_MESSENGER_HOME'] = str(profile)
    os.environ['BRAID_RECEIVER_DIR'] = str(profile/'inbox')
    from braid_client.server import serve_http_app
    from braid_client.private_files import private_dir, atomic_private_write
    private_dir(profile)
    session = profile/'session.json'
    def ready(host: str, actual_port: int) -> None:
        atomic_private_write(session, json.dumps({'port':actual_port,'version':VERSION,'pid':os.getpid()}).encode())
        print('\nArchangel is ready: http://%s:%s/' % (host,actual_port), flush=True)
        print('Closing the browser does not stop receiving. Use Settings > Quit Archangel, or Control-C here.\n', flush=True)
    try:
        serve_http_app(host='127.0.0.1',port=port,key_path=str(profile/'identity.pem'),
                       open_browser=not no_browser,on_ready=ready)
    finally:
        session.unlink(missing_ok=True)
    return 0


def backup_before_upgrade(profile: Path):
    """Snapshot mutable desktop/trust configuration. Semantic stores are not rewritten."""
    marker = profile/'archangel-upgrade.json'
    dbfile = profile/'messenger.sqlite3'
    if not dbfile.exists(): return
    if marker.exists():
        try:
            if json.loads(marker.read_text()).get('version') == VERSION: return
        except (ValueError, OSError):
            pass  # An unreadable old marker cannot skip this version's snapshot.
    backup = profile/'backups'/('pre-archangel-'+VERSION+'-'+time.strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(3))
    backup.mkdir(parents=True, mode=0o700)
    source = sqlite3.connect(dbfile)
    dest = sqlite3.connect(backup/'messenger.sqlite3')
    try: source.backup(dest)
    finally: dest.close(); source.close()
    for name in ('identity.pem','identity.pub','lan-certificate.pem','lan-tls-private.pem'):
        if (profile/name).is_file(): shutil.copy2(profile/name,backup/name)
    if (profile/'peers').exists(): shutil.copytree(profile/'peers', backup/'peers',symlinks=True)
    marker.write_text(json.dumps({'backup':str(backup),'version':VERSION,'scope':'desktop database, identity and peer routes; semantic stores retained in place'},indent=2))
    print('Pre-Archangel desktop/trust snapshot: '+str(backup),flush=True)


def validate_existing(python: Path):
    # Explicit operator opt-in only. Validate imports and versions before reuse.
    code = """import sys,importlib.metadata as m
import numpy,cryptography,jsonschema,referencing,rpds
from pip._vendor.packaging.version import Version
for name,lower in [('numpy','1.20'),('cryptography','42.0'),('jsonschema','4.18')]:
    if Version(m.version(name))<Version(lower): raise RuntimeError(name+' is too old')
print('Existing dependency environment validated; it is NOT isolated from host packages.')
"""
    subprocess.run([str(python),'-c',code],check=True,timeout=30)


def link_existing_environment(python: Path):
    """Explicitly expose the selected interpreter's package directories.

    A nested venv's system_site_packages points at the base interpreter, not
    necessarily the caller's venv. A visible, path-only .pth file handles that
    explicit opt-in without changing or installing into the host environment.
    The ordinary isolated runtime never receives this file.
    """
    candidates = list(sys.path) + list(site.getsitepackages())
    user_site = site.getusersitepackages()
    candidates += [user_site] if isinstance(user_site, str) else list(user_site)
    paths = []
    for item in candidates:
        path = Path(item).expanduser().resolve() if item else None
        if path and path.is_dir() and path.name in ('site-packages', 'dist-packages'):
            value = str(path)
            if '\n' in value or '\r' in value: raise ValueError('Invalid existing-environment package path.')
            if value not in paths: paths.append(value)
    if not paths: raise RuntimeError('No reusable package directories found in the explicitly selected interpreter.')
    result = subprocess.run([str(python), '-I', '-c', 'import sysconfig;print(sysconfig.get_path("purelib"))'],
                            check=True, capture_output=True, text=True, timeout=20)
    destination = Path(result.stdout.strip()) / 'archangel-host-explicit.pth'
    destination.write_text('\n'.join(paths) + '\n', encoding='utf-8')
    if os.name != 'nt': destination.chmod(0o600)
    print('Explicit host package links: ' + str(destination), flush=True)
    validate_existing(python)


def stop_child(process, profile):
    print('\nRequesting cooperative shutdown; unfinished handoffs will not be auto-retried.',flush=True)
    request_shutdown(profile)
    try: return process.wait(timeout=12)
    except subprocess.TimeoutExpired: pass
    print('A local operation did not drain. Stopping the process; check unconfirmed sends on restart.',flush=True)
    process.terminate()
    try: return process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        return process.wait(timeout=5)


def main() -> int:
    parser = argparse.ArgumentParser(description='Braid Messenger Archangel - local rigs, durable handoffs.')
    parser.add_argument('--profile',type=Path,default=default_profile())
    parser.add_argument('--port',type=int,default=0)
    parser.add_argument('--no-browser',action='store_true')
    parser.add_argument('--check',action='store_true',help='Verify bundle without installing.')
    parser.add_argument('--offline',action='store_true',help='Never consult package indexes.')
    parser.add_argument('--wheelhouse',type=Path,help='Verified offline pack made by prepare_offline.py.')
    parser.add_argument('--isolated-runtime',action='store_true',help='Return to isolated installation after explicit host reuse.')
    parser.add_argument('--use-existing-env',action='store_true',help='Explicitly reuse validated host packages (not isolated).')
    parser.add_argument('--stop',action='store_true',help='Request authenticated cooperative shutdown for this profile.')
    parser.add_argument('--run-client',action='store_true',help=argparse.SUPPRESS)
    args = parser.parse_args()
    if platform.python_implementation() != 'CPython' or sysconfig.get_config_var('Py_GIL_DISABLED'): raise RuntimeError('Use standard, non-free-threaded CPython 3.10 through 3.13 for this release.')
    if not (3,10) <= sys.version_info[:2] < (3,14): raise RuntimeError("Archangel's packaged dependency set supports Python 3.10 through 3.13. Choose one of those runtimes.")
    if args.port != 0 and not 1024 <= args.port <= 65535: raise ValueError('Invalid UI port.')
    profile = args.profile.expanduser().resolve()
    if args.stop:
        if not request_shutdown(profile): raise RuntimeError('No responsive Archangel session found for this profile.')
        print('Shutdown requested.'); return 0
    if args.run_client: return client(profile,args.port,args.no_browser)
    wheel = ROOT/WHEEL
    manifest = json.loads((ROOT/'bundle-manifest.json').read_text('utf-8'))
    digest = hashlib.sha256(wheel.read_bytes()).hexdigest()
    if manifest.get('version') != VERSION or manifest.get('wheel') != WHEEL or manifest.get('sha256') != digest:
        raise RuntimeError('Bundle integrity check failed. Re-extract an unmodified release.')
    for name, expected in manifest.get('support_files',{}).items():
        if Path(name).name != name or hashlib.sha256((ROOT/name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('Launcher/support file integrity check failed: '+name)
    print('Braid Messenger %s | Archangel | bundle verified' % VERSION,flush=True)
    print('Local profile: '+str(profile),flush=True)
    if args.check: return 0
    if args.use_existing_env and args.isolated_runtime: raise ValueError('Choose isolated runtime OR explicit existing-environment reuse.')
    if args.use_existing_env and args.wheelhouse: raise ValueError('Choose an offline pack OR explicit existing-environment reuse.')
    profile.mkdir(parents=True,exist_ok=True,mode=0o700)
    lock = acquire_lock(profile/'launcher.lock')
    if lock is None:
        for _ in range(8):
            if existing_window(profile,args.no_browser):return 0
            time.sleep(.5)
        raise RuntimeError('This profile is already starting. No second instance was started.')
    process = None
    try:
        # The OS lock, not a leftover filename, establishes exclusive ownership.
        (profile/'session.json').unlink(missing_ok=True)
        (profile/'shutdown-requested.json').unlink(missing_ok=True)
        policy_path=profile/'install-policy.json'
        policy=json.loads(policy_path.read_text()) if policy_path.exists() else {}
        use_existing=args.use_existing_env or (policy.get('mode')=='host-explicit' and not args.isolated_runtime and not args.wheelhouse)
        mode = 'host-explicit' if use_existing else 'isolated'
        if use_existing: print('Using the explicitly selected host dependency environment (not isolated).',flush=True)
        runtime_tag = '-py' + '.'.join(map(str, sys.version_info[:2])) + '-' + platform.machine().lower()
        runtime = profile/('runtime-'+VERSION+'-'+mode+runtime_tag)
        python = runtime/('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
        marker = runtime/'installed-wheel.sha256'
        if use_existing:
            validate_existing(Path(sys.executable))
        if not python.is_file():
            print('Creating '+mode+' runtime...',flush=True)
            venv.EnvBuilder(with_pip=True,system_site_packages=False).create(runtime)
        if use_existing:
            link_existing_environment(python)
        installed = marker.is_file() and marker.read_text().strip() == digest
        if not installed:
            pack = args.wheelhouse or (ROOT/'wheelhouse' if (ROOT/'wheelhouse'/'wheelhouse-manifest.json').is_file() else None)
            if pack:
                from offline_support import verify_pack
                pack = pack.expanduser().resolve()
                verify_pack(pack, ROOT/'dependencies.txt')
                subprocess.run([str(python),'-m','pip','--isolated','--disable-pip-version-check','install',
                    '--no-input','--no-index','--find-links',str(pack),'--require-hashes','--no-deps','-r',str(pack/'requirements.lock')],check=True,timeout=300)
            elif use_existing:
                validate_existing(python)
            elif args.offline:
                raise RuntimeError('Offline first launch needs a verified wheelhouse. On a connected equivalent rig run prepare_offline.py; or explicitly use --use-existing-env after reviewing its isolation tradeoff. No index was contacted.')
            else:
                print('Installing pinned dependencies. For air-gapped setup, supply --wheelhouse or explicitly --use-existing-env.',flush=True)
                subprocess.run([str(python),'-m','pip','--isolated','--disable-pip-version-check','install',
                    '--no-input','--only-binary=:all:','--timeout','15','--retries','1','-r',str(ROOT/'dependencies.txt')],check=True,timeout=300)
            subprocess.run([str(python),'-m','pip','--isolated','--disable-pip-version-check','install',
                '--no-index','--no-deps','--force-reinstall',str(wheel)],check=True,timeout=90)
            subprocess.run([str(python),'-c',"import braid_client,numpy,cryptography,jsonschema; assert braid_client.__version__ == '"+VERSION+"'"],check=True,timeout=30)
            marker.write_text(digest+'\n')
        policy_path.write_text(json.dumps({'mode':mode,'version':VERSION},indent=2))
        # Establish a Windows protected DACL before copying private backup material.
        subprocess.run([str(python),'-c','from braid_client.private_files import private_dir; from pathlib import Path; import sys; private_dir(Path(sys.argv[1]))',str(profile)],check=True,timeout=20)
        backup_before_upgrade(profile)
        command = [str(python),'-I',str(Path(__file__).resolve()),'--run-client','--profile',str(profile),'--port',str(args.port)]
        if args.no_browser: command.append('--no-browser')
        options = {'creationflags':subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == 'nt' else {'start_new_session':True}
        process = subprocess.Popen(command,**options)
        # Parent owns console signals and requests a normal HTTP shutdown first.
        def interrupted(signum, frame): raise KeyboardInterrupt
        signal.signal(signal.SIGTERM, interrupted)
        if hasattr(signal,'SIGBREAK'): signal.signal(signal.SIGBREAK, interrupted)
        try:
            while process.poll() is None:
                if (profile/'shutdown-requested.json').is_file():
                    return stop_child(process,profile)
                time.sleep(.2)
            return process.returncode
        except KeyboardInterrupt: return stop_child(process,profile)
    finally:
        if process is not None and process.poll() is None:
            stop_child(process,profile)
        lock.close()


if __name__ == '__main__':
    try: sys.exit(main())
    except KeyboardInterrupt: sys.exit(130)
    except Exception as exc:
        print('\nArchangel could not start: '+str(exc),file=sys.stderr)
        print('No automatic resend was performed. See START_HERE.md for offline setup and recovery.',file=sys.stderr)
        sys.exit(1)
