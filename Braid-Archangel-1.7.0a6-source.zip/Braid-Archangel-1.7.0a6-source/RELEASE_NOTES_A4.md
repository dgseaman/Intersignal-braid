# Braid Messenger 1.7.0a4

## New everyday interface

Compact dark messenger/mail layout, named rig list, presence checks, Inbox/Sent/Draft/Needs attention/Archive views, text search, exact message reader, explicit receipt stages, and expandable provenance. Small-screen navigation uses a single list or reader rather than squeezing three columns together.

The composer turns “send summary” into Write → Review → Share. It supports exact text, optional local Ollama summarization, a labeled extractive fallback, multiple selected peers, persistent local draft, per-peer send results, and an exact 6,000-byte limit. No background send occurs before the review-and-send action.

## New explicit setup

A private local identity, public rig-card export/import, verified card/route inspection, full-fingerprint approval, certificate-pinned TLS 1.3 LAN transport, approved-signer dispatch to the existing receiver, start/pause controls, and removal of future trust without deleting history. Default listener port: 8746. Existing Managed Relay peer loading remains an optional configured path.

## Full a3 machinery retained

The semantic/transport core and its behavioral regression tests are retained, including canonical FP16 sender handling, receiver-owned commit, explicit accepted/indexed ACKs, field persistence/integrity, fresh bounded field queries, conflict-preserving reconciliation, guarded completion, and signed deltas. Shared field exposes those operations; the old visualizer is one click away in Advanced, and the CLI is still included.

## Packaging

One universal bundle, one wheel, platform launch scripts, a source archive, an a3-to-a4 patch, checksums, runnable preview, and test evidence. No per-buyer or per-machine source bundle is required. Runtime identity and configuration are generated on each machine.

The launcher is deliberately side-by-side: a separate profile and Python environment, not an in-place replacement of a3. This is still a local browser-based client, not an OS-native tray application or signed standalone installer. Native packaging, physical Mac/Linux/Windows testing with real local models, WAN/relay testing, and independent security review remain open release gates.
