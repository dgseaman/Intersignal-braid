# Intersignal Braid 1.9.1 - Archangel

One complete installer for free LAN use and membership-activated Away from home.
No patches, separate customer builds or new third-party runtime dependencies.

## Start or upgrade

1. Quit the running Braid through Settings & tools > Quit Archangel, or Control-C
   in its launcher. Back up the COMPLETE private profile before upgrading. The
   automatic desktop/trust snapshot is NOT a complete semantic-store backup.
2. Extract this entire ZIP into a NEW folder. Do not replace individual files and
   do not run two versions against one live profile.
3. Use Start Braid.command on macOS, Start Braid.cmd on Windows, or run
   `sh "Start Braid.sh"` on Linux. Confirm **1.9.1** beside Settings & tools.

Standard CPython 3.10-3.13, Ollama and local model weights remain prerequisites.
The first run installs pinned dependencies into a version-specific environment.
Python/models are not inside this small ZIP. The Mac runtime-discovery correction
is included. Use per-app OS approval; do not disable OS security globally.
Native signing/notarization is not supplied.

**Already activated on 1.9.0rc1:** your identity, WAN encryption key, membership,
approved contacts, routing choices, channel permissions and delivery records stay
in your existing profile. Do not reissue invitations, reset keys or re-pair merely
to install this update. Existing WAN-enabled profiles resume their already chosen
connection behavior on restart. Unknown handoffs are not automatically resent.

**Coming from 1.8.1:** identities and local state remain; Away from home begins
unactivated/off. It is optional. Local sharing does not require a membership.

The installed 1.9.0rc1 relay speaks the same unchanged WAN protocol as this client.
**No droplet redeployment, certificate change or service restart is required for
this UI/diagnostic release.** `operator/` is for Intersignal, not ordinary users.
Do not run the fresh-server installer against an existing installation.

## Free LAN or Away from home

Use the inbox, reviewed summary composer, project Channels and local field as
before. The Away-from-home entry remains visible for all users, with a link to
membership information when unactivated. There is no subscription pop-up, hidden
cloud inference, tracking or automatic enrollment. The same software is supplied
to everyone; service access is provisioned separately.

Membership enables managed relay access after Intersignal activates the intended
rigs. Both rigs make outbound HTTPS requests. No customer DigitalOcean account,
router forwarding or server SSH key is required. Support/enrollment is operator-
assisted; payment is not automatically connected to activation by this release.

## What changed in 1.9.1

- Away from home has an explicit, viewport-bounded width and height and a single
  large scrolling body. Header/footer remain visible, long fingerprint records
  wrap, and text is not shrunk to fit. This addresses the Safari-specific collapse
  reported during the physical session. Native Safari confirmation remains due.
- Action errors are retained across routine state refreshes instead of disappearing
  after a few seconds. A subsequent explicit operation clears the prior action error.
- Clock failures get a plain-language explanation in the reading pane and WAN panel.
  The actual timestamps, signed receipts, validation limits and retry rules remain
  untouched. An explicit rejection is not presented as accepted just because a copy
  was stored in the rejected-message directory.
- An authenticated REJECTED_BEFORE_PHASE_B response with complete negative commit/
  index evidence now remains a definite rejection on the sender even when a copy
  was stored in quarantine. Ambiguous or contradictory responses stay unknown.
- Receipt & provenance has **Save receipt JSON**, exporting the existing receipt
  locally without a resend. It may contain shared text and local paths; review it
  before sharing. Activation credentials and settings are not added to the export.
- Failed activation-file selection clears stale preview data; the same file can
  be deliberately selected again. This does not automatically retry enrollment.

## When clocks disagree

The September 10 session's Mac receipt explicitly reported ERR_FUTURE_TIMESTAMP:
issued_at 1789087123, receiver Now 1789087115. It recorded managed_wan transport,
rejection before Phase B and storage in the rejected directory. That is delivery
to the receiver followed by a clock rejection, not accepted shared state.

On **both rigs**, check automatic system time synchronization:
- Mac: System Settings > General > Date & Time > Set time and date automatically.
- Windows: Settings > Time & language > Date & time > Set time automatically;
  choose Sync now where provided, and check the synchronization result.
- Linux: enable automatic network time in the desktop's Date & Time settings.

Different display time zones are fine; epoch-time accuracy is what matters. The
receipt alone cannot identify which clock is correct. Braid does not adjust OS
clocks, relax the five-second future-time allowance, extend signed frames or retry
an uncertain delivery. Preserve the old receipt. After synchronization, use one
new harmless test handoff only when deliberately chosen; do not blindly duplicate
an unresolved send. For unknown outcomes use **Check WAN receipt (no resend)**.

## First controlled WAN use

On each rig: save its own public .braidjoin request; obtain its device-bound private
.braidmember from Intersignal; import it after comparing the full operator signing
fingerprint through a trusted channel. Do not put .braidmember files, private keys
or complete profiles in chat, public hosting or a repository.

Enable Away from home, explicitly permit incoming notes where intended, publish
current rig cards and approve the other rig after full fingerprint comparison.
Select **Managed WAN** for that destination and save. A LAN failure never silently
selects the internet. Membership does not grant permission to read any Channel.

For a remote question, separately authorize the specific peer and Channel on the
home rig; enable that Channel's Use in chat and Send to that peer, and choose a
local completion model. Send only the intended question from the traveling rig.
Inspect the returned answering-rig identity and shared-note evidence. This is a
one-shot query, not remote desktop, a shell, a filesystem browser, an exposed
Ollama endpoint, a phone-browser portal or automatic transcript mirroring.

Home rigs must remain awake, online and running Braid. Requests live at most five
minutes under the existing frame boundary. This is not a multi-day offline mailbox;
encrypted replies can be checked for roughly one day. Queued is not accepted;
accepted is not indexed; an indexed note is not proof of model use or action
constraint enforcement. Unknown results stay unknown until evidence resolves them.

## Verification and release boundary

See QA.md for newly executed checks and docs/PHYSICAL_EVIDENCE_2026-09-10.md for the
actual lab observations. Existing relay deployment, activation and cross-network
receiver delivery are documented; the rejected frame is explicitly not a success.
The earlier accepted/indexed excerpt has a different digest and is not conflated
with it. Successful remote-model querying and remaining negative/soak tests are
not established by those excerpts. Native Safari, macOS/Windows upgrade checks and
independent security review remain important for broader managed-service rollout.

This distribution has no credentials. The relay sees routing, timing, sizes and
public-card metadata, not plaintext encrypted payloads. The inherited encryption
composition is not an independent audit, post-quantum protection or forward secrecy
after recipient-key compromise. Local state is access-controlled, not encrypted
at rest. The build did not change your website, billing, droplet or installed rigs.

Further detail: docs/WAN_PROTOCOL.md, docs/UAT_WAN.md and docs/CLOCK_HELP.md.
A7 Resilience remains separate, not silently merged.
