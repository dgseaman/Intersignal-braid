# Documentation status - Intersignal Braid 1.9.1

## Current release

- ../START_HERE.md: one complete client, free LAN and activated Managed WAN.
- ../RELEASE_NOTES.md: exact maintenance scope and compatibility.
- ../QA.md: current automated tests, methods and limitations.
- CLOCK_HELP.md: synchronize system clocks without weakening signed-time checks.
- PHYSICAL_EVIDENCE_2026-09-10.md: operator-reported rc1 deployment and rig evidence.
- WAN_PROTOCOL.md: unchanged managed-wan.v1 implementation contract.
- UAT.md and UAT_WAN.md: remaining physical checks, not a claim that all have passed.
- ../operator/DEPLOY.md: operator-only fresh-server template. Already deployed rc1
  servers do not need reinstalling for the 1.9.1 client update.

## Retained references

Other documents describe implementation history and their version labels, counts
and promotion gates are historical. In particular, MANAGED_RELAY.md describes the
older Jump Kit, not /braid/v1/. The new integrated WAN path does not require the
Jump Kit executable. The old Channels guide remains useful for local controls;
its blanket relay limitations are superseded only by the explicit 1.9 WAN path.

historical-1.8.1/ and history/QA_1_9_0rc1.md retain earlier evidence separately.
No old test result should be treated as a new 1.9.1 test run.
