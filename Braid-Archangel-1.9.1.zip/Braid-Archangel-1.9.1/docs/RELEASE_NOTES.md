# Release notes - Braid 1.9.1

The current record is [../RELEASE_NOTES.md](../RELEASE_NOTES.md).
The prior 1.8.1 record is retained under historical-1.8.1/.
