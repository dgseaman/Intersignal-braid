# Managed WAN v1 - trust and lifecycle

## Scope

`managed-wan.v1` is an additive signed rig-card capability. `wan.encryption_key`
contains the X25519 public key bound by the existing Ed25519 rig-card signature.
The descriptor, channel-note and BRAD schemas remain unchanged. A 1.8.1 peer can
retain ordinary direct transfers, but cannot be silently promoted to the new WAN
protocol. The new member plane does not depend on old Jump Kit processes/tokens.

Three boundaries remain distinct:

1. **Operator authorization:** Intersignal's CLI creates/renews/suspends membership
   and enrollment of specific device keys. HTTPS API has no admin method.
2. **Relay admission:** active account and device, signed fresh request, nonce,
   destination in same account, limits and expiry. This only admits queued bytes.
3. **Rig admission:** locally approved signer and recipient encryption key, exact
   envelope binding, BRAD signature/route/session/replay/Phase B and channel policy.
   A remote query additionally needs an explicit local peer/channel grant and
   permission to export that channel to that peer.

## Cryptographic envelope

Canonical JSON uses sorted keys, compact separators, ASCII escapes, no duplicate
keys/nonfinite numbers/lone surrogates, bounded nesting/size. Each signature has a
distinct domain label. Application request/response identities bind member, device,
action/data, timestamp and nonce; responses bind exact request hash plus nonce.

The sealed packet header binds schema/suite, random 128-bit packet ID, member,
sender, recipient, recipient-key hash, fresh ephemeral X25519 key, random 96-bit
AES-GCM nonce, creation and expiry. HKDF-SHA256 derives a 256-bit key from the DH
secret with a hash of the header as salt and domain+header as info. AES-GCM uses the
header as AAD. Ed25519 signs the header and ciphertext. Fresh ephemeral keys and
nonces are generated for every packet. The receiver verifies before decrypting.

This is an explicit application construction using cryptography's implementations,
NOT an implementation of RFC 9180 HPKE and not independently audited. Recipient
key compromise can decrypt previously captured envelopes; post-compromise recovery,
owner-key hierarchies and cryptographic-suite migration remain future work. TLS
certificate validation and operator-key pinning are additional controls, not
substitutes for peer verification.

## API

`POST /braid/v1/rpc`, HTTPS. No generic URL/tunnel dispatch. Actions:

- enroll: short-lived invitation bound to exact rig keys, possession proved by request
  signature; token hashed at rest, not retained in client configuration after use.
- status, peers, card: account-scoped metadata/public cards. Discovery grants no trust.
- publish-card: signed same-device key/monotonic revision, bounded public payload.
- enqueue: immutable encrypted packet and deadline, never a receiver ACK.
- poll: one eligible leased packet. Lease retries repeat exact ciphertext, not new
  BRAD frames. Revoked publishers are not newly dispatched.
- reply: exact addressed recipient's immutable encrypted signed response.
- result: original sender reads that response or an unconfirmed/waiting observation.

The control signature window is +/-60 seconds, response window 90 seconds. These
are separate from the unchanged BRAD validity policy; clocks must still be correct.
Request/response endpoints refuse browser-origin calls, redirects are not followed,
and the desktop's new API remains behind loopback Host/Origin/session checks.

## Data and failure states

Clearing local activation marks unresolved outgoing requests as activation-changed
and withholds unsent replies. Old membership work does not block or replay into a
new account. Socket deadlines do not guarantee preemption of OS DNS resolution or
arbitrary native inference.

Before any enqueue attempt the sender persists the exact ciphertext and its digest.
Note sends also retain the exact original prepared BRAD file and existing durable
handoff record. Loss of an enqueue reply means unknown, not preparation failure or
automatic retry. The global send path never changes its chosen transport on error.

The receiver persists request identity/hash BEFORE processing. It caches a signed
response AFTER processing. Duplicate envelopes reuse that completed record. A crash
between steps yields interrupted/unknown, not a replayed operation. Phase B may
already have occurred; there is no new distributed exactly-once claim or atomic
transaction spanning the relay DB, client DB and protocol artifact files.

For frames, the outer peer must also be the signer of the inner BRAD frame. The
existing receiver owns admission. A callback error after entry results in an
uncertain reply, not a false rejection. Only a verified reply tied to packet ID,
original envelope digest, original frame hash and approved receiver can update the
sender's existing message. Contradictory boolean finality is rejected.

For queries, only a selected channel ID and bounded question are accepted. No model
URL, tool request, remote filesystem or command. The home rig's configured local
completion model is used. Scoped source selection and guard behavior are retained.
The return count is the actual home prompt's semantic-atom count. Permissions are
rechecked before response export; detected revocation withholds answer content.
Already-dispatched content is not recallable. Errors are reduced to codes rather
than returning private filesystem paths. Query history is separate from local chat.

## Bounds and operations

- Desktop: at most 32 unresolved outgoing requests, 10,000 records, 256 MiB counted
  outgoing record payload; one relay intake worker. No unlimited offline spool.
- Relay: eight simultaneous handlers, socket/body deadlines, 16 MiB control bodies,
  3 MiB sealed-packet limit, 2 MiB plaintext cap, 12 MiB card cap, strict JSON bounds.
- Active identity request quota: 180 requests/minute. Account defaults: two devices,
  1 GiB counted payload/month, 16 MiB queued data, 256 retained packet records. Global
  stored card/packet payload cap: 512 MiB. These are not total process/disk memory caps.
- Idle client poll about 15 seconds; busier receiving loop five seconds. Reconnect
  uses bounded exponential backoff and jitter. This is not instantaneous push.
- Requests: <=300 seconds and never longer than the original frame's remaining TTL.
  Replies: up to one day. Server periodically deletes old encrypted queue records;
  storage/backups/SQLite free pages are not guaranteed securely erased.

Limits don't stop all DoS, enforce hardware uniqueness, preempt arbitrary native
inference, or make one droplet proven for thousands of members. Transport metadata
is visible to the operator. Device/profile compromises and malicious approved
receivers remain within the threat model. Independently review before production.
