# Clock checks and receipt recovery

A relay can deliver a packet successfully while the receiver rejects its signed
creation time. In the recorded case the frame was eight integer seconds ahead of
the Mac validator clock. The five-second future-skew check is deliberately unchanged.
The receipt does not tell us which system had the inaccurate clock.

Use OS automatic time synchronization on BOTH sender and receiver; check that it
actually synchronizes. Date/time-zone display settings alone do not repair a clock
that is several seconds wrong. The app supplies guidance, not privileged clock
commands, an NTP client, a network time estimate or automatic resend.

Mac: System Settings > General > Date & Time > Set time and date automatically.
Windows: Settings > Time & language > Date & time > Set time automatically; use
Sync now where available. Linux: enable automatic network time through the desktop.

An explicit REJECTED_BEFORE_PHASE_B record must stay rejected. The old signed
frame is not re-dated. An unknown or missing receipt is not a rejection: use the
existing no-resend check, preserve the handoff identifier and never create a new
attempt merely to dismiss an old one. Keep an exact receipt via Save receipt JSON.
It may include shared text and local paths; review before providing to support.

Sources checked while preparing these instructions:
- https://support.apple.com/en-gb/guide/mac-help/mchlp2996/mac
- https://support.microsoft.com/en-us/windows/experience/personalization/set-time-date-and-time-zone-settings-in-windows
- Existing braid_client/mcp_core/protocol.py ReplayLedger (unchanged).
