# Physical session evidence - September 10, 2026 (local time)

Source: operator console outputs, request files and receipt excerpts supplied in
this conversation. These are user-reported observations, not remote commands run
by the build environment. All runs below were on **1.9.0rc1**, not 1.9.1.

## Demonstrated during the session

- Additional relay service deployed on the existing DigitalOcean host. A dedicated
  TLS leaf and persistent exact-host HAProxy SNI route were added without replacing
  the legacy member route. External Mac HTTPS health passed TLS 1.3, CA/hostname and
  exact-leaf verification. The health response explicitly denied receiver authority.
- MacBook Air and Windows/Avalon-core completed membership activation and mutual
  member-rig discovery and card approval. WAN enable/receive settings and explicit
  Managed WAN destinations were reported saved on both.
- Operator identifies Mac on condo Wi-Fi and Windows on independent Starlink.
  Reported routes to the relay: Mac en0 172.25.0.128 via 172.25.0.1; Windows Wi-Fi
  192.168.1.251 via 192.168.1.1. Operator subsequently confirmed BOTH direct LAN
  receivers were paused. These are host routes and operator topology reports,
  not an exhaustive alternate-path audit.
- Mac receipt records source_transport=managed_wan, transport_completed=true and
  `ERR_FUTURE_TIMESTAMP: Timestamp in future beyond clock skew: 1789087123 (Now: 1789087115)`.
  The exact frame SHA-256 is
  `6ecd64bd93c28a9967f85a25abe425c2328647080bbfe817536169181ca4556e`.
  It reports accepted=false, phase_a_validated=false, phase_b_committed=false,
  finality=rejected and result_summary=REJECTED_BEFORE_PHASE_B. stored=true refers
  to the rejected-store copy, not admission. source_peer=null; no sender identity
  is invented from generic node labels. No raw frame was supplied for revalidation.

## Separate accepted result, not a matching receipt

An earlier excerpt reports accepted=true, accepted_and_indexed=true, Phase B
committed and a 384D finite receiver-local vector. Its frame digest is
`b97f13c51df84e242b63cdf890ec394c9ac04d99b358fe5b58251a51b022ac69`.
Transport/peer attribution and matching signed sender receipt were not provided
for that excerpt. It is not the rejection above later turning into an acceptance.
Neither excerpt demonstrates a completed remote-model question/answer.

## Release follow-up

Synchronize system clocks on both rigs without editing signed timestamps, then
record one fresh deliberate WAN handoff with its matching accepted/indexed receipt
and separately authorized remote Channel answer. Test permissions, interruptions,
expiry and revocation as set out in UAT_WAN.md. Confirm the 1.9.1 dialog in native
Safari and the upgraded Mac/Windows lifecycle. Container tests are listed in QA.md.

The dedicated server certificate expires March 9, 2027 at 22:34:49 UTC. An automatic
renewal/alerting process was not installed in this session. Address before broad
managed-service fulfillment. Do not put activation tokens, operator keys, private
CA keys, complete profiles or customer records in the public evidence archive.
