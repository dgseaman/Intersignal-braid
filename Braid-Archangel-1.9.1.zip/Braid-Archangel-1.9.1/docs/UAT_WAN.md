# 1.9 WAN physical qualification checklist

Read PHYSICAL_EVIDENCE_2026-09-10.md for recorded rc1 progress. This list is not
a pass report; remaining checks must be recorded against the actual tested build.

Do not change public downloads merely by running this checklist. Use the exact
release hashes on both rigs, complete
backups and harmless context. Record OS, Python, Ollama/model digest, endpoint,
version, account limits, clock state and per-step evidence without private keys.

1. Inspect/deploy the additive relay service without changing old Jump Kit listeners.
   From an unrelated network verify DNS, TLS chain/hostname and API health. Verify
   unknown methods cannot administer accounts or proxy to private endpoints.
2. Verify 1.8.1-to-1.9 upgrade, blank composer/Drafts/X/Escape, retained identity,
   channel and source state, older-running-instance refusal, cooperative shutdown.
   Execute on Mac and Windows; Linux container tests do not certify native behavior.
3. Issue two activation files under one internal member account. Wrong-device,
   expired, altered and wrong-operator-fingerprint activations must fail. A third
   device must fail at a two-device limit. No private keys leave a rig.
4. Approve fresh signed 1.9 rig cards in BOTH directions. Independently exchange one
   channel card and allow the intended publishers. Discovery must grant no trust.
5. Put one rig on home internet and one on a phone hotspot/separate NAT. Select WAN
   explicitly, leave LAN listeners off for this test, and show the actual network
   route/endpoints. Send ordinary exact text and a channel note. Relay queue is not
   acceptance; receiver reply must show exact-byte acceptance/indexing. Reverse.
6. On the home rig, explicitly grant remote questions for one peer/channel and
   select a local completion model. From the traveler ask about the test note.
   Record the home model request, returned shared-note count and exact evidence.
   A no-grant channel and an unrelated peer must not invoke the model or expose notes.
7. Remove a grant during inference/before export; withhold the new answer. Receiving
   a question or model response must never trigger automatic /note forwarding.
8. Drop connectivity after enqueue and after receiver acceptance. Restart sender
   and receiver separately. Check existing outcomes; no new send, fresh BRAD frame,
   or duplicate acceptance should be created. Interrupted execution remains unknown.
9. Sleep home rig past the five-minute request window. Do not claim it was delivered
   later; show unconfirmed expiry. Wake before expiry and test receipt recovery.
   Demonstrate that captured relay payloads contain no note/question/answer plaintext.
10. Suspend/expire the internal membership and revoke one registered device. Verify
    new requests/polls/replies denied while free LAN and retained local queries work.
    Renew/resume, verify capacity changes and normal reconnect without a new installer.
11. Test quota exhaustion and restored service, bounded reconnection, stale LAN IP,
    untrusted TLS certificate, clock skew and malformed/tampered packet rejection.
    Keep original BRAD clocks/TTL; do not relax gates to pass a run.
12. Run a small consented multi-account soak and measure server CPU/RAM/queue/idle
    bandwidth/request latency and device energy use. Define an operating capacity
    from evidence before advertising scale or a bandwidth guarantee.
13. Practice an access-controlled server key+DB backup/restore and a complete user
    profile restore. Verify original identities, replay rules and no automatic resend.

Camera/QR and a7 preview tests remain separate. This qualification concerns the
new WAN path, not universal native/browser/security certification. Independent
adversarial review of the new envelope/control protocol is still required.
