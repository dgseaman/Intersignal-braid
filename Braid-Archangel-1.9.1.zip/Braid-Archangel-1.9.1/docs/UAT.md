# Braid 1.9.1 - physical release checks

Automated results are in ../QA.md. They do not establish
native Safari or Windows behavior. Read PHYSICAL_EVIDENCE_2026-09-10.md for
operator-reported rc1 progress; do not repeat completed server deployment.

## First check on the upgraded rigs

1. Back up the complete private profile, quit the running client and extract the
   complete 1.9.1 ZIP into a new folder. Start it and confirm the displayed version.
   Do not run two versions against one live profile or reissue activation merely
   to upgrade. Leave the existing 1.9.0rc1 relay service and certificate intact.
2. In native Safari, open Away from home. Check that its body has substantial
   usable height, its header/footer do not overlap settings, and every setting,
   activation control, peer review and remote-question section can be reached.
   Resize the window; check normal and increased browser zoom, Tab and Escape.
   Repeat on Edge. Record browser/OS/version and screenshots of actual results.
3. Confirm the existing rig identity, local notes, Channels, approved contacts,
   WAN activation and chosen send/receive/query permissions are retained. Confirm
   a fresh Share summary opens blank, while Drafts deliberately resumes work.
4. Open the retained future-timestamp rejection. Check the clock guidance and
   explicit rejection wording. Save receipt JSON; compare it with the existing
   record. The action must not issue a send or include activation/settings data.
5. Synchronize automatic OS time on BOTH rigs, verify successful time sync, and
   preserve the original rejected record. Do not change Braid's skew/TTL checks,
   re-date frames, or duplicate an uncertain handoff to clear its status.
6. With the chosen independent networks and LAN listeners paused, deliberately
   create one new harmless ordinary handoff. Record exact original text, sender
   and receiver, frame digest, managed_wan attribution, authenticated receipt,
   accepted/indexed stages. Check the reverse direction separately.
7. Grant exactly one intended peer/Channel remote-question access on the home rig.
   Ask a new question from the traveling rig, and record answering rig/model and
   exact shared-note evidence. A question typed locally on the receiver is a
   different test from a returned remote-model response.

## Wider supported rollout

Complete UAT_WAN.md,
including rejection, revoked access, interrupted receipts, restart/restore,
capacity and real-model timing. Report each result, not merely an overall label.
Do not advertise an availability, large-fleet throughput or security guarantee
from these limited checks. Certificate renewal/monitoring remains operator work.
