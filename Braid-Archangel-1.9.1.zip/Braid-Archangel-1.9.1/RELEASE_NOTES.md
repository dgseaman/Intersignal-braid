# Intersignal Braid 1.9.1

## Integrated polish release

Baseline: exact Braid-Archangel-1.9.0rc1.zip, SHA-256
`0c5985f09d3deef5334a343490722471dfced354be84babff5b619294578e704`.

- Definite, responsive grid geometry for the Away-from-home dialog; visible header,
  footer and large keyboard-accessible scrolling body without reduced text size.
- Persistent action-error messages, explicit clock diagnostics, and cautious handling
  of rejected-store semantics in the reader. No validation limits were relaxed.
- Correct sender finality for explicitly authenticated pre-commit rejections saved
  in the rejected store; preserve uncertainty for incomplete/contradictory evidence.
- Save the existing receipt as JSON, without a new send, question or receipt rewrite.
- A failed activation selection no longer leaves a previous activation preview
  usable. Same-file selection works without automatic activation/retry.
- Optional membership invitation for LAN users in the existing Away-from-home panel.
  No billing change, tracking, nag prompt or enrollment on launch.
- Unified launcher/package/UI version, full source and one complete installer.

The installed rc1 relay and its /braid/v1 protocol remain compatible. Existing
memberships and local identities/permissions are preserved. No server deployment,
certificate change, new membership issuance or public-site update is performed by
this build. A7 is not merged. See QA.md and the physical evidence note rather than
assuming version numbering establishes end-to-end production qualification.
