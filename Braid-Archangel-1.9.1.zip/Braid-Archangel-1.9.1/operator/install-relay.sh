#!/bin/sh
# Explicit operator installation, NOT a member installer or a remote auto-deploy.
# Adds only braid-wan-19.service. Does not stop/reconfigure existing relay services.
set -eu
umask 077
VERSION=1.9.1
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
PYTHON=${BRAID_OPERATOR_PYTHON:-python3}
[ "$(id -u)" = 0 ] || { echo 'Run on the droplet as root after reviewing DEPLOY.md.' >&2; exit 1; }
[ "${1:-}" = '--install-reviewed' ] || { echo 'Read DEPLOY.md and run inspect-droplet.sh first. Then: sh operator/install-relay.sh --install-reviewed'; exit 1; }
"$PYTHON" -c 'import sys; assert (3,10)<=sys.version_info[:2]<(3,14), "CPython 3.10-3.13 required"'
"$PYTHON" "$ROOT/verify_release.py" "$ROOT" > /dev/null
if systemctl is-active --quiet braid-wan-19.service; then
  echo 'Existing 1.9 relay is running. Back up and stop ONLY that service deliberately before replacing it.' >&2
  exit 1
fi
if ss -lnt | awk '{print $4}' | grep -Eq '(^|:)8765$'; then
  echo 'Port 8765 is occupied; no service was stopped or replaced.' >&2; exit 1
fi
DEST=/opt/intersignal-braid-wan/$VERSION
[ ! -e "$DEST" ] || { echo 'Version directory already exists. Inspect it; refusing overwrite.' >&2; exit 1; }
if ! id braid-wan >/dev/null 2>&1; then
  useradd --system --user-group --home-dir /var/lib/intersignal-braid-wan --shell /usr/sbin/nologin braid-wan
fi
install -d -o braid-wan -g braid-wan -m 700 /var/lib/intersignal-braid-wan
install -d -m 755 "$DEST"
"$PYTHON" -m venv "$DEST/venv"
# Public Python packages, pinned by the same specification as the client.
# Requires outbound package-index access; this is not a universal offline pack.
"$DEST/venv/bin/python" -m pip install --only-binary=:all: -r "$ROOT/dependencies.txt"
"$DEST/venv/bin/python" -m pip install --no-deps "$ROOT/braid_client-$VERSION-py3-none-any.whl"
"$DEST/venv/bin/python" -m pip check
# This directory contains software only, never identities or member state.
# The service account must be able to traverse root-installed venv directories.
chmod -R a+rX "$DEST"
install -m 644 "$ROOT/operator/braid-wan-19.service" /etc/systemd/system/braid-wan-19.service
systemctl daemon-reload
systemctl enable --now braid-wan-19.service
systemctl is-active --quiet braid-wan-19.service
printf '\nLoopback relay service installed. HTTPS routing and firewall have NOT been changed.\n'
printf 'Read operator/DEPLOY.md before issuing activations. Keep old relay services intact.\n'
printf 'Operator command prefix:\n  sudo -u braid-wan %s/venv/bin/python -m braid_client.wan_relay --state /var/lib/intersignal-braid-wan\n' "$DEST"
