# Intersignal operator deployment - Braid 1.9.1 fresh-server template

**Fresh-server instructions only. Members do not perform these steps.**

For the existing relay deployed during the September 10 session: **leave it running
on 1.9.0rc1**. The 1.9.1 client uses identical wire and relay implementations; this
UI release does not require a droplet upgrade. Do not run install-relay.sh against
an existing deployment, overwrite its HAProxy generator, remove its TLS override,
regenerate keys or reissue device invitations. The current /opt/.../1.9.0rc1 operator
command path remains valid. See ../docs/PHYSICAL_EVIDENCE_2026-09-10.md for observed
progress and remaining UAT, rather than treating the whole service as unconfigured.

The rest of this document is a template for a NEW installation. Operator inspection
is required before touching any service. This build performs no production writes.

The client and server are in this ONE release ZIP. The same client goes to every
member. Small per-device signed activation files carry membership authorization;
there are no bespoke installers, embedded customer keys, or DigitalOcean accounts
for customers. The existing commercial relay/Jump Kit is NOT this HTTP protocol.
Installing only the new desktop client cannot upgrade an old server.

## 1. Inspect and preserve the existing droplet

Run `sh operator/inspect-droplet.sh` on the actual droplet. Review occupied ports,
services, available memory/disk, Python and current TLS termination. Historical
project notes mention 159.223.126.155, Jump Kit 8750 and a possible SNI/cell service
on 443. Those notes are not a current inventory and MUST NOT be used to overwrite
unknown live services. Verify the host through your DigitalOcean account and SSH
host-key records. Do not paste SSH private keys or API tokens into chat or GitHub.

Back up the current service configuration, current relay state and evidence with
an access-controlled snapshot appropriate to those running services. This bundle
does not migrate old enrollment tokens, old Member Passes, Jump Kit peers or SNI
cells. Keep those intact. Never put the operator signing key in the public repo.

The build environment did not access or reconfigure the live droplet. The earlier
operator-guided rc1 deployment is recorded separately. Do not interpret lack of
build-container network access as a production DNS failure.

## 2. Install the additional loopback service

On the droplet, use standard CPython 3.10-3.13 with venv support (Ubuntu 24.04
normally uses 3.12). Upload and verify the COMPLETE release, not source-only.
Review scripts first, then run:

```sh
sh operator/install-relay.sh --install-reviewed
```

The installer requires root, uses pinned package versions, creates an unprivileged
`braid-wan` account and versioned virtual environment, and adds ONLY
`braid-wan-19.service` on 127.0.0.1:8765. It fails instead of replacing an active
instance or occupied port. It does not install a proxy, change UFW/DigitalOcean
firewalls, DNS, payment settings, old services or other ports. It needs package
index access for initial dependencies; native execution of this installer has not
been performed by the build container.

## 3. Provide HTTPS without disrupting an existing listener

The intended URL is **https://relay.intersignal.org** and requests go to
`/braid/v1/rpc`; `/braid/v1/health` is the limited health route. Put a TLS 1.3 HTTPS
reverse proxy in front of the loopback service, with a certificate valid for this
hostname and a 16 MiB request limit. `Caddyfile.example` is a template to REVIEW and
MERGE, not a replacement configuration. Do not enable proxy request-body logging.

If port 443 currently handles TLS passthrough for Jump Kit/member SNI cells, do
not convert it blindly to an HTTP endpoint. Either carefully add compatible SNI
routing, or stage the new HTTPS service on **8751** (8443 is also permitted by the
client) and issue activations with that explicit port. The Python service can
terminate TLS directly using `serve --bind 0.0.0.0 --port 8751 --tls-cert PATH
--tls-key PATH`; only use valid certificate files with narrowly scoped read
access. Do not expose 8765 or any rig's control panel/Ollama port to the internet.
A separately reviewed certificate/proxy plan is required when the existing layout
is unknown; this candidate does not automate that decision.

Allow the chosen HTTPS port in BOTH applicable cloud and host firewalls. Retain
existing operator SSH and any intentionally live old relay ports. Do not disable
firewalls or use wildcard port forwarding at members' homes. Normal member rigs
make outbound HTTPS requests only.

From a separate network, verify DNS, TLS hostname/chain, and:

```sh
curl --fail https://relay.intersignal.org/braid/v1/health
```

Health means the relay API responds, not that a member/peer/model can receive.
The built-in client additionally verifies the signed operator response bound to
each request. If a private CA is deliberately used, supply its public certificate
when issuing activation and verify the operator fingerprint separately.

## 4. Member administration (local CLI only)

Command prefix on the droplet:

```sh
sudo -u braid-wan /opt/intersignal-braid-wan/1.9.1/venv/bin/python \
  -m braid_client.wan_relay --state /var/lib/intersignal-braid-wan
```

Append `status` to see the public operator fingerprint and limits. Convey that
fingerprint to members through the established support channel. Publish it on a
trusted company page after verifying the production key, not from a test fixture.
Loss of an existing operator key fails closed; restore the original backup.

After independently checking the active Stripe subscription, append:

```text
member FM0001 --devices 2 --expires 2027-09-09T00:00:00Z
```

Use the REAL paid-through date, not this illustrative date. `member` updates
expiry/capacity but does not automatically resume a suspended membership. Default
operator limits are 2 identity keys, 1 GiB of metered relay payload bytes per UTC
month, and 16 MiB of temporarily retained packets. They are adjustable with
`--devices` (2-16), `--month-bytes`, and `--queue-bytes` (max 256 MiB). These are
engineering defaults, not new advertised subscription promises. Metering includes
card and envelope transfer payloads, not exact DigitalOcean billing (TLS/HTTP and
control-message overhead remain). Lowering capacity below active device count is
refused until surplus devices are explicitly revoked.

On EACH member rig: save its `.braidjoin` request via Away from home. Check the
request fingerprint against the member's intended device through support. Issue
one small activation file per device with the same generic installer:

```text
issue FM0001 --request /private/incoming/home.braidjoin \
  --out /private/outgoing/home.braidmember --relay https://relay.intersignal.org
```

Use `--ca /path/to/public-ca.pem` only for a deliberately configured private CA.
The enrollment token is random, stored hashed on the server, bound to the exact
Ed25519/X25519 keys, and expires after seven days. Deliver activation privately.
After registration, the client uses its own signing key, not the token. Reissuing
invalidates the previous invitation for that device. A public checkout/thank-you
URL is NOT payment proof. No Stripe webhook or automated billing was added.

Other subcommands:

```text
suspend FM0001
resume FM0001
revoke-device FM0001 FULL_DEVICE_SIGNING_FINGERPRINT
```

Suspension, expiry and device revocation gate new relay requests, polling,
responses and discovery. They do not disable LAN or erase local notes. Requests
already obtained by a rig may finish; no system can revoke plaintext already
received. Device limits count signing identities, not hardware attestation;
cloning a private profile is not a separately identifiable device. Never share
one profile/private key among members. Restore device keys from their private
backup rather than silently rotating them.

## 5. Controlled two-network test before fulfillment

Provision an internal one-week member, two real devices, harmless channel notes.
Use one home connection and one phone hotspot; disable their LAN path for the
WAN test. Follow docs/UAT_WAN.md. Verify payload opacity on the relay, actual
receiver receipts, remote model evidence, permissions, suspension/renewal,
restart and an interrupted result. A queued relay object is never acceptance.

Current delivery windows remain bounded by the original BRAD lifetime, up to
300 seconds. This is NOT a multi-day offline mailbox. Keep rigs awake and online.
Retained encrypted responses can be checked for roughly 24 hours. Test sleep and
expiry honestly. Do not increase signed TTLs just to get a test green.

## 6. Operations and rollback

Monitor systemd service health, disk free space, request failures, queue and usage
counters and host resource utilization. Start small; no throughput or multi-tenant
load certification is claimed. The server admits eight concurrent connections,
uses request deadlines and account quotas, and prunes expired queue records once
per minute while running. It cannot prevent all denial of service or preempt a
home GPU's arbitrary native inference call. Use ordinary provider/network
protections and an independently reviewed operational alerting setup.

Back up the operator key and SQLite store consistently, encrypted/access-controlled.
Do not ship database backups in support emails. A complete-profile user backup
also includes `wan/encryption.key`, not only the pre-upgrade desktop snapshot.

Rollback: disable/stop ONLY `braid-wan-19.service` and remove/revert ONLY its reviewed
proxy route. Preserve its state and key for recovery. Leave old relay services and
public 1.8.1 download untouched. Stop 1.9 before restoring a user's complete 1.8.1
profile backup. Do not run both versions against one live profile. No security
claim of atomic restoration spanning all files is made.

## External implementation references

- DigitalOcean SSH: https://docs.digitalocean.com/products/droplets/how-to/connect-with-ssh/
- Cloud firewall rules: https://docs.digitalocean.com/products/networking/firewalls/how-to/configure-rules/
- Caddy reverse proxy: https://caddyserver.com/docs/caddyfile/directives/reverse_proxy
- cryptography X25519: https://cryptography.io/en/latest/hazmat/primitives/asymmetric/x25519/
- cryptography AEAD: https://cryptography.io/en/latest/hazmat/primitives/aead/

These documents inform the deployment design; they do not establish that this
particular droplet has been configured or that the new protocol has been audited.
