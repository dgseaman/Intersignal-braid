#!/bin/sh
# READ ONLY. Run on the existing droplet; do not publish output with credentials.
set -eu
printf '\nBraid WAN preflight - read only\n'
date -u
uname -a
printf '\nExisting listeners (look carefully at 443, 8750, 8751 and 8765):\n'
ss -lntp || true
printf '\nRelated services (no configuration or secret file contents):\n'
systemctl list-units --type=service --all --no-pager | grep -Ei 'braid|relay|haproxy|caddy|nginx' || true
printf '\nRuntime:\n'
python3 --version
printf '\nResources:\n'
df -h /
free -h
printf '\nDo not replace an existing TLS passthrough listener with an HTTP proxy.\n'
printf 'The new service uses /braid/v1/ on HTTPS; old Jump Kit traffic is a different protocol.\n'
