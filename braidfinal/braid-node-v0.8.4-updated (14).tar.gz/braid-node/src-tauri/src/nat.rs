use std::net::{SocketAddr, UdpSocket, IpAddr, Ipv4Addr};
use std::time::{Duration, Instant};
use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PublicEndpointResult {
    pub attempted: bool,
    pub local_bind_addr: String,
    pub observed_public_endpoint: Option<String>,
    pub server_used: Option<String>,
    pub elapsed_ms: Option<u64>,
    pub error: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum NatReachability {
    Unknown,
    LocalOnly,
    PubliclyReachable,
    PortForwardLikelyRequired,
    SymmetricOrRestrictiveNatSuspected,
    RelayRecommended,
}

impl NatReachability {
    pub fn as_str(&self) -> &'static str {
        match self {
            NatReachability::Unknown => "Unknown",
            NatReachability::LocalOnly => "LocalOnly",
            NatReachability::PubliclyReachable => "PubliclyReachable",
            NatReachability::PortForwardLikelyRequired => "PortForwardLikelyRequired (direct UDP possible with router/NAT configuration)",
            NatReachability::SymmetricOrRestrictiveNatSuspected => "SymmetricOrRestrictiveNatSuspected",
            NatReachability::RelayRecommended => "RelayRecommended",
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReachabilityReport {
    pub local_endpoint: String,
    pub public_endpoint: Option<String>,
    pub nat_status: String,
    pub direct_udp_likely: bool,
    pub relay_recommended: bool,
    pub evidence: Vec<String>,
    pub warnings: Vec<String>,
}

/// Helper function to perform a minimal STUN binding query
pub fn query_stun(server: &str, timeout: Duration) -> Result<SocketAddr, String> {
    let socket = UdpSocket::bind("0.0.0.0:0").map_err(|e| e.to_string())?;
    socket.set_read_timeout(Some(timeout)).map_err(|e| e.to_string())?;
    socket.set_write_timeout(Some(timeout)).map_err(|e| e.to_string())?;

    let stun_addr = server.parse::<SocketAddr>()
        .or_else(|_| {
            use std::net::ToSocketAddrs;
            let mut addrs = server.to_socket_addrs().map_err(|e| e.to_string())?;
            addrs.next().ok_or_else(|| "Failed to resolve domain name".to_string())
        })?;

    // Message transaction ID (12 bytes)
    let transaction_id: [u8; 12] = [0x42, 0x72, 0x61, 0x69, 0x64, 0x4e, 0x41, 0x54, 0x54, 0x65, 0x73, 0x74];
    let mut request = [0u8; 20];
    request[0..2].copy_from_slice(&[0x00, 0x01]); // Binding Request
    request[2..4].copy_from_slice(&[0x00, 0x00]); // Message Length: 0
    request[4..8].copy_from_slice(&[0x21, 0x12, 0xA4, 0x42]); // Magic Cookie
    request[8..20].copy_from_slice(&transaction_id);

    socket.send_to(&request, stun_addr).map_err(|e| e.to_string())?;

    let mut buf = [0u8; 512];
    let (amt, _) = socket.recv_from(&mut buf).map_err(|e| e.to_string())?;

    if amt < 20 {
        return Err("Response too short".to_string());
    }

    let msg_type = u16::from_be_bytes([buf[0], buf[1]]);
    let msg_len = u16::from_be_bytes([buf[2], buf[3]]) as usize;
    let magic_cookie = u32::from_be_bytes([buf[4], buf[5], buf[6], buf[7]]);

    if msg_type != 0x0101 {
        return Err(format!("Not a Binding Response: type = {:#04x}", msg_type));
    }
    if magic_cookie != 0x2112A442 {
        return Err("Magic cookie mismatch".to_string());
    }
    if &buf[8..20] != &transaction_id {
        return Err("Transaction ID mismatch".to_string());
    }

    let mut pos = 20;
    let end = 20 + msg_len;
    if end > amt {
        return Err("Declared message length exceeds bytes received".to_string());
    }

    while pos + 4 <= end {
        let attr_type = u16::from_be_bytes([buf[pos], buf[pos+1]]);
        let attr_len = u16::from_be_bytes([buf[pos+2], buf[pos+3]]) as usize;
        pos += 4;

        if pos + attr_len > end {
            return Err("Attribute overflow".to_string());
        }

        if attr_type == 0x0001 { // MAPPED-ADDRESS
            if attr_len >= 8 {
                let family = buf[pos + 1];
                if family == 0x01 { // IPv4
                    let port = u16::from_be_bytes([buf[pos+2], buf[pos+3]]);
                    let ip = Ipv4Addr::new(buf[pos+4], buf[pos+5], buf[pos+6], buf[pos+7]);
                    return Ok(SocketAddr::new(IpAddr::V4(ip), port));
                }
            }
        } else if attr_type == 0x0020 { // XOR-MAPPED-ADDRESS
            if attr_len >= 8 {
                let family = buf[pos + 1];
                if family == 0x01 { // IPv4
                    let xor_port = u16::from_be_bytes([buf[pos+2], buf[pos+3]]);
                    let port = xor_port ^ 0x2112;
                    let xor_ip = [buf[pos+4], buf[pos+5], buf[pos+6], buf[pos+7]];
                    let cookie_bytes = [0x21, 0x12, 0xA4, 0x42];
                    let ip = Ipv4Addr::new(
                        xor_ip[0] ^ cookie_bytes[0],
                        xor_ip[1] ^ cookie_bytes[1],
                        xor_ip[2] ^ cookie_bytes[2],
                        xor_ip[3] ^ cookie_bytes[3],
                    );
                    return Ok(SocketAddr::new(IpAddr::V4(ip), port));
                }
            }
        }

        let padding = (4 - (attr_len % 4)) % 4;
        pos += attr_len + padding;
    }

    Err("No mapped address found in response attributes".to_string())
}

/// Helper function to detect RFC1918 private IPv4 ranges
pub fn is_rfc1918(ip: &IpAddr) -> bool {
    match ip {
        IpAddr::V4(ipv4) => {
            let octets = ipv4.octets();
            octets[0] == 10
                || (octets[0] == 172 && octets[1] >= 16 && octets[1] <= 31)
                || (octets[0] == 192 && octets[1] == 168)
        }
        _ => false,
    }
}

/// Honest classification of NAT reachability based on evidence
pub fn classify_nat(
    local_bind: SocketAddr,
    observed_public: Option<SocketAddr>,
    evidence: &mut Vec<String>,
    warnings: &mut Vec<String>,
) -> NatReachability {
    let Some(public_addr) = observed_public else {
        evidence.push("Could not discover public endpoint via STUN.".to_string());
        warnings.push("Offline, behind a highly restrictive symmetric firewall, or all STUN servers timed out.".to_string());
        return NatReachability::Unknown;
    };

    let local_ip = local_bind.ip();
    let public_ip = public_addr.ip();

    evidence.push(format!("Local bind IP: {}, observed public IP: {}", local_ip, public_ip));

    if local_ip.is_loopback() {
        evidence.push("Local bind address is localhost loopback.".to_string());
        return NatReachability::LocalOnly;
    }

    let is_private = is_rfc1918(&local_ip);

    if !is_private && local_ip == public_ip {
        evidence.push("Local bind address equals public observed IP address.".to_string());
        if local_bind.port() == public_addr.port() {
            evidence.push("Port mapping is 1:1 direct (no translation). Direct connection is highly likely.".to_string());
            return NatReachability::PubliclyReachable;
        } else {
            evidence.push("Port was mapped to a different public port, but direct IP is public.".to_string());
            return NatReachability::PortForwardLikelyRequired;
        }
    }

    if is_private {
        evidence.push("Local bind address is a private RFC1918 IPv4 address, confirming presence of NAT.".to_string());
        if local_bind.port() == public_addr.port() {
            evidence.push("Preserve-Port NAT mapping suspected: local port matches observed public port.".to_string());
            return NatReachability::PortForwardLikelyRequired;
        } else {
            evidence.push("Port translation occurred: local port does not match observed public port.".to_string());
            return NatReachability::SymmetricOrRestrictiveNatSuspected;
        }
    }

    NatReachability::Unknown
}
