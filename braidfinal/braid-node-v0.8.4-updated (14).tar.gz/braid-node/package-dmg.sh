#!/bin/bash
set -e

echo "====================================================================="
echo "        BRAID TENDRIL v0.8.4-alpha: NATIVE macOS DMG BUILDER        "
echo "====================================================================="

# 1. Environment pre-flight checks
echo "[CHECK] Verifying Node.js and NPM environments..."
if ! command -v npm &> /dev/null; then
    echo "Error: NPM is not installed. Please install Node.js/NPM before packaging."
    exit 1
fi
echo "✓ Node.js/NPM is available: $(node --version) / npm v$(npm --version)"

echo "[CHECK] Verifying Rust and Cargo compiler toolchains..."
if ! command -v cargo &> /dev/null; then
    echo "Error: Cargo is not installed. Please install Rustup and Cargo toolchains."
    exit 1
fi
echo "✓ Cargo compiler is available: $(cargo --version)"

# 2. Dependency resolution
if [ ! -d "node_modules" ]; then
    echo "[RESOLVE] Installing frontend React/Vite dependencies..."
    npm ci
else
    echo "✓ Frontend node_modules already resolved."
fi

# 3. Compile static React interface
echo "[COMPILE] Packaging static web visualizer bundle..."
npm run build

# 4. Native macOS DMG Compile
echo "[BUILD] Commencing native macOS DMG compilation via Tauri..."
npm run tauri build -- --bundle dmg

# 5. Extract output package
DMG_SOURCE="src-tauri/target/release/bundle/dmg/braid-node_0.8.4-alpha_aarch64.dmg"
DMG_TARGET="Braid-Tendril-v0.8.4-alpha-aarch64.dmg"

if [ -f "$DMG_SOURCE" ]; then
    cp "$DMG_SOURCE" "$DMG_TARGET"
    echo "====================================================================="
    echo " [SUCCESS] Braid native macOS DMG package generated successfully!"
    echo " Package Location: ./$DMG_TARGET"
    echo " SHA-256 Checksum: $(shasum -a 256 "$DMG_TARGET" | cut -d' ' -f1)"
    echo "====================================================================="
else
    echo "Error: DMG compilation succeeded but output package was not found at $DMG_SOURCE."
    exit 1
fi
