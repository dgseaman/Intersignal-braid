# Out-of-the-Box 384d Vector Transfer Spec

Braid Tendril v0.8.4 supports real, end-to-end 384-dimensional vector transfer over UDP. 

## Technical Details

- **Dimension Count**: Exactly 384 dimensions.
- **Encoding Formats**:
  - `raw_f32`: Standard IEEE-754 single-precision float coordinates. Total packet size stays under 1738 bytes.
  - `qint8`: 8-bit quantized signed integers using min-max calibration to save up to 1,147 bytes over raw_f32.

## Privacy & Sensitivity Notice

- A 384d vector is not automatically human-readable text, but it can still encode meaningful state. Treat vectors as sensitive unless you know how they were generated.
- Braid does not make unsafe data safe merely by vectorizing it. Do not vectorize sensitive or confidential data without understanding your model's information disclosure characteristics.
