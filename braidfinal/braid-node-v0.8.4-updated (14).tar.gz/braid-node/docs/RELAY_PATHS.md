# Zero-Trust Relay Paths & MTU Safety

## Inner-Envelope Opacity

Relay nodes function strictly at the network forwarding level. They act as transit nodes and do not need to understand or decode the inner state-drift vector payload. They only validate:
1. Outer envelope signature.
2. Relay frame TTL.
3. Routing headers.
4. Trust/admission status of forwarding peer.

The inner state-drift envelope remains completely opaque to transit relays.

## MTU Limits and Safety

Relay frames introduce extra routing overhead (such as final recipient NodeId, origin sender, and signatures). If raw f32 transmission is selected, the outer frame size could exceed the strict 2048-byte UDP ceiling.

To guarantee delivery without fragmentation:
- **Default Encoding**: Braid Tendril v0.8.4 enforces `qint8` for all relay routes by default.
- **Size Gating**: Raw f32 is permitted over relay only if the serialized size strictly satisfies `size <= MAX_PACKET_SIZE`. If it exceeds the ceiling, a clear transmission error is raised.
