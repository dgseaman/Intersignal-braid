# Braid Tendril v0.8.4-alpha Privacy Disclosure

## Core Privacy Statement
Braid Tendril does not automatically share files, documents, chats, browser history, API keys, private keys, or personal data.

Network mode may share protocol-level data required for peer operation: node id, public signing key, UDP endpoint candidates, discovery probes, session handshakes, route metadata, signed protocol envelopes, relay headers, capabilities, timing metadata, and user-generated or app-generated 384-dimensional state vectors.

A 384d vector is not plain text, but it can still encode meaningful state. Treat vectors as sensitive unless you know exactly how they were generated.

Braid does not make unsafe data safe merely by vectorizing it.

## Network Isolation Guardrails
- **No Background Scanning**: Braid Tendril does not perform blind IP scans or auto-expansion of peer networks on the public internet.
- **No Telemetry**: No background reporting or telemetry is sent to any centralized server. All public endpoint discoveries (STUN) must be initiated explicitly via user-driven UI action and operate with no account, no paid API, and no central Braid service.
- **Diagnostics Security**: The diagnostic bundle generated via the "Copy Diagnostics" button is fully sanitized, containing only route state, session state, and metadata. No private keys, seed phrases, or raw vector coordinates are ever exposed.
