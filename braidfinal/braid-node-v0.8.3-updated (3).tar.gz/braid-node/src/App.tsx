import React, { useState, useEffect } from "react";
import { invoke } from "@tauri-apps/api/tauri";
import { listen } from "@tauri-apps/api/event";

interface UdpPacketPayload {
  node_id: string;
  timestamp: number;
  sequence_id: number;
  latent_vector: number[];
  sender_address: string;
  byte_size: number;
}

interface NodeInfo {
  node_id: string;
  local_address: string;
  software_version: string;
  wire_version: number;
}

interface StreamResult {
  sent_count: number;
  failures: string[];
}

export default function App() {
  const [nodeInfo, setNodeInfo] = useState<NodeInfo | null>(null);
  const [peers, setPeers] = useState<string[]>([]);
  const [receivedPackets, setReceivedPackets] = useState<UdpPacketPayload[]>([]);
  const [vector, setVector] = useState<number[]>([]);
  const [vectorDim] = useState<number>(384);
  const [isBroadcasting, setIsBroadcasting] = useState<boolean>(false);
  const [lastBroadcastResult, setLastBroadcastResult] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"visualizer" | "raw">("visualizer");
  const [activeView, setActiveView] = useState<"dashboard" | "lab">("dashboard");

  // Connection Lab States
  const [networkStatus, setNetworkStatus] = useState<any>(null);
  const [routes, setRoutes] = useState<any[]>([]);
  const [sessions, setSessions] = useState<any[]>([]);
  const [receipts, setReceipts] = useState<any[]>([]);
  const [diagnosticsResult, setDiagnosticsResult] = useState<string | null>(null);

  // Manual peer form states
  const [manualLabel, setManualLabel] = useState("");
  const [manualEndpoint, setManualEndpoint] = useState("");
  const [manualNodeId, setManualNodeId] = useState("");
  const [manualTrustMode, setManualTrustMode] = useState("ManualTrusted");
  const [addPeerResult, setAddPeerResult] = useState<any>(null);

  // Probe form states
  const [probeEndpoint, setProbeEndpoint] = useState("");
  const [probeResult, setProbeResult] = useState<any>(null);

  // Send test vector states
  const [sendTargetNodeId, setSendTargetNodeId] = useState("");
  const [sendEncoding, setSendEncoding] = useState("raw_f32");
  const [sendSeed, setSendSeed] = useState("");
  const [sendResult, setSendResult] = useState<any>(null);

  // Fetch initial info
  useEffect(() => {
    async function loadData() {
      try {
        const info = await invoke<NodeInfo>("get_node_info");
        setNodeInfo(info);
        const peerList = await invoke<string[]>("get_peers");
        setPeers(peerList);
      } catch (err) {
        console.error("Failed to load node data:", err);
      }
    }
    loadData();
    generateRandomVector(vectorDim);
  }, []);

  // Poll for dynamically discovered peers in the background
  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const peerList = await invoke<string[]>("get_peers");
        setPeers(peerList);
      } catch (err) {
        console.error("Failed to refresh peers:", err);
      }
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  // Listen for background UDP packets
  useEffect(() => {
    let unlistenFn: (() => void) | null = null;

    async function setupListener() {
      try {
        const unlisten = await listen<UdpPacketPayload>("udp-packet-received", (event) => {
          setReceivedPackets((prev) => {
            const updated = [event.payload, ...prev];
            return updated.slice(0, 100); // keep last 100 packets
          });
        });
        unlistenFn = unlisten;
      } catch (err) {
        console.error("Failed to bind Tauri event listener:", err);
      }
    }

    setupListener();

    return () => {
      if (unlistenFn) {
        unlistenFn();
      }
    };
  }, []);

  // Listen for vector-receipt event
  useEffect(() => {
    let unlistenFn: (() => void) | null = null;

    async function setupReceiptListener() {
      try {
        const unlisten = await listen<any>("vector-receipt", (event) => {
          setReceipts((prev) => {
            const updated = [event.payload, ...prev];
            return updated.slice(0, 50);
          });
        });
        unlistenFn = unlisten;
      } catch (err) {
        console.error("Failed to bind vector-receipt listener:", err);
      }
    }

    setupReceiptListener();

    return () => {
      if (unlistenFn) {
        unlistenFn();
      }
    };
  }, []);

  const refreshLabState = async () => {
    try {
      const rList = await invoke<any[]>("list_routes");
      setRoutes(rList);
      const sList = await invoke<any[]>("list_sessions");
      setSessions(sList);
      const net = await invoke<any>("get_network_status");
      setNetworkStatus(net);
    } catch (err) {
      console.error("Failed to refresh lab data:", err);
    }
  };

  useEffect(() => {
    if (activeView === "lab") {
      refreshLabState();
      const interval = setInterval(refreshLabState, 1500);
      return () => clearInterval(interval);
    }
  }, [activeView]);

  const generateRandomVector = (dim: number) => {
    const newVec = Array.from({ length: dim }, () => {
      return parseFloat((Math.random() * 2 - 1).toFixed(4));
    });
    setVector(newVec);
  };

  const handleStreamDrift = async () => {
    setIsBroadcasting(true);
    setLastBroadcastResult(null);
    try {
      const result = await invoke<StreamResult>("stream_state_drift", {
        latentVector: vector,
      });
      if (result.sent_count > 0) {
        setLastBroadcastResult(
          `Successfully broadcast state drift directly to ${result.sent_count} active peer(s).`
        );
      } else {
        setLastBroadcastResult(
          `Drift queued. Awaiting routebound session Ready commit...`
        );
      }
    } catch (err) {
      setLastBroadcastResult(`Broadcast failed: ${err}`);
    } finally {
      setIsBroadcasting(false);
    }
  };

  const handleAddManualPeer = async () => {
    setAddPeerResult(null);
    try {
      const res = await invoke<any>("add_manual_peer", {
        label: manualLabel,
        endpoint: manualEndpoint,
        nodeId: manualNodeId ? manualNodeId : null,
        trustMode: manualTrustMode,
      });
      setAddPeerResult(res);
      refreshLabState();
    } catch (err) {
      setAddPeerResult({ accepted: false, message: `Error: ${err}` });
    }
  };

  const handleProbePeer = async () => {
    setProbeResult(null);
    try {
      const res = await invoke<any>("probe_peer", {
        endpoint: probeEndpoint,
      });
      setProbeResult(res);
      refreshLabState();
    } catch (err) {
      setProbeResult({ sent: false, error: `Error: ${err}` });
    }
  };

  const handleSendTestVector = async () => {
    setSendResult(null);
    try {
      const res = await invoke<any>("send_test_vector", {
        targetNodeId: sendTargetNodeId ? sendTargetNodeId : null,
        encodingPreference: sendEncoding ? sendEncoding : null,
        seed: sendSeed ? sendSeed : null,
      });
      setSendResult(res);
      refreshLabState();
    } catch (err) {
      setSendResult({ attempted: false, error: `Error: ${err}` });
    }
  };

  const copyDiagnostics = async () => {
    try {
      const rList = await invoke<any[]>("list_routes");
      const sList = await invoke<any[]>("list_sessions");
      const net = await invoke<any>("get_network_status");
      const bundle = {
        version: "0.8.3-alpha",
        node_id: nodeInfo?.node_id || "",
        routes: rList,
        sessions: sList,
        last_send_result: sendResult,
        last_receipts: receipts,
        network_status: net,
      };
      await navigator.clipboard.writeText(JSON.stringify(bundle, null, 2));
      setDiagnosticsResult("Diagnostics copied to clipboard!");
      setTimeout(() => setDiagnosticsResult(null), 3000);
    } catch (err) {
      setDiagnosticsResult(`Failed to copy: ${err}`);
      setTimeout(() => setDiagnosticsResult(null), 3000);
    }
  };

  // Heatmap rendering utility for latent vector
  const renderHeatmap = (vec: number[], height: number = 80) => {
    if (vec.length === 0) return null;
    return (
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "1px",
          background: "#161922",
          padding: "4px",
          borderRadius: "4px",
          maxHeight: `${height}px`,
          overflowY: "auto",
        }}
      >
        {vec.map((val, idx) => {
          const intensity = Math.min(Math.max((Math.abs(val)), 0), 1);
          const color =
            val >= 0
              ? `rgba(57, 219, 219, ${intensity})`  // Teal for positive
              : `rgba(235, 64, 52, ${intensity})`;   // Orange/Red for negative

          return (
            <div
              key={idx}
              title={`Index ${idx}: ${val.toFixed(4)}`}
              style={{
                width: "8px",
                height: "8px",
                backgroundColor: intensity < 0.05 ? "#242835" : color,
                borderRadius: "1px",
              }}
            />
          );
        })}
      </div>
    );
  };

  const getLatency = (timestamp: number): string => {
    const latencyMs = Date.now() - timestamp;
    if (!Number.isFinite(latencyMs)) return "unknown";
    if (latencyMs < 0) return "clock skew";
    if (latencyMs < 1000) {
      return `${latencyMs} ms`;
    }
    return `${(latencyMs / 1000).toFixed(1)} s`;
  };

  const activeUnicastPeers = peers.filter((p) => !p.includes("255.255"));
  const uniqueNodes = new Set(receivedPackets.map((p) => p.node_id));

  return (
    <div style={styles.container}>
      {/* HEADER */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.glowDot}></div>
          <h1 style={styles.title}>BRAID TENDRIL v0.8.3-alpha</h1>
          <span style={styles.version}>v0.8.3-alpha</span>
        </div>

        {/* View Toggles */}
        <div style={{ display: "flex", gap: "10px", margin: "0 20px" }}>
          <button
            onClick={() => setActiveView("dashboard")}
            style={activeView === "dashboard" ? styles.viewBtnActive : styles.viewBtn}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveView("lab")}
            style={activeView === "lab" ? styles.viewBtnActive : styles.viewBtn}
          >
            Connection Lab
          </button>
        </div>

        <div style={styles.headerRight}>
          {nodeInfo ? (
            <div style={styles.nodeMeta}>
              <span style={styles.label}>LOCAL PORT:</span>
              <code style={styles.code}>{nodeInfo.local_address.split(":").pop()}</code>
              <span style={{ ...styles.label, marginLeft: "15px" }}>NODE ID:</span>
              <code style={styles.code}>{nodeInfo.node_id.substring(0, 16)}...</code>
            </div>
          ) : (
            <span style={styles.connecting}>Initializing UDP Socket...</span>
          )}
        </div>
      </header>

      {/* DASHBOARD VIEW */}
      {activeView === "dashboard" && (
        <div style={styles.dashboard}>
          {/* LEFT COLUMN: Zero-Config Active Mesh Map */}
          <section style={styles.card}>
            <h2 style={styles.cardTitle}>Verified WAN Peer Sessions</h2>
            <div style={styles.cardContent}>
              <div style={styles.peerListHeader}>
                <span>Handshaked Peering Mesh ({activeUnicastPeers.length})</span>
              </div>
              
              <div style={styles.peerList}>
                {activeUnicastPeers.length === 0 ? (
                  <div style={styles.emptyMeshState}>
                    <div style={styles.radarRing}></div>
                    <div style={{ marginTop: "12px", color: "#8a94a6", fontWeight: "600" }}>
                      Awaiting handshaked sessions...
                    </div>
                    <div style={{ fontSize: "11px", color: "#56617a", padding: "0 10px", marginTop: "4px" }}>
                      Broadcasting rendezvous hello. Set trusted peer NodeId or use --open-dev flag to auto-verify.
                    </div>
                  </div>
                ) : (
                  activeUnicastPeers.map((peer, idx) => (
                    <div key={idx} style={peerRecordStyle}>
                      <div style={{ fontWeight: "bold" }}>Peer {idx + 1}</div>
                      <div style={{ fontSize: "11px", color: "#888" }}>Endpoint: {peer}</div>
                      <div style={{ fontSize: "11px", color: "#4ade80" }}>● READY FOR TRANSFER</div>
                    </div>
                  ))
                )}
              </div>

              <div style={styles.note}>
                <strong>WAN-Native Discovery:</strong> Braid Tendril v0.8.3-alpha implements NodeId-first routing with signed-presence rendezvous. Sockets are completely abstracted; sessions are verified prior to exchanging state drift.
              </div>
            </div>
          </section>

          {/* MIDDLE COLUMN: State Generator */}
          <section style={styles.card}>
            <div style={styles.cardHeaderWithControls}>
              <h2 style={styles.cardTitle}>State Drift Generator</h2>
              <div style={styles.dimensionSelector}>
                <span style={styles.miniLabel}>DIM:</span>
                <select disabled style={styles.select}>
                  <option value="384">384 f32 (DeepBlend)</option>
                </select>
              </div>
            </div>

            <div style={styles.cardContent}>
              <div style={styles.tabHeader}>
                <button
                  style={activeTab === "visualizer" ? styles.tabActive : styles.tab}
                  onClick={() => setActiveTab("visualizer")}
                >
                  Latent Heatmap
                </button>
                <button
                  style={activeTab === "raw" ? styles.tabActive : styles.tab}
                  onClick={() => setActiveTab("raw")}
                >
                  Raw f32 Stream
                </button>
              </div>

              <div style={styles.vectorContainer}>
                {activeTab === "visualizer" ? (
                  <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                    <div style={styles.heatmapLabel}>
                      Each block represents a dimensional f32 coefficient [-1.0, 1.0]. Teal is positive, red is negative, slate is baseline (0.0).
                    </div>
                    {renderHeatmap(vector, 180)}
                  </div>
                ) : (
                  <textarea
                    readOnly
                    value={JSON.stringify(vector)}
                    style={styles.textarea}
                  />
                )}
              </div>

              <div style={styles.actionRow}>
                <button
                  onClick={() => generateRandomVector(vectorDim)}
                  style={styles.btnSecondary}
                >
                  Randomize State
                </button>
                <button
                  onClick={handleStreamDrift}
                  disabled={isBroadcasting}
                  style={styles.btnPrimary}
                >
                  {isBroadcasting ? "Broadcasting..." : "Stream State Drift"}
                </button>
              </div>

              {lastBroadcastResult && (
                <div
                  style={
                    lastBroadcastResult.includes("failed")
                      ? styles.statusError
                      : styles.statusSuccess
                  }
                >
                  {lastBroadcastResult}
                </div>
              )}
            </div>
          </section>

          {/* RIGHT COLUMN: Real-time Ingestion Feed */}
          <section style={styles.card}>
            <h2 style={styles.cardTitle}>Verified Ingestion Feed</h2>
            <div style={styles.cardContent}>
              <div style={styles.feedHeader}>
                <div style={styles.statMini}>
                  <span style={styles.statMiniValue}>{receivedPackets.length}</span>
                  <span style={styles.statMiniLabel}>Packets Received</span>
                </div>
                <div style={styles.statMini}>
                  <span style={styles.statMiniValue}>{uniqueNodes.size}</span>
                  <span style={styles.statMiniLabel}>Active Nodes</span>
                </div>
              </div>

              <div style={styles.feed}>
                {receivedPackets.length === 0 ? (
                  <div style={styles.feedEmpty}>
                    <div style={styles.radarGlow}></div>
                    <span>Awaiting cryptographically signed state drift...</span>
                  </div>
                ) : (
                  receivedPackets.map((packet, idx) => {
                    return (
                      <div key={idx} style={styles.feedItem}>
                        <div style={styles.feedItemHeader}>
                          <span style={styles.nodeIdBadge}>
                            Node: {packet.node_id.substring(0, 12)}
                          </span>
                          <span style={styles.latencyBadge}>
                            Latency: {getLatency(packet.timestamp)}
                          </span>
                        </div>

                        <div style={styles.packetDetails}>
                          <div>
                            <strong>From:</strong> <code>{packet.sender_address}</code>
                          </div>
                          <div style={{ color: "#39dbdb", fontWeight: "bold", fontSize: "10px", marginTop: "2px" }}>
                            🔒 CRYPTO SIGNATURE VERIFIED (ED25519)
                          </div>
                          <div style={{ color: "#39dbdb", fontWeight: "bold", fontSize: "10px", marginTop: "2px" }}>
                            📦 ROUTE-BOUND SECURE WAN SESSION
                          </div>
                        </div>

                        <div style={{ marginTop: "6px" }}>
                          {renderHeatmap(packet.latent_vector, 50)}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </section>
        </div>
      )}

      {/* CONNECTION LAB VIEW */}
      {activeView === "lab" && (
        <div style={styles.labContainer}>
          {/* LEFT FORM BLOCK */}
          <div style={{ display: "flex", flexDirection: "column", gap: "16px", overflowY: "auto", paddingRight: "8px" }}>
            
            {/* ADD MANUAL PEER */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Add Manual WAN Peer</h3>
              <div style={styles.formContent}>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Label:</label>
                  <input
                    type="text"
                    value={manualLabel}
                    onChange={(e) => setManualLabel(e.target.value)}
                    placeholder="e.g. Seed Node"
                    style={styles.input}
                  />
                </div>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Endpoint (SocketAddr):</label>
                  <input
                    type="text"
                    value={manualEndpoint}
                    onChange={(e) => setManualEndpoint(e.target.value)}
                    placeholder="e.g. 127.0.0.1:12001"
                    style={styles.input}
                  />
                </div>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Node ID (Optional Hex):</label>
                  <input
                    type="text"
                    value={manualNodeId}
                    onChange={(e) => setManualNodeId(e.target.value)}
                    placeholder="64-char hex target node id"
                    style={styles.input}
                  />
                </div>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Trust Mode:</label>
                  <select
                    value={manualTrustMode}
                    onChange={(e) => setManualTrustMode(e.target.value)}
                    style={styles.selectField}
                  >
                    <option value="ManualTrusted">Manual Trusted</option>
                    <option value="PendingTrust">Pending Trust</option>
                    <option value="DiscoveryOnly">Discovery Only</option>
                  </select>
                </div>
                <button onClick={handleAddManualPeer} style={styles.btnPrimary}>
                  Add Manual Peer
                </button>
                {addPeerResult && (
                  <div style={addPeerResult.accepted ? styles.statusSuccess : styles.statusError}>
                    {addPeerResult.message || (addPeerResult.accepted ? "Peer accepted" : "Peer rejected")}
                  </div>
                )}
              </div>
            </section>

            {/* PROBE ENDPOINT */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Probe WAN Endpoint</h3>
              <div style={styles.formContent}>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Endpoint IP:Port:</label>
                  <input
                    type="text"
                    value={probeEndpoint}
                    onChange={(e) => setProbeEndpoint(e.target.value)}
                    placeholder="e.g. 127.0.0.1:12001"
                    style={styles.input}
                  />
                </div>
                <button onClick={handleProbePeer} style={styles.btnSecondary}>
                  Probe Peer
                </button>
                {probeResult && (
                  <div style={probeResult.response_received ? styles.statusSuccess : styles.statusError}>
                    <div><strong>Sent:</strong> {probeResult.sent ? "Yes" : "No"}</div>
                    <div><strong>Packet Size:</strong> {probeResult.packet_size} bytes</div>
                    <div><strong>Elapsed:</strong> {probeResult.elapsed_ms !== null ? `${probeResult.elapsed_ms} ms` : "timeout"}</div>
                    <div><strong>Response Received:</strong> {probeResult.response_received ? "Yes" : "No"}</div>
                    <div><strong>Route State:</strong> {probeResult.route_state}</div>
                    {probeResult.error && <div style={{ color: "#ff6b6b" }}>Error: {probeResult.error}</div>}
                  </div>
                )}
              </div>
            </section>

            {/* SEND TEST VECTOR */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Send Test 384d Vector</h3>
              <div style={styles.formContent}>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Target Peer Node ID:</label>
                  <input
                    type="text"
                    value={sendTargetNodeId}
                    onChange={(e) => setSendTargetNodeId(e.target.value)}
                    placeholder="Target Node ID (leave empty for first available)"
                    style={styles.input}
                  />
                </div>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Encoding Preference:</label>
                  <select
                    value={sendEncoding}
                    onChange={(e) => setSendEncoding(e.target.value)}
                    style={styles.selectField}
                  >
                    <option value="raw_f32">Raw F32</option>
                    <option value="qint8">QINT8 (8-bit Quantized)</option>
                  </select>
                </div>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Deterministic RNG Seed:</label>
                  <input
                    type="text"
                    value={sendSeed}
                    onChange={(e) => setSendSeed(e.target.value)}
                    placeholder="RNG seed string for vector values"
                    style={styles.input}
                  />
                </div>
                <button onClick={handleSendTestVector} style={styles.btnPrimary}>
                  Send Test Vector
                </button>
                {sendResult && (
                  <div style={sendResult.attempted ? styles.statusSuccess : styles.statusError}>
                    <div><strong>Attempted:</strong> {sendResult.attempted ? "Yes" : "No"}</div>
                    <div><strong>Sent Count:</strong> {sendResult.sent_count}</div>
                    {sendResult.target_node_id && <div><strong>Recipient:</strong> {sendResult.target_node_id.substring(0, 16)}...</div>}
                    {sendResult.route_kind && <div><strong>Transport Path:</strong> {sendResult.route_kind}</div>}
                    <div><strong>Encoding used:</strong> {sendResult.encoding}</div>
                    <div><strong>Vector Hash:</strong> {sendResult.vector_sha256.substring(0, 16)}...</div>
                    <div><strong>Packet Size:</strong> {sendResult.packet_size} bytes</div>
                    {sendResult.error && <div style={{ color: "#ff6b6b" }}>Status/Skip Reason: {sendResult.error}</div>}
                  </div>
                )}
              </div>
            </section>
          </div>

          {/* RIGHT STATE TABLES AND MONITORS */}
          <div style={{ display: "flex", flexDirection: "column", gap: "16px", overflowY: "auto" }}>
            
            {/* NETWORK STATUS CARD */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Network Diagnostics</h3>
              <div style={styles.formContent}>
                {networkStatus ? (
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", fontSize: "12px" }}>
                    <div><strong>Bind Address:</strong> <code>{networkStatus.local_bind_addr}</code></div>
                    <div><strong>Local UDP Port:</strong> <code>{networkStatus.local_udp_port}</code></div>
                    <div><strong>NAT Status:</strong> <code style={{ color: "#ffad47" }}>{networkStatus.nat_status}</code></div>
                    <div><strong>Relay Connected:</strong> <code style={{ color: networkStatus.relay_available ? "#4ade80" : "#ff6b6b" }}>{networkStatus.relay_available ? "Yes" : "No"}</code></div>
                    <div style={{ gridColumn: "span 2" }}><strong>WAN Support Status:</strong> <div style={{ color: "#8a94a6", fontSize: "11px" }}>{networkStatus.direct_wan_supported}</div></div>
                  </div>
                ) : (
                  <div>Gathering network reachability stats...</div>
                )}
                
                <div style={{ display: "flex", alignItems: "center", gap: "10px", marginTop: "15px" }}>
                  <button onClick={copyDiagnostics} style={styles.btnSecondary}>Copy Diagnostics</button>
                  {diagnosticsResult && <span style={{ color: "#39dbdb", fontSize: "11px" }}>{diagnosticsResult}</span>}
                </div>
                
                <div style={{ fontSize: "11px", color: "#56617a", borderTop: "1px solid #1c202d", paddingTop: "8px", marginTop: "10px" }}>
                  <strong>NAT/Router Honest Disclosure:</strong> Direct WAN peer mode requires reachable UDP ports or compatible NAT/router configuration. If direct UDP is unavailable, use a relay route.
                </div>
              </div>
            </section>

            {/* ROUTE TABLE */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Active Routes Engine</h3>
              <div style={styles.formContent}>
                {routes.length === 0 ? (
                  <div style={{ color: "#56617a", fontSize: "12px" }}>No ready peers yet</div>
                ) : (
                  <table style={styles.table}>
                    <thead>
                      <tr>
                        <th style={styles.th}>Peer ID</th>
                        <th style={styles.th}>Endpoint</th>
                        <th style={styles.th}>Kind</th>
                        <th style={styles.th}>State</th>
                        <th style={styles.th}>Latency</th>
                        <th style={styles.th}>Encoding</th>
                      </tr>
                    </thead>
                    <tbody>
                      {routes.map((r, i) => (
                        <tr key={i} style={styles.tr}>
                          <td style={styles.td}><code>{r.peer_node_id.substring(0, 8)}...</code></td>
                          <td style={styles.td}><code>{r.endpoint}</code></td>
                          <td style={styles.itemBadge}>{r.route_kind}</td>
                          <td style={{ ...styles.td, color: r.verified ? "#4ade80" : "#ffad46" }}>{r.route_state}</td>
                          <td style={styles.td}>{r.latency_ms ? `${r.latency_ms}ms` : "N/A"}</td>
                          <td style={styles.td}>{r.preferred_vector_encoding}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </section>

            {/* SESSION TABLE */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Secure Session Handshakes</h3>
              <div style={styles.cardContent}>
                {sessions.length === 0 ? (
                  <div style={{ color: "#56617a", fontSize: "12px", padding: "10px 16px" }}>No sessions verified yet</div>
                ) : (
                  <table style={{ ...styles.table, width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                      <tr>
                        <th style={styles.th}>Peer ID</th>
                        <th style={styles.th}>Session ID</th>
                        <th style={styles.th}>State</th>
                        <th style={styles.th}>Capabilities</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sessions.map((s, i) => (
                        <tr key={i} style={styles.tr}>
                          <td style={styles.td}><code>{s.peer_node_id.substring(0, 8)}...</code></td>
                          <td style={styles.td}><code>{s.session_id.substring(0, 8)}...</code></td>
                          <td style={{ ...styles.td, color: s.ready_for_state_drift ? "#4ade80" : "#ffad46" }}>{s.state}</td>
                          <td style={styles.td}>{s.capabilities.join(", ")}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </section>

            {/* VECTOR RECEIPTS */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Vector Receipt Logs</h3>
              <div style={styles.cardContent}>
                {receipts.length === 0 ? (
                  <div style={{ color: "#56617a", fontSize: "12px", padding: "10px 16px" }}>Awaiting first received 384d vector receipt...</div>
                ) : (
                  <div style={{ maxHeight: "250px", overflowY: "auto", padding: "0 16px" }}>
                    {receipts.map((rec, idx) => (
                      <details key={idx} style={receiptStyle}>
                        <summary style={{ cursor: "pointer", fontWeight: "bold", fontSize: "12px", color: "#39dbdb" }}>
                          📥 Receipt: {rec.from_node_id.substring(0, 12)}... ({rec.encoding}) - {getLatency(rec.received_at_ms)} ago
                        </summary>
                        <div style={{ padding: "8px 10px", fontSize: "11px", color: "#8a94a6", background: "#0a0b0f", marginTop: "4px", borderRadius: "4px" }}>
                          <div><strong>From:</strong> <code>{rec.from_node_id}</code></div>
                          <div><strong>Session:</strong> <code>{rec.session_id}</code></div>
                          <div><strong>Path:</strong> <code>{rec.route_kind} {rec.relay_used ? "(relayed)" : "(direct)"}</code></div>
                          <div><strong>Dimension:</strong> {rec.dimension}</div>
                          <div><strong>Packet Size:</strong> {rec.packet_size} bytes</div>
                          <div><strong>SHA-256:</strong> <code>{rec.vector_sha256}</code></div>
                        </div>
                      </details>
                    ))}
                  </div>
                )}
              </div>
            </section>
          </div>
        </div>
      )}

      {/* FOOTER STATS */}
      <footer style={styles.footer}>
        <div style={styles.footerBlock}>
          <span>PROTOCOL:</span>
          <strong>IMTP Wire Spec v8 (WAN Pathfinder Active)</strong>
        </div>
        <div style={styles.footerBlock}>
          <span>CRYPTO:</span>
          <strong>Handshaked Session Keys</strong>
        </div>
        <div style={styles.footerBlock}>
          <span>STATUS:</span>
          <span style={{ color: "#39dbdb" }}>● ROUTEBOUND PEER SESSIONS</span>
        </div>
      </footer>
    </div>
  );
}

const peerRecordStyle: React.CSSProperties = {
  backgroundColor: "#161922",
  border: "1px solid #202430",
  borderRadius: "6px",
  padding: "10px 12px",
  marginBottom: "8px",
};

const receiptStyle: React.CSSProperties = {
  backgroundColor: "#12151e",
  border: "1px solid #1c202d",
  borderRadius: "4px",
  padding: "8px",
  marginBottom: "8px",
};

const styles: { [key: string]: React.CSSProperties } = {
  container: {
    display: "flex",
    flexDirection: "column",
    height: "100%",
    width: "100%",
    boxSizing: "border-box",
    backgroundColor: "#0d0e12",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "16px 24px",
    borderBottom: "1px solid #1c202d",
    backgroundColor: "#10121a",
  },
  headerLeft: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
  },
  glowDot: {
    width: "8px",
    height: "8px",
    borderRadius: "50%",
    backgroundColor: "#39dbdb",
    boxShadow: "0 0 10px #39dbdb",
  },
  title: {
    margin: 0,
    fontSize: "16px",
    fontWeight: "700",
    letterSpacing: "1px",
    color: "#ffffff",
  },
  version: {
    fontSize: "11px",
    padding: "2px 6px",
    borderRadius: "3px",
    backgroundColor: "#202430",
    color: "#8a94a6",
    fontWeight: "600",
  },
  headerRight: {
    display: "flex",
    alignItems: "center",
  },
  nodeMeta: {
    display: "flex",
    alignItems: "center",
    fontSize: "12px",
    backgroundColor: "#08090d",
    padding: "6px 12px",
    borderRadius: "6px",
    border: "1px solid #202430",
  },
  label: {
    color: "#56617a",
    marginRight: "6px",
    fontWeight: "600",
  },
  code: {
    color: "#39dbdb",
    fontFamily: "Courier, monospace",
    fontWeight: "700",
  },
  connecting: {
    color: "#ffad47",
    fontWeight: "700",
  },

  viewBtn: {
    background: "#161922",
    border: "1px solid #202430",
    color: "#8a94a6",
    padding: "6px 16px",
    borderRadius: "4px",
    fontSize: "12px",
    fontWeight: "bold",
    cursor: "pointer",
  },
  viewBtnActive: {
    background: "#39dbdb",
    border: "1px solid #39dbdb",
    color: "#0d0e12",
    padding: "6px 16px",
    borderRadius: "4px",
    fontSize: "12px",
    fontWeight: "bold",
    cursor: "pointer",
  },
  dashboard: {
    display: "grid",
    gridTemplateColumns: "300px 1fr 340px",
    gap: "16px",
    padding: "16px",
    flex: 1,
    overflow: "hidden",
    boxSizing: "border-box",
  },
  labContainer: {
    display: "grid",
    gridTemplateColumns: "400px 1fr",
    gap: "16px",
    padding: "16px",
    flex: 1,
    overflow: "hidden",
    boxSizing: "border-box",
  },
  card: {
    display: "flex",
    flexDirection: "column",
    backgroundColor: "#10121a",
    border: "1px solid #1c202d",
    borderRadius: "8px",
    overflow: "hidden",
  },
  formCard: {
    backgroundColor: "#10121a",
    border: "1px solid #1c202d",
    borderRadius: "8px",
    overflow: "hidden",
  },
  formTitle: {
    margin: 0,
    fontSize: "12px",
    fontWeight: "700",
    color: "#ffffff",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
    padding: "10px 14px",
    background: "#161922",
    borderBottom: "1px solid #1c202d",
  },
  formContent: {
    padding: "14px",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
  },
  formRow: {
    display: "flex",
    flexDirection: "column",
    gap: "4px",
  },
  formLabel: {
    fontSize: "11px",
    color: "#8a94a6",
    fontWeight: "bold",
  },
  input: {
    background: "#08090d",
    border: "1px solid #202430",
    borderRadius: "4px",
    color: "#ffffff",
    padding: "8px",
    fontSize: "12px",
    fontFamily: "monospace",
  },
  selectField: {
    background: "#08090d",
    border: "1px solid #202430",
    borderRadius: "4px",
    color: "#ffffff",
    padding: "8px",
    fontSize: "12px",
    cursor: "pointer",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    fontSize: "11px",
    textAlign: "left",
  },
  th: {
    background: "#161922",
    color: "#8a94a6",
    padding: "8px 10px",
    fontWeight: "bold",
    borderBottom: "1px solid #1c202d",
  },
  tr: {
    borderBottom: "1px solid #1c202d",
  },
  td: {
    padding: "8px 10px",
    color: "#ffffff",
  },
  itemBadge: {
    padding: "2px 6px",
    borderRadius: "3px",
    background: "#242835",
    color: "#39dbdb",
    fontSize: "10px",
    fontWeight: "bold",
  },
  cardHeaderWithControls: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "12px 16px 8px 16px",
    borderBottom: "1px solid #1c202d",
  },
  cardTitle: {
    margin: 0,
    fontSize: "13px",
    fontWeight: "700",
    color: "#ffffff",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
    padding: "12px 16px 8px 16px",
  },
  cardContent: {
    padding: "16px",
    display: "flex",
    flexDirection: "column",
    flex: 1,
    overflow: "hidden",
  },
  peerListHeader: {
    display: "flex",
    justifyContent: "space-between",
    fontSize: "12px",
    color: "#8a94a6",
    marginBottom: "12px",
    fontWeight: "600",
  },
  peerList: {
    flex: 1,
    overflowY: "auto",
    marginBottom: "12px",
  },
  emptyMeshState: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    textAlign: "center",
    color: "#56617a",
  },
  radarRing: {
    width: "40px",
    height: "40px",
    borderRadius: "50%",
    border: "2px solid #202430",
    position: "relative",
    animation: "radarPulse 2s infinite ease-out",
  },
  note: {
    fontSize: "11px",
    color: "#56617a",
    lineHeight: "1.4",
    backgroundColor: "#0c0d12",
    padding: "10px",
    borderRadius: "6px",
    border: "1px solid #1c202d",
  },
  dimensionSelector: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
  },
  miniLabel: {
    fontSize: "10px",
    color: "#56617a",
    fontWeight: "700",
  },
  select: {
    backgroundColor: "#161922",
    border: "1px solid #202430",
    color: "#ffffff",
    borderRadius: "4px",
    fontSize: "11px",
    padding: "4px 8px",
    fontWeight: "600",
  },
  tabHeader: {
    display: "flex",
    gap: "8px",
    borderBottom: "1px solid #1c202d",
    paddingBottom: "8px",
    marginBottom: "12px",
  },
  tab: {
    background: "none",
    border: "none",
    color: "#56617a",
    fontSize: "12px",
    fontWeight: "700",
    cursor: "pointer",
    padding: "4px 8px",
  },
  tabActive: {
    background: "none",
    border: "none",
    color: "#39dbdb",
    fontSize: "12px",
    fontWeight: "700",
    cursor: "pointer",
    padding: "4px 8px",
    borderBottom: "2px solid #39dbdb",
  },
  vectorContainer: {
    flex: 1,
    overflow: "hidden",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    marginBottom: "16px",
  },
  heatmapLabel: {
    fontSize: "11px",
    color: "#56617a",
    marginBottom: "8px",
    lineHeight: "1.3",
  },
  textarea: {
    width: "100%",
    height: "100%",
    minHeight: "150px",
    backgroundColor: "#08090d",
    border: "1px solid #202430",
    borderRadius: "6px",
    color: "#4ade80",
    fontFamily: "monospace",
    fontSize: "11px",
    padding: "8px",
    resize: "none",
    outline: "none",
  },
  actionRow: {
    display: "flex",
    gap: "10px",
    marginBottom: "12px",
  },
  btnPrimary: {
    flex: 1,
    backgroundColor: "#39dbdb",
    color: "#0d0e12",
    border: "none",
    borderRadius: "6px",
    padding: "10px 16px",
    fontSize: "12px",
    fontWeight: "700",
    cursor: "pointer",
    transition: "background-color 0.2s",
  },
  btnSecondary: {
    backgroundColor: "#202430",
    color: "#ffffff",
    border: "1px solid #2d3245",
    borderRadius: "6px",
    padding: "10px 16px",
    fontSize: "12px",
    fontWeight: "600",
    cursor: "pointer",
    transition: "background-color 0.2s",
  },
  statusSuccess: {
    fontSize: "11px",
    color: "#4ade80",
    backgroundColor: "rgba(74, 222, 128, 0.05)",
    border: "1px solid rgba(74, 222, 128, 0.2)",
    padding: "10px",
    borderRadius: "6px",
    lineHeight: "1.4",
  },
  statusError: {
    fontSize: "11px",
    color: "#ff6b6b",
    backgroundColor: "rgba(255, 107, 107, 0.05)",
    border: "1px solid rgba(255, 107, 107, 0.2)",
    padding: "10px",
    borderRadius: "6px",
    lineHeight: "1.4",
  },
  feedHeader: {
    display: "flex",
    gap: "12px",
    borderBottom: "1px solid #1c202d",
    paddingBottom: "12px",
    marginBottom: "12px",
  },
  statMini: {
    display: "flex",
    flexDirection: "column",
    flex: 1,
    backgroundColor: "#161922",
    padding: "8px 12px",
    borderRadius: "6px",
    border: "1px solid #202430",
  },
  statMiniValue: {
    fontSize: "16px",
    fontWeight: "800",
    color: "#ffffff",
  },
  statMiniLabel: {
    fontSize: "10px",
    color: "#56617a",
    fontWeight: "600",
    textTransform: "uppercase",
  },
  feed: {
    flex: 1,
    overflowY: "auto",
    display: "flex",
    flexDirection: "column",
    gap: "12px",
  },
  feedEmpty: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    color: "#56617a",
    textAlign: "center",
    fontSize: "12px",
    gap: "12px",
  },
  radarGlow: {
    width: "30px",
    height: "30px",
    borderRadius: "50%",
    backgroundColor: "#161922",
    border: "2px solid #202430",
  },
  feedItem: {
    backgroundColor: "#161922",
    border: "1px solid #202430",
    borderRadius: "6px",
    padding: "12px",
  },
  feedItemHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "8px",
  },
  nodeIdBadge: {
    fontSize: "10px",
    backgroundColor: "#242835",
    color: "#8a94a6",
    padding: "2px 6px",
    borderRadius: "3px",
    fontWeight: "700",
    fontFamily: "monospace",
  },
  latencyBadge: {
    fontSize: "10px",
    color: "#ffad47",
    fontWeight: "600",
  },
  packetDetails: {
    fontSize: "11px",
    color: "#8a94a6",
    lineHeight: "1.5",
    fontFamily: "monospace",
  },
  footer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "12px 24px",
    borderTop: "1px solid #1c202d",
    backgroundColor: "#10121a",
    fontSize: "10px",
  },
  footerBlock: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
    color: "#56617a",
  },
};
