use std::net::SocketAddr;
use std::sync::Arc;
use tokio::net::UdpSocket;
use async_trait::async_trait;
use crate::protocol::{BraidTransport, BraidTransportError, BraidEndpoint, MAX_PACKET_SIZE};

pub struct UdpTransport {
    pub socket: Arc<UdpSocket>,
}

impl UdpTransport {
    pub fn new(socket: UdpSocket) -> Self {
        Self {
            socket: Arc::new(socket),
        }
    }
}

#[async_trait]
impl BraidTransport for UdpTransport {
    async fn send_to(&self, bytes: &[u8], target: BraidEndpoint) -> Result<(), BraidTransportError> {
        if bytes.len() > MAX_PACKET_SIZE {
            return Err(BraidTransportError::BufferOverflow(
                format!("packet {} > {}", bytes.len(), MAX_PACKET_SIZE)
            ));
        }

        let addr = match target {
            BraidEndpoint::Direct(socket_addr) => socket_addr,
            BraidEndpoint::Relay(relay_addr, _) => {
                // Relay framing acts as standard UDP wrapper destination (Pillar 4)
                relay_addr
            }
        };

        self.socket.send_to(bytes, addr).await
            .map_err(|e| BraidTransportError::Io(e.to_string()))?;
        Ok(())
    }

    async fn recv_from(&self) -> Result<(Vec<u8>, BraidEndpoint), BraidTransportError> {
        let mut buf = vec![0u8; MAX_PACKET_SIZE + 1]; // Tighter buffer aligned with protocol budget!
        let (size, src) = self.socket.recv_from(&mut buf).await
            .map_err(|e| BraidTransportError::Io(e.to_string()))?;

        if size > MAX_PACKET_SIZE {
            return Err(BraidTransportError::BufferOverflow(
                format!("packet {} > {}", size, MAX_PACKET_SIZE)
            ));
        }

        // Default incoming UDP socket connections mapped as Direct endpoints
        Ok((buf[..size].to_vec(), BraidEndpoint::Direct(src)))
    }

    fn local_endpoint(&self) -> SocketAddr {
        self.socket.local_addr().unwrap_or_else(|_| "0.0.0.0:0".parse().unwrap())
    }

    fn transport_kind(&self) -> String {
        "udp".to_string()
    }
}
