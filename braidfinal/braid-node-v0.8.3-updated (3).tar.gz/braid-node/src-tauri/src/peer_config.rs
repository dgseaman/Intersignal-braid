use serde::{Serialize, Deserialize};
use crate::protocol::{NodeId, BraidEndpoint};
use std::net::{SocketAddr, IpAddr};

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq)]
pub enum SeedTrustMode {
    ManualTrusted,
    PendingTrust,
    DiscoveryOnly,
}

impl std::fmt::Display for SeedTrustMode {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SeedTrustMode::ManualTrusted => write!(f, "ManualTrusted"),
            SeedTrustMode::PendingTrust => write!(f, "PendingTrust"),
            SeedTrustMode::DiscoveryOnly => write!(f, "DiscoveryOnly"),
        }
    }
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]
pub struct PeerSeed {
    pub label: String,
    pub node_id: Option<NodeId>,
    pub endpoint: BraidEndpoint,
    pub trust_mode: SeedTrustMode,
    pub enabled: bool,
}

impl PeerSeed {
    pub fn validate(&self) -> Result<(), String> {
        if self.label.trim().is_empty() {
            return Err("Label cannot be empty".to_string());
        }

        let addr = match self.endpoint {
            BraidEndpoint::Direct(sa) => sa,
            BraidEndpoint::Relay(sa, _) => sa,
        };

        if addr.port() == 0 {
            return Err("Port cannot be zero".to_string());
        }

        let ip = addr.ip();
        if ip.is_unspecified() {
            return Err("Unspecified remote address is invalid".to_string());
        }

        if let Some(node_id) = self.node_id {
            if node_id == [0u8; 32] {
                return Err("Node ID cannot be all zeros".to_string());
            }
        }

        Ok(())
    }
}

pub fn validate_duplicate_seeds(seeds: &[PeerSeed]) -> Result<(), String> {
    let mut endpoints = std::collections::HashSet::new();
    for seed in seeds {
        let addr = match seed.endpoint {
            BraidEndpoint::Direct(sa) => sa,
            BraidEndpoint::Relay(sa, _) => sa,
        };
        if !endpoints.insert(addr) {
            return Err(format!("Duplicate seed endpoint: {}", addr));
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::str::FromStr;

    #[test]
    fn test_validate_peer_seed() {
        let valid_addr = SocketAddr::from_str("127.0.0.1:12000").unwrap();
        let invalid_ip = SocketAddr::from_str("0.0.0.0:12000").unwrap();
        let invalid_port = SocketAddr::from_str("127.0.0.1:0").unwrap();

        let s1 = PeerSeed {
            label: "Valid".to_string(),
            node_id: None,
            endpoint: BraidEndpoint::Direct(valid_addr),
            trust_mode: SeedTrustMode::ManualTrusted,
            enabled: true,
        };
        assert!(s1.validate().is_ok());

        let s2 = PeerSeed {
            label: "   ".to_string(),
            node_id: None,
            endpoint: BraidEndpoint::Direct(valid_addr),
            trust_mode: SeedTrustMode::ManualTrusted,
            enabled: true,
        };
        assert_eq!(s2.validate().unwrap_err(), "Label cannot be empty");

        let s3 = PeerSeed {
            label: "Unspecified IP".to_string(),
            node_id: None,
            endpoint: BraidEndpoint::Direct(invalid_ip),
            trust_mode: SeedTrustMode::PendingTrust,
            enabled: true,
        };
        assert_eq!(s3.validate().unwrap_err(), "Unspecified remote address is invalid");

        let s4 = PeerSeed {
            label: "Zero Port".to_string(),
            node_id: None,
            endpoint: BraidEndpoint::Direct(invalid_port),
            trust_mode: SeedTrustMode::DiscoveryOnly,
            enabled: true,
        };
        assert_eq!(s4.validate().unwrap_err(), "Port cannot be zero");
    }

    #[test]
    fn test_duplicate_seeds() {
        let addr1 = SocketAddr::from_str("127.0.0.1:12000").unwrap();
        let addr2 = SocketAddr::from_str("127.0.0.1:12001").unwrap();

        let s1 = PeerSeed {
            label: "P1".to_string(),
            node_id: None,
            endpoint: BraidEndpoint::Direct(addr1),
            trust_mode: SeedTrustMode::ManualTrusted,
            enabled: true,
        };
        let s2 = PeerSeed {
            label: "P2".to_string(),
            node_id: None,
            endpoint: BraidEndpoint::Direct(addr2),
            trust_mode: SeedTrustMode::ManualTrusted,
            enabled: true,
        };
        let s3 = PeerSeed {
            label: "P3".to_string(),
            node_id: None,
            endpoint: BraidEndpoint::Direct(addr1),
            trust_mode: SeedTrustMode::PendingTrust,
            enabled: true,
        };

        assert!(validate_duplicate_seeds(&[s1.clone(), s2]).is_ok());
        assert!(validate_duplicate_seeds(&[s1, s3]).is_err());
    }
}
