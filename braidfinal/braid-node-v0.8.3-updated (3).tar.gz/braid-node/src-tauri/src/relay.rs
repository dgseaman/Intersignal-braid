use serde::{Serialize, Deserialize};
use crate::protocol::NodeId;

// =====================================================================
// OPAQUE ZERO-TRUST WAN RELAY ROUTING FRAME (Pillar 4)
// =====================================================================

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct RelayFrame {
    pub origin_sender: NodeId,
    pub final_recipient: NodeId,
    pub route_id: [u8; 16],
    pub inner_message_type: u16,
    pub inner_vector_encoding: u16,
    pub created_at_ms: u64,
    pub expires_at_ms: u64,
    pub inner_envelope_bytes: Vec<u8>, // End-to-end encrypted or opaque inner BraidEnvelope
}

impl RelayFrame {
    /// Verify static parameters and envelope bounds on the relay frame prior to forwarding (Pillar 4)
    pub fn validate_frame(&self, current_time_ms: u64) -> Result<(), String> {
        if current_time_ms > self.expires_at_ms {
            return Err("Relay frame has expired".into());
        }
        
        let drift = (current_time_ms as i128 - self.created_at_ms as i128).abs();
        if drift > 60_000 {
            return Err("Relay frame created_at timestamp exceeds maximum drift tolerances".into());
        }

        if self.inner_envelope_bytes.is_empty() {
            return Err("Relay frame carries empty payload".into());
        }

        Ok(())
    }
}
