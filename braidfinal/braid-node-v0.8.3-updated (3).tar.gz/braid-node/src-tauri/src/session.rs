use serde::{Serialize, Deserialize};
use crate::protocol::NodeId;

// =====================================================================
// CRYPTOGRAPHIC WAN HANDSHAKE SESSION STATE MACHINE (Pillar 3)
// =====================================================================

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq)]
pub enum SessionState {
    Init,
    HelloSent,
    Challenged,
    Ready,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidSession {
    pub peer_node_id: NodeId,
    pub session_id: [u8; 16],
    pub route_id: [u8; 16],
    pub established_at_ms: u64,
    pub expires_at_ms: u64,
    pub accepted_capabilities: u64,
    pub state: SessionState,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SessionHello {
    pub initiator_node_id: NodeId,
    pub target_node_id: NodeId,
    pub route_id: [u8; 16],
    pub nonce_a: [u8; 32],
    pub capabilities: u64,
    pub timestamp_ms: u64,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SessionChallenge {
    pub initiator_node_id: NodeId,
    pub responder_node_id: NodeId,
    pub route_id: [u8; 16],
    pub nonce_a: [u8; 32],
    pub nonce_b: [u8; 32],
    pub accepted_capabilities: u64,
    pub timestamp_ms: u64,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SessionResponse {
    pub route_id: [u8; 16],
    pub nonce_a: [u8; 32],
    pub nonce_b: [u8; 32],
    pub timestamp_ms: u64,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SessionReady {
    pub route_id: [u8; 16],
    pub session_id: [u8; 16],
    pub expires_at_ms: u64,
}
