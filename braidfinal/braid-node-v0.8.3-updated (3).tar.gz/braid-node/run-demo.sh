#!/usr/bin/env sh
set -eu

echo "==============================================================="
echo "   Executing Braid Tendril v0.8.3 Peering & Vector Transfer Demo"
echo "==============================================================="
python3 vector_transfer_demo.py
