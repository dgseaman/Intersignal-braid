# Braid Pathfinder v0.8 WAN Conformance Fixtures & Test Vectors

These files serve as language-agnostic cross-verification test vectors. Implementers of Braid clients in Python, Go, TypeScript, C++, or other systems must verify that their cryptographic derivations, key layouts, payload serializations, and signature preimages produce exact matching byte structures to the Rust node.

## Directory Contents

1.  `keys.ed25519.public.hex`: Raw 32-byte Ed25519 public verifying material used to derive the `NodeId`.
2.  `derived_node_id.hex`: Expected derived 32-byte canonical `NodeId` from public key material.
3.  `BraidSigningBody.state_drift.f32.packed.hex`: Expected deterministic packed big-endian bytes for the unquantized F32 state-drift signing body.
4.  `BraidEnvelope.state_drift.f32.bincode.hex`: Real, complete little-endian Bincode-serialized Braid envelope containing the unquantized F32 vector drift payload and its cryptographically verified Ed25519 signature.
5.  `vectors.f32.txt`: Explanatory sample float array.
