# Braid Tendril v0.8.3-alpha (WAN Discovery Lab + Out-of-the-Box 384d Vector Transfer)

Braid Tendril v0.8.3-alpha is a hardened developer release focused on WAN discovery readiness and out-of-the-box 384-dimensional vector transfer. It operates completely cloud-free, allowing local enclaves and edge devices to establish policy-gated neural coordinate synchronizations over physical subnets, mapped WAN tunnels, and zero-trust relay infrastructure.

*Note: This is an experimental pre-1.0 developer release. It is designed as a secure, WAN-routing prototype, not a production-complete WAN solution.*

This release represents **Braid Tendril v0.8.3-alpha** (Package `0.8.3-alpha` / Wire Protocol version `8`).

## New in v0.8.3-alpha
- **Connection Lab Interface**: Built an advanced network tab in the frontend exposing network status diagnostics, manual WAN peer adding, rate-limited probing, active routes, secure session tables, and first-class vector receipts.
- **Seeded Test Vector Generator**: Added deterministic 384d vector generation with min/max/mean statistical metrics and little-endian f32 SHA-256 integrity hashing.
- **Relay MTU Protection**: Automated qint8 quantization fallback for relay-bound routes to ensure transport sizes satisfy strict MTU limits, with strict size-gates on raw f32 transmission.
- **Robust Probing Rate-Limiter**: Enforced rate limits (max 1/endpoint/5s, max 10 global/min, and max 3 failures before backoff) to protect nodes from scanning and connection storms.

## Architectural Specifications
1.  **NodeId-First WAN Routing**: Dynamic route resolution via `send_to_node(NodeId, envelope)`. Transport and session layers communicate exclusively using 32-byte hash NodeIds rather than raw physical socket addresses.
2.  **Untrusted Signed-Presence Rendezvous**: Sockets and route hints are published as signed `BraidPresenceRecord` announcements containing raw public key materials and absolute expirations (`expires_at_ms`). Edge nodes verify presence authenticity directly against these keys before updating rendezvous stores.
3.  **Cryptographic Handshake State Machine**: Handles multi-message handshake sequences over direct routes (`MSG_SESSION_HELLO`, `MSG_SESSION_CHALLENGE`, `MSG_SESSION_RESPONSE`, and `MSG_SESSION_READY`) to authenticate peer NodeId identity before state transitions to `Ready`.
4.  **Transit Relay Forwarding**: Supports transit packet forwarding via signed `BraidRelayFrame` envelopes supporting target NodeId routing, sender tracking, and absolute TTL expirations to prevent loop leaks. Supports final-recipient inline packet ingestion.
5.  **Message-Type-Keyed Replay Ledger**: Protects state against cross-protocol replay threats by tracking sequence numbers independently per message type.
6.  **Quantized INT8 Decompression**: Active decompression pipeline for 384-dimension quantized vector states.

## Privacy & Sensitivity Notice
- Braid Tendril does not automatically share user documents, chats, files, browser history, API keys, private keys, or personal data. 
- A 384d vector is not automatically human-readable text, but it can still encode meaningful state. Treat vectors as sensitive unless you know how they were generated. Braid does not make unsafe data safe merely by vectorizing it. Do not vectorize sensitive or confidential data without understanding your model's information disclosure characteristics.

## Verification & Clean Builds
Ensure that the project passes all pre-release tests before commits:
```bash
# 1. Run the local conformance verification suite
python3 conformance_verify.py

# 2. Run the vector transfer verification suite
python3 vector_transfer_demo.py
```
