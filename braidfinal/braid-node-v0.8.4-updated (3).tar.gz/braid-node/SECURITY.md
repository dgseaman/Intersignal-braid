# Braid Security Policy & Hardened Controls

Braid is designed from the ground up for absolute OpSec, localized data sovereignty, and hardware-enclosed operations.

## Hardened Security & NAT Controls (v0.8.4 / NAT & Privacy Controls)

Braid Tendril v0.8.4 introduces advanced wide-area NAT reachability testing and strict privacy isolation:

1.  **Cloud-Free STUN Isolation**: Public STUN resolution utilizes public, standardized servers without requiring user accounts or paid keys, running completely cloud-free without any centralized Braid telemetry or auto-scanning.
2.  **Explicit User-Initiated Discoveries**: All STUN binding queries and reachability checks are manually triggered by the user via the Connection Lab UI, blocking any automated background network exposure.
3.  **Symmetric NAT Variance Detection**: Analyzes public mapped endpoint consistency across multiple distinct STUN servers to detect restrictive, port-translating Symmetric NAT mappings honestly.
4.  **Asynchronous Thread Isolation**: Offloads blocking STUN socket operations onto isolated worker pools (`spawn_blocking`) to keep the primary async transport loop fully responsive under load.
5.  **Strict Local Loopback Sandboxing**: Classifies loopback addresses (`127.0.0.1`) as strictly `LocalOnly`, preventing local test nodes from initiating wide-area discoveries or leaking routing indicators.
6.  **Diagnostics Sanitization**: Generates diagnostic bundles that are completely sanitized, guaranteeing that no private keys, seed materials, or raw vector coordinates are ever exported.

## Hardened Security Controls (v0.8.3 / Wire Protocol 8)

Braid Tendril establishes a robust, highly resilient cryptographic fence at the wide-area network (WAN) boundary:

1.  **Rate-Limited WAN Endpoint Probing**: To prevent background scanning, connection storms, and denial-of-service, manual probing commands enforce a rate-limit ceiling (max 1 probe/endpoint/5s, max 10 global probes/min, and max 3 failed retries before backoff).
2.  **Duplicate Seed Endpoint Rejection**: All peer configuration operations enforce strict duplicate seed endpoint validation, blocking duplicate route/endpoint registration vectors.
3.  **Relay MTU and Payload Opacity**: Transit nodes only validate outer signatures, TTLs, and routing headers. They cannot inspect, decrypt, or unwrap the inner state-drift envelope, maintaining zero-trust opacity.
4.  **Relayed Packet Ceiling Enforcements**: Enforces `qint8` quantization by default on relays to prevent outer packet ceiling overflows, gating raw f32 relays behind strict size checks.

## Hardened Security Controls (v0.8.2 / Wire Protocol 8)

1.  **Pre-Deserialization Buffer Ceiling**: Receivers enforce a strict `2048` byte UDP packet limit directly on the socket stream. Any buffer reading exceeding this MTU limit is dropped prior to deserialization, defending the host from memory inflation and CPU-exhaustion vectors.
2.  **Stable Hash-Derived Node Identity**: Node IDs are modeled as fixed 32-byte hash structures, derived dynamically from the signature scheme and public key bytes:
    $$\text{NodeId} = \text{SHA256}(\text{"braid-node-id-v1"} \mathbin{\Vert} \text{scheme\_id} \mathbin{\Vert} \text{public\_material})$$
3.  **Untrusted Signed-Presence Registry**: Sockets and route hints are published as signed `BraidPresenceRecord` announcements containing raw public key materials and absolute expirations (`expires_at_ms`). Edge nodes verify presence authenticity directly against these keys before updating rendezvous stores.
4.  **Message-Type-Keyed Replay Ledger**: Protects state against cross-protocol replay threats by tracking sequence numbers independently per message type.
5.  **Transit Relay Forwarding**: Built real transit packet forwarding via signed `BraidRelayFrame` envelopes supporting target NodeId routing, sender tracking, and absolute TTL expirations to prevent loop leaks.
6.  **Persistent Trust & Pairing Pending (v0.8.2)**: Integrates local peer trust configurations into a persistent `trust_policy.json` manifest. Any unknown node in Manual or Pinned mode is dynamically placed in a `PairingPending` state rather than being silently admitted, requiring explicit user/admin action to approve.
7.  **One-Hop Conservative Relay Forwarding bounds (v0.8.2)**: Hardens transit relaying to prevent multi-hop routing, loop injection, or signed-frame tampering. Relays verify that the sender possesses the `CAP_RELAY_SEND` capability and is allowed in local trust policies, that the inner envelope is completely unmutated and authentic, and that the relay holds a direct connection candidate for the final recipient.

## Reporting Vulnerabilities

Please report verified security flaws or protocol exploits directly to our trust team:
*   Email: `missy@intersignal.ai`
