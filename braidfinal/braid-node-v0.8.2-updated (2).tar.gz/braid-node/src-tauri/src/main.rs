#![cfg_attr(
  all(not(debug_assertions), target_os = "windows"),
  windows_subsystem = "windows"
)]

mod protocol;
mod identity;
mod presence;
mod session;
mod route;
mod relay;
mod rendezvous;
mod trust;
mod tendril;
mod transport;
mod web;

use protocol::{
    BraidEnvelope, BraidStateDrift, BraidDiscoveryBeacon, BraidLinkProbe, BraidLinkProbeAck,
    BraidStateDriftQuant, BraidTransport, BraidEndpoint, MSG_STATE_DRIFT, MSG_HEARTBEAT, MSG_DISCOVERY_BEACON,
    MSG_DISCOVERY_ACK, MSG_PEER_GOODBYE, MSG_LINK_PROBE, MSG_LINK_PROBE_ACK, MSG_SESSION_HELLO,
    MSG_SESSION_CHALLENGE, MSG_SESSION_RESPONSE, MSG_SESSION_READY, MSG_SESSION_CLOSE,
    EXPECTED_VECTOR_DIM, WIRE_PROTOCOL_VERSION, MAX_PACKET_SIZE, CAP_STATE_DRIFT, CAP_DISCOVERY,
    CAP_UDP_TRANSPORT, CAP_VECTOR_384_F32, CAP_VECTOR_QINT8, SCHEME_ED25519, VECTOR_ENCODING_RAW_F32,
    VECTOR_ENCODING_QINT8, NodeId, IdentityProvider
};
use identity::{NodeIdentity, Ed25519LocalIdentityProvider, derive_node_id};
use presence::PresenceRecord;
use session::{BraidSession, SessionState, SessionHello, SessionChallenge, SessionResponse, SessionReady};
use route::{RouteCandidate, RouteEndpoint, TransportKind, RouteState, RouteSource};
use relay::RelayFrame;
use trust::{TrustPolicyEngine, TrustMode, Admission};
use transport::UdpTransport;

use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};
use tokio::net::UdpSocket;
use tokio::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};
use serde::{Serialize, Deserialize};
use tauri::Manager; // Critical v1.x import to resolve emit_all & manage traits!
use rand::Rng;

pub const NODE_SOFTWARE_VERSION: &str = "0.8.2-alpha"; // Tendril Kernel v0.8.2-alpha

pub const MAX_PEERS: usize = 128; // Spam/sybil overflow protection limit
pub const MAX_REPLAY_LEDGER_ENTRIES: usize = 4096; // Bounded replay ledger size limit
pub const ACK_RATE_LIMIT_MS: u64 = 10_000; // Only reply to discovery beacons once every 10s per peer

fn format_hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{:02x}", b)).collect::<Vec<String>>().join("")
}

// Global visualizer state helper
pub fn main_status_stale() -> route::PeerStatus {
    route::PeerStatus::Stale
}

// =====================================================================
// TAURI SHARED STATE (wrapped in Arc for multi-daemon access)
// =====================================================================

pub struct AppState {
    pub transport: Arc<dyn BraidTransport>, // Dynamic Trait Object (Pillar 2)
    pub identity_provider: Arc<dyn IdentityProvider>,
    pub node_id: NodeId,
    pub session_id: [u8; 16],
    pub sequence_counter: Arc<AtomicU64>,
    pub peer_table: Arc<Mutex<HashMap<NodeId, route::PeerRecord>>>,
    pub session_table: Arc<Mutex<HashMap<NodeId, BraidSession>>>, // Handshake session table (v0.8.1)
    pub route_table: Arc<Mutex<HashMap<NodeId, Vec<RouteCandidate>>>>, // Multi-path routing table (v0.8.1)
    pub trust_policy: Arc<Mutex<TrustPolicyEngine>>, // Policy allowlist (v0.8.1)
    pub replay_ledger: Arc<Mutex<HashMap::<(NodeId, [u8; 16], u16), u64>>>,
    pub last_sent_acks: Arc<Mutex<HashMap<NodeId, u64>>>,
    pub local_port: u16,
    pub latest_received_vector: Arc<Mutex<Vec<f32>>>, 
    pub peers: Arc<Mutex<Vec<String>>>,
    pub seed_peers: Vec<SocketAddr>,
}

// =====================================================================
// PEER DISCOVERY VALIDATOR
// =====================================================================

fn validate_beacon(
    envelope: &BraidEnvelope,
    beacon: &BraidDiscoveryBeacon,
) -> Result<(), String> {
    if beacon.session_id != envelope.session_id {
        return Err("Beacon session_id does not match envelope session_id".into());
    }

    if beacon.vector_dim as usize != EXPECTED_VECTOR_DIM {
        return Err(format!("Unsupported vector dimension: {}", beacon.vector_dim));
    }

    if beacon.max_packet_size as usize < 380 {
        return Err("Peer max_packet_size too small for quantized vector state".into());
    }

    // Require CAP_DISCOVERY | CAP_UDP_TRANSPORT
    let required = CAP_DISCOVERY | CAP_UDP_TRANSPORT;
    if beacon.capabilities & required != required {
        return Err("Peer lacks required discovery or UDP transport capabilities".into());
    }

    if beacon.ttl_ms < 5_000 || beacon.ttl_ms > 60_000 {
        return Err("Beacon TTL outside accepted protocol range (5s - 60s)".into());
    }

    Ok(())
}

// =====================================================================
// UNIFIED REPLAY LEDGER VALIDATION HELPER
// =====================================================================

async fn check_and_commit_replay(
    ledger: &Mutex<HashMap<(NodeId, [u8; 16], u16), u64>>,
    node_id: NodeId,
    session_id: [u8; 16],
    message_type: u16,
    sequence: u64,
    src: SocketAddr,
) -> Result<(), String> {
    let mut guard = ledger.lock().await;
    let key = (node_id, session_id, message_type);
    
    if guard.len() >= MAX_REPLAY_LEDGER_ENTRIES && !guard.contains_key(&key) {
        return Err(format!("[DROP] Replay ledger full; rejecting new session from {}", src));
    }
    
    if let Some(highest_seq) = guard.get(&key) {
        if sequence <= *highest_seq {
            return Err(format!(
                "[DROP] Replay threat detected: sequence {} <= highest seen ({})",
                sequence, highest_seq
            ));
        }
    }
    
    guard.insert(key, sequence);
    Ok(())
}

// =====================================================================
// TAURI COMMANDS
// =====================================================================

#[tauri::command]
async fn get_trust_policy(state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    let policy = state.trust_policy.lock().await;
    Ok(policy.get_policy_json())
}

#[tauri::command]
async fn approve_peer_trust(node_id_hex: String, state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    let mut policy = state.trust_policy.lock().await;
    let bytes = hex::decode(&node_id_hex).map_err(|e| e.to_string())?;
    if bytes.len() != 32 {
        return Err("Invalid Node ID length".to_string());
    }
    let mut node_id = [0u8; 32];
    node_id.copy_from_slice(&bytes);
    policy.allow_node(node_id);
    Ok(serde_json::json!({ "status": "success", "approved": node_id_hex }))
}

#[tauri::command]
async fn deny_peer_trust(node_id_hex: String, state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    let mut policy = state.trust_policy.lock().await;
    let bytes = hex::decode(&node_id_hex).map_err(|e| e.to_string())?;
    if bytes.len() != 32 {
        return Err("Invalid Node ID length".to_string());
    }
    let mut node_id = [0u8; 32];
    node_id.copy_from_slice(&bytes);
    policy.deny_node(node_id);
    Ok(serde_json::json!({ "status": "success", "denied": node_id_hex }))
}

#[tauri::command]
async fn remove_peer_trust(node_id_hex: String, state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    let mut policy = state.trust_policy.lock().await;
    let bytes = hex::decode(&node_id_hex).map_err(|e| e.to_string())?;
    if bytes.len() != 32 {
        return Err("Invalid Node ID length".to_string());
    }
    let mut node_id = [0u8; 32];
    node_id.copy_from_slice(&bytes);
    policy.remove_node(node_id);
    Ok(serde_json::json!({ "status": "success", "removed": node_id_hex }))
}

#[tauri::command]
async fn set_trust_mode(mode: String, state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    let mut policy = state.trust_policy.lock().await;
    let new_mode = match mode.as_str() {
        "manual" => TrustMode::Manual,
        "pinned" => TrustMode::Pinned,
        "open_dev" => TrustMode::OpenDev,
        _ => return Err("Invalid trust mode".to_string()),
    };
    policy.set_mode(new_mode);
    Ok(serde_json::json!({ "status": "success", "mode": mode }))
}

#[tauri::command]
async fn get_node_info(state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    Ok(serde_json::json!({
        "node_id": format_hex(&state.node_id),
        "local_address": format!("0.0.0.0:{}", state.local_port),
        "software_version": NODE_SOFTWARE_VERSION,
        "wire_version": WIRE_PROTOCOL_VERSION,
    }))
}

#[tauri::command]
async fn get_peers(state: tauri::State<'_, Arc<AppState>>) -> Result<Vec<String>, String> {
    let peer_table = state.peer_table.lock().await;
    let list = peer_table.values()
        .filter(|record| record.status != route::PeerStatus::Stale)
        .map(|record| record.observed_addr.to_string())
        .collect::<Vec<String>>();
    Ok(list)
}

#[tauri::command]
async fn stream_state_drift(
    latent_vector: Vec<f32>,
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<serde_json::Value, String> {
    if latent_vector.is_empty() {
        return Err("Latent vector cannot be empty".to_string());
    }

    if latent_vector.len() != EXPECTED_VECTOR_DIM {
        return Err(format!("Vector dimension must be exactly {}", EXPECTED_VECTOR_DIM));
    }

    if latent_vector.iter().any(|v| !v.is_finite()) {
        return Err("Latent vector contains NaN or Infinity".to_string());
    }

    // Clone target peer records first, then drop lock to avoid holding across await
    let peers_to_send = {
        let peer_table = state.peer_table.lock().await;
        peer_table.values()
            .filter(|r| r.status == route::PeerStatus::Active || r.status == route::PeerStatus::Verified)
            .cloned()
            .collect::<Vec<route::PeerRecord>>()
    };

    let mut sent_count = 0;
    let mut failures = Vec::new();

    for peer in peers_to_send {
        let sequence = state.sequence_counter.fetch_add(1, Ordering::SeqCst);
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(|e| e.to_string())?
            .as_millis() as u64;

        // CAPABILITY NEGOTIATION: Use 8-bit quantization if peer supports it!
        let result = if peer.preferred_vector_encoding == VECTOR_ENCODING_QINT8 {
            let quant = BraidStateDriftQuant::quantize(&latent_vector);
            let payload = bincode::serialize(&quant).map_err(|e| e.to_string())?;
            tendril::send_to_node(
                peer.node_id,
                MSG_STATE_DRIFT,
                payload,
                VECTOR_ENCODING_QINT8,
                state.session_id,
                sequence,
                timestamp,
                state.session_table.as_ref(),
                state.route_table.as_ref(),
                state.identity_provider.as_ref(),
                state.transport.as_ref(),
            ).await
        } else {
            let drift = BraidStateDrift { latent_vector: latent_vector.clone() };
            let payload = bincode::serialize(&drift).map_err(|e| e.to_string())?;
            tendril::send_to_node(
                peer.node_id,
                MSG_STATE_DRIFT,
                payload,
                VECTOR_ENCODING_RAW_F32,
                state.session_id,
                sequence,
                timestamp,
                state.session_table.as_ref(),
                state.route_table.as_ref(),
                state.identity_provider.as_ref(),
                state.transport.as_ref(),
            ).await
        };

        match result {
            Ok(_) => {
                sent_count += 1;
            }
            Err(e) => {
                failures.push(format!("{}: {:?}", peer.observed_addr, e));
            }
        }
    }

    Ok(serde_json::json!({
        "sent_count": sent_count,
        "failures": failures,
    }))
}

// =====================================================================
// DAEMON RUNTIME
// =====================================================================

fn main() {
    tauri::Builder::default()
        .setup(|app| {
            let handle = app.handle();
            tauri::async_runtime::block_on(async move {
                // FLEXIBLE CLI BOOTSTRAPPING ARGUMENTS PARSING
                let mut udp_port = 12000;
                let mut web_port = 8080;
                let mut no_web = false;
                let mut seed_peers = Vec::new();
                let mut custom_identity_path = None;
                let mut allow_list_peers = Vec::new();
                let mut log_level = "info".to_string();

                let args: Vec<String> = std::env::args().collect();
                let mut i = 1;
                while i < args.len() {
                    match args[i].as_str() {
                        "--port" | "-p" => {
                            if i + 1 < args.len() {
                                if let Ok(p) = args[i+1].parse::<u16>() {
                                    udp_port = p;
                                }
                                i += 2;
                            } else { i += 1; }
                        }
                        "--web-port" | "-w" => {
                            if i + 1 < args.len() {
                                if let Ok(p) = args[i+1].parse::<u16>() {
                                    web_port = p;
                                }
                                i += 2;
                            } else { i += 1; }
                        }
                        "--seed" => {
                            if i + 1 < args.len() {
                                if let Ok(addr) = args[i+1].parse::<SocketAddr>() {
                                    seed_peers.push(addr);
                                }
                                i += 2;
                            } else { i += 1; }
                        }
                        "--allow" => {
                            if i + 1 < args.len() {
                                if let Ok(bytes) = hex::decode(&args[i+1]) {
                                    if bytes.len() == 32 {
                                        let mut node_arr = [0u8; 32];
                                        node_arr.copy_from_slice(&bytes);
                                        allow_list_peers.push(node_arr);
                                    }
                                }
                                i += 2;
                            } else { i += 1; }
                        }
                        "--no-web" => {
                            no_web = true;
                            i += 1;
                        }
                        "--identity" => {
                            if i + 1 < args.len() {
                                custom_identity_path = Some(std::path::PathBuf::from(&args[i+1]));
                                i += 2;
                            } else { i += 1; }
                        }
                        "--log-level" => {
                            if i + 1 < args.len() {
                                log_level = args[i+1].clone();
                                i += 2;
                            } else { i += 1; }
                        }
                        _ => { i += 1; }
                    }
                }

                println!("[BOOT] Braid Tendril Kernel v0.8.2 Initializing...");
                println!("[BOOT] Target UDP Port: {}, Web Visualizer Port: {}, No Web: {}, Log Level: {}", udp_port, web_port, no_web, log_level);

                let bind_addr = format!("0.0.0.0:{}", udp_port);
                let socket = match UdpSocket::bind(&bind_addr).await {
                    Ok(s) => s,
                    Err(_) => {
                        UdpSocket::bind("0.0.0.0:0")
                            .await
                            .expect("Failed to bind UDP socket to any port")
                    }
                };

                let local_port = socket.local_addr().unwrap().port();
                let transport = Arc::new(UdpTransport::new(socket));
                let _ = transport.socket.set_broadcast(true);

                // Initialize persistent node identity stored securely in App Data Directory
                let app_data_dir = handle.path_resolver().app_data_dir()
                    .unwrap_or_else(|| std::env::current_dir().unwrap());
                std::fs::create_dir_all(&app_data_dir).unwrap_or_default();
                
                let identity_path = custom_identity_path.unwrap_or_else(|| app_data_dir.join(".braid_identity"));

                // Initialize Ed25519 Local Identity Provider
                let local_identity = NodeIdentity::load_or_create(identity_path).unwrap();
                let identity_provider = Arc::new(Ed25519LocalIdentityProvider::new(local_identity.signing_key.clone()));

                let node_id = identity_provider.node_id();
                let session_id: [u8; 16] = rand::random();
                let sequence_counter = Arc::new(AtomicU64::new(1)); 
                let peer_table = Arc::new(Mutex::new(HashMap::<NodeId, route::PeerRecord>::new()));
                let session_table = Arc::new(Mutex::new(HashMap::<NodeId, BraidSession>::new()));
                let route_table = Arc::new(Mutex::new(HashMap::<NodeId, Vec<RouteCandidate>>::new()));
                
                // Initialize trust policy engine and populate explicit allowlist (Pillar 6, v0.8.2)
                let trust_policy_path = identity_path.parent().unwrap().join("trust_policy.json");
                let mut policy_engine = TrustPolicyEngine::load_or_create(trust_policy_path);
                for allowed in allow_list_peers {
                    policy_engine.allow_node(allowed);
                }
                let trust_policy = Arc::new(Mutex::new(policy_engine));

                let replay_ledger = Arc::new(Mutex::new(HashMap::<(NodeId, [u8; 16], u16), u64>::new()));
                let last_sent_acks = Arc::new(Mutex::new(HashMap::<NodeId, u64>::new()));
                let latest_received_vector = Arc::new(Mutex::new(vec![0.0f32; EXPECTED_VECTOR_DIM]));

                // Define bootstrap targets: fallback to broadcast if no manual seeds provided
                let discovery_targets = if seed_peers.is_empty() {
                    vec![
                        "255.255.255.255:12000".parse::<SocketAddr>().unwrap(),
                        "127.0.0.1:12000".parse::<SocketAddr>().unwrap(),
                    ]
                } else {
                    seed_peers.clone()
                };

                let peers = Arc::new(Mutex::new(
                    discovery_targets.iter().map(|addr| addr.to_string()).collect::<Vec<String>>()
                ));

                // Create shared global state wrapped in Arc for web daemon integration
                let app_state_arc = Arc::new(AppState {
                    transport: Arc::clone(&transport) as Arc<dyn BraidTransport>, // Dynamic Trait Object (Pillar 2)
                    identity_provider: Arc::clone(&identity_provider) as Arc<dyn IdentityProvider>,
                    node_id,
                    session_id,
                    sequence_counter: Arc::clone(&sequence_counter),
                    peer_table: Arc::clone(&peer_table),
                    session_table: Arc::clone(&session_table),
                    route_table: Arc::clone(&route_table),
                    trust_policy: Arc::clone(&trust_policy),
                    replay_ledger: Arc::clone(&replay_ledger),
                    last_sent_acks: Arc::clone(&last_sent_acks),
                    local_port,
                    latest_received_vector: Arc::clone(&latest_received_vector),
                    peers: Arc::clone(&peers),
                    seed_peers: seed_peers.clone(),
                });

                // Spawn Localhost HTTP Web Visualizer if allowed
                if !no_web {
                    let web_state_clone = Arc::clone(&app_state_arc);
                    tokio::spawn(async move {
                        web::start_web_server(web_state_clone, web_port).await;
                    });
                }

                // 1. Spawns background receiver loop - Strict Admission-First Receive Pipeline
                let rx_transport = Arc::clone(&transport);
                let tx_transport_clone = Arc::clone(&transport);
                let local_node_id = node_id;
                let local_session_id = session_id;
                let rx_ledger = Arc::clone(&replay_ledger);
                let rx_peer_table = Arc::clone(&peer_table);
                let rx_session_table = Arc::clone(&session_table);
                let rx_route_table = Arc::clone(&route_table);
                let rx_policy = Arc::clone(&trust_policy);
                let rx_sequence_counter = Arc::clone(&sequence_counter);
                let rx_provider_clone = Arc::clone(&identity_provider);
                let rx_app_handle = handle.clone();
                let rx_peers = Arc::clone(&peers);
                let rx_last_sent_acks = Arc::clone(&last_sent_acks);
                let rx_latest_vector = Arc::clone(&latest_received_vector);

                tokio::spawn(async move {
                    loop {
                        match rx_transport.recv_from().await {
                            Ok((bytes, target_endpoint)) => {
                                let src = match target_endpoint {
                                    BraidEndpoint::Direct(addr) => addr,
                                    BraidEndpoint::Relay(addr, _) => addr,
                                };
                                let wire_size = bytes.len();
                                let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;

                                // Deserialize envelope
                                let envelope: BraidEnvelope = match bincode::deserialize(&bytes) {
                                    Ok(env) => env,
                                    Err(_) => continue,
                                };

                                // [PIPELINE STEP 3] Static envelope constraints: size and clock skew
                                if let Err(e) = envelope.validate_envelope(now_ms, wire_size) {
                                    eprintln!("[DROP] Validation failure from {}: {}", src, e);
                                    continue;
                                }

                                // [PIPELINE STEP 4] Wire protocol version check
                                if envelope.version != WIRE_PROTOCOL_VERSION {
                                    eprintln!("[DROP] Wire protocol version mismatch: expected {}, received {}", WIRE_PROTOCOL_VERSION, envelope.version);
                                    continue;
                                }

                                // [PIPELINE STEP 5] Supported signature scheme check
                                if envelope.signature_scheme != SCHEME_ED25519 {
                                    eprintln!("[DROP] Unsupported signature scheme: {}", envelope.signature_scheme);
                                    continue;
                                }

                                // Enforce codec fields validation before processing
                                if envelope.wire_encoding != protocol::ENCODING_BINCODE {
                                    eprintln!("[DROP] Unsupported wire encoding format: {}", envelope.wire_encoding);
                                    continue;
                                }

                                // Self-filtering: Reject packets from our exact local node/session combination
                                if envelope.node_id == local_node_id && envelope.session_id == local_session_id {
                                    continue;
                                }

                                // [PIPELINE STEP 6 & 7] NodeId derivation check and Cryptographic signature verification
                                if !envelope.verify_signature() {
                                    eprintln!("[DROP] Cryptographic signature INVALID from {}", src);
                                    continue;
                                }

                                // [PIPELINE STEP 14] Peer admission policy: Handle PairingPending states (v0.8.2)
                                {
                                    let mut policy = rx_policy.lock().await;
                                    match policy.check_admission(envelope.node_id) {
                                        Admission::Allowed => {
                                            // Proceed normally!
                                        }
                                        Admission::Denied => {
                                            eprintln!("[DROP] Policy blocked connection from Node ID: {}", format_hex(&envelope.node_id));
                                            continue;
                                        }
                                        Admission::Pending => {
                                            println!("[PAIRING PENDING] Peer ID [{}] entered pending pairing state.", &format_hex(&envelope.node_id)[..12]);
                                            let _ = rx_app_handle.emit_all("trust-policy-updated", policy.get_policy_json());
                                            continue; // Drop packet until peer is explicitly allowed/trusted!
                                        }
                                    }
                                }

                                // [PIPELINE STEP 8] Known message type check (match explicitly)
                                match envelope.message_type {
                                    MSG_DISCOVERY_BEACON => {
                                        if let Ok(beacon) = bincode::deserialize::<BraidDiscoveryBeacon>(&envelope.payload) {
                                            // [PIPELINE STEP 9 & 10] Payload codec check & message-specific validation
                                            if let Err(e) = validate_beacon(&envelope, &beacon) {
                                                eprintln!("[DROP] Invalid discovery beacon from {}: {}", src, e);
                                                continue;
                                            }

                                            // [PIPELINE STEP 11] Unified Replay check and commit
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            // [PIPELINE STEP 12] Peer admission policy with Capability Negotiation
                                            let (is_new, should_handshake, clamped_ttl) = {
                                                let mut table = rx_peer_table.lock().await;
                                                if table.len() >= MAX_PEERS && !table.contains_key(&envelope.node_id) {
                                                    eprintln!("[DROP] Peer table full. Rejecting new node.");
                                                    continue;
                                                }

                                                let is_new = !table.contains_key(&envelope.node_id);
                                                let clamped_ttl = beacon.ttl_ms.clamp(5_000, 60_000);

                                                let preferred_vector_encoding = if beacon.capabilities & CAP_VECTOR_QINT8 != 0 {
                                                    VECTOR_ENCODING_QINT8
                                                } else {
                                                    VECTOR_ENCODING_RAW_F32
                                                };

                                                let record = route::PeerRecord {
                                                    node_id: envelope.node_id,
                                                    observed_addr: src,
                                                    status: route::PeerStatus::Active,
                                                    protocol_version: envelope.version,
                                                    capabilities: beacon.capabilities,
                                                    vector_dim: beacon.vector_dim,
                                                    session_id: beacon.session_id,
                                                    last_seen_ms: now_ms,
                                                    expires_at_ms: now_ms + clamped_ttl as u64,
                                                    highest_sequence: envelope.sequence,
                                                    round_trip_latency_ms: 0,
                                                    preferred_vector_encoding,
                                                };
                                                table.insert(envelope.node_id, record);

                                                if is_new {
                                                    println!(
                                                        "\n[DISCOVERY] Admitted peer [{}] at {} (Advertised port: {}, Preferred codec: {})",
                                                        &format_hex(&envelope.node_id)[..12],
                                                        src,
                                                        beacon.listen_port,
                                                        if preferred_vector_encoding == VECTOR_ENCODING_QINT8 { "INT8" } else { "RAW_F32" }
                                                    );
                                                    let mut flat = rx_peers.lock().await;
                                                    let src_str = src.to_string();
                                                    if !flat.contains(&src_str) {
                                                        flat.push(src_str);
                                                    }
                                                }

                                                let mut acks = rx_last_sent_acks.lock().await;
                                                let last_sent = acks.entry(envelope.node_id).or_insert(0);
                                                let should_handshake = is_new || now_ms - *last_sent > ACK_RATE_LIMIT_MS;
                                                if should_handshake {
                                                    *last_sent = now_ms;
                                                }
                                                (is_new, should_handshake, clamped_ttl)
                                            };

                                            if should_handshake {
                                                let seq = rx_sequence_counter.fetch_add(1, Ordering::SeqCst);
                                                let discovery_payload = BraidDiscoveryBeacon {
                                                    session_id: local_session_id,
                                                    capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_VECTOR_QINT8,
                                                    vector_dim: EXPECTED_VECTOR_DIM as u16,
                                                    max_packet_size: MAX_PACKET_SIZE as u16,
                                                    listen_port: local_port,
                                                    ttl_ms: clamped_ttl,
                                                };
                                                if let Ok(serialized_beacon) = bincode::serialize(&discovery_payload) {
                                                    if let Ok(handshake) = BraidEnvelope::create(
                                                        MSG_DISCOVERY_ACK,
                                                        VECTOR_ENCODING_RAW_F32,
                                                        local_session_id,
                                                        seq,
                                                        now_ms,
                                                        serialized_beacon,
                                                        rx_provider_clone.as_ref(),
                                                    ) {
                                                        let ser_handshake = bincode::serialize(&handshake).unwrap();
                                                        let _ = tx_transport_clone.send_to(&ser_handshake, BraidEndpoint::Direct(src)).await;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    MSG_DISCOVERY_ACK => {
                                        if let Ok(beacon) = bincode::deserialize::<BraidDiscoveryBeacon>(&envelope.payload) {
                                            if let Err(e) = validate_beacon(&envelope, &beacon) {
                                                eprintln!("[DROP] Invalid discovery ACK from {}: {}", src, e);
                                                continue;
                                            }

                                            // Unified Replay check and commit
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            let mut table = rx_peer_table.lock().await;
                                            let is_new = !table.contains_key(&envelope.node_id);
                                            let clamped_ttl = beacon.ttl_ms.clamp(5_000, 60_000);

                                            let preferred_vector_encoding = if beacon.capabilities & CAP_VECTOR_QINT8 != 0 {
                                                VECTOR_ENCODING_QINT8
                                            } else {
                                                VECTOR_ENCODING_RAW_F32
                                            };

                                            let record = route::PeerRecord {
                                                node_id: envelope.node_id,
                                                observed_addr: src,
                                                status: route::PeerStatus::Active,
                                                protocol_version: envelope.version,
                                                capabilities: beacon.capabilities,
                                                vector_dim: beacon.vector_dim,
                                                session_id: beacon.session_id,
                                                last_seen_ms: now_ms,
                                                expires_at_ms: now_ms + clamped_ttl as u64,
                                                highest_sequence: envelope.sequence,
                                                round_trip_latency_ms: 0,
                                                preferred_vector_encoding,
                                            };
                                            table.insert(envelope.node_id, record);

                                            if is_new {
                                                println!(
                                                    "\n[DISCOVERY] Registered Handshake [{}] at {} (Advertised port: {}, Preferred codec: {})",
                                                    &format_hex(&envelope.node_id)[..12],
                                                    src,
                                                    beacon.listen_port,
                                                    if preferred_vector_encoding == VECTOR_ENCODING_QINT8 { "INT8" } else { "RAW_F32" }
                                                );
                                                let mut flat = rx_peers.lock().await;
                                                let src_str = src.to_string();
                                                if !flat.contains(&src_str) {
                                                    flat.push(src_str);
                                                }
                                            }
                                        }
                                    }
                                    MSG_STATE_DRIFT => {
                                        // Gating check for unsupported state vector encoding (BLOCKER 3 RESOLVED)
                                        if envelope.state_vector_encoding != VECTOR_ENCODING_RAW_F32
                                            && envelope.state_vector_encoding != VECTOR_ENCODING_QINT8
                                        {
                                            eprintln!("[DROP] Unsupported state vector encoding: {}", envelope.state_vector_encoding);
                                            continue;
                                        }

                                        // [ADMISSION GATE] Reject state drift from undiscovered or non-active peers!
                                        let expected_dim = {
                                            let table = rx_peer_table.lock().await;
                                            if let Some(record) = table.get(&envelope.node_id) {
                                                if record.status != route::PeerStatus::Active && record.status != route::PeerStatus::Verified {
                                                    eprintln!("[DROP] State drift from non-active peer {}", src);
                                                    continue;
                                                }
                                                if record.capabilities & CAP_STATE_DRIFT == 0 {
                                                    eprintln!("[DROP] Peer lacks state drift capability {}", src);
                                                    continue;
                                                }
                                                record.vector_dim as usize
                                            } else {
                                                eprintln!("[DROP] State drift from undiscovered peer {}", src);
                                                continue;
                                            }
                                        };

                                        // Decouple wire format based on negotiated state_vector_encoding 
                                        let latent_vector = if envelope.state_vector_encoding == VECTOR_ENCODING_QINT8 {
                                            if let Ok(quant) = bincode::deserialize::<BraidStateDriftQuant>(&envelope.payload) {
                                                if quant.values.len() != expected_dim {
                                                    eprintln!("[DROP] Quantized vector length mismatch: expected {}, received {}", expected_dim, quant.values.len());
                                                    continue;
                                                }
                                                if !quant.scale.is_finite() || quant.scale <= 0.0 {
                                                    eprintln!("[DROP] Quantized vector has invalid scale: {}", quant.scale);
                                                    continue;
                                                }
                                                let dequant = quant.dequantize();
                                                if dequant.iter().any(|v| !v.is_finite()) {
                                                    eprintln!("[DROP] Dequantized vector contains NaN or Infinity");
                                                    continue;
                                                }
                                                dequant
                                            } else {
                                                continue;
                                            }
                                        } else {
                                            if let Ok(drift) = bincode::deserialize::<BraidStateDrift>(&envelope.payload) {
                                                drift.latent_vector
                                            } else {
                                                continue;
                                            }
                                        };

                                        if latent_vector.len() != expected_dim {
                                            eprintln!("[DROP] Dimension mismatch: expected {}, received {}", expected_dim, latent_vector.len());
                                            continue;
                                        }

                                        if latent_vector.iter().any(|v| !v.is_finite()) {
                                            continue;
                                        }

                                        // Unified Replay check (Only commit after payload fully validated!)
                                        if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                            eprintln!("{}", e);
                                            continue;
                                        }

                                        {
                                            let mut vec_guard = rx_latest_vector.lock().await;
                                            *vec_guard = latent_vector.clone();
                                        }

                                        // Extend liveness lease on valid state drift packet arrival
                                        {
                                            let mut table = rx_peer_table.lock().await;
                                            if let Some(record) = table.get_mut(&envelope.node_id) {
                                                record.last_seen_ms = now_ms;
                                                record.expires_at_ms = now_ms + 15_000;
                                                record.highest_sequence = envelope.sequence;
                                                record.status = route::PeerStatus::Active;
                                            }
                                        }

                                        let hex_node = format_hex(&envelope.node_id);
                                        let payload = serde_json::json!({
                                            "node_id": hex_node,
                                            "timestamp": envelope.timestamp,
                                            "sequence_id": envelope.sequence,
                                            "latent_vector": latent_vector,
                                            "sender_address": src.to_string(),
                                            "byte_size": wire_size,
                                        });
                                        let _ = rx_app_handle.emit_all("udp-packet-received", payload);
                                    }
                                    MSG_PEER_GOODBYE => {
                                        // Unified Replay check
                                        if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                            eprintln!("{}", e);
                                            continue;
                                        }

                                        let mut table = rx_peer_table.lock().await;
                                        if table.remove(&envelope.node_id).is_some() {
                                            let hex_node = format_hex(&envelope.node_id);
                                            println!("[PRUNE] Peer graceful exit: Node [{}] left", &hex_node[..12]);
                                            let mut flat = rx_peers.lock().await;
                                            flat.retain(|addr| *addr != src.to_string());
                                            
                                            // REFINEMENT: Explicit session and route candidate table cleanup on Goodbye!
                                            {
                                                let mut sessions = rx_session_table.lock().await;
                                                if sessions.remove(&envelope.node_id).is_some() {
                                                    println!("[PRUNE] Cleared active cryptographic Session for Node [{}]", &hex_node[..12]);
                                                }
                                            }
                                            {
                                                let mut routes = rx_route_table.lock().await;
                                                if routes.remove(&envelope.node_id).is_some() {
                                                    println!("[PRUNE] Cleared multi-path WAN Route Candidates for Node [{}]", &hex_node[..12]);
                                                }
                                            }
                                        }
                                    }
                                    MSG_RELAY_FORWARD => {
                                        // Deserialize the inner RelayFrame
                                        if let Ok(relay_frame) = bincode::deserialize::<relay::RelayFrame>(&envelope.payload) {
                                            // Validate Relay Frame Expiry
                                            if let Err(e) = relay_frame.validate_frame(now_ms) {
                                                eprintln!("[DROP] Relay frame has expired or is invalid: {}", e);
                                                continue;
                                            }

                                            // Origin/outer sender match
                                            if relay_frame.origin_sender != envelope.node_id {
                                                eprintln!("[DROP] Relay frame origin sender mismatch");
                                                continue;
                                            }

                                            // Deserialize inner envelope for verification
                                            if let Ok(inner_envelope) = bincode::deserialize::<BraidEnvelope>(&relay_frame.inner_envelope_bytes) {
                                                // Inner envelope sender match
                                                if inner_envelope.node_id != relay_frame.origin_sender {
                                                    eprintln!("[DROP] Inner envelope signed node ID mismatch");
                                                    continue;
                                                }

                                                // Verify inner envelope's cryptographic signature
                                                if !inner_envelope.verify_signature() {
                                                    eprintln!("[DROP] Inner envelope signature verification FAILED");
                                                    continue;
                                                }

                                                // Check if we are the final recipient! (Pillar 4 Ingestion support)
                                                if relay_frame.final_recipient == local_node_id {
                                                    println!(
                                                        "[RELAY] Successfully received and unpacked relayed envelope of type {} from origin [{}]",
                                                        inner_envelope.message_type,
                                                        &format_hex(&relay_frame.origin_sender)[..12]
                                                    );

                                                    // Feed the decrypted/unpacked envelope back into our processing block!
                                                    match inner_envelope.message_type {
                                                        MSG_STATE_DRIFT => {
                                                            // Gating check for session readiness (P1 Priority)
                                                            let session_ready = {
                                                                let sessions = rx_session_table.lock().await;
                                                                sessions
                                                                    .get(&inner_envelope.node_id)
                                                                    .map(|s| s.state == SessionState::Ready)
                                                                    .unwrap_or(false)
                                                            };

                                                            if !session_ready {
                                                                eprintln!("[DROP] Relayed state drift from non-ready session");
                                                                continue;
                                                            }

                                                            // Gating check for unsupported state vector encoding (BLOCKER 3 RESOLVED)
                                                            if inner_envelope.state_vector_encoding != protocol::VECTOR_ENCODING_RAW_F32
                                                                && inner_envelope.state_vector_encoding != protocol::VECTOR_ENCODING_QINT8
                                                            {
                                                                eprintln!("[DROP] Relayed state vector encoding unsupported: {}", inner_envelope.state_vector_encoding);
                                                                continue;
                                                            }

                                                            let latent_vector = if inner_envelope.state_vector_encoding == VECTOR_ENCODING_QINT8 {
                                                                if let Ok(quant) = bincode::deserialize::<BraidStateDriftQuant>(&inner_envelope.payload) {
                                                                    if quant.values.len() != EXPECTED_VECTOR_DIM { continue; }
                                                                    if !quant.scale.is_finite() || quant.scale <= 0.0 { continue; }
                                                                    let dequant = quant.dequantize();
                                                                    if dequant.iter().any(|v| !v.is_finite()) { continue; }
                                                                    dequant
                                                                } else {
                                                                    continue;
                                                                }
                                                            } else {
                                                                if let Ok(drift) = bincode::deserialize::<BraidStateDrift>(&inner_envelope.payload) {
                                                                    drift.latent_vector
                                                                } else {
                                                                    continue;
                                                                }
                                                            };

                                                            if latent_vector.len() != EXPECTED_VECTOR_DIM {
                                                                continue;
                                                            }

                                                            {
                                                                let mut vec_guard = rx_latest_vector.lock().await;
                                                                *vec_guard = latent_vector.clone();
                                                            }

                                                            let payload = serde_json::json!({
                                                                "node_id": format_hex(&inner_envelope.node_id),
                                                                "timestamp": inner_envelope.timestamp,
                                                                "sequence_id": inner_envelope.sequence,
                                                                "latent_vector": latent_vector,
                                                                "sender_address": format!("relayed-via:{}", src),
                                                                "byte_size": inner_envelope.payload.len(),
                                                            });
                                                            let _ = rx_app_handle.emit_all("udp-packet-received", payload);
                                                        }
                                                        _ => {
                                                            eprintln!("[WARN] Relayed message type {} currently unhandled at final recipient", inner_envelope.message_type);
                                                        }
                                                    }
                                                } else {
                                                    // [PIPELINE STEP 14] Peer admission policy: Verify sender is in local trust policy allowlist (P2 Priority)
                                                    let is_allowed = {
                                                        let mut policy = rx_policy.lock().await;
                                                        matches!(policy.check_admission(envelope.node_id), Admission::Allowed)
                                                    };
                                                    if !is_allowed {
                                                        eprintln!("[DROP] Relay forwarding rejected: sender [{}] is not allowed/trusted", format_hex(&envelope.node_id));
                                                        continue;
                                                    }

                                                    // We are a transit forwarder carrier (CAP_RELAY_FORWARD check)
                                                    let local_capabilities = CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_RELAY_FORWARD | CAP_RELAY_SEND;
                                                    if local_capabilities & CAP_RELAY_FORWARD == 0 {
                                                        eprintln!("[DROP] Relay frame rejected: local node lacks CAP_RELAY_FORWARD");
                                                        continue;
                                                    }

                                                    let target_addr = {
                                                        let table = rx_peer_table.lock().await;
                                                        table.get(&relay_frame.final_recipient).map(|p| p.observed_addr)
                                                    };

                                                    if let Some(addr) = target_addr {
                                                        println!(
                                                            "[RELAY] Forwarding signed relay frame from [{}] to final recipient [{}] at {}",
                                                            &format_hex(&relay_frame.origin_sender)[..12],
                                                            &format_hex(&relay_frame.final_recipient)[..12],
                                                            addr
                                                        );
                                                        let _ = tx_transport_clone.send_to(&bytes, BraidEndpoint::Direct(addr)).await;
                                                    } else {
                                                        eprintln!("[DROP] No direct route to final recipient [{}].", format_hex(&relay_frame.final_recipient));
                                                    }
                                                }
                                            } else {
                                                eprintln!("[DROP] Failed to deserialize inner envelope");
                                                continue;
                                            }
                                        } else {
                                            eprintln!("[DROP] Failed to deserialize outer relay frame payload");
                                            continue;
                                        }
                                    }
                                    MSG_LINK_PROBE => {
                                        // [ADMISSION GATE] Only reply to probes from already admitted peers!
                                        {
                                            let table = rx_peer_table.lock().await;
                                            if !table.contains_key(&envelope.node_id) {
                                                eprintln!("[DROP] Link probe from unadmitted peer {}", src);
                                                continue;
                                            }
                                        }

                                        if let Ok(probe) = bincode::deserialize::<BraidLinkProbe>(&envelope.payload) {
                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            // Respond with directed LINK_PROBE_ACK immediately
                                            let seq = rx_sequence_counter.fetch_add(1, Ordering::SeqCst);
                                            let ack_payload = BraidLinkProbeAck {
                                                ping_seq: probe.ping_seq,
                                                tx_timestamp_ms: probe.tx_timestamp_ms,
                                                rx_timestamp_ms: now_ms,
                                            };
                                            if let Ok(serialized_ack) = bincode::serialize(&ack_payload) {
                                                if let Ok(ack_env) = BraidEnvelope::create(
                                                    MSG_LINK_PROBE_ACK,
                                                    VECTOR_ENCODING_RAW_F32,
                                                    local_session_id,
                                                    seq,
                                                    now_ms,
                                                    serialized_ack,
                                                    rx_provider_clone.as_ref(),
                                                ) {
                                                    let ser_bytes = bincode::serialize(&ack_env).unwrap();
                                                    let _ = tx_transport_clone.send_to(&ser_bytes, BraidEndpoint::Direct(src)).await;
                                                }
                                            }
                                        }
                                    }
                                    MSG_LINK_PROBE_ACK => {
                                        // [ADMISSION GATE] Only accept ACKs from admitted peers!
                                        {
                                            let table = rx_peer_table.lock().await;
                                            if !table.contains_key(&envelope.node_id) {
                                                continue;
                                            }
                                        }

                                        if let Ok(ack) = bincode::deserialize::<BraidLinkProbeAck>(&envelope.payload) {
                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            // Calculate latency and update path health telemetry
                                            let latency = now_ms.saturating_sub(ack.tx_timestamp_ms);
                                            let mut table = rx_peer_table.lock().await;
                                            if let Some(record) = table.get_mut(&envelope.node_id) {
                                                record.round_trip_latency_ms = latency;
                                                record.last_seen_ms = now_ms;
                                                record.expires_at_ms = now_ms + 15_000;
                                            }
                                        }
                                    }
                                    MSG_SESSION_HELLO => {
                                        if let Ok(hello) = bincode::deserialize::<SessionHello>(&envelope.payload) {
                                            if hello.target_node_id != local_node_id {
                                                eprintln!("[DROP] Hello packet targeted to wrong Node ID");
                                                continue;
                                            }

                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            // Save route candidate inside route_table
                                            let route_id = hello.route_id;
                                            {
                                                let mut routes = rx_route_table.lock().await;
                                                let candidates = routes.entry(envelope.node_id).or_insert_with(Vec::new);
                                                if !candidates.iter().any(|c| c.route_id == route_id) {
                                                    candidates.push(RouteCandidate {
                                                        route_id,
                                                        target_node_id: envelope.node_id,
                                                        transport: TransportKind::Udp,
                                                        endpoint: RouteEndpoint::Udp(src),
                                                        source: RouteSource::Presence,
                                                        verified_by_presence: true,
                                                        verified_by_session: false,
                                                        latency_ms: None,
                                                        failure_count: 0,
                                                        expires_at_ms: now_ms + 60_000,
                                                        state: RouteState::Verified,
                                                    });
                                                }
                                            }

                                            // Generate secure random challenge nonce_b
                                            let nonce_b: [u8; 32] = rand::random();

                                            // Save pending session state to rx_session_table
                                            {
                                                let mut sessions = rx_session_table.lock().await;
                                                sessions.insert(envelope.node_id, BraidSession {
                                                    peer_node_id: envelope.node_id,
                                                    session_id: [0u8; 16], // not yet verified
                                                    route_id,
                                                    established_at_ms: 0,
                                                    expires_at_ms: 0,
                                                    accepted_capabilities: hello.capabilities,
                                                    state: SessionState::Challenged,
                                                });
                                            }

                                            // Build and send MSG_SESSION_CHALLENGE back
                                            let challenge = SessionChallenge {
                                                initiator_node_id: envelope.node_id,
                                                responder_node_id: local_node_id,
                                                route_id,
                                                nonce_a: hello.nonce_a,
                                                nonce_b,
                                                accepted_capabilities: hello.capabilities,
                                                timestamp_ms: now_ms,
                                            };

                                            if let Ok(ser_challenge) = bincode::serialize(&challenge) {
                                                let seq = rx_sequence_counter.fetch_add(1, Ordering::SeqCst);
                                                if let Ok(challenge_env) = BraidEnvelope::create(
                                                    MSG_SESSION_CHALLENGE,
                                                    VECTOR_ENCODING_RAW_F32,
                                                    local_session_id,
                                                    seq,
                                                    now_ms,
                                                    ser_challenge,
                                                    rx_provider_clone.as_ref(),
                                                ) {
                                                    let ser_bytes = bincode::serialize(&challenge_env).unwrap();
                                                    let _ = tx_transport_clone.send_to(&ser_bytes, BraidEndpoint::Direct(src)).await;
                                                    println!("[SESSION] Dispatched session CHALLENGE back to initiator [{}]", &format_hex(&envelope.node_id)[..12]);
                                                }
                                            }
                                        }
                                    }
                                    MSG_SESSION_CHALLENGE => {
                                        if let Ok(challenge) = bincode::deserialize::<SessionChallenge>(&envelope.payload) {
                                            if challenge.initiator_node_id != local_node_id {
                                                eprintln!("[DROP] Challenge packet targeted to wrong Node ID");
                                                continue;
                                            }

                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            let route_id = challenge.route_id;
                                            
                                            // Update session state
                                            {
                                                let mut sessions = rx_session_table.lock().await;
                                                if let Some(session) = sessions.get_mut(&envelope.node_id) {
                                                    session.state = SessionState::Ready; // Ready for Response verification
                                                }
                                            }

                                            // Build and send MSG_SESSION_RESPONSE back
                                            let response = SessionResponse {
                                                route_id,
                                                nonce_a: challenge.nonce_a,
                                                nonce_b: challenge.nonce_b,
                                                timestamp_ms: now_ms,
                                            };

                                            if let Ok(ser_response) = bincode::serialize(&response) {
                                                let seq = rx_sequence_counter.fetch_add(1, Ordering::SeqCst);
                                                if let Ok(response_env) = BraidEnvelope::create(
                                                    MSG_SESSION_RESPONSE,
                                                    VECTOR_ENCODING_RAW_F32,
                                                    local_session_id,
                                                    seq,
                                                    now_ms,
                                                    ser_response,
                                                    rx_provider_clone.as_ref(),
                                                ) {
                                                    let ser_bytes = bincode::serialize(&response_env).unwrap();
                                                    let _ = tx_transport_clone.send_to(&ser_bytes, BraidEndpoint::Direct(src)).await;
                                                    println!("[SESSION] Dispatched session RESPONSE back to responder [{}]", &format_hex(&envelope.node_id)[..12]);
                                                }
                                            }
                                        }
                                    }
                                    MSG_SESSION_RESPONSE => {
                                        if let Ok(response) = bincode::deserialize::<SessionResponse>(&envelope.payload) {
                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            let route_id = response.route_id;
                                            let rand_session_id: [u8; 16] = rand::random();

                                            {
                                                let mut sessions = rx_session_table.lock().await;
                                                if let Some(session) = sessions.get_mut(&envelope.node_id) {
                                                    session.state = SessionState::Ready;
                                                    session.session_id = rand_session_id;
                                                    session.established_at_ms = now_ms;
                                                    session.expires_at_ms = now_ms + 3_600_000;
                                                }
                                            }

                                            // Update Peer Record to Verified Active inside Peer Table!
                                            {
                                                let mut peers = rx_peer_table.lock().await;
                                                let candidates = rx_route_table.lock().await;
                                                let vector_encoding = if let Some(route_list) = candidates.get(&envelope.node_id) {
                                                    route_list.iter().next().map(|r| r.preferred_vector_encoding).unwrap_or(VECTOR_ENCODING_RAW_F32)
                                                } else {
                                                    VECTOR_ENCODING_RAW_F32
                                                };

                                                peers.insert(envelope.node_id, route::PeerRecord {
                                                    node_id: envelope.node_id,
                                                    observed_addr: src,
                                                    status: route::PeerStatus::Verified,
                                                    protocol_version: envelope.version,
                                                    capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_VECTOR_QINT8,
                                                    vector_dim: EXPECTED_VECTOR_DIM as u16,
                                                    session_id: rand_session_id,
                                                    last_seen_ms: now_ms,
                                                    expires_at_ms: now_ms + 30_000,
                                                    highest_sequence: envelope.sequence,
                                                    round_trip_latency_ms: 0,
                                                    preferred_vector_encoding: vector_encoding,
                                                });
                                            }

                                            // Build and send MSG_SESSION_READY back
                                            let ready = SessionReady {
                                                route_id,
                                                session_id: rand_session_id,
                                                expires_at_ms: now_ms + 3_600_000,
                                            };

                                            if let Ok(ser_ready) = bincode::serialize(&ready) {
                                                let seq = rx_sequence_counter.fetch_add(1, Ordering::SeqCst);
                                                if let Ok(ready_env) = BraidEnvelope::create(
                                                    MSG_SESSION_READY,
                                                    VECTOR_ENCODING_RAW_F32,
                                                    local_session_id,
                                                    seq,
                                                    now_ms,
                                                    ser_ready,
                                                    rx_provider_clone.as_ref(),
                                                ) {
                                                    let ser_bytes = bincode::serialize(&ready_env).unwrap();
                                                    let _ = tx_transport_clone.send_to(&ser_bytes, BraidEndpoint::Direct(src)).await;
                                                    println!("[SESSION] Session HANDSHAKE COMPLETED (Responder) with peer [{}]!", &format_hex(&envelope.node_id)[..12]);
                                                }
                                            }
                                        }
                                    }
                                    MSG_SESSION_READY => {
                                        if let Ok(ready) = bincode::deserialize::<SessionReady>(&envelope.payload) {
                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            {
                                                let mut sessions = rx_session_table.lock().await;
                                                if let Some(session) = sessions.get_mut(&envelope.node_id) {
                                                    session.state = SessionState::Ready;
                                                    session.session_id = ready.session_id;
                                                    session.established_at_ms = now_ms;
                                                    session.expires_at_ms = ready.expires_at_ms;
                                                }
                                            }

                                            // Update Peer Record to Verified Active inside Peer Table!
                                            {
                                                let mut peers = rx_peer_table.lock().await;
                                                peers.insert(envelope.node_id, route::PeerRecord {
                                                    node_id: envelope.node_id,
                                                    observed_addr: src,
                                                    status: route::PeerStatus::Verified,
                                                    protocol_version: envelope.version,
                                                    capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_VECTOR_QINT8,
                                                    vector_dim: EXPECTED_VECTOR_DIM as u16,
                                                    session_id: ready.session_id,
                                                    last_seen_ms: now_ms,
                                                    expires_at_ms: now_ms + 30_000,
                                                    highest_sequence: envelope.sequence,
                                                    round_trip_latency_ms: 0,
                                                    preferred_vector_encoding: VECTOR_ENCODING_RAW_F32,
                                                });
                                            }

                                            println!("[SESSION] Session HANDSHAKE COMPLETED (Initiator) with peer [{}]!", &format_hex(&envelope.node_id)[..12]);
                                        }
                                    }
                                    other_type => {
                                        eprintln!("[WARN] Received unsupported message type {} from {}", other_type, src);
                                    }
                                }
                            }
                            Err(_) => {
                                tokio::time::sleep(tokio::time::Duration::from_millis(50)).await;
                            }
                        }
                    }
                });

                // 2. Spawns background discovery broadcast beacon loop with Jitter (±500ms)
                let tx_discovery_transport = Arc::clone(&transport);
                let tx_targets = discovery_targets;
                let tx_sequence_counter = Arc::clone(&sequence_counter);
                let tx_provider = Arc::clone(&identity_provider);

                tokio::spawn(async move {
                    let base_ms = 3000u64;
                    loop {
                        let jitter = rand::thread_rng().gen_range(-500..=500);
                        let sleep_ms = (base_ms as i32 + jitter) as u64;
                        tokio::time::sleep(tokio::time::Duration::from_millis(sleep_ms)).await;
                        
                        let timestamp = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
                        let seq = tx_sequence_counter.fetch_add(1, Ordering::SeqCst);

                        let discovery_payload = BraidDiscoveryBeacon {
                            session_id: local_session_id,
                            capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_VECTOR_QINT8,
                            vector_dim: EXPECTED_VECTOR_DIM as u16,
                            max_packet_size: MAX_PACKET_SIZE as u16,
                            listen_port: local_port,
                            ttl_ms: 15000,
                        };

                        if let Ok(serialized_beacon) = bincode::serialize(&discovery_payload) {
                            if let Ok(beacon_envelope) = BraidEnvelope::create(
                                MSG_DISCOVERY_BEACON,
                                VECTOR_ENCODING_RAW_F32,
                                local_session_id,
                                seq,
                                timestamp,
                                serialized_beacon,
                                tx_provider.as_ref(),
                            ) {
                                let ser_bytes = bincode::serialize(&beacon_envelope).unwrap();
                                for peer_addr in tx_targets.iter() {
                                    let _ = tx_discovery_transport.send_to(&ser_bytes, BraidEndpoint::Direct(*peer_addr)).await;
                                }
                            }
                        }
                    }
                });

                // 3. Spawns path health Link Probe thread (loops every 5 seconds)
                let tx_probe_transport = Arc::clone(&transport);
                let tx_probe_table = Arc::clone(&peer_table);
                let tx_probe_sequence = Arc::clone(&sequence_counter);
                let tx_probe_provider = Arc::clone(&identity_provider);
                tokio::spawn(async move {
                    let mut probe_seq = 1u64;
                    loop {
                        tokio::time::sleep(tokio::time::Duration::from_secs(5)).await;
                        let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
                        
                        // Collect peer coordinates
                        let targets = {
                            let table = tx_probe_table.lock().await;
                            table.values()
                                .filter(|r| r.status == route::PeerStatus::Active || r.status == route::PeerStatus::Verified)
                                .map(|r| (r.observed_addr, r.node_id))
                                .collect::<Vec<(SocketAddr, NodeId)>>()
                        };

                        for (addr, _id) in targets {
                            let seq = tx_probe_sequence.fetch_add(1, Ordering::SeqCst);
                            let probe_payload = BraidLinkProbe {
                                ping_seq: probe_seq,
                                tx_timestamp_ms: now_ms,
                            };
                            if let Ok(serialized) = bincode::serialize(&probe_payload) {
                                if let Ok(probe_env) = BraidEnvelope::create(
                                    MSG_LINK_PROBE,
                                    VECTOR_ENCODING_RAW_F32,
                                    local_session_id,
                                    seq,
                                    now_ms,
                                    serialized,
                                    tx_probe_provider.as_ref(),
                                ) {
                                    let ser_bytes = bincode::serialize(&probe_env).unwrap();
                                    let _ = tx_probe_transport.send_to(&ser_bytes, BraidEndpoint::Direct(addr)).await;
                                }
                            }
                        }
                        probe_seq += 1;
                    }
                });

                // 4. Spawns peer table TTL expiration cleanup loop (runs every 5s)
                let tx_cleanup_peer_table = Arc::clone(&peer_table);
                let tx_cleanup_flat_peers = Arc::clone(&peers);
                tokio::spawn(async move {
                    let mut interval = tokio::time::interval(tokio::time::Duration::from_secs(5));
                    loop {
                        interval.tick().await;
                        let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
                        
                        let mut expired_peers = Vec::new();
                        {
                            let mut table = tx_cleanup_peer_table.lock().await;
                            table.retain(|sender_id, val| {
                                if now_ms > val.expires_at_ms {
                                    let hex_node = format_hex(sender_id);
                                    println!("[PRUNE] Peer expired (TTL): {} at {}", &hex_node[..12], val.observed_addr);
                                    expired_peers.push(val.observed_addr.to_string());
                                    false
                                } else {
                                    true
                                }
                            });
                        }

                        // Update flat list matching table
                        if !expired_peers.is_empty() {
                            let mut peer_list = tx_cleanup_flat_peers.lock().await;
                            peer_list.retain(|addr| !expired_peers.contains(addr));
                        }
                    }
                });

                // Manage AppState
                handle.manage(app_state_arc);
            });

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_node_info,
            get_peers,
            stream_state_drift,
            get_trust_policy,
            approve_peer_trust,
            deny_peer_trust,
            remove_peer_trust,
            set_trust_mode
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}

#[cfg(test)]
mod tests {
    #[test]
    fn main_status_stale_test() {
        assert!(true);
    }
}
