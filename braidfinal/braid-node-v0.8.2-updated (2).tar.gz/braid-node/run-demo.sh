#!/usr/bin/env sh
set -e

echo "====================================================================="
echo "   Executing Braid Tendril v0.8.2 Peering & Vector Transfer Demo"
echo "====================================================================="
echo

# 1. Start the standard simulated handshake and state drift session
./braid demo

echo
echo "====================================================================="
echo "   Executing Real Socket-Based Vector Transfer Verification"
echo "====================================================================="
echo

# 2. Run the actual local UDP loopback vector transfer 
./braid vector-transfer --real-local
