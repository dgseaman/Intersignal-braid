# Archangel a6 - Composer Fix 1: verification

Version: `1.7.0a6+composer1`. Date: September 7, 2026.

## Scope and findings

The original a6 composer silently substituted the saved draft whenever its
new-message function was called without an explicit payload. X/close saved the
same draft again. Its New handoff action minted a new ID but retained the old
text/type, including signed-delta mode. This fix separates new-message entry
points from explicit Drafts resume and adds explicit draft discard.

The original reopen loop was reproduced in Chromium with the actual production
HTML/JS and a synthetic saved delta. Native Safari's separately reported failure
to dismiss was not reproduced here: closing itself worked in the baseline
Chromium fixture. The fixed X/Escape actions and removal of late close autosave
were tested, but no native Safari claim is made.

## Executed on the final source / wheel

- 338 retained Python tests passed, plus six subtests (see full-final.txt).
- 32 fixed-composer browser checks passed, with three additional baseline and
  workaround observations (35 recorded checks total). Coverage includes blank
  Share summary/N, explicit Drafts restore, read-only deltas, new IDs without
  old delta linkage, X/Escape, draft replacement confirmation, failed saves,
  discard preserving history, successful send cleanup, partial-recipient and
  unknown-outcome locks, in-flight dismissal/reopening, and 320-1280px widths.
- Retained delivery-browser assertions passed after changing only their
  explicit resume entry point from Share summary to Drafts. Their accepted and
  unknown recipient locks, retry-only-rejected behavior, and keyboard
  assertions were retained.
- Nine targeted database/delivery/backend tests passed in a separate rerun.
- Sixteen installed-wheel launcher/HTTP/lifecycle checks passed, including
  restart retaining identity, channel, and thread; cooperative stop; duplicate
  launcher handling; version marker; and bundle verification.
- Sixteen Mac runtime-discovery tests passed against the unchanged launcher
  using simulated install paths on Linux. The actual launcher --check also
  passed with CPython 3.13.5 on Linux.
- Wheel RECORD and bundle support hashes passed. Source-to-wheel comparison
  confirms 42 application files are byte-identical
  to a6. Changes are messenger.js, messenger.html, messenger.css (scoped footer
  wrapping), and __init__.py (version only). All other Python application
  modules, including receiver, transport, channel, field, and delivery-ledger
  code, are unchanged.

The two release-specific Python version assertions were updated to the explicit
local package version. The source-version and launcher-version changes ensure
an old a6 runtime cannot silently satisfy the fixed bundle. No new backend
schema, key rotation, protocol negotiation, or model dependency was added.

## Limits

The browser executes shipping HTML/CSS/JS with explicit synthetic API responses
and a secure-context UUID shim in an offline Chromium document. Browser sends
are simulated; no physical two-rig transfer is claimed. The retained Python
suite exercises real local HTTP/TLS and cryptographic operations around fixture
models. It does not substitute for real Ollama or native Mac/Windows tests.

The installed wheel was exercised in the launcher's explicit host-dependency
mode (not isolated). No fresh upstream dependency download, new native Mac run,
Windows GUI/ACL test, or public hosting test was performed. Prior tool-bounded
suite invocations were interrupted and are not counted as passing runs; the
completed final logs and zero-exit-status records are supplied separately.

The existing failed delta's detailed error was not present in the screenshots.
This fix does not diagnose that separate preparation failure. The failed entry
remains in Sent/Needs attention. Failed preparation is pre-network; it is not
proof of receiver replay rejection. Discarding a draft never clears delivery
history, accepted state, or uncertain-outcome locks.

No production website, Google Drive object, installed user profile, or a7
member preview was modified remotely. This remains an engineering alpha.

## Reproduce

From the fixed source with existing development dependencies:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONPATH=. python -m pytest -q tests --disable-warnings
python tests/browser_composer_fix.py /path/to/original-a6-source ./composer-evidence
python tests/browser_archangel.py ./retained-browser
python tests/installed_channels_smoke.py /path/to/fixed-release ./installed-evidence
```

Browser tests require Playwright/Chromium. The source bundle is not a replacement
for the complete installer bundle. Use temporary test profiles, not your live
profile. Final app wheel SHA-256:

`19daebb9219c65206bb6c554cfced39ca355f163bdfba6e2c427be4d9ddc30f4`
