"""Read-only release ZIP/wheel consistency checker. Does not execute the app."""
import argparse,base64,csv,hashlib,io,json,sys,zipfile
from pathlib import Path

def verify(root):
    root=Path(root);checks=[]
    def check(name,value):
        checks.append({'name':name,'passed':bool(value)})
        if not value:raise AssertionError(name)
    manifest=json.loads((root/'bundle-manifest.json').read_text())
    check('1.8 release identity',manifest['version']=='1.8.0')
    wheel=root/manifest['wheel'];digest=hashlib.sha256(wheel.read_bytes()).hexdigest()
    check('wheel hash',digest==manifest['sha256'])
    for name,value in manifest['support_files'].items():
        check('support '+name,Path(name).name==name and hashlib.sha256((root/name).read_bytes()).hexdigest()==value)
    with zipfile.ZipFile(wheel) as z:
        check('wheel ZIP integrity',z.testzip() is None)
        check('no executable runtime state in wheel',not any(n.endswith(('.pem','.sqlite3','.pyc')) or '__pycache__' in n for n in z.namelist()))
        for name in ('channel_protocol.py','channels.py','channel_chat.py','channel_optical.py','static/channels.js','static/channels.css'):
            check('packaged '+name,'braid_client/'+name in z.namelist())
        record=next(n for n in z.namelist() if n.endswith('.dist-info/RECORD'))
        count=0
        for name,h,size in csv.reader(io.StringIO(z.read(record).decode())):
            if not h:continue
            payload=z.read(name);actual='sha256='+base64.urlsafe_b64encode(hashlib.sha256(payload).digest()).decode().rstrip('=')
            if actual!=h or len(payload)!=int(size):raise AssertionError('Invalid wheel RECORD: '+name)
            count+=1
        check('all wheel RECORD entries',count>40)
        check('metadata version',b'Version: 1.8.0' in z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))))
    return {'passed':True,'checks':checks,'wheel_sha256':digest,'record_entries_verified':count}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('directory',type=Path);p.add_argument('--report',type=Path);a=p.parse_args()
    r=verify(a.directory);text=json.dumps(r,indent=2);print(text)
    if a.report:a.report.write_text(text+'\n')
