# Braid Changelog

## Braid Tendril v0.8.2-alpha — July 3, 2026
*   **Decentralized Signed-Presence Rendezvous**: Sockets and route hints are dynamically advertised and verified via signed `BraidPresenceRecord` packets containing raw cryptographic `public_material` and absolute lease expirations (`expires_at_ms`).
*   **Presence Signature Verification**: Node identity signatures inside presence announcements are verified directly against their supplied `public_material` rather than just assuming key bytes from NodeId.
*   **NodeId-First Routing**: Fully decoupled transport and session logic from direct socket addresses, routing exclusively based on `NodeId`. Implemented `send_to_node(NodeId, envelope)` dynamic route resolution.
*   **Message-Type-Keyed Replay Ledger**: Bounded replay ledgers track sequences independently across each message type to prevent inter-protocol sequence interference.
*   **Transit Relay Forwarding & Ingestion**: Built real transit packet forwarding via signed `BraidRelayFrame` envelopes supporting target NodeId routing, sender tracking, and absolute TTL expirations to prevent loop leaks. Supports final-recipient inline packet ingestion.
*   **Quantized INT8 State Decompression**: Rebuilt the QINT8 decompression path inside the receiver loop to seamlessly decompress and synchronize 384-dimension state vectors.
*   **Handshake Session State Machine**: Integrated full cryptographic multi-message WAN session handshake sequences over active route candidates.
*   **Persistent Trust Policies & Pairing Pending**: Implemented persistent `trust_policy.json` to manage trusted, denied, and pending pairing states.
*   **Portable Conformance Verification**: Shipped a clean, executable `conformance_verify.py` script that validates protocol compliance down to the byte.
