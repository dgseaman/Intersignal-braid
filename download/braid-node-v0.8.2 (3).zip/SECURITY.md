# Braid Security Policy & Hardened Controls

Braid is designed from the ground up for absolute OpSec, localized data sovereignty, and hardware-enclosed operations.

## Hardened Security Controls (v0.8.2 / Wire Protocol 8)

Braid Tendril establishes a robust, highly resilient cryptographic fence at the wide-area network (WAN) boundary:

1.  **Pre-Deserialization Buffer Ceiling**: Receivers enforce a strict `2048` byte UDP packet limit directly on the socket stream. Any buffer reading exceeding this MTU limit is dropped prior to deserialization, defending the host from memory inflation and CPU-exhaustion vectors.
2.  **Stable Hash-Derived Node Identity**: Node IDs are modeled as fixed 32-byte hash structures, derived dynamically from the signature scheme and public key bytes:
    $$\text{NodeId} = \text{SHA256}(\text{"braid-node-id-v1"} \mathbin{\Vert} \text{scheme\_id} \mathbin{\Vert} \text{public\_material})$$
3.  **Untrusted Signed-Presence Registry**: Sockets and route hints are published as signed `BraidPresenceRecord` announcements containing raw public key materials and absolute expirations (`expires_at_ms`). Edge nodes verify presence authenticity directly against these keys before updating rendezvous stores.
4.  **Message-Type-Keyed Replay Ledger**: Protects state against cross-protocol replay threats by tracking sequence numbers independently per message type.
5.  **Transit Relay Forwarding**: Built real transit packet forwarding via signed `BraidRelayFrame` envelopes supporting target NodeId routing, sender tracking, and absolute TTL expirations to prevent loop leaks.
6.  **Persistent Trust & Pairing Pending (v0.8.2)**: Integrates local peer trust configurations into a persistent `trust_policy.json` manifest. Any unknown node in Manual or Pinned mode is dynamically placed in a `PairingPending` state rather than being silently admitted, requiring explicit user/admin action to approve.
7.  **One-Hop Conservative Relay Forwarding bounds (v0.8.2)**: Hardens transit relaying to prevent multi-hop routing, loop injection, or signed-frame tampering. Relays verify that the sender possesses the `CAP_RELAY_SEND` capability and is allowed in local trust policies, that the inner envelope is completely unmutated and authentic, and that the relay holds a direct connection candidate for the final recipient.

## Reporting Vulnerabilities

Please report verified security flaws or protocol exploits directly to our trust team:
*   Email: `missy@intersignal.ai`
