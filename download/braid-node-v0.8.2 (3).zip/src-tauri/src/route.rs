use serde::{Serialize, Deserialize};
use std::net::SocketAddr;
use crate::protocol::NodeId;

// =====================================================================
// MULTI-PATH WAN ROUTING ENGINE (Pillar 4)
// =====================================================================

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq)]
pub enum TransportKind {
    Udp,
    Relay,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]
pub enum RouteEndpoint {
    Udp(SocketAddr),
    Relay { relay_node_id: NodeId, target_endpoint: String },
}

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq)]
pub enum RouteSource {
    Discovery,
    Presence,
    Manual,
}

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq)]
pub enum RouteState {
    Probing,
    Verified,
    Failed,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]
pub struct RouteCandidate {
    pub route_id: [u8; 16],
    pub target_node_id: NodeId,
    pub transport: TransportKind,
    pub endpoint: RouteEndpoint,
    pub source: RouteSource,
    pub verified_by_presence: bool,
    pub verified_by_session: bool,
    pub latency_ms: Option<u64>,
    pub failure_count: u32,
    pub expires_at_ms: u64,
    pub state: RouteState,
}
