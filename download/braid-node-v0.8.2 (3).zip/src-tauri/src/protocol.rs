use serde::{Serialize, Deserialize};
use ed25519_dalek::{VerifyingKey, Signature};
use sha2::{Sha256, Digest};
use std::net::SocketAddr;
use async_trait::async_trait;

pub const WIRE_PROTOCOL_VERSION: u16 = 8; // Braid Tendril Wire Protocol v8

// Message Type Registries
pub const MSG_STATE_DRIFT: u16 = 1;
pub const MSG_HEARTBEAT: u16 = 2; 
pub const MSG_DISCOVERY_BEACON: u16 = 3;
pub const MSG_DISCOVERY_ACK: u16 = 4;
pub const MSG_PEER_GOODBYE: u16 = 5; 
pub const MSG_LINK_PROBE: u16 = 6;   
pub const MSG_LINK_PROBE_ACK: u16 = 7; 

// Session Handshake Messages (Pillar 3)
pub const MSG_SESSION_HELLO: u16 = 8;
pub const MSG_SESSION_CHALLENGE: u16 = 9;
pub const MSG_SESSION_RESPONSE: u16 = 10;
pub const MSG_SESSION_READY: u16 = 11;
pub const MSG_SESSION_CLOSE: u16 = 12;

// Relay Messages (Pillar 4)
pub const MSG_RELAY_FORWARD: u16 = 13;

// Pluggable Cryptography Registries
pub const SCHEME_UNKNOWN: u16 = 0;
pub const SCHEME_ED25519: u16 = 1; 

// Wire Encodings Namespace
pub const ENCODING_UNKNOWN: u16 = 0;
pub const ENCODING_BINCODE: u16 = 1;         // Outer transport serialization format
pub const ENCODING_CANONICAL_PACKED: u16 = 2; // Preimage signing/verification packed spec

// State Vector Encodings Namespace
pub const VECTOR_ENCODING_RAW_F32: u16 = 1; 
pub const VECTOR_ENCODING_RAW_F16: u16 = 2; 
pub const VECTOR_ENCODING_QINT8: u16 = 3;   

// Protocol Constants
pub const MAX_PACKET_SIZE: usize = 2048; 
pub const EXPECTED_VECTOR_DIM: usize = 384; 
pub const MAX_TIMESTAMP_DRIFT_SECS: u64 = 60; 

// Capability Bits
pub const CAP_STATE_DRIFT: u64 = 1 << 0;
pub const CAP_DISCOVERY: u64 = 1 << 1;
pub const CAP_UDP_TRANSPORT: u64 = 1 << 2;
pub const CAP_VECTOR_384_F32: u64 = 1 << 3;
pub const CAP_VECTOR_QINT8: u64 = 1 << 4; 
pub const CAP_RELAY_FORWARD: u64 = 1 << 5; // Node can act as an opaque relay forwarder
pub const CAP_RELAY_SEND: u64 = 1 << 6;    // Node requires/supports relaying

pub type NodeId = [u8; 32]; // Fixed-size canonical node identity key

// =====================================================================
// TRANSPORT TRAIT SEPARATION & ERROR BOUNDS
// =====================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum BraidTransportError {
    Io(String),
    Serialization(String),
    BufferOverflow(String),
}

#[async_trait]
pub trait BraidTransport: Send + Sync {
    async fn send_to(&self, bytes: &[u8], target: SocketAddr) -> Result<(), BraidTransportError>;
    async fn recv_from(&self) -> Result<(Vec<u8>, SocketAddr), BraidTransportError>;
    fn local_endpoint(&self) -> SocketAddr;
    fn transport_kind(&self) -> String;
}

// =====================================================================
// PORTABLE IDENTITY PROVIDER TRAIT
// =====================================================================

pub trait IdentityProvider: Send + Sync {
    fn scheme_id(&self) -> u16;
    fn public_material(&self) -> Vec<u8>;
    fn node_id(&self) -> NodeId;
    fn sign(&self, message: &[u8]) -> Result<Vec<u8>, String>;
}

// =====================================================================
// WIRE PROTOCOL LAYOUT WITH DETERMINISTIC PACKED CODING
// =====================================================================

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidSigningBody {
    pub version: u16,
    pub message_type: u16,
    pub signature_scheme: u16,
    pub wire_encoding: u16,
    pub state_vector_encoding: u16,
    pub node_id: NodeId,          
    pub public_material: Vec<u8>, 
    pub session_id: [u8; 16],
    pub sequence: u64,
    pub timestamp: u64,
    pub payload: Vec<u8>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidEnvelope {
    pub version: u16,
    pub message_type: u16,
    pub signature_scheme: u16,
    pub wire_encoding: u16,
    pub state_vector_encoding: u16,
    pub node_id: NodeId,
    pub public_material: Vec<u8>,
    pub session_id: [u8; 16],
    pub sequence: u64,
    pub timestamp: u64,
    pub signature: Vec<u8>,       
    pub payload: Vec<u8>,
}

impl BraidSigningBody {
    /// Serialize to deterministic packed big-endian layout for cross-language validation (Pillar 1)
    pub fn serialize_canonical(&self) -> Vec<u8> {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&self.version.to_be_bytes());
        bytes.extend_from_slice(&self.message_type.to_be_bytes());
        bytes.extend_from_slice(&self.signature_scheme.to_be_bytes());
        bytes.extend_from_slice(&self.wire_encoding.to_be_bytes());
        bytes.extend_from_slice(&self.state_vector_encoding.to_be_bytes());
        bytes.extend_from_slice(&self.node_id);
        
        bytes.extend_from_slice(&(self.public_material.len() as u32).to_be_bytes());
        bytes.extend_from_slice(&self.public_material);
        
        bytes.extend_from_slice(&self.session_id);
        bytes.extend_from_slice(&self.sequence.to_be_bytes());
        bytes.extend_from_slice(&self.timestamp.to_be_bytes());
        
        bytes.extend_from_slice(&(self.payload.len() as u32).to_be_bytes());
        bytes.extend_from_slice(&self.payload);
        
        bytes
    }
}

impl BraidEnvelope {
    /// Create a deterministic signed envelope setting state_vector_encoding BEFORE signing
    pub fn create(
        message_type: u16,
        state_vector_encoding: u16,
        session_id: [u8; 16],
        sequence: u64,
        timestamp: u64,
        payload: Vec<u8>,
        provider: &dyn IdentityProvider,
    ) -> Result<Self, String> {
        let body = BraidSigningBody {
            version: WIRE_PROTOCOL_VERSION,
            message_type,
            signature_scheme: provider.scheme_id(),
            wire_encoding: ENCODING_CANONICAL_PACKED, // Deterministic preimage layout
            state_vector_encoding, 
            node_id: provider.node_id(),
            public_material: provider.public_material(),
            session_id,
            sequence,
            timestamp,
            payload,
        };

        let sig_data = body.serialize_canonical(); // Deterministic packed binary
        let signature = provider.sign(&sig_data)?;

        Ok(BraidEnvelope {
            version: body.version,
            message_type: body.message_type,
            signature_scheme: body.signature_scheme,
            wire_encoding: ENCODING_BINCODE, // Set canonically to BINCODE outer wire format
            state_vector_encoding: body.state_vector_encoding,
            node_id: body.node_id,
            public_material: body.public_material,
            session_id: body.session_id,
            sequence: body.sequence,
            timestamp: body.timestamp,
            signature,
            payload: body.payload,
        })
    }

    /// Verify signature on the envelope using deterministic packing verification
    pub fn verify_signature(&self) -> bool {
        let derived_id = crate::identity::derive_node_id(self.signature_scheme, &self.public_material);
        if self.node_id != derived_id {
            eprintln!("[DROP] Derived Node ID does not match declared node_id!");
            return false;
        }

        if self.signature_scheme == SCHEME_ED25519 {
            let verifying_key_bytes: Result<[u8; 32], _> = self.public_material.clone().try_into();
            let signature_bytes: Result<[u8; 64], _> = self.signature.clone().try_into();

            match (verifying_key_bytes, signature_bytes) {
                (Ok(key_arr), Ok(sig_arr)) => {
                    let verifying_key_res = VerifyingKey::from_bytes(&key_arr);
                    let signature = Signature::from_bytes(&sig_arr);

                    match verifying_key_res {
                        Ok(pubkey) => {
                            let body = BraidSigningBody {
                                version: self.version,
                                message_type: self.message_type,
                                signature_scheme: self.signature_scheme,
                                wire_encoding: ENCODING_CANONICAL_PACKED, 
                                state_vector_encoding: self.state_vector_encoding,
                                node_id: self.node_id,
                                public_material: self.public_material.clone(),
                                session_id: self.session_id,
                                sequence: self.sequence,
                                timestamp: self.timestamp,
                                payload: self.payload.clone(),
                            };
                            
                            let canonical_data = body.serialize_canonical(); // Pack deterministically
                            use ed25519_dalek::Verifier;
                            pubkey.verify(&canonical_data, &signature).is_ok()
                        }
                        _ => false,
                    }
                }
                _ => false,
            }
        } else {
            false
        }
    }

    /// Validate basic envelope properties: size limit, clock skew, and protocol version
    pub fn validate_envelope(&self, current_time_ms: u64, packet_size: usize) -> Result<(), String> {
        if packet_size > MAX_PACKET_SIZE {
            return Err(format!("Packet exceeds size limit: {} > {} bytes", packet_size, MAX_PACKET_SIZE));
        }

        if self.version != WIRE_PROTOCOL_VERSION {
            return Err(format!("Unsupported protocol version: {}", self.version));
        }

        // Check clock skew tolerance (±60 seconds)
        let drift = (current_time_ms as i128 - self.timestamp as i128).abs();
        let max_drift = (MAX_TIMESTAMP_DRIFT_SECS * 1000) as i128;
        if drift > max_drift {
            return Err(format!("Timestamp skew exceeded: {} ms (max allowed: {} ms)", drift, max_drift));
        }

        Ok(())
    }
}

// =====================================================================
// STATE DRIFT LAYOUTS
// =====================================================================

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidStateDrift {
    pub latent_vector: Vec<f32>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidStateDriftQuant {
    pub scale: f32,
    pub zero_point: i8,
    pub values: Vec<i8>, 
}

impl BraidStateDriftQuant {
    pub fn quantize(vector: &[f32]) -> Self {
        let mut min_val = f32::MAX;
        let mut max_val = f32::MIN;
        for &val in vector {
            if val < min_val { min_val = val; }
            if val > max_val { max_val = val; }
        }

        let range = max_val - min_val;
        let scale = if range.abs() < 1e-6 { 1.0 / 255.0 } else { range / 255.0 };
        let zero_point = (-128.0 - (min_val / scale)).clamp(-128.0, 127.0) as i8;

        let values = vector.iter().map(|&x| {
            let q = (x / scale).round() + zero_point as f32;
            q.clamp(-128.0, 127.0) as i8
        }).collect::<Vec<i8>>();

        Self { scale, zero_point, values }
    }

    pub fn dequantize(&self) -> Vec<f32> {
        self.values.iter().map(|&q| {
            (q as f32 - self.zero_point as f32) * self.scale
        }).collect::<Vec<f32>>()
    }
}

// =====================================================================
// SYSTEM-LEVEL PACKET CEILING TESTING
// =====================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use rand::rngs::OsRng;
    use ed25519_dalek::SigningKey;
    use crate::identity::Ed25519LocalIdentityProvider;

    #[test]
    fn signed_384_f32_state_drift_envelope_stays_under_udp_ceiling() {
        let mut csprng = OsRng;
        let signing_key = SigningKey::generate(&mut csprng);
        let provider = Ed25519LocalIdentityProvider::new(signing_key);

        let vector = vec![1.2345f32; EXPECTED_VECTOR_DIM];
        let drift = BraidStateDrift { latent_vector: vector };
        let payload = bincode::serialize(&drift).unwrap();

        let envelope = BraidEnvelope::create(
            MSG_STATE_DRIFT,
            VECTOR_ENCODING_RAW_F32,
            [255u8; 16],
            999_999u64,
            1_719_876_543_210u64,
            payload,
            &provider,
        ).unwrap();

        let serialized = bincode::serialize(&envelope).unwrap();
        println!("Worst-case signed state drift envelope size: {} bytes", serialized.len());
        
        assert!(
            serialized.len() < MAX_PACKET_SIZE,
            "Serialized packet size {} exceeds maximum MTU ceiling {}",
            serialized.len(),
            MAX_PACKET_SIZE
        );
    }

    #[test]
    fn test_8bit_quantization_codec() {
        let vector = vec![2.345f32, -4.567f32, 0.0f32, 9.876f32];
        let quant = BraidStateDriftQuant::quantize(&vector);
        let dequant = quant.dequantize();
        
        for i in 0..vector.len() {
            let error = (vector[i] - dequant[i]).abs();
            assert!(error < 0.15, "Quantization error at index {} exceeds calibration bounds: {} vs {}", i, vector[i], dequant[i]);
        }
    }
}
