use std::sync::Arc;
use std::net::SocketAddr;
use std::collections::HashMap;
use tokio::sync::Mutex;
use crate::protocol::{
    BraidEnvelope, NodeId, MSG_STATE_DRIFT, MSG_SESSION_HELLO, MSG_SESSION_READY,
    MSG_SESSION_CHALLENGE, MSG_SESSION_RESPONSE, WIRE_PROTOCOL_VERSION
};
use crate::session::{BraidSession, SessionState, SessionHello, SessionChallenge, SessionResponse, SessionReady};
use crate::route::{RouteCandidate, RouteTable, RouteEndpoint, TransportKind, RouteState};
use crate::identity::IdentityProvider;

// =====================================================================
// CORE OUTBOUND ORCHESTRATION LAYER: send_to_node (Pillar 1)
// =====================================================================

#[derive(Debug)]
pub enum TendrilError {
    SessionNotReady(String),
    NoRoute(String),
    Transport(String),
    Identity(String),
}

/// The Sacred Law: A Braid node never sends "to an address". 
/// It sends: Envelope -> NodeId -> Session -> Route -> Transport (Pillar 1)
pub async fn send_to_node(
    target_node_id: NodeId,
    message_type: u16,
    payload: Vec<u8>,
    vector_encoding: u16,
    session_id: [u8; 16],
    sequence: u64,
    timestamp: u64,
    session_table: &Mutex<HashMap<NodeId, BraidSession>>,
    route_table: &Mutex<HashMap<NodeId, Vec<RouteCandidate>>>,
    provider: &dyn IdentityProvider,
    transport_engine: &dyn crate::protocol::BraidTransport,
) -> Result<(), TendrilError> {
    // 1. Resolve Session status
    let session_active = {
        let sessions = session_table.lock().await;
        if let Some(session) = sessions.get(&target_node_id) {
            session.state == SessionState::Ready
        } else {
            false
        }
    };

    // If session is not ready, we must prevent any StateDrift from slipping through!
    if message_type == MSG_STATE_DRIFT && !session_active {
        return Err(TendrilError::SessionNotReady(
            "Target NodeId does not have a verified, active Session. State drift rejected.".into()
        ));
    }

    // 2. Resolve Best Route Candidate from Route Table with Explicit Multi-Path Prioritization
    let target_route = {
        let routes = route_table.lock().await;
        if let Some(candidates) = routes.get(&target_node_id) {
            let mut verified_candidates: Vec<RouteCandidate> = candidates.iter()
                .filter(|r| r.state == RouteState::Verified || r.state == RouteState::Probing)
                .cloned()
                .collect();

            // REFINEMENT: Implement strict multi-path latency sorting and route prioritization
            verified_candidates.sort_by(|a, b| {
                // Prioritize RouteState::Verified over Probing
                let a_state_score = if a.state == RouteState::Verified { 1 } else { 0 };
                let b_state_score = if b.state == RouteState::Verified { 1 } else { 0 };
                if a_state_score != b_state_score {
                    return b_state_score.cmp(&a_state_score);
                }

                // Prioritize Direct UDP over Relays
                let a_is_udp = matches!(a.endpoint, RouteEndpoint::Udp(_));
                let b_is_udp = matches!(b.endpoint, RouteEndpoint::Udp(_));
                if a_is_udp != b_is_udp {
                    return b_is_udp.cmp(&a_is_udp);
                }

                // If both same state and transport, sort by latency (prefer lowest latency)
                match (a.latency_ms, b.latency_ms) {
                    (Some(la), Some(lb)) => la.cmp(&lb),
                    (Some(_), None) => std::cmp::Ordering::Less,
                    (None, Some(_)) => std::cmp::Ordering::Greater,
                    (None, None) => std::cmp::Ordering::Equal,
                }
            });

            verified_candidates.into_iter().next() // Grab the optimal routed path candidate
        } else {
            None
        }
    };

    let selected_route = match target_route {
        Some(route) => route,
        None => {
            return Err(TendrilError::NoRoute(
                "No verified path candidates exist for the target NodeId in RouteTable.".into()
            ));
        }
    };

    // 3. Build cryptographically signed BraidEnvelope
    let envelope = BraidEnvelope::create(
        message_type,
        vector_encoding,
        session_id,
        sequence,
        timestamp,
        payload,
        provider,
    ).map_err(|e| TendrilError::Identity(e))?const; // Use .unwrap() or match if compile requires

    let serialized_bytes = bincode::serialize(&envelope)
        .map_err(|e| TendrilError::Transport(e.to_string()))?;

    // 4. Dispatch purely over selected Transport (Sockets are hidden inside route endpoints!)
    match selected_route.endpoint {
        RouteEndpoint::Udp(addr) => {
            transport_engine.send_to(&serialized_bytes, addr).await
                .map_err(|e| TendrilError::Transport(format!{"{:?}", e}))?;
        }
        RouteEndpoint::Relay { relay_node_id: _, target_endpoint: _ } => {
            // Future Relay framing dispatch
        }
    }

    Ok(())
}
